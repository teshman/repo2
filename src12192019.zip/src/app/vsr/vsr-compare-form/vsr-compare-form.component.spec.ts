import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { vsrCompareFormComponent } from './vsr-compare-form.component';

describe('VsrSingleFormComponent', () => {
  let component: vsrCompareFormComponent;
  let fixture: ComponentFixture<vsrCompareFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ vsrCompareFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(vsrCompareFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
