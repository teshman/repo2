import { Component, OnInit, Input } from '@angular/core';
import { VsrRecordEntity, Vsr, Address, Address2, DOLSummary } from 'src/app/shared/vsr';
import { AppSettings } from '../../shared/app-settings';
@Component({
  selector: 'vsr-compare-form',
  templateUrl: './vsr-compare-form.component.html',
  styleUrls: ['./vsr-compare-form.component.css']
})


export class vsrCompareFormComponent implements OnInit {
  //private vsrUrl = '/vibe-plus/rest/vsr/receipt/';

  @Input() vsrSelected: VsrRecordEntity[] = [];
  @Input() vsrRecords: VsrRecordEntity[];
  adjudicativeStatusStyle: string = "success-standard";
  adjudicativeStatusStyle2: string = "success-standard";
  appsAlert;
  branchInfoAvailable: boolean = false;
  dolInformationAvailable: boolean = false;
  displayManualAddress: boolean = false;
  displayDOLCaseNumber: boolean = false;
  relatedToPetitioner1: string = "";
  relatedToPetitioner2: string = "";
  hasGrossAnualIncome: boolean = false;
  grossAnualIncome: string;
  grossAnualIncome2: string;
  outOfBusinessIndicator: boolean;
  outOfBusinessIndicator2: boolean;
  preDefinedScoreAvailable: boolean;
  Record1Exec1: string = "empty";
  Record2Exec1: string = "empty";
  resubmitShowModal: boolean = false;
  scoreCardID1: string;
  scoreCardID2: string;
  showPrevFilingsCount1: boolean = false;
  showPrevFilingsCount2: boolean = false;
  showForm = false;
  
  formType1:string = "";
  formType2:string = "";
  tradeStyle1: string = "";
  tradeStyle2: string = "";
  tradeStyle3: string = "";
  ValidEndDate: string = "Valid End Date:"
  ValidStartDate: string = "Valid Start Date:"
  vibePreDefinedCompanyScore: string = "";
  VIBEScoreResult_Score: string = "";
  VIBEScoreResult_Score2: string = "";
  vsrRecord1: VsrRecordEntity
  vsrRecord1Index: string = "";
  vsrRecord2: VsrRecordEntity;
  vsrRecord2Index: string = "";


  selectedDol1: DOLSummary;
  multipleDolEta1: string[] = [];
  selectedDol2: DOLSummary;
  selectedDolRow: DolSummaryView;
  multipleDolEta2: string[] = [];
  multipleDolSummary1: DOLSummary[] = [];
  multipleDolSummary2: DOLSummary[] = [];
  dolSummaryList: DolSummaryView[] = [];
  selectedEtaNumber: string = "";
  etaCaseNumbeLength: number = 15;

  petitioner1CompanyAddress: string = "";
  manualSearch1Address: string = "";
  DNBMatchedBranch1Address: string = "";
  DNBMatchedCompany1Address: string = "";
  static readonly addrDelimeter = "!!!";
  static readonly addrDelimeter3 = "!!!!!!!!!";
  petitioner2CompanyAddress: string = "";
  manualSearch2Address: string = "";
  DNBMatchedBranch2Address: string = "";
  DNBMatchedCompany2Address: string = "";
  model = {
    receiptNumber: "", //"WAC1802550980" //WAC1419550371 - no DOL,
    lat: 38.8977643,
    long: -77.0106754,
    streetView: '',
    fullMap: ''
  }

  constructor() {
  }

  ngOnInit() {
    this.refresh();
  }

  refresh(): void {
    //  console.log("refesh has started");    
    this.InitBooleans();

    if (this.vsrSelected && this.vsrSelected.length == 2) {
      this.showForm = true;
      this.appsAlert = "";
      this.scoreCardID1 = this.vsrSelected[0].ScoreID;
      this.scoreCardID2 = this.vsrSelected[1].ScoreID;

      this.vsrRecord1 = this.vsrSelected[0];
      this.vsrRecord2 = this.vsrSelected[1];

      this.vsrRecord1Index = "VSR " + (this.vsrRecords.indexOf(this.vsrRecord1) + 1);
      this.vsrRecord2Index = "VSR " + (this.vsrRecords.indexOf(this.vsrRecord2) + 1);
      //  console.log("vsrrecord1Index is: " + this.vsrRecord1Index);

      this.outOfBusinessIndicator = this.vsrRecord1.DNBDetailedCompanyInformation.OutOfBusinessIndicator;
      this.outOfBusinessIndicator2 = this.vsrRecord2.DNBDetailedCompanyInformation.OutOfBusinessIndicator;
      this.adjudicativeStatusStyle = this.getAdjudicativeStatusStyle(this.vsrRecord1.AdjudicativeStatus);
      this.adjudicativeStatusStyle2 = this.getAdjudicativeStatusStyle(this.vsrRecord2.AdjudicativeStatus);

      this.formType1 = (this.vsrRecord1.PetitionInformation.PetitionType == null) ? "" : this.vsrRecord1.PetitionInformation.PetitionType;      
      this.formType2 = (this.vsrRecord2.PetitionInformation.PetitionType == null) ? "" : this.vsrRecord2.PetitionInformation.PetitionType;
      if (this.vsrRecord1.VIBEScoreResult && this.vsrRecord2.VIBEScoreResult) {
        this.VIBEScoreResult_Score = this.vsrRecord1.VIBEScoreResult.Score;
        this.VIBEScoreResult_Score2 = this.vsrRecord2.VIBEScoreResult.Score;
        let cf: number = parseInt(this.vsrRecord1.VIBEScoreResult.ConfidenceFactor);
        if (cf > 6)
          this.showPrevFilingsCount1 = true;
        else
          this.showPrevFilingsCount1 = false;

        let cf2: number = parseInt(this.vsrRecord2.VIBEScoreResult.ConfidenceFactor);
        if (cf > 6)
          this.showPrevFilingsCount2 = true;
        else
          this.showPrevFilingsCount2 = false;
      }


      // console.log("before bindbusinessrule");
      this.bindBusinessRules();

      // console.log("after bindbusinessrule");

    }
    else {
      this.appsAlert = "No records found matching this receipt number.";
    }

  }


  setSelectedRecord(event, record) {
    // let ind = this.dolSummaryList.indexOf(record);
    this.selectedDolRow = this.dolSummaryList[record];
  }
  
  private bindBusinessRules() {
    let receiptFromDate = new Date(AppSettings.DOL_DISPLAY_RECEIPT_FROM_DATE);
    let receiptDate1 = new Date(this.vsrRecord1.PetitionInformation.ReceiptDate.substr(0, 10));
    let receiptDate2 = new Date(this.vsrRecord2.PetitionInformation.ReceiptDate.substr(0, 10));

    try {
      this.setupAddreses();
    } catch (error) {
      console.log("error, inside setupAddreses: " + JSON.stringify(error));
    }

    // console.log("before checkForPredefinedInfo");   
    try {
      this.checkForPredefinedInfo();
    } catch (error) {
      console.log("error, inside checkForPredefinedInfo: " + JSON.stringify(error));

    }

    // console.log("before checkForDNBCompanyFinancialInformation");
    try {
      this.checkForDNBCompanyFinancialInformation();
    } catch (error) {
      console.log("error, inside checkForDNBCompanyFinancialInformation: " + JSON.stringify(error));
    }

    // console.log("before checkFordolInformationAvailable");
    try {
      this.checkFordolInformationAvailable();
    } catch (error) {
      console.log("error, inside checkFordolInformationAvailable();: " + JSON.stringify(error));
    }

    // console.log("before setDisplayManualAddress");
    try {
      this.setDisplayManualAddress();
    } catch (error) {
      console.log("error, inside : setDisplayManualAddress" + JSON.stringify(error));
    }

    // console.log("before checkForBranchInfoAvailable");  
    try {
      this.checkForBranchInfoAvailable();
    } catch (error) {
      console.log("error, inside checkForBranchInfoAvailable: " + JSON.stringify(error));
    }

    // console.log("before checkForExec1Available");
    try {
      this.checkForExec1Available();
    } catch (error) {
      console.log("error, inside checkForExec1Available: " + JSON.stringify(error));
    }

    // console.log("before setDisplayDOLCaseNumber");
    try {
      this.setDisplayDOLCaseNumber(this.vsrRecord1, receiptDate1, receiptFromDate);
    } catch (error) {
      console.log("error, inside setDisplayDOLCaseNumber: " + JSON.stringify(error));
    }
   
  }
  private setupAddreses() {

    this.DNBMatchedBranch1Address = "";
    this.DNBMatchedCompany1Address = "";
    this.DNBMatchedBranch2Address = "";
    this.DNBMatchedCompany2Address = "";


    this.petitioner1CompanyAddress = "";
    this.petitioner2CompanyAddress = "";
    this.manualSearch1Address = "";
    this.manualSearch2Address = "";
    this.setupPetitionerAddress();


  }

  private formatAddressWithComma(address: string): string {
    if (address === vsrCompareFormComponent.addrDelimeter3) {
      return "";
    }
    else {
      var delimeter = /!!!/gi;
      return address.replace(delimeter, ", ");
    }
  }

  private setDisplayDOLCaseNumber(vsrRcord: VsrRecordEntity, receiptDate1: Date, receiptFromDate: Date) {
    if (vsrRcord.PetitionInformation.DolEtaCaseNumber) {
      if ((this.vsrRecord1.PetitionInformation.PetitionVisaType === "1B1" ||
        vsrRcord.PetitionInformation.PetitionVisaType === "E3" ||
        vsrRcord.PetitionInformation.PetitionVisaType === "HSC" ||
        vsrRcord.PetitionInformation.PetitionVisaType === "H2A" ||
        vsrRcord.PetitionInformation.PetitionVisaType === "H2B") &&
        (receiptDate1 >= receiptFromDate)
        &&
        (vsrRcord.DOLSummary))
        this.displayDOLCaseNumber = true;
      // console.log("setDisplayDOLCaseNumber is : " + this.displayDOLCaseNumber);
    }
  }


  private checkForExec1Available() {
    if (this.vsrRecord1.DNBCompanyExecutiveBio.Executive1 !== null)
      this.Record1Exec1 = this.vsrRecord1.DNBCompanyExecutiveBio.Executive1;
    if (this.vsrRecord2.DNBCompanyExecutiveBio.Executive1 !== null)
      this.Record2Exec1 = this.vsrRecord2.DNBCompanyExecutiveBio.Executive1;
  }

  private checkForBranchInfoAvailable() {
    if (this.vsrRecord1.DNBMatchedBranchInformation ||
      this.vsrRecord2.DNBMatchedBranchInformation)
      this.branchInfoAvailable = true;
    this.setDNBMatchedBranchAddress();

    this.setDNBMatchedCompanyAddress();

  }

  private setupPetitionerAddress() {
    this.petitioner1CompanyAddress = this.getPetionerFormattedAddress(this.vsrRecord1.PetitionInformation.Address);    
    this.petitioner1CompanyAddress = this.removelastCommaCharacter(this.petitioner1CompanyAddress.trim());
    this.petitioner2CompanyAddress = this.getPetionerFormattedAddress(this.vsrRecord2.PetitionInformation.Address);    
    this.petitioner2CompanyAddress = this.removelastCommaCharacter(this.petitioner2CompanyAddress.trim());
  }

  private getFormattedAddress(vsrAddress: Address2): string {
    if (vsrAddress) {
      let compareAddress1: string = vsrAddress.StreetFullText + vsrCompareFormComponent.addrDelimeter +
        vsrAddress.LocationCityName + vsrCompareFormComponent.addrDelimeter +
        vsrAddress.LocationStateName + vsrCompareFormComponent.addrDelimeter +
        vsrAddress.LocationPostalCode + ", " +
        vsrAddress.LocationCountryName;
      return this.formatAddressWithComma(compareAddress1).replace(", null", "").replace("null,", "").replace("null","");
    }
    else
      return "";
  }
  private getPetionerFormattedAddress(vsrAddress: Address): string {
    if (vsrAddress) {
      let compareAddress1: string = vsrAddress.StreetFullText + vsrCompareFormComponent.addrDelimeter +
        vsrAddress.LocationCityName + vsrCompareFormComponent.addrDelimeter +
        vsrAddress.LocationStateName + vsrCompareFormComponent.addrDelimeter +
        vsrAddress.LocationPostalCode + ", " +
        vsrAddress.LocationCountryName;
      return this.formatAddressWithComma(compareAddress1).replace(", null", "").replace("null,", "").replace("null","");
    }
    else
      return "";
  }
  private setDNBMatchedCompanyAddress() {
    
    let regex = /null/gi;
    if (this.vsrRecord1.DNBMatchedCompanyInformation) {
      this.DNBMatchedCompany1Address = this.getFormattedAddress(this.vsrRecord1.DNBMatchedCompanyInformation.Address).replace(", null", "").replace("null,", "").replace("null","");
      
      this.DNBMatchedCompany1Address = this.removelastCommaCharacter(this.DNBMatchedCompany1Address.trim());
    }
    if (this.vsrRecord2.DNBMatchedCompanyInformation) {
      this.DNBMatchedCompany2Address = this.getFormattedAddress(this.vsrRecord2.DNBMatchedCompanyInformation.Address).replace(", null, null", "");      
      this.DNBMatchedCompany2Address = this.removelastCommaCharacter(this.DNBMatchedCompany2Address.trim());
    }
  }

  
  private removelastCommaCharacter(str: string): string {
    if (str !== null && str.length > 0 && str.charAt(str.length - 1) == ',') {
      str = str.substring(0, str.length - 1);
    }
    return str;
  }

  private setDNBMatchedBranchAddress() {
    if (this.vsrRecord1.DNBMatchedBranchInformation) {

      this.DNBMatchedBranch1Address = this.getFormattedAddress(this.vsrRecord1.DNBMatchedBranchInformation.Address);
      this.DNBMatchedBranch1Address = this.removelastCommaCharacter(this.DNBMatchedBranch1Address.trim());
    }
    if (this.vsrRecord2.DNBMatchedBranchInformation) {

      this.DNBMatchedBranch2Address = this.getFormattedAddress(this.vsrRecord2.DNBMatchedBranchInformation.Address);
      this.DNBMatchedBranch2Address = this.removelastCommaCharacter(this.DNBMatchedBranch2Address.trim());
    }
  }

  private setDisplayManualAddress() {
    if (this.vsrRecord1.PetitionInformation.OrganizationDataSource === "Manual") {
      this.displayManualAddress = true;
      this.manualSearch1Address = this.getFormattedAddress(this.vsrRecord1.ManualSearchInfo.Address).replace(", null", "").replace("null,", "").replace("null","");    
      this.manualSearch1Address = this.removelastCommaCharacter(this.manualSearch1Address.trim());
      if (this.vsrRecord1.ManualSearchInfo.RelatedToPetitioner === true)
        this.relatedToPetitioner1 = "Y";
      else
        this.relatedToPetitioner1 = "N";
    }


    if (this.vsrRecord2.PetitionInformation.OrganizationDataSource === "Manual") {
      this.displayManualAddress = true;
      this.manualSearch2Address = this.getFormattedAddress(this.vsrRecord2.ManualSearchInfo.Address).replace(", null", "").replace("null,", "").replace("null","");   
      this.manualSearch2Address = this.removelastCommaCharacter(this.manualSearch2Address.trim());
      if (this.vsrRecord2.ManualSearchInfo.RelatedToPetitioner === true)
        this.relatedToPetitioner2 = "Y";
      else
        this.relatedToPetitioner2 = "N";
    }
  }

  private checkFordolInformationAvailable() {
    let vsr1 = this.vsrRecord1;
    let vsr2 = this.vsrRecord2;
    vsr1.PetitionInformation.DolEtaCaseNumber = vsr1.PetitionInformation.DolEtaCaseNumber ? vsr1.PetitionInformation.DolEtaCaseNumber.replace('NA', 'N/A') : '';
    vsr2.PetitionInformation.DolEtaCaseNumber = vsr2.PetitionInformation.DolEtaCaseNumber ? vsr2.PetitionInformation.DolEtaCaseNumber.replace('NA', 'N/A') : '';

    this.multipleDolEta1 = vsr1.PetitionInformation.DolEtaCaseNumber ? vsr1.PetitionInformation.DolEtaCaseNumber.split(',') : [];
    this.multipleDolEta2 = vsr2.PetitionInformation.DolEtaCaseNumber ? vsr2.PetitionInformation.DolEtaCaseNumber.split(',') : [];

   
    // console.log("multipleDolEta is: " + this.multipleDolEta2.length +  "   " + this.multipleDolEta2);
    // console.log("multipleDolEta1 is: " + this.multipleDolEta1.length +  "   " + this.multipleDolEta1);

    if (vsr1.DOLSummary || vsr2.DOLSummary) {

      let multipleDolEta: string[] = [];
      for (let i = 0; i < this.multipleDolEta1.length; i++) {
if(vsr1.DOLSummary[i].EtaCaseNumber == 'N/A'  )
multipleDolEta.push(vsr1.DOLSummary[i].EtaCaseNumber);
else
        multipleDolEta.push(this.multipleDolEta1[i].trim());
      }
      for (let j = 0; j < this.multipleDolEta2.length - 1; j++) {
        let ind = multipleDolEta.indexOf(this.multipleDolEta2[j].trim());
        //  console.log("inside dol inof the index is: " + ind);
        if (ind<0){
          if(vsr2.DOLSummary[j].EtaCaseNumber == 'N/A'  )
          multipleDolEta.push(vsr2.DOLSummary[j].EtaCaseNumber);
          else
          multipleDolEta.push(this.multipleDolEta2[j]);
          console.log("new record pushed. " + this.multipleDolEta2[j]);
     } 

    }
    
      
      // let k: number = 0;
      for (let caseNum of multipleDolEta) {

        let Dol1: DOLSummary;
        let Dol2: DOLSummary;
        
        let petition1 ;
        let petition2;
        let dolSummaryView = new DolSummaryView({ caseNumber: caseNum, selectedDol1: Dol1, selectedDol2: Dol2, rowColor: {} });
        if (vsr1.DOLSummary && vsr1 !== undefined) {
          for (let dol1 of vsr1.DOLSummary) {
            console.log("dol1.EtaCaseNumber: " + dol1.EtaCaseNumber);
            console.log("caseNum: " + caseNum);
            if (dol1.EtaCaseNumber.trim() == caseNum.trim()) {
              dolSummaryView.selectedDol1 = dol1;
              petition1 = dol1.PetitionID;
            }
          }
        }

        if (vsr2.DOLSummary && vsr2 !== undefined) {
          for (let dol2 of vsr2.DOLSummary) {
            if (dol2.EtaCaseNumber.trim() == caseNum.trim()) {   
              dolSummaryView.selectedDol2 = dol2
              petition2 = dol2.PetitionID;
            }
          }
        }
        
      if(dolSummaryView.selectedDol1 !== undefined) dolSummaryView.selectedDol1.PetitionID ="";
       if(dolSummaryView.selectedDol2 !==  undefined) dolSummaryView.selectedDol2.PetitionID ="";
       if(dolSummaryView.selectedDol1 !== undefined &&  dolSummaryView.selectedDol2 !==  undefined)
       {
          if(JSON.stringify(dolSummaryView.selectedDol1).toLowerCase() === JSON.stringify(dolSummaryView.selectedDol2).toLowerCase())
        dolSummaryView.rowColor =   {};
        else
        dolSummaryView.rowColor =   { color: 'blue', 'background-color': 'turquoise', 'font-weight': 'bold' };
        dolSummaryView.selectedDol1.PetitionID=petition1;
        dolSummaryView.selectedDol2.PetitionID=petition2;
      }
        
        else if(dolSummaryView.selectedDol1 == undefined ||  dolSummaryView.selectedDol2 ==  undefined)
        dolSummaryView.rowColor =   { color: 'blue', 'background-color': 'turquoise', 'font-weight': 'bold' };
        console.log("The dolSummanryView is: " + JSON.stringify(dolSummaryView));
      
        this.dolSummaryList.push(dolSummaryView);

      }

      

      console.log("The dolSummaryList is: " + JSON.stringify(this.dolSummaryList[0]));
      this.dolSummaryList = this.dolSummaryList.sort((b, a) => a.caseNumber.localeCompare(b.caseNumber))
      this.selectedDolRow = this.dolSummaryList[0];
      console.log("the selewcted row is: " + JSON.stringify(this.selectedDolRow));
      if(this.selectedDolRow.selectedDol1 !== undefined) { 
        console.log("we are here.");
        this.selectedDol1 = this.selectedDolRow.selectedDol1;
        if (this.multipleDolEta1.length > 0 || this.multipleDolEta2.length > 0)
        this.selectedEtaNumber = this.selectedDol1.EtaCaseNumber
        else
        this.selectedEtaNumber = vsr1.PetitionInformation.DolEtaCaseNumber
        
      }

       if(this.selectedDolRow.selectedDol2 !==  undefined) {
        console.log("or we are here.");
         this.selectedDol2 = this.selectedDolRow.selectedDol2;
         if (this.multipleDolEta1.length > 0 || this.multipleDolEta2.length > 0)
        this.selectedEtaNumber = this.selectedDol2.EtaCaseNumber
        else
        this.selectedEtaNumber = vsr2.PetitionInformation.DolEtaCaseNumber        
        }
     
      
      console.log("the dol summary list count is: " + this.dolSummaryList.length);
      if (this.selectedEtaNumber && this.selectedEtaNumber.includes("-"))
        this.etaCaseNumbeLength = 18;


      if ((vsr1.PetitionInformation.PetitionVisaType === "1B1" ||
        vsr1.PetitionInformation.PetitionVisaType === "E3" ||
        vsr1.PetitionInformation.PetitionVisaType === "HSC")
        ||
        (vsr2.PetitionInformation.PetitionVisaType === "1B1" ||
          vsr2.PetitionInformation.PetitionVisaType === "E3" ||
          vsr2.PetitionInformation.PetitionVisaType === "HSC")
      ) {
        this.ValidStartDate = "Intended Employment Begin Date";
        this.ValidEndDate = "Intended Employment End Date";
      }

      if (this.selectedEtaNumber && this.selectedEtaNumber.length > 0) {
        //console.log("the selectedDolRow case number is is: " + this.selectedDolRow.caseNumber);
        this.dolInformationAvailable = true;
      }

    }
    else
      this.dolInformationAvailable = false;
  }

  private checkForDNBCompanyFinancialInformation() {
    if (this.vsrRecord1.DNBCompanyFinancialInformation && this.vsrRecord1.DNBCompanyFinancialInformation.GrossAnualIncome) {
      this.hasGrossAnualIncome = true;
      let strGrossAnualIncome = this.vsrRecord1.DNBCompanyFinancialInformation.GrossAnualIncome;
      this.grossAnualIncome =
        parseInt(strGrossAnualIncome.substr(0, strGrossAnualIncome.indexOf('|')).trim(), 10).toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1,")
        + " " + (strGrossAnualIncome.substr(strGrossAnualIncome.indexOf('|') + 1)).trim();
      this.grossAnualIncome = this.grossAnualIncome.replace(".00", "");
    }
    else
      this.hasGrossAnualIncome = false;

    if (this.vsrRecord2.DNBCompanyFinancialInformation && this.vsrRecord2.DNBCompanyFinancialInformation.GrossAnualIncome) {
      this.hasGrossAnualIncome = true;
      let strGrossAnualIncome2 = this.vsrRecord2.DNBCompanyFinancialInformation.GrossAnualIncome;
      this.grossAnualIncome2 =
        parseInt(strGrossAnualIncome2.substr(0, strGrossAnualIncome2.indexOf('|')).trim(), 10).toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1,")
        + " " + (strGrossAnualIncome2.substr(strGrossAnualIncome2.indexOf('|') + 1)).trim();
      this.grossAnualIncome2 = this.grossAnualIncome2.replace(".00", "");
      // console.log("gross anual income" + this.grossAnualIncome);
    }
    else
      this.hasGrossAnualIncome = false;
  }

  private checkForPredefinedInfo() {
    if (this.vsrRecord1.VibePreDefinedCompanyScore) {
      this.preDefinedScoreAvailable = true;
      this.vibePreDefinedCompanyScore = this.vsrRecord1.VibePreDefinedCompanyScore.OverrideScore;
    }
    else if (this.vsrRecord2.VibePreDefinedCompanyScore) {
      this.preDefinedScoreAvailable = true;
      this.vibePreDefinedCompanyScore = this.vsrRecord2.VibePreDefinedCompanyScore.OverrideScore;
    }
    else
      this.preDefinedScoreAvailable = false;
  }

  private InitBooleans() {
    this.branchInfoAvailable = false;
    this.displayManualAddress = false;
    this.dolInformationAvailable = false;
    this.hasGrossAnualIncome = false;
    this.outOfBusinessIndicator = false;
    this.preDefinedScoreAvailable = false;
    this.resubmitShowModal = false;
  }

  private getCompareFieldsStyle(fieldName: string): any {
    let retVal: any;
    if (fieldName !== '') {
      let parameters: any[] = [];
      parameters = fieldName.split('.');
      let childNodes: number = 0;
      if (fieldName.includes('.'))
        childNodes = parameters.length;

      else {
        childNodes = 1;
      }

      try {
        switch (childNodes) {
          case 1:
            return this.processFirstChildNodes(parameters, retVal);
          case 2:
            return this.process2ndChildNodes(parameters, fieldName, retVal);
          case 3:
            return this.process3rdChildNodes(fieldName, retVal, childNodes, parameters);
          default: {
            return {};
          }
        }
      } catch (error) {
        return {};
      }
    }
  }

  private compareDoLSummary(fieldName: string): any {
    let param1: string = "";
    let param2: string = "";

    this.selectedDol1 = this.selectedDolRow.selectedDol1;
    this.selectedDol2 = this.selectedDolRow.selectedDol2;
    if (this.selectedDol1) param1 = this.selectedDol1[fieldName];
    if (this.selectedDol2) param2 = this.selectedDol2[fieldName];
    if (param1 !==null && param1 !== undefined
      && param2 !==null && param2 !== undefined) {
      if (fieldName === "Fein" || fieldName === "TotalWorkerPositions" || fieldName === "PreviousEtaFilings") {
        if (param1 !== param2) {
          console.log("fein1, and fein2 : " + param1 + ", " + param2);
          return { color: 'blue', 'background-color': 'turquoise', 'font-weight': 'bold' };
        }
      }
      else if (param1.toUpperCase() !== param2.toUpperCase()) {
        return { color: 'blue', 'background-color': 'turquoise', 'font-weight': 'bold' };
      }
    }
    else if (((param1 == null || param1 == undefined || param1 == "") && param2 && param2 !== undefined && param2 !== "") ||
      (param1 && param1 !== null && param1 !== undefined && (param2 == null || param2 == undefined || param2 == ""))) {
      {
        if (param1 == null && param2 == null)
          return { color: 'red', 'background-color': 'turquoise', 'font-weight': 'bold' };
        else
          return { color: 'blue', 'background-color': 'turquoise', 'font-weight': 'bold' };
      }
    }
    else return {};
  }
  
  private processFirstChildNodes(parameters: any[], retVal: any) {
    let param1: string = "";
    let param2: string = "";
    if (this.vsrRecord1[parameters[0]])
      param1 = this.vsrRecord1[parameters[0]];
    if (this.vsrRecord2[parameters[0]])
      param2 = this.vsrRecord2[parameters[0]];
    if (param1 !== "" && param2 !== "") {
      if (param1.toUpperCase() !== param2.toUpperCase())
        retVal = { color: 'blue', 'background-color': 'turquoise', 'font-weight': 'bold' };
    }
    else if ((param1 == "" && param2 !== "") || (param1 !== "" && param2 == "")) {
      retVal = { color: 'blue', 'background-color': 'turquoise', 'font-weight': 'bold' };
    }
    return retVal;
  }

  private process2ndChildNodes(parameters: any[], fieldName: string, retVal: any) {
    let param1: string = "";
    let param2: string = "";


    if (this.vsrRecord1[parameters[0]] && this.vsrRecord1[parameters[0]][parameters[1]])
      param1 = this.vsrRecord1[parameters[0]][parameters[1]];
    if (this.vsrRecord2[parameters[0]] && this.vsrRecord2[parameters[0]][parameters[1]])
      param2 = this.vsrRecord2[parameters[0]][parameters[1]];

    if (fieldName === "DNBCompanyFinancialInformation.FinancialStressScore" && param1 !== "" && param2 !== "" && (parseInt(param1) !== parseInt(param2))) {
      return { color: 'blue', 'background-color': 'turquoise', 'font-weight': 'bold' };
    }
    if (param1 !== "" && param2 !== "") {
      if (param1.toUpperCase() !== param2.toUpperCase())
        return { color: 'blue', 'background-color': 'turquoise', 'font-weight': 'bold' };
    }
    else if ((param1 == "" && param2 !== "") || (param1 !== "" && param2 == "")) {
      return { color: 'blue', 'background-color': 'turquoise', 'font-weight': 'bold' };
    }

    if (fieldName === "DNBDetailedCompanyInformation.NumberOfRelatedEntities" && (param1 !== param2)) {
      return { color: 'blue', 'background-color': 'turquoise', 'font-weight': 'bold' };
    }
    return retVal;
  }

  private process3rdChildNodes(fieldName: string, retVal: any, childNodes: number, parameters: any[]) {
    if (fieldName === "PetitionInformation.Address.StreetFullText") {
      if (this.petitioner1CompanyAddress !== this.petitioner2CompanyAddress) {
        retVal = { color: 'blue', 'background-color': 'turquoise', 'font-weight': 'bold' };
      }
    }
    else if (fieldName === "DNBMatchedCompanyInformation.Address.StreetFullText") {
      if (this.DNBMatchedCompany1Address !== this.DNBMatchedCompany2Address) {
        retVal = { color: 'blue', 'background-color': 'turquoise', 'font-weight': 'bold' };
      }
    }
    else if (fieldName === "DNBMatchedBranchInformation.Address.OrganizationName") {
      if (this.vsrRecord1.DNBMatchedBranchInformation.Address.OrganizationName.toUpperCase() !==
        this.vsrRecord2.DNBMatchedBranchInformation.Address.OrganizationName.toUpperCase())
        retVal = { color: 'blue', 'background-color': 'turquoise', 'font-weight': 'bold' };
    }
    else if (fieldName === "DNBMatchedBranchInformation.Address.StreetFullText") {
      if (this.DNBMatchedBranch1Address !== this.DNBMatchedBranch2Address) {
        retVal = { color: 'blue', 'background-color': 'turquoise', 'font-weight': 'bold' };
      }
    }
    else if (fieldName === "ManualSearchInfo.Address.StreetFullText") {
      if (this.manualSearch1Address !== this.manualSearch2Address) {
        retVal = { color: 'blue', 'background-color': 'turquoise', 'font-weight': 'bold' };
      }
    }
    else if (fieldName === "DNBMatchedCompanyInformation.OrganizationPhone.TelephoneNumberFullID") {
      if ((this.vsrRecord1.DNBMatchedCompanyInformation.OrganizationPhone) && (this.vsrRecord2.DNBMatchedCompanyInformation.OrganizationPhone)
        && (this.vsrRecord1.DNBMatchedCompanyInformation.OrganizationPhone.TelephoneNumberFullID.toUpperCase() !=
          this.vsrRecord2.DNBMatchedCompanyInformation.OrganizationPhone.TelephoneNumberFullID.toUpperCase())) {
        retVal = { color: 'blue', 'background-color': 'turquoise', 'font-weight': 'bold' };
      }
      else if (((!this.vsrRecord1.DNBMatchedCompanyInformation.OrganizationPhone ||
        this.vsrRecord1.DNBMatchedCompanyInformation.OrganizationPhone.TelephoneNumberFullID === null) &&
        (this.vsrRecord2.DNBMatchedCompanyInformation.OrganizationPhone.TelephoneNumberFullID !== null)) ||
        ((this.vsrRecord1.DNBMatchedCompanyInformation.OrganizationPhone) && (!this.vsrRecord2.DNBMatchedCompanyInformation.OrganizationPhone ||
          this.vsrRecord2.DNBMatchedCompanyInformation.OrganizationPhone.TelephoneNumberFullID === null))) {
        retVal = { color: 'blue', 'background-color': 'turquoise', 'font-weight': 'bold' };
      }
    }
    else if ((childNodes !== 1 && this.vsrRecord1[parameters[0]][parameters[1]][parameters[2]])
      && (this.vsrRecord2[parameters[0]][parameters[1]][parameters[2]])
      && (this.vsrRecord1[parameters[0]][parameters[1]][parameters[2]] !== this.vsrRecord2[parameters[0]][parameters[1]][parameters[2]])) {
      retVal = { color: 'blue', 'background-color': 'turquoise', 'font-weight': 'bold' };
    }
    return retVal;
  }

  private getScoreResultStyle(ScoreCodeType): any {
    switch (ScoreCodeType) {
      case 'GREEN':
        return { color: 'white', 'background-color': 'green', 'font-weight': 'bold' };
      case 'RED':
        return { color: 'black', 'background-color': 'red', 'font-weight': 'bold' };
      case 'ORANGE':
        return { color: 'black', 'background-color': 'orange', 'font-weight': 'bold' };
      case 'YELLOW':
        return { color: 'black', 'background-color': 'yellow', 'font-weight': 'bold' };
      case 'BLUE':
        return { color: 'white', 'background-color': 'blue', 'font-weight': 'bold' };
      default:
        return {};
    }

  }

  getAdjudicativeStatusStyle(status: string): any {
    let statusIcon: string = "";
    switch (status) {
      case 'APPROVED':
        // return "success-standard";
        return "assets/approved.png";
      case 'PENDING':
        return "assets/pending.png";
      case 'DENIED':
        return "assets/denied.png";
      case 'DENIED FRAUD':
        return "assets/deniedFraud.png";
      case 'REJECTED':
        return "assets/rejected.png";
      case 'CLOSED':
        return "assets/closed.png";
      default:
        return "assets/unknown.svg";
    }
  }
}
export class DolSummaryView {
  caseNumber: string;
  selectedDol1: DOLSummary;
  selectedDol2: DOLSummary;
  rowColor: any;
  public constructor(
    fields?: {
      caseNumber?: string,
      selectedDol1?: DOLSummary,
      selectedDol2?: DOLSummary,
      rowColor?: any
    }) {
    if (fields) Object.assign(this, fields);
  }
}