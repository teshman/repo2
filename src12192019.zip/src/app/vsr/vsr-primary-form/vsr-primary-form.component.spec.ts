import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { vsrPrimaryFormComponent } from './vsr-primary-form.component';

describe('vsrPrimaryFormComponent', () => {
  let component: vsrPrimaryFormComponent;
  let fixture: ComponentFixture<vsrPrimaryFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ vsrPrimaryFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(vsrPrimaryFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
