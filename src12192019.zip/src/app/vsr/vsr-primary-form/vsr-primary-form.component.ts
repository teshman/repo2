
import { GeocodeService } from 'src/app/geocode.service';
import { Component, Input, OnInit, Output, SimpleChanges, EventEmitter, ViewChild, ElementRef, AfterViewInit, AfterViewChecked } from '@angular/core';
import { VsrRecordEntity, Vsr } from 'src/app/shared/vsr';
import { AppSettings } from '../../shared/app-settings';
import { VsrSearchService } from '../../vsr-search.service';
import { PreviousFilingsService } from '../../previous-filings.service';
import { Previousfiling } from '../../shared/previous_filings_interfaces';
import { DolEtaSearchService } from '../../dol-eta-search.service';
import { DolData, DOLDATA } from '../../shared/dol_interfaces';
import { load, urlSettings } from 'google-maps-promise';
import { UserInRoleService } from '../../user-profile/user-in-role.service';
import { DOLSummary } from '../../shared/vsr-resubmit';
import { FormControl, FormBuilder } from '@angular/forms';
import { DolProxy } from '../../shared/dol_proxy';
import { ScoreCardRecordEntity, ScoreCard } from '../../shared/score-card';
import { ClrWizard } from "@clr/angular";
import { PredefinedInformationWorkflowRequest, PredfinedInfoRequestAddress, ValidUntilDateRange } from '../../shared/predefined-Info-request';
import { PredefWorkflowService } from '../../predefined-info/predef-workflow.service';
import { PredefinedInfoWorkflowFacade } from '../../shared/predefined-info-workflow-facade';
import { PredefinedInfoService } from '../../predefined-info/predefined-info.service';
import { PredefinedInformationGetDetailResponse } from '../../shared/predefined-info-response';
import { PredefinedInfoCreateComponent } from '../../predefined-info/predefined-info-create.component'
import { stringify } from 'querystring';


function etaIdValidator(control: FormControl): { [key: string]: any } {
  const value: string = control.value || '';
  let etaCaseId = value.trim().replace(/-/g, "").toUpperCase();
  if ((etaCaseId != '') && (etaCaseId.length == 15) && ((etaCaseId.indexOf("H") == 0) || (etaCaseId.indexOf("I") == 0) || (etaCaseId.indexOf("C") == 0)) && (Number(etaCaseId.substring(1)))) {
    // console.log("valid dol case #");
    return null;
  } else {
    // console.log("invalid dol case #" + etaCaseId);

    return { validId: true };
  }
}


@Component({
  selector: 'vsr-primary-form',
  templateUrl: './vsr-primary-form.component.html',
  styleUrls: ['./vsr-primary-form.component.css']
})

export class vsrPrimaryFormComponent implements OnInit, AfterViewChecked {
  @Input() vsrRecord: VsrRecordEntity;
  @Input() displayManualSearch: boolean = true;

  @Input() showVsrResubmit: boolean = false;
  @Input() vsrReceipt: string = "";
  @Output() vsrRecordRefreshed: EventEmitter<VsrRecordEntity> = new EventEmitter<VsrRecordEntity>();
  @Output() etaSearchComplete: EventEmitter<string[]> = new EventEmitter<string[]>();
  @Output() pfsSearchComplete: EventEmitter<Previousfiling> = new EventEmitter<Previousfiling>();
  @Output() resubmitComplete: EventEmitter<boolean> = new EventEmitter<boolean>();
  @Output() pfsSearchBegin: EventEmitter<string[]> = new EventEmitter<string[]>();




  pageWidthStyle: string = "clr-col-sm-12 clr-col-md-6";
  showForm: boolean = false;
  showMap: boolean = true;
  showPetitionerAlert: boolean = false;
  showIIPAlert: boolean = false;
  showManualAlert: boolean = false;
  showPrevFilingsCount: boolean = false;
  alertMessage = AppSettings.GOOGLEMAPS_NO_STREETVIEW;
  loadingmap: boolean = false;
  ROA_ENABLED: boolean = false;
  dolEta: any
  adjucativeStatusStyle: string = "success-standard";
  appsAlert;
  predefAlertMessage: string = "";
  predefLoading: boolean = false;
  showPredefAlertMessage: boolean = false;
  branchInfoAvailable: boolean = false;
  etaPetitionId: string = "";
  etaCaseIdNum: string = "";
  dolAlertMessage: string = "";
  dolInformationAvailable: boolean = false;
  displayManualAddress: boolean = false;
  displayDOLCaseNumber: boolean = false;
  DOLManualSearchModal: boolean = false;
  relatedToPetitioner: string = "";
  exec1: string = "empty";
  hasGrossAnualIncome: boolean = false;
  grossAnualIncome: string;
  loading: boolean = false;
  selectedDol: DOLSummary;
  multipleDolEta: string[] = [];
  multipleDolSummary: DOLSummary[] = [];
  selectedEtaNumber: string = "";
  etaCaseNumbeLength: number = 15;
  outOfBusinessIndicator: string = "";
  preDefinedScoreAvailable: boolean = false;
  preDefinedAttornyScoreAvailable: boolean = false;
  preDefinedAddressScoreAvailable: boolean = false;
  resubmitShowModal: boolean = false;
  scoreCardID: string;
  scRecords: ScoreCardRecordEntity[] = [];


  searchBy: string = "Receipt Number";

  showVsr: boolean = false;
  showDOLdates: boolean = true;
  userInRoeleDol: boolean = false;
  dolHyperLinkActive: boolean = false;
  dolSearchButtonActive: boolean = false;
  ValidEndDate: string = "Valid End Date:"
  ValidStartDate: string = "Valid Start Date:"
  formType: string = "";
  PetitionerOrEmployer: string = "";
  PetitionOrApplication: string = "";
  vibePreDefinedCompanyScore: string = "";
  vibePreDefinedAttorneyScore: string = "";
  vibePreDefinedAddressScore: string = "";
  showAddressScore: boolean = false;
  showAttorneyScore: boolean = false;
  redAddressInfo: string = "";
  VIBEScoreResult_Score: string;
  vsr: Vsr;

  scoreCardRuleNames: string[] = [];
  scoreCardRuleScores: string[] = [];
  dolSearchForm;
  petitionerAddress: string = "";
  petitionerGoogleAddressInvalid: boolean = false;
  manualSearchAddress: string = "";
  manualSearchGoogleAddress: string = "";
  petitionerGoogleAddress: string = "";
  manualSearchGoogleAddressInvalid: boolean = false;
  branchSearchAddress: string = "";
  branchSearchGoogleAddress: string = "";
  DNBMatchedCompanyAddress: string = "";
  DNBMatchedCompanyGoogleAddress: string = "";
  branchOrDNBAddress: string = "";
  branchOrDNBAddressInvalid: boolean = false;
  branchOrDNBAddressLabel: string = "";
  branchCompanyInfoAvailable: boolean = false;
  showPredefRequestWizard: boolean = false;
  showPredefViewDetailForm: boolean = false;
  canRequestPredefinedInfo: boolean = false;
  predefResponse: PredefinedInformationGetDetailResponse;
  predefIIPMatchedAddress: PredfinedInfoRequestAddress;
  predefManualSearchAddress: PredfinedInfoRequestAddress;
  predefPetitionAddress: PredfinedInfoRequestAddress;

  private dolSvc: DolEtaSearchService;
  dol: DolData;
  previousFiling: Previousfiling;
  showEta: boolean = false;
  expandAll: boolean = false;
  expandAllScore: boolean = true;
  selectedRowIndexes =
    [{ ind: 0, expanded: false }, { ind: 2, expanded: false }, { ind: 3, expanded: false }, { ind: 4, expanded: false },
    { ind: 5, expanded: false }, { ind: 6, expanded: false }, { ind: 7, expanded: false }, { ind: 8, expanded: false },
    { ind: 9, expanded: false }, { ind: 10, expanded: false },
    { ind: 11, expanded: false }, { ind: 12, expanded: false }, { ind: 13, expanded: false }, { ind: 14, expanded: false }];

  clrSbExpanded: boolean = false;

  model = {
    searchById: "", //"WAC1802550980" //WAC1419550371 - no DOL,
    lat: -0.0,
    long: -0.0,
    streetView: '',
    fullMap: ''
  }

  private vsrSvc: VsrSearchService;
  private geocodeSvc: GeocodeService;
  geoInfo = [];
  orgs: string[];
  public focusEtaCaseId: EventEmitter<boolean> = new EventEmitter();
  private visibilityChanged: boolean = true;
  @ViewChild(PredefinedInfoCreateComponent,{static: false}) createPredefInfo : PredefinedInfoCreateComponent
  ngAfterViewChecked() {
    if (this.visibilityChanged) {
      this.focusEtaCaseId.emit(this.DOLManualSearchModal);
      this.visibilityChanged = false;
    }
  }

  constructor(
    private predefWorkflowService: PredefWorkflowService, private predefInfoListService: PredefinedInfoService,
    private vsrSearchService: VsrSearchService, private geocodeService: GeocodeService, private _el: ElementRef,
    private dolEtaService: DolEtaSearchService, private pfSvc: PreviousFilingsService, private fb: FormBuilder, private userInRoleService: UserInRoleService) {
    this.vsrSvc = vsrSearchService;
    this.geocodeSvc = geocodeService;

  }

  ngOnInit() {
    if (this.userInRoleService.userInRole && this.userInRoleService.userInRole.dolUser) this.userInRoeleDol = true;
    if (this.vsrReceipt && this.vsrReceipt !== "") {
      try {
        this.refreshFromService(this.vsrReceipt)
      }
      catch (error) {
        console.log("error while refreshing from service. " + JSON.stringify(error));
      }
    }
    else
      this.refresh();

    this.initPredefList();
  }

  private showWizard() {
    this.predefAlertMessage = "";
    let exceptionId: string = "";
    this.showPredefAlertMessage = false;

    if (this.predefWorkflowService.predefCompleteList !== undefined && this.vsrRecord.VibePreDefinedCompanyScore !== undefined &&
      this.vsrRecord.VibePreDefinedCompanyScore.ExceptionID !== undefined &&
      this.vsrRecord.VibePreDefinedCompanyScore.ExceptionID !== null
      && this.vsrRecord.VibePreDefinedCompanyScore.ExceptionID !== "") {

        exceptionId = this.vsrRecord.VibePreDefinedCompanyScore.ExceptionID;
      this.createOrUpdatePredefinedInformation(exceptionId);
      console.log("processing existing predefined info...");
    }
    else{
      
      console.log("this.predefWorkflowService.predefCompleteList ..." + JSON.stringify(this.predefWorkflowService.predefCompleteList));
      
      console.log("this.vsrRecord.VibePreDefinedCompanyScore ..." + JSON.stringify(this.vsrRecord.VibePreDefinedCompanyScore));
    console.log("No existing exception id, processing new record...");
      this.processNewPredefinedInfoCreation();
    }
    if(this.createPredefInfo){
    this.createPredefInfo.clickAddress()
    }
  }

  createOrUpdatePredefinedInformation(exceptionID: string): void {
    this.predefLoading = true;
    this.showPredefAlertMessage =false;
    this.predefAlertMessage = "" ;
    let predefResponse;
    this.predefInfoListService.getPredefInfoDetailByExceptionId(exceptionID).subscribe(

      data => {
        if (data && !JSON.stringify(data).includes("ESB2Exception")) {
          try {
            this.predefResponse = new PredefinedInformationGetDetailResponse();
            this.predefWorkflowService.predefCompleteList.PredefinedInformationGetDetailResponse = new PredefinedInformationGetDetailResponse();
            this.predefWorkflowService.predefCompleteList.PredefinedInformationGetDetailResponse = data as PredefinedInformationGetDetailResponse;
            this.predefResponse = data as PredefinedInformationGetDetailResponse;
            this.predefResponse.exceptionId = exceptionID;
            this.predefLoading = false;
            this.processExistingPredefinedInfo(exceptionID);
          } catch (error) {
            this.predefLoading = false;
            console.log("no good response retieved..." + JSON.stringify(error));
            this.setAlertMessage(data);
          }
         

        }
        else {
          this.predefLoading = false;
          console.log("no good response retieved..." + JSON.stringify(data));
          this.setAlertMessage(data);
        }
      }, error => {
        (async () => {
          // await this.delay(1000);  //when simulating a long delay or timeout from a service.

          console.log("data not retieved. error happens..." + JSON.stringify(error));
          if (JSON.stringify(error).includes(AppSettings.VSR_EXCEPTION_CODE_0107))
            this.appsAlert = AppSettings.VSR_EXCEPTION_CODE_0107_DESC;
          else if (JSON.stringify(error).includes(AppSettings.VSR_EXCEPTION_CODE_0108))
            this.appsAlert = AppSettings.VSR_EXCEPTION_CODE_0108_DESC;
          else if (JSON.stringify(error).includes(AppSettings.VSR_EXCEPTION_CODE_0500))
            this.appsAlert = AppSettings.VSR_EXCEPTION_CODE_0500_DESC;
          else
            this.appsAlert = AppSettings.SYSTEM_EXCEPTION;
          this.predefLoading = false;
        })();
        this.predefAlertMessage = "Error while retrieving predefined info.";
        if(this.predefAlertMessage !== "") 
        this.showPredefAlertMessage = true;
      }

     
    );
   
  }

  private setAlertMessage(data: PredefinedInformationGetDetailResponse) {
    if (JSON.stringify(data).includes(AppSettings.VSR_EXCEPTION_CODE_0107))
      this.predefAlertMessage = AppSettings.VSR_EXCEPTION_CODE_0107_DESC;
    else if (JSON.stringify(data).includes(AppSettings.VSR_EXCEPTION_CODE_0108))
      this.predefAlertMessage = AppSettings.VSR_EXCEPTION_CODE_0108_DESC;
    else if (JSON.stringify(data).includes(AppSettings.VSR_EXCEPTION_CODE_0500))
      this.predefAlertMessage = AppSettings.VSR_EXCEPTION_CODE_0500_DESC;
    else if (JSON.stringify(data).includes(AppSettings.HTTP_STATUS_401))
      this.predefAlertMessage = AppSettings.VSR_EXCEPTION_CODE_0500_DESC;
    else if (JSON.stringify(data).includes("exception"))
      this.predefAlertMessage = AppSettings.SYSTEM_EXCEPTION;
    else {
      console.log("none system exception... processig new predefined Info creation.");
      this.processNewPredefinedInfoCreation();
    }
    if (this.predefAlertMessage !== "")
      this.showPredefAlertMessage = true;
    // console.log("the predefAlertMessage is: " + this.predefAlertMessage);
  }

  private processExistingPredefinedInfo(exceptionID) {
    // console.log("processing existing info...");
    this.initPredefList();

    let predefList: PredefinedInfoWorkflowFacade = new PredefinedInfoWorkflowFacade({ source: "vsr" });
    if (this.predefWorkflowService.predefCompleteList) {


      if (
        this.initPredefRequestByExceptionIdDetailResponse(predefList,exceptionID) == true) {
          if (this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.duns !== undefined &&
            this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.duns !== null &&
            this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.duns !== "") {
            this.predefWorkflowService.predefCompleteList.searchByAddress = false;
            this.predefWorkflowService.predefCompleteList.iipNextDisabled = false;
          }
          else {
            this.predefWorkflowService.predefCompleteList.searchByAddress = true;
            this.predefWorkflowService.predefCompleteList.iipNextDisabled = true;
          }
      this.predefWorkflowService.predefCompleteList.forceEdit = true;
      this.predefWorkflowService.predefCompleteList.setFormType();
        this.showPredefViewDetailForm = true;
        this.showPredefRequestWizard = false;
      }
      else {
        this.appsAlert = "unable to process Predefined Information Request at this time."
      }
    }
    else {
      this.initPredefList();
    }
  }

  private processNewPredefinedInfoCreation() {
    // console.log("processing new predefined info...");
    let predefList: PredefinedInfoWorkflowFacade = new PredefinedInfoWorkflowFacade({ source: "vsr" });
    this.showPredefViewDetailForm = false;
    predefList.predefinedInformationRequest = new PredefinedInformationWorkflowRequest();
    predefList.predefinedInformationRequest.receiptNumber = this.vsrRecord.ReceiptNumber;
    if(this.vsrRecord.PetitionInformation !== undefined &&
      this.vsrRecord.PetitionInformation.Fein !== undefined && this.vsrRecord.PetitionInformation.Fein !== null)
    predefList.predefinedInformationRequest.fein = this.vsrRecord.PetitionInformation.Fein  ;
    if(this.vsrRecord.PetitionInformation !== undefined && this.vsrRecord.PetitionInformation !== null && 
      this.vsrRecord.PetitionInformation.OrganizationName !== undefined && this.vsrRecord.PetitionInformation.OrganizationName !== null)
    predefList.predefinedInformationRequest.organizationName = this.vsrRecord.PetitionInformation.OrganizationName  ;
    
    
    predefList.predefinedInformationRequest.address = new PredfinedInfoRequestAddress();
    predefList.businessSearchAddress = new PredfinedInfoRequestAddress();
    let cf: number = parseInt(this.vsrRecord.VIBEScoreResult.ConfidenceFactor);
    if (cf > 6) {
      predefList.predefinedInformationRequest.duns = this.vsrRecord.DNBMatchedCompanyInformation.OrganizationDUNSNumber;

      
      if(this.vsrRecord.PetitionInformation !== undefined && this.vsrRecord.PetitionInformation !== null && 
        this.vsrRecord.PetitionInformation.OrganizationName !== undefined && this.vsrRecord.PetitionInformation.OrganizationName !== null)
      predefList.predefinedInformationRequest.organizationName = this.vsrRecord.PetitionInformation.OrganizationName  ;
      else
      if(this.vsrRecord.ManualSearchInfo !== undefined && this.vsrRecord.ManualSearchInfo !== null && 
        this.vsrRecord.ManualSearchInfo.OrganizationName !== undefined && this.vsrRecord.ManualSearchInfo.OrganizationName !== null)
      predefList.predefinedInformationRequest.organizationName = this.vsrRecord.ManualSearchInfo.OrganizationName  ;

      predefList.iipNextDisabled = false;
      predefList.searchByAddress = false;
    }
    else {
      predefList.searchByAddress = true;
      predefList.predefinedInformationRequest.duns = "";
      predefList.IIPMatchedAddress = this.predefIIPMatchedAddress;
      predefList.ManualSearchAddress = this.predefManualSearchAddress;
      predefList.PetitionAddress = this.predefPetitionAddress;
      if( predefList.businessSearchAddress !== undefined &&  predefList.businessSearchAddress !== null){
       if( predefList.businessSearchAddress.country == null ||  predefList.businessSearchAddress.country == ""){
        if(predefList.IIPMatchedAddress !== undefined && predefList.IIPMatchedAddress !== null && predefList.IIPMatchedAddress.country !== ""){
          predefList.businessSearchAddress.country = predefList.IIPMatchedAddress.country;
          // console.log("iipMatched address is selected.. " + JSON.stringify( predefList.businessSearchAddress));
        }
       }
      }
      predefList.predefinedInformationRequest.address = this.predefPetitionAddress;
    }

    predefList.formTypeManualEdit = true;
    predefList.workFlowStatus = 'INIT_STARTED';
    this.predefWorkflowService.predefCompleteList = predefList;
    
    // console.log("this.predefWorkflowService.predefCompleteList " + JSON.stringify( this.predefWorkflowService.predefCompleteList.businessSearchAddress));
    this.showPredefRequestWizard = true;
  }

  private initPredefRequestByExceptionIdDetailResponse(predefList: PredefinedInfoWorkflowFacade, exceptionID:any): boolean {
    let retVal: boolean = false;
    try {
      let predef = this.mapPredefinedInfoRequestData(predefList);
      this.mapPredefinedInfoDetailResponse(predefList, exceptionID);


      let StreetFullText = (predef.PredefinedInformationGetDetailResponse.address.streetFull == null) ? "" : predef.PredefinedInformationGetDetailResponse.address.streetFull + ", ";
      let LocationCityName = (predef.PredefinedInformationGetDetailResponse.address.city == null) ? "" : predef.PredefinedInformationGetDetailResponse.address.city + ", ";
      let LocationStateName = (predef.PredefinedInformationGetDetailResponse.address.state == null) ? "" : predef.PredefinedInformationGetDetailResponse.address.state + ", ";
      let LocationPostalCode = (predef.PredefinedInformationGetDetailResponse.address.postalCode == null) ? "" : predef.PredefinedInformationGetDetailResponse.address.postalCode + ", ";
      let LocationCountryName = (predef.PredefinedInformationGetDetailResponse.address.country == null) ? "" : predef.PredefinedInformationGetDetailResponse.address.country;

      let DNBMatchedCompanyAddress = StreetFullText + LocationCityName + LocationStateName + LocationPostalCode + LocationCountryName;
      if(DNBMatchedCompanyAddress !== undefined && DNBMatchedCompanyAddress !== null && DNBMatchedCompanyAddress !== ""){
      DNBMatchedCompanyAddress = this.removelastCommaCharacter(DNBMatchedCompanyAddress.trim());
      predefList.PredefinedInformationGetDetailResponse.address.singleLineFullAddress = DNBMatchedCompanyAddress;
      
      predefList.predefinedInformationRequest.address.singleLineFullAddress = DNBMatchedCompanyAddress;

    }
      this.predefWorkflowService.predefCompleteList = predefList;
      // console.log("the predefWorkFlowService is: " + JSON.stringify(this.predefWorkflowService.predefCompleteList));
      retVal = true;

    } catch (error) {
      console.log(" hmm..., error happens, and the error is: " + JSON.stringify(error));
      retVal = false;
    }
    return retVal;
  }

  private mapPredefinedInfoDetailResponse(predefList: PredefinedInfoWorkflowFacade, exceptionId: any) {
    
    let predef = JSON.parse(JSON.stringify(this.predefResponse));
    // console.log("THE RESPONSE IS: " + JSON.stringify(predef));
    predefList.PredefinedInformationGetDetailResponse = new PredefinedInformationGetDetailResponse();
   
    predefList.PredefinedInformationGetDetailResponse.fein = predef.PredefinedInformationGetDetailResponse.fein;
    predefList.PredefinedInformationGetDetailResponse.exceptionId =exceptionId;
    predefList.PredefinedInformationGetDetailResponse.duns = predef.PredefinedInformationGetDetailResponse.duns;
    predefList.PredefinedInformationGetDetailResponse.addressId = predef.PredefinedInformationGetDetailResponse.address.addressId;
    predefList.PredefinedInformationGetDetailResponse.receiptNumber = predef.PredefinedInformationGetDetailResponse.receiptNumber;
    predefList.PredefinedInformationGetDetailResponse.processStatus = predef.PredefinedInformationGetDetailResponse.processStatus;
    predefList.PredefinedInformationGetDetailResponse.agn = predef.PredefinedInformationGetDetailResponse.agn;
    predefList.PredefinedInformationGetDetailResponse.iipConfidenceCode = predef.PredefinedInformationGetDetailResponse.iipConfidenceCode;
    predefList.PredefinedInformationGetDetailResponse.validUntilDateRange = new ValidUntilDateRange();
    if (predef.PredefinedInformationGetDetailResponse.validUntilDateRange !== undefined && predef.PredefinedInformationGetDetailResponse.validUntilDateRange !== null) {

      if (predef.PredefinedInformationGetDetailResponse.validUntilDateRange.startDate !== undefined &&
        predef.PredefinedInformationGetDetailResponse.validUntilDateRange.startDate !== null &&
        predef.PredefinedInformationGetDetailResponse.validUntilDateRange.startDate !== "null") {
        predefList.PredefinedInformationGetDetailResponse.validUntilDateRange.startDate = predef.PredefinedInformationGetDetailResponse.validUntilDateRange.startDate;
      }
      if (predef.PredefinedInformationGetDetailResponse.validUntilDateRange.endDate !== undefined &&
        predef.PredefinedInformationGetDetailResponse.validUntilDateRange.endDate !== null &&
        predef.PredefinedInformationGetDetailResponse.validUntilDateRange.endDate !== "null") {
        predefList.PredefinedInformationGetDetailResponse.validUntilDateRange.endDate = predef.PredefinedInformationGetDetailResponse.validUntilDateRange.endDate;
      }
    }


    predefList.PredefinedInformationGetDetailResponse.office = predef.PredefinedInformationGetDetailResponse.office;
    predefList.PredefinedInformationGetDetailResponse.fdnsdsNumber = predef.PredefinedInformationGetDetailResponse.fdnsdsNumber;
    predefList.PredefinedInformationGetDetailResponse.predefinedInformationComment = predef.PredefinedInformationGetDetailResponse.predefinedInformationComment;
    predefList.PredefinedInformationGetDetailResponse.justificationComment = predef.PredefinedInformationGetDetailResponse.justificationComment;
    predefList.PredefinedInformationGetDetailResponse.siteVisitProgram = predef.PredefinedInformationGetDetailResponse.siteVisitProgram;
    predefList.PredefinedInformationGetDetailResponse.nominationSource = predef.PredefinedInformationGetDetailResponse.nominationSource;
    predefList.PredefinedInformationGetDetailResponse.addressId = predef.PredefinedInformationGetDetailResponse.address.addressId;
    predefList.PredefinedInformationGetDetailResponse.organizationName = predef.PredefinedInformationGetDetailResponse.organizationName;
    predefList.PredefinedInformationGetDetailResponse.address = new PredfinedInfoRequestAddress();
    // console.log("predefList.PredefinedInformationGetDetailResponse.receiptNumber" + predefList.PredefinedInformationGetDetailResponse.receiptNumber);
    predefList.PredefinedInformationGetDetailResponse.address.city = predef.PredefinedInformationGetDetailResponse.address.city;
    predefList.PredefinedInformationGetDetailResponse.address.country = predef.PredefinedInformationGetDetailResponse.address.country;
    predefList.PredefinedInformationGetDetailResponse.address.organizationName = predef.PredefinedInformationGetDetailResponse.address.organizationName;
    predefList.PredefinedInformationGetDetailResponse.address.postalCode = predef.PredefinedInformationGetDetailResponse.address.postalCode;
    predefList.PredefinedInformationGetDetailResponse.address.state = predef.PredefinedInformationGetDetailResponse.address.state;
    predefList.PredefinedInformationGetDetailResponse.address.streetExtension = predef.PredefinedInformationGetDetailResponse.address.streetExtension;
    predefList.PredefinedInformationGetDetailResponse.address.streetFull = predef.PredefinedInformationGetDetailResponse.address.streetFull;
    predefList.PredefinedInformationGetDetailResponse.address.telephoneNumber = predef.PredefinedInformationGetDetailResponse.address.telephoneNumber;
    predefList.PredefinedInformationGetDetailResponse.preDefCommentType = this.getPredefCommentType(predef.PredefinedInformationGetDetailResponse.preDefCommentType);
    predefList.PredefinedInformationGetDetailResponse.preDefFormCommentType = predef.PredefinedInformationGetDetailResponse.preDefFormCommentType;
    predefList.PredefinedInformationGetDetailResponse.lastWizardStep = predef.PredefinedInformationGetDetailResponse.lastWizardStep;
    predefList.PredefinedInformationGetDetailResponse.operationCode = predef.PredefinedInformationGetDetailResponse.operationCode;
    predefList.PredefinedInformationGetDetailResponse.overrideScore = predef.PredefinedInformationGetDetailResponse.overrideScore;
    
// console.log("what is the exception Id? " + predefList.PredefinedInformationGetDetailResponse.exceptionId);
  }

  getPredefCommentType(commentType:string):string{
    let commentTypeStr:string = "";
    if(commentType !== undefined && commentType !== null){
    for (let i = 0; i < commentType.length; i++) {
      let ct = commentType.charAt(i);
      switch (ct.toUpperCase()) {
        case "L":
          commentTypeStr = commentTypeStr + " " + "LE13";
          break;
  
        case "H":
          commentTypeStr  = commentTypeStr + " " +  "H2A";
          break;
  
        case "Q":
          commentTypeStr  = commentTypeStr + " " +  "Q";;
          break;
        case "S":
          commentTypeStr  = commentTypeStr + " " +  "SIEVE";
          break;
        case "V":
          commentTypeStr  = commentTypeStr + " " +  "Viability";
          break;
        case "P":
          commentTypeStr  = commentTypeStr + " " +  "Public Law";
          break;
        default:
          commentTypeStr  = commentTypeStr + " " +  "";
          break;
      }
  
    }
  }
  return commentTypeStr;
  }
  private mapPredefinedInfoRequestData(predefList: PredefinedInfoWorkflowFacade) { 
    let predef = JSON.parse(JSON.stringify(this.predefResponse));
    try {
      predefList.predefinedInformationRequest = new PredefinedInformationWorkflowRequest();
      if( predef.PredefinedInformationGetDetailResponse !== undefined ) {
        if( predef.PredefinedInformationGetDetailResponse.fein !== undefined ) predefList.predefinedInformationRequest.fein = predef.PredefinedInformationGetDetailResponse.fein ;
      if( predef.PredefinedInformationGetDetailResponse !== undefined ) predefList.predefinedInformationRequest.duns = predef.PredefinedInformationGetDetailResponse.duns;
      if( predef.PredefinedInformationGetDetailResponse !== undefined ) predefList.predefinedInformationRequest.agn = predef.PredefinedInformationGetDetailResponse.agn;
      if( predef.PredefinedInformationGetDetailResponse !== undefined ) predefList.predefinedInformationRequest.receiptNumber = predef.PredefinedInformationGetDetailResponse.receiptNumber;
      if( predef.PredefinedInformationGetDetailResponse !== undefined ) predefList.predefinedInformationRequest.organizationName = predef.PredefinedInformationGetDetailResponse.organizationName;
      if( predef.PredefinedInformationGetDetailResponse !== undefined ) predefList.predefinedInformationRequest.address = new PredfinedInfoRequestAddress();
  
      if( predef.PredefinedInformationGetDetailResponse !== undefined ) predefList.businessSearchAddress = new PredfinedInfoRequestAddress();
      if( predef.PredefinedInformationGetDetailResponse !== undefined ) predefList.predefinedInformationRequest.address.city = predef.PredefinedInformationGetDetailResponse.address.city;
      if( predef.PredefinedInformationGetDetailResponse !== undefined ) predefList.predefinedInformationRequest.address.country = predef.PredefinedInformationGetDetailResponse.address.country;
      if( predef.PredefinedInformationGetDetailResponse !== undefined ) predefList.predefinedInformationRequest.address.organizationName = predef.PredefinedInformationGetDetailResponse.address.organizationName;
      if( predef.PredefinedInformationGetDetailResponse !== undefined ) predefList.predefinedInformationRequest.address.postalCode = predef.PredefinedInformationGetDetailResponse.address.postalCode;
      if( predef.PredefinedInformationGetDetailResponse !== undefined ) predefList.predefinedInformationRequest.address.state = predef.PredefinedInformationGetDetailResponse.address.statestate;
      if( predef.PredefinedInformationGetDetailResponse !== undefined ) predefList.predefinedInformationRequest.address.streetExtension = predef.PredefinedInformationGetDetailResponse.address.streetExtension;
      if( predef.PredefinedInformationGetDetailResponse !== undefined ) predefList.predefinedInformationRequest.address.streetFull = predef.PredefinedInformationGetDetailResponse.address.streetFull;
      if( predef.PredefinedInformationGetDetailResponse !== undefined ) predefList.predefinedInformationRequest.address.telephoneNumber = predef.PredefinedInformationGetDetailResponse.address.telephoneNumber;
      predefList.businessSearchAddress = predefList.predefinedInformationRequest.address;
      
      predefList.businessSearchAddress.organizationName = predef.PredefinedInformationGetDetailResponse.organizationName;
       // if( predef.PredefinedInformationGetDetailResponse !== undefined ) predefList.predefinedInformationRequest.lastWizardStep = predef.PredefinedInformationGetDetailResponse.lastWizardStep;
      if( predef.PredefinedInformationGetDetailResponse !== undefined ) predefList.predefinedInformationRequest.operationCode = predef.PredefinedInformationGetDetailResponse.operationCode;
      // if( predef.PredefinedInformationGetDetailResponse !== undefined ) predefList.predefinedInformationRequest.iipConfidenceCode = "";
      if( predef.PredefinedInformationGetDetailResponse !== undefined ) predefList.predefinedInformationRequest.overrideScore = predef.PredefinedInformationGetDetailResponse.overrideScore;
      if( predef.PredefinedInformationGetDetailResponse !== undefined ) predefList.predefinedInformationRequest.preDefFormCommentType = predef.PredefinedInformationGetDetailResponse.preDefFormCommentType;
      if( predef.PredefinedInformationGetDetailResponse !== undefined ) predefList.predefinedInformationRequest.office = predef.PredefinedInformationGetDetailResponse.office;
      
  
  
      if( predef.PredefinedInformationGetDetailResponse !== undefined ) predefList.predefinedInformationRequest.fdnsdsNumber = predef.PredefinedInformationGetDetailResponse.fdnsdsNumber;
      if( predef.PredefinedInformationGetDetailResponse !== undefined ) predefList.predefinedInformationRequest.predefinedInformationComment = predef.PredefinedInformationGetDetailResponse.predefinedInformationComment;
      if( predef.PredefinedInformationGetDetailResponse !== undefined ) predefList.predefinedInformationRequest.justificationComment = predef.PredefinedInformationGetDetailResponse.justificationComment;
      if( predef.PredefinedInformationGetDetailResponse !== undefined ) predefList.predefinedInformationRequest.siteVisitProgram = predef.PredefinedInformationGetDetailResponse.siteVisitProgram;
      if( predef.PredefinedInformationGetDetailResponse !== undefined ) predefList.predefinedInformationRequest.nominationSource = predef.PredefinedInformationGetDetailResponse.nominationSource;
      if( predef.PredefinedInformationGetDetailResponse !== undefined ) predefList.predefinedInformationRequest.addressId = predef.PredefinedInformationGetDetailResponse.address.addressId;
    

  
      }
      } catch (error) {
      console.log("error happens while fetching detail InfoWindowManager. " + error);
    }
   
    return predef;
  }



  private closePredefEditForm() {
    let predefList: PredefinedInfoWorkflowFacade = new PredefinedInfoWorkflowFacade({ source: "vsr" });
    predefList.predefinedInformationRequest = new PredefinedInformationWorkflowRequest();
    this.predefWorkflowService.predefCompleteList.predefinedInformationRequest = predefList.predefinedInformationRequest;
    this.predefWorkflowService.predefCompleteList.searchByAddress = false;
    this.showPredefViewDetailForm = false;
  }

  private predefInfoDetailEdit() {
    
    this.showPredefViewDetailForm = false;
    if (this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.duns !== undefined &&
      this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.duns !== null &&
      this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.duns !== "")
      this.predefWorkflowService.predefCompleteList.searchByAddress = false;
    else
      this.predefWorkflowService.predefCompleteList.searchByAddress = true;

      this.predefWorkflowService.predefCompleteList.forceEdit = true;
      this.showPredefRequestWizard = true;
  }

  private initPredefList() {
    let predefList: PredefinedInfoWorkflowFacade = new PredefinedInfoWorkflowFacade({ source: "vsr" });
    predefList.businessSearchAddress = new PredfinedInfoRequestAddress();
    predefList.predefinedInformationRequest = new PredefinedInformationWorkflowRequest();
    predefList.predefinedInformationRequest.address = new PredfinedInfoRequestAddress();
    this.predefWorkflowService.predefCompleteList = predefList;
    let cf: number;
    if(this.vsrRecord !== undefined && this.vsrRecord.VIBEScoreResult !== undefined 
      && this.vsrRecord.VIBEScoreResult.ConfidenceFactor !== null) {
    cf = parseInt(this.vsrRecord.VIBEScoreResult.ConfidenceFactor);
    if (cf > 6) 
      predefList.predefinedInformationRequest.duns = this.vsrRecord.DNBMatchedCompanyInformation.OrganizationDUNSNumber;
    }
  }

  private ngOnChanges(changes: SimpleChanges) {  
    if (this.vsrReceipt && this.vsrReceipt !== "") {
      this.refreshFromService(this.vsrReceipt)
    }
    else
      this.refresh();
  }

  refresh(): void {
    this.InitBooleans();
    if (this.vsrRecord && this.showVsrResubmit) {
      this.dolSearchForm = this.fb.group({
        etaCaseId: ["", etaIdValidator]
      });


      this.appsAlert = "";

      this.bindBusinessRules2();
      this.setOutOfBusinessIndicator();
      this.setPreviousFilingsCount();
      this.adjucativeStatusStyle = this.getAdjudicativeStatusStyle();
      this.setScoreCard();
    }
    else if (this.vsrRecord) {
      this.dolSearchForm = this.fb.group({
        etaCaseId: ["", etaIdValidator]
      });

      this.appsAlert = "";
      this.formType = (this.vsrRecord.PetitionInformation.PetitionType == null) ? "" : this.vsrRecord.PetitionInformation.PetitionType;
      if (this.formType && this.formType !== "" && this.formType == "I485J") {
        this.PetitionerOrEmployer = "Employer";
        this.PetitionOrApplication = "Application";
      }
      else {
        this.PetitionerOrEmployer = "Petitioner";
        this.PetitionOrApplication = "Petition";
      }
      this.bindBusinessRules();
      this.setPetitionerAddress();
      this.setOutOfBusinessIndicator();
      this.setPreviousFilingsCount();
      this.adjucativeStatusStyle = this.getAdjudicativeStatusStyle();
      this.scoreCardID = this.vsrRecord.ScoreID;
      this.showForm = true;

      this.showVsr = true;
    }

    else {
      this.appsAlert = "No receipts found matching this receipt number.";
      this.loading = false;
      this.showVsr = false;
    }
    this.vsrRecordRefreshed.emit(this.vsrRecord);
    this.loading = false;

  }
  private setScoreCard() {
    if (this.vsrRecord.ScoreID) this.scoreCardID = this.vsrRecord.ScoreID;
    else if (this.vsrRecord.DolScoreCardRecord) {
      let scoreCard: Scorecard;
      this.scRecords = [];
      this.scoreCardRuleNames = this.vsrRecord.DolScoreCardRecord.RuleNames ? this.vsrRecord.DolScoreCardRecord.RuleNames.split('~') : [];
      this.scoreCardRuleScores = this.vsrRecord.DolScoreCardRecord.RuleScores ? this.vsrRecord.DolScoreCardRecord.RuleScores.split('~') : [];
      for (let i = 0; i < this.scoreCardRuleNames.length; i++) {
        scoreCard = new Scorecard();
        scoreCard.BusinessRuleName = this.scoreCardRuleNames[i];
        scoreCard.Score = this.scoreCardRuleScores[i];
        if (this.scRecords !== undefined && scoreCard !== undefined) this.scRecords.push(scoreCard);
      }
    }
    this.showForm = true;



  }

  private setPreviousFilingsCount() {
    try {
      if (this.vsrRecord.VIBEScoreResult) {
        this.VIBEScoreResult_Score = this.vsrRecord.VIBEScoreResult.Score;
        let cf: number = parseInt(this.vsrRecord.VIBEScoreResult.ConfidenceFactor);
        if (cf > 6)
          this.showPrevFilingsCount = true;
        else
          this.showPrevFilingsCount = false;
      }
    } catch (error) {
      console.log("Error inside setPreviousFilingsCount, " + JSON.stringify(error));
    }

  }

  private setOutOfBusinessIndicator() {
    try {
      if (this.vsrRecord.DNBDetailedCompanyInformation) {
        if (this.vsrRecord.DNBDetailedCompanyInformation.OutOfBusinessIndicator)
          this.outOfBusinessIndicator = "Record is inactive";
        else
          this.outOfBusinessIndicator = "Record is active";
      }
    } catch (error) {
      console.log("Error inside setOutOfBusinessIndicator, " + JSON.stringify(error));

    }
  }

  private setPetitionerAddress() {
    try {
      let StreetFullText = (this.vsrRecord.PetitionInformation.Address.StreetFullText == null) ? "" : this.vsrRecord.PetitionInformation.Address.StreetFullText + ", ";
      let LocationCityName = (this.vsrRecord.PetitionInformation.Address.LocationCityName == null) ? "" : this.vsrRecord.PetitionInformation.Address.LocationCityName + ", ";
      let LocationStateName = (this.vsrRecord.PetitionInformation.Address.LocationStateName == null) ? "" : this.vsrRecord.PetitionInformation.Address.LocationStateName + ", ";
      let LocationPostalCode = (this.vsrRecord.PetitionInformation.Address.LocationPostalCode == null) ? "" : this.vsrRecord.PetitionInformation.Address.LocationPostalCode + ", ";
      let dnbCountry:string = "";
      dnbCountry = (this.vsrRecord.DNBMatchedCompanyInformation.Address.LocationCountryName == null) ? "" : this.vsrRecord.DNBMatchedCompanyInformation.Address.LocationCountryName;
      let LocationCountryName = (this.vsrRecord.PetitionInformation.Address.LocationCountryName == null) ? dnbCountry : this.vsrRecord.PetitionInformation.Address.LocationCountryName;
      this.petitionerAddress = StreetFullText + LocationCityName + LocationStateName + LocationPostalCode + LocationCountryName;
      this.petitionerAddress = this.removelastCommaCharacter(this.petitionerAddress.trim());
      
      let zipCode = LocationPostalCode;
      if (LocationCountryName && (LocationCountryName.toString().toUpperCase() == "USA" || LocationCountryName.toString().toUpperCase() == "U.S.A"
        || LocationCountryName.toString().toUpperCase() == "US")
        && LocationPostalCode && LocationPostalCode.length > 5 && !LocationPostalCode.includes("-"))
        zipCode = LocationPostalCode.substring(0, 5) + "-" + LocationPostalCode.substring(5, LocationPostalCode.length);
      this.petitionerGoogleAddress = StreetFullText + LocationCityName + LocationStateName + zipCode + LocationCountryName;

      this.petitionerGoogleAddress = this.removelastCommaCharacter(this.petitionerGoogleAddress.trim());
      if (this.addressInvalid(StreetFullText, LocationCityName))
        this.petitionerGoogleAddressInvalid = true;
      else
        this.petitionerGoogleAddressInvalid = false;

      var latlong = this.model.lat + "," + this.model.long;


      this.predefPetitionAddress = new PredfinedInfoRequestAddress();
      this.predefPetitionAddress.singleLineFullAddress = this.petitionerAddress;
      this.predefPetitionAddress.streetFull = StreetFullText.replace(',', '');
      this.predefPetitionAddress.city = LocationCityName.replace(',', '');
      this.predefPetitionAddress.state = LocationStateName.replace(',', '');
      this.predefPetitionAddress.postalCode = LocationPostalCode.replace(',', '');
      this.predefPetitionAddress.country = (LocationCountryName as string).replace(',', '');
      this.predefPetitionAddress.organizationName = this.vsrRecord.PetitionInformation.OrganizationName;
    } catch (error) {
      console.log("Error inside setPetitionerAddress, " + JSON.stringify(error));

    }
  }

  private removelastCommaCharacter(str: string): string {
    if (str !== null && str.length > 0 && str.charAt(str.length - 1) == ',') {
      str = str.substring(0, str.length - 1);
    }
    return str;
  }

  selectionChanged(dol) {
    // console.log("we have seen change.")
    // console.log("the selected etacase number is: " + dol.EtaCaseNumber);
  }

  private bindBusinessRules2() {

    this.checkForPredefinedInfo();
    this.checkForPredefinedAddressInfo();
    this.checkForPredefinedAttornyeyInfo();

    console.log("the predefined info is available? " + this.preDefinedScoreAvailable);

    this.checkForDNBCompanyFinancialInformation();

    this.checkForDisplayManualAddress();

    this.checkForBranchInfoAvailable();


    this.checkForExec1Available();
  }

  private bindBusinessRules() {
    let receiptFromDate = new Date(AppSettings.DOL_DISPLAY_RECEIPT_FROM_DATE);
    let receiptDate = new Date(this.vsrRecord.PetitionInformation.ReceiptDate.substr(0, 10));

    this.checkForPredefinedInfo();
    this.checkForPredefinedAddressInfo();
    this.checkForPredefinedAttornyeyInfo();

    this.checkForDNBCompanyFinancialInformation();

    this.checkFordolInformationAvailable();

    this.checkForDisplayManualAddress();

    this.checkForBranchInfoAvailable();

    this.setupGoogleMapAddress();


    this.checkForExec1Available();

    this.checkForDisplayDOLCaseNumber(receiptDate, receiptFromDate);

  }

  private checkForBranchInfoAvailable() {
    try {
      if (this.vsrRecord.DNBMatchedBranchInformation) {
        let StreetFullText = (this.vsrRecord.DNBMatchedBranchInformation.Address.StreetFullText == null) ? "" : this.vsrRecord.DNBMatchedBranchInformation.Address.StreetFullText + ", ";
        let LocationCityName = (this.vsrRecord.DNBMatchedBranchInformation.Address.LocationCityName == null) ? "" : this.vsrRecord.DNBMatchedBranchInformation.Address.LocationCityName + ", ";
        let LocationStateName = (this.vsrRecord.DNBMatchedBranchInformation.Address.LocationStateName == null) ? "" : this.vsrRecord.DNBMatchedBranchInformation.Address.LocationStateName + ", ";
        let LocationPostalCode = (this.vsrRecord.DNBMatchedBranchInformation.Address.LocationPostalCode == null) ? "" : this.vsrRecord.DNBMatchedBranchInformation.Address.LocationPostalCode + ", ";
        let LocationCountryName = (this.vsrRecord.DNBMatchedBranchInformation.Address.LocationCountryName == null) ? "" : this.vsrRecord.DNBMatchedBranchInformation.Address.LocationCountryName;

        this.branchSearchAddress = StreetFullText + LocationCityName + LocationStateName + LocationPostalCode + LocationCountryName;

        this.branchSearchAddress = this.removelastCommaCharacter(this.branchSearchAddress.trim());
        if (this.branchSearchAddress !== "")
          this.branchInfoAvailable = true;

        let zipCode = LocationPostalCode;
        if (LocationCountryName && (LocationCountryName.toUpperCase() == "USA" || LocationCountryName.toUpperCase() == "U.S.A" || LocationCountryName.toUpperCase() == "US")
          && LocationPostalCode && LocationPostalCode.length > 5 && !LocationPostalCode.includes("-"))
          zipCode = LocationPostalCode.substring(0, 5) + "-" + LocationPostalCode.substring(5, LocationPostalCode.length);
        this.branchSearchGoogleAddress = StreetFullText + LocationCityName + LocationStateName + zipCode + LocationCountryName;

        this.branchSearchGoogleAddress = this.removelastCommaCharacter(this.branchSearchGoogleAddress.trim());
        if (this.addressInvalid(StreetFullText, LocationCityName)) this.branchOrDNBAddressInvalid = true;
        else
          this.branchOrDNBAddressInvalid = false;

      }
      if (this.vsrRecord.DNBMatchedCompanyInformation) {

        let StreetFullText = (this.vsrRecord.DNBMatchedCompanyInformation.Address.StreetFullText == null) ? "" : this.vsrRecord.DNBMatchedCompanyInformation.Address.StreetFullText + ", ";
        let LocationCityName = (this.vsrRecord.DNBMatchedCompanyInformation.Address.LocationCityName == null) ? "" : this.vsrRecord.DNBMatchedCompanyInformation.Address.LocationCityName + ", ";
        let LocationStateName = (this.vsrRecord.DNBMatchedCompanyInformation.Address.LocationStateName == null) ? "" : this.vsrRecord.DNBMatchedCompanyInformation.Address.LocationStateName + ", ";
        let LocationPostalCode = (this.vsrRecord.DNBMatchedCompanyInformation.Address.LocationPostalCode == null) ? "" : this.vsrRecord.DNBMatchedCompanyInformation.Address.LocationPostalCode + ", ";
        let LocationCountryName = (this.vsrRecord.DNBMatchedCompanyInformation.Address.LocationCountryName == null) ? "" : this.vsrRecord.DNBMatchedCompanyInformation.Address.LocationCountryName;

        this.DNBMatchedCompanyAddress = StreetFullText + LocationCityName + LocationStateName + LocationPostalCode + LocationCountryName;
        this.DNBMatchedCompanyAddress = this.removelastCommaCharacter(this.DNBMatchedCompanyAddress.trim());


        let zipCode = LocationPostalCode;
        if (LocationCountryName && (LocationCountryName.toUpperCase() == "USA" || LocationCountryName.toUpperCase() == "U.S.A" || LocationCountryName.toUpperCase() == "US")
          && LocationPostalCode && LocationPostalCode.length > 5 && !LocationPostalCode.includes("-"))
          zipCode = LocationPostalCode.substring(0, 5) + "-" + LocationPostalCode.substring(5, LocationPostalCode.length);
        this.DNBMatchedCompanyGoogleAddress = StreetFullText + LocationCityName + LocationStateName + zipCode + LocationCountryName;
        this.DNBMatchedCompanyGoogleAddress = this.removelastCommaCharacter(this.DNBMatchedCompanyGoogleAddress.trim());

        if (this.vsrRecord.PetitionInformation && this.vsrRecord.PetitionInformation.OrganizationName.trim() !== "" && StreetFullText !== "" && LocationCityName !== "")
          this.branchOrDNBAddressInvalid = false;
        else
          this.branchOrDNBAddressInvalid = true;



        this.predefIIPMatchedAddress = new PredfinedInfoRequestAddress();
        this.predefIIPMatchedAddress.singleLineFullAddress = this.DNBMatchedCompanyAddress;
        this.predefIIPMatchedAddress.streetFull = StreetFullText;
        this.predefIIPMatchedAddress.city = LocationCityName;
        this.predefIIPMatchedAddress.state = LocationStateName;
        this.predefIIPMatchedAddress.postalCode = LocationPostalCode;
        this.predefIIPMatchedAddress.country = LocationCountryName as string;
        this.predefIIPMatchedAddress.organizationName = this.vsrRecord.PetitionInformation.OrganizationName;



      }
    } catch (error) {
      console.log("Error inside checkForBranchInfoAvailable, " + JSON.stringify(error));

    }
  }
  private addressInvalid(StreetFullText: string, LocationCityName: string, ): boolean {
    if (this.vsrRecord.PetitionInformation && this.vsrRecord.PetitionInformation.OrganizationName.trim() !== ""
      && this.vsrRecord.PetitionInformation.OrganizationName.trim() !== ","
      && StreetFullText.trim() !== ","
      && StreetFullText.trim() !== "" && StreetFullText.trim() !== "," && LocationCityName.trim() !== "" && LocationCityName.trim() !== ",") {
      return false;
    }
    else return true;
  }
  private setupGoogleMapAddress() {
    try {
      if (this.branchSearchGoogleAddress && this.branchSearchGoogleAddress != undefined && this.branchSearchGoogleAddress !== "") {
        this.branchOrDNBAddress = this.branchSearchGoogleAddress;
        this.branchOrDNBAddressLabel = "IIP Matched Branch Address:";
      }
      else if (this.DNBMatchedCompanyGoogleAddress && this.DNBMatchedCompanyGoogleAddress != undefined && this.DNBMatchedCompanyGoogleAddress !== "") {
        this.branchOrDNBAddress = this.DNBMatchedCompanyGoogleAddress;
        this.branchOrDNBAddressLabel = "IIP Matched Address:";
        if (this.branchOrDNBAddress.trim() !== "") this.branchCompanyInfoAvailable = true;

      }
    } catch (error) {
      console.log("Error inside setupGoogleMapAddress, " + JSON.stringify(error));

    }

  }

  private checkForDisplayDOLCaseNumber(receiptDate: Date, receiptFromDate: Date) {
    try {
      if (this.vsrRecord.PetitionInformation.DolEtaCaseNumber) {
        if ((this.vsrRecord.PetitionInformation.PetitionVisaType === "1B1" ||
          this.vsrRecord.PetitionInformation.PetitionVisaType === "E3" ||
          this.vsrRecord.PetitionInformation.PetitionVisaType === "HSC" ||
          this.vsrRecord.PetitionInformation.PetitionVisaType === "H2A" ||
          this.vsrRecord.PetitionInformation.PetitionVisaType === "H2B") &&
          (receiptDate >= receiptFromDate)
          &&
          (this.vsrRecord.DOLSummary))
          this.displayDOLCaseNumber = true;
      }

    } catch (error) {
      console.log("Error inside checkForDisplayDOLCaseNumber, " + JSON.stringify(error));
    }
  }

  private checkForExec1Available() {
    try {

      if (this.vsrRecord.DNBCompanyExecutiveBio && this.vsrRecord.DNBCompanyExecutiveBio.Executive1 != null)
        this.exec1 = this.vsrRecord.DNBCompanyExecutiveBio.Executive1;
    } catch (error) {
      console.log("Error inside checkForExec1Available, " + JSON.stringify(error));

    }
  }
  private checkForDisplayManualAddress() {
    let manualAddress: string = "";
    try {
      let StreetFullText = "";
      let LocationCityName = "";
      let LocationStateName = "";
      let LocationPostalCode = "";
      let LocationCountryName = "";
      if (this.showVsrResubmit || this.vsrRecord.PetitionInformation.OrganizationDataSource === "Manual") {
        {

          if (this.vsrRecord.ManualSearchInfo && this.vsrRecord.ManualSearchInfo.Address) {
            StreetFullText = (this.vsrRecord.ManualSearchInfo.Address.StreetFullText == null || this.vsrRecord.ManualSearchInfo.Address.StreetFullText == "") ? "" : this.vsrRecord.ManualSearchInfo.Address.StreetFullText + ", ";
            LocationCityName = (this.vsrRecord.ManualSearchInfo.Address.LocationCityName == null || this.vsrRecord.ManualSearchInfo.Address.LocationCityName == "") ? "" : this.vsrRecord.ManualSearchInfo.Address.LocationCityName + ", ";
            LocationStateName = (this.vsrRecord.ManualSearchInfo.Address.LocationStateName == null || this.vsrRecord.ManualSearchInfo.Address.LocationStateName == "") ? "" : this.vsrRecord.ManualSearchInfo.Address.LocationStateName + ", ";
            LocationPostalCode = (this.vsrRecord.ManualSearchInfo.Address.LocationPostalCode == null || this.vsrRecord.ManualSearchInfo.Address.LocationPostalCode == "") ? "" : this.vsrRecord.ManualSearchInfo.Address.LocationPostalCode + ", ";
            LocationCountryName = (this.vsrRecord.ManualSearchInfo.Address.LocationCountryName == null || this.vsrRecord.ManualSearchInfo.Address.LocationCountryName == "") ? "" : this.vsrRecord.ManualSearchInfo.Address.LocationCountryName;

            this.manualSearchAddress = StreetFullText + LocationCityName + LocationStateName + LocationPostalCode + LocationCountryName;

            this.manualSearchAddress = this.removelastCommaCharacter(this.manualSearchAddress.trim());
            let zipCode = LocationPostalCode;
            if (LocationCountryName && (LocationCountryName.toUpperCase() == "USA" || LocationCountryName.toUpperCase() == "U.S.A" || LocationCountryName.toUpperCase() == "US")
              && LocationPostalCode && LocationPostalCode.length > 5 && !LocationPostalCode.includes("-"))
              zipCode = LocationPostalCode.substring(0, 5) + "-" + LocationPostalCode.substring(5, LocationPostalCode.length);
            this.manualSearchGoogleAddress = StreetFullText + LocationCityName + LocationStateName + zipCode + LocationCountryName;
            this.manualSearchGoogleAddress = this.removelastCommaCharacter(this.manualSearchGoogleAddress.trim());
            if (this.addressInvalid(StreetFullText, LocationCityName))
              this.manualSearchGoogleAddressInvalid = true;
            else
              this.manualSearchGoogleAddressInvalid = false;
          }
          if (this.manualSearchAddress && this.manualSearchAddress !== "" && this.manualSearchAddress.length > 0) this.displayManualAddress = true;

          if (this.vsrRecord.ManualSearchInfo && this.vsrRecord.ManualSearchInfo.RelatedToPetitioner === true)
            this.relatedToPetitioner = "Y";
          else
            this.relatedToPetitioner = "N";

          this.manualSearchAddress = this.removelastCommaCharacter(this.manualSearchAddress.trim());

          this.predefManualSearchAddress = new PredfinedInfoRequestAddress();
          this.predefManualSearchAddress.singleLineFullAddress = this.manualSearchAddress;
          this.predefManualSearchAddress.streetFull = StreetFullText;
          this.predefManualSearchAddress.city = LocationCityName;
          this.predefManualSearchAddress.state = LocationStateName;
          this.predefManualSearchAddress.postalCode = LocationPostalCode;
          this.predefManualSearchAddress.country = LocationCountryName;
          this.predefManualSearchAddress.organizationName = this.vsrRecord.PetitionInformation.OrganizationName;
        }

      }
      else
        this.displayManualAddress = false;


    } catch (error) {
      console.log("Error inside checkForDisplayManualAddress, " + JSON.stringify(error));

    }
  }
  private checkFordolInformationAvailable() {
    try {
      if (this.vsrRecord.DOLSummary) {
        this.multipleDolSummary = this.vsrRecord.DOLSummary;
        this.multipleDolSummary = this.multipleDolSummary.sort((b, a) => a.EtaCaseNumber.localeCompare(b.EtaCaseNumber));
        this.selectedDol = this.vsrRecord.DOLSummary[0];
        this.multipleDolEta = this.vsrRecord.PetitionInformation.DolEtaCaseNumber.split(',');

        if (this.multipleDolEta.length > 0) {
          this.selectedEtaNumber = this.vsrRecord.DOLSummary[0].EtaCaseNumber;
          for (let i: number = 0; i < this.multipleDolSummary.length; i++) {
            let item = { ind: i, expanded: false }
            this.selectedRowIndexes.push(item);

          }
        }
        else
          this.selectedEtaNumber = this.vsrRecord.PetitionInformation.DolEtaCaseNumber;

        if (this.vsrRecord.PetitionInformation.PetitionVisaType === "1B1" ||
          this.vsrRecord.PetitionInformation.PetitionVisaType === "E3" ||
          this.vsrRecord.PetitionInformation.PetitionVisaType === "HSC") {
          this.ValidStartDate = "Intended Employment Begin Date";
          this.ValidEndDate = "Intended Employment End Date";
        }
      if (this.vsrRecord.PetitionInformation.PetitionVisaType === "1B1" ||
          this.vsrRecord.PetitionInformation.PetitionVisaType === "E3" ||
          this.vsrRecord.PetitionInformation.PetitionVisaType === "HSC" ||
          this.vsrRecord.PetitionInformation.PetitionVisaType == "H2A" ||
          this.vsrRecord.PetitionInformation.PetitionVisaType == "H2B") {
          if (this.userInRoleService.userInRole.businessAdministrator ||
            this.userInRoleService.userInRole.vibeTeam || this.userInRoleService.userInRole.standardUser ||
            this.userInRoleService.userInRole.cfdoOrRiskAnalyst || this.userInRoleService.userInRole.dolUser) {
              // console.log("the user is a dol    user: " + this.userInRoleService.userInRole.dolUser);
            this.dolHyperLinkActive = true;
            if (!this.userInRoleService.userInRole.dolUser) this.dolSearchButtonActive = true;
            if (this.selectedEtaNumber && this.selectedEtaNumber.includes("-"))
              this.etaCaseNumbeLength = 18;
            if (this.selectedEtaNumber && this.selectedEtaNumber.length > 0)
              this.dolInformationAvailable = true;
          }
          if (this.vsrRecord.DOLSummary[0].DolEtaFormType == "9035") {
            this.display9035DOLSummary();
          }
        }
      }
      else
        this.dolInformationAvailable = false;
    } catch (error) {
      console.log("Error inside checkFordolInformationAvailable, " + JSON.stringify(error));

    }
  }
  private display9035DOLSummary() {
    try {
      if (this.vsrRecord.DOLSummary[0].EtaStatus == 'CERTIFIED'
        || this.vsrRecord.DOLSummary[0].EtaStatus == 'Certified-Withdrawn'
        || this.vsrRecord.DOLSummary[0].EtaStatus == 'CERTIFIED-WITHDRAWN') {
        this.ValidStartDate = "Certification Valid From";
        this.ValidEndDate = "Certification Valid To";
      }
      else
        this.showDOLdates = false;

    } catch (error) {
      console.log("Error inside display9035DOLSummary, " + JSON.stringify(error));

    }
  }

  private checkForDNBCompanyFinancialInformation() {
    try {
      if (this.vsrRecord.DNBCompanyFinancialInformation && this.vsrRecord.DNBCompanyFinancialInformation.GrossAnualIncome) {
        this.hasGrossAnualIncome = true;
        let strGrossAnualIncome = this.vsrRecord.DNBCompanyFinancialInformation.GrossAnualIncome;
        if (strGrossAnualIncome.trim() == "0")
          this.grossAnualIncome = "0";
        else
          this.grossAnualIncome = "$" +
            parseInt(strGrossAnualIncome.substr(0, strGrossAnualIncome.indexOf('|')).trim(), 10).toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1,")
            + " " + (strGrossAnualIncome.substr(strGrossAnualIncome.indexOf('|') + 1)).trim();
        this.grossAnualIncome = this.grossAnualIncome.replace(".00", "");
      }
      else
        this.hasGrossAnualIncome = false;
    } catch (error) {
      console.log("Error inside checkForDNBCompanyFinancialInformation, " + JSON.stringify(error));
    }
  }

  private checkForPredefinedInfo() {
    try {
      // this.userInRoleService.userInRole.businessAdministrator = false;
      // this.userInRoleService.userInRole.dolUser = true;

      if (this.userInRoleService.userInRole.businessAdministrator ||
        this.userInRoleService.userInRole.vibeTeam ||
        this.userInRoleService.userInRole.cfdoOrRiskAnalyst ) {
        this.canRequestPredefinedInfo = true;
      }



      if (this.vsrRecord.VibePreDefinedCompanyScore) {
        this.preDefinedScoreAvailable = true;
        this.vibePreDefinedCompanyScore = this.vsrRecord.VibePreDefinedCompanyScore.OverrideScore;
      }
      else
        this.preDefinedScoreAvailable = false;
      this.expandAllScore = true;
    } catch (error) {
      console.log("Error inside checkForPredefinedInfo, " + JSON.stringify(error));
    }
  }

  private checkForPredefinedAttornyeyInfo() {
    try {
      if (this.vsrRecord.RedAttorney && this.vsrRecord.RedAttorney !== undefined) {
        this.preDefinedAttornyScoreAvailable = true;

        this.showAttorneyScore = true;
        if (this.vsrRecord.RedAttorney.OverrideScore !== undefined && this.vsrRecord.RedAttorney.OverrideScore !== null
          && this.vsrRecord.RedAttorney.OverrideScore !== "")
          this.vibePreDefinedAttorneyScore = this.vsrRecord.RedAttorney.OverrideScore;
        else
          this.vibePreDefinedAttorneyScore = "N/A";
      }
      else
        this.preDefinedAttornyScoreAvailable = false;
   
      this.expandAllScore = true;
    } catch (error) {
      console.log("Error inside checkForPredefinedInfo, " + JSON.stringify(error));
    }
  }

  private checkForPredefinedAddressInfo() {
    try {
      if (this.vsrRecord.RedAddress && this.vsrRecord.RedAddress !== undefined) {
        if (this.vsrRecord.RedAddress.OverrideScore !== undefined && this.vsrRecord.RedAddress.OverrideScore !== null
          && this.vsrRecord.RedAddress.OverrideScore !== "")
          this.vibePreDefinedAddressScore = this.vsrRecord.RedAddress.OverrideScore;
        else
          this.vibePreDefinedAddressScore = "N/A";
        this.preDefinedAddressScoreAvailable = true;
        this.showAddressScore = true;
        this.getPredefInfoAddress();

      }
      else
        this.preDefinedAddressScoreAvailable = false;
             
      this.expandAllScore = true;
    } catch (error) {
      console.log("Error inside checkForPredefinedInfo, " + JSON.stringify(error));
    }
  }

  ExpandAddressScore() {
    this.showAddressScore = !this.showAddressScore;
  }

  ExpandAttorneyScore() {
    this.showAttorneyScore = !this.showAttorneyScore;
  }
  private getPredefInfoAddress() {
    try {
      if (this.vsrRecord.RedAddress && this.vsrRecord.RedAddress !== undefined) {
        {


          let StreetFullText = (this.vsrRecord.RedAddress.Address.StreetFullText == null) ? "" : this.vsrRecord.RedAddress.Address.StreetFullText + ", ";
          let LocationCityName = (this.vsrRecord.RedAddress.Address.LocationCityName == null) ? "" : this.vsrRecord.RedAddress.Address.LocationCityName + ", ";
          let LocationStateName = (this.vsrRecord.RedAddress.Address.LocationStateName == null) ? "" : this.vsrRecord.RedAddress.Address.LocationStateName + ", ";
          let LocationPostalCode = (this.vsrRecord.RedAddress.Address.LocationPostalCode == null) ? "" : this.vsrRecord.RedAddress.Address.LocationPostalCode + ", ";
          let LocationCountryName = (this.vsrRecord.RedAddress.Address.LocationCountryName == null) ? "" : this.vsrRecord.RedAddress.Address.LocationCountryName;

          this.redAddressInfo = StreetFullText + LocationCityName + LocationStateName + LocationPostalCode + LocationCountryName;

          this.redAddressInfo = this.removelastCommaCharacter(this.redAddressInfo.trim());

        }

      }
    } catch (error) {
      console.log("Error inside getPredefInfoAddress, " + JSON.stringify(error));

    }
  }

  private InitBooleans() {
    this.branchInfoAvailable = false;
    this.displayManualAddress = false;
    this.dolInformationAvailable = false;
    this.hasGrossAnualIncome = false;
    this.outOfBusinessIndicator = "";
    this.preDefinedScoreAvailable = false;
    this.resubmitShowModal = false;
    this.showDOLdates = true;
    this.petitionerAddress = "";
    this.manualSearchAddress = "";
    this.branchSearchAddress = "";
    this.DNBMatchedCompanyAddress = "";
    this.branchOrDNBAddressLabel = "IP Matched Address:";
    this.petitionerGoogleAddress = "";
    this.manualSearchGoogleAddress = "";
    this.branchSearchGoogleAddress = "";
    this.DNBMatchedCompanyGoogleAddress = "";
    this.branchOrDNBAddress = "";
    this.branchCompanyInfoAvailable = false;
    if (!this.displayManualSearch) this.pageWidthStyle = "clr-col-sm-12 clr-col-md-12";
  }

  private onResubmitComplete(resubmitStatus: string): void {
    try {
      // console.log("onResubmitComplete called. the status is: " + resubmitStatus);
      let vsrUrl = '/vsr/receipt';// + "WAC1804550499" ; //this.vsrRecord.ReceiptNumber;
      let receipt = this.vsrRecord.ReceiptNumber;
      this.refreshFromService(receipt);
    } catch (error) {
      console.log("Error inside onResubmitComplete, " + JSON.stringify(error));
    }
  }
  private onHidePredefFormModal($event) {
    this.showPredefRequestWizard = false;
  }
  private refreshFromService(receiptNumber): void {
    try {
      this.loading = true;
      this.vsrSvc.getVSR(receiptNumber.toUpperCase()).subscribe(
        data => {
          if (data) {
            try {
              this.loading = false;
              this.vsr = data;
              this.vsrRecord = this.vsr.VsrGetResponse.VsrResultSet.VsrRecord[0] as VsrRecordEntity;
              sessionStorage.setItem("receiptNumber-key", this.vsrRecord.ReceiptNumber.toUpperCase());
              this.refresh();

              this.resubmitComplete.emit(true);
            } catch (error) {
              this.loading = false;
              this.appsAlert = AppSettings.SYSTEM_EXCEPTION;
            }
          }
        }, error => {
          this.loading = false;
          console.log("error happens while retrieving data from the service. " + JSON.stringify(error));
        }
      );
    } catch (error) {
      console.log("Error inside refreshFromService, " + JSON.stringify(error));
    }
  }
  private async  delay(ms: number) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
  onShowModalChange(showModal: boolean): void {

    (async () => {
      await this.delay(5000);
    });

    this.loading = false;
    this.resubmitShowModal = false
  }

  private onResubmitBegin(resubmitStatus: string): void {
    console.log("resubmit is begining..." + resubmitStatus);
    if (resubmitStatus == "")
      this.loading = true;
    else
      this.loading = false;
  }

  private updateVSRStatus(resubmitStatus: string) {
    try {

      if (resubmitStatus === AppSettings.VSR_STATUS_CODE_002) {
        this.loading = false;
        this.resubmitShowModal = false;
        this.showVsr = true;
      }
      else if (resubmitStatus === "in progress") {
        this.loading = true;
        this.showVsr = true;
      }
      else {
        switch (resubmitStatus) {
          case AppSettings.VSR_STATUS_CODE_001:
            this.appsAlert = AppSettings.VSR_STATUS_CODE_001_DESC;
            break;
          case AppSettings.VSR_STATUS_CODE_004:
            this.appsAlert = AppSettings.VSR_STATUS_CODE_004_DESC;
            break;
          default:
            this.appsAlert = AppSettings.VSR_STATUS_CODE_003_DESC;
            break;
        }
        this.showVsr = false;
        this.loading = false;
        this.resubmitShowModal = false;
      }
    } catch (error) {
      console.log("Error inside updateVSRStatus, " + JSON.stringify(error));
    }
  }

  private showScoreCard() {
    try {
      this.scoreCardID = this.vsrRecord.ScoreID;
    } catch (error) {
      console.log("Error inside showScoreCard, " + JSON.stringify(error));
    }
  }

  private locateOnMapClick() {
    try {
      var latlong = this.model.lat + "," + this.model.long
      this.model.fullMap = this.geocodeService.getFullMapForLatLong(latlong)
      window.open(this.model.fullMap, "_blank");
    } catch (error) {
      console.log("Error inside locateOnMapClick, " + JSON.stringify(error));
    }
  }
  private getGeoMapAddress(addressType): any {
    try {
      let address: string = "";
      switch (addressType) {
        case 'PETITION':
          address = this.petitionerGoogleAddress;
          break;

        case 'IIP':
          if (this.vsrRecord.DNBMatchedCompanyInformation.Address)
            address = this.branchOrDNBAddress
          break;

        case 'MANUAL':
          if (this.vsrRecord.ManualSearchInfo)
            address = this.manualSearchGoogleAddress;
          break;

        default:
          address = "";
          break;

      }
      this.getGeoLocationForAddress(address, addressType);

    } catch (error) {
      console.log("Error inside getGeoMapAddress, " + JSON.stringify(error));
    }
  }

  getGeoLocationForAddress(address: string, addressType: string) {
    try {
      this.showMap = true;
      this.showPetitionerAlert = false;
      this.showIIPAlert = false;
      this.showManualAlert = false;
      this.alertMessage = "";
      if (
        (addressType.toUpperCase() == "PETITION" && this.petitionerGoogleAddressInvalid) ||
        (addressType.toUpperCase() == "IIP") && this.branchOrDNBAddressInvalid ||
        (addressType.toUpperCase() == "MANUAL") && this.manualSearchGoogleAddressInvalid) {
        this.showMap = false;
        this.alertMessage = AppSettings.INVALID_ADDRESS_GOOGLE_MAP_NOT_AVAILABLE;
        this.setWarnings(addressType);
      }
      else if (
        address.toUpperCase().includes('P.O.BOX') ||
        address.toUpperCase().includes('P.O. BOX') ||
        address.toUpperCase().includes('P O BOX') ||
        address.toUpperCase().includes('P. O. BOX') ||
        address.toUpperCase().includes('PO BOX') ||
        address.toUpperCase().includes('PO NUMBER') ||
        address.toUpperCase().includes('POST OFFICE') ||
        address.toUpperCase().includes('POST OFFICE BOX')) {
        // console.log('address contains p.o.box');
        this.showMap = false;
        this.alertMessage = AppSettings.PO_BOX_STREET_VIEW_NOT_AVAILABLE;
        this.setWarnings(addressType);
      }
      else {
        try {
          this.geocodeService.getLatLongForAddress(address).subscribe(data => {

            if (data) {
              this.model.lat = JSON.parse(JSON.stringify(data)).results[0].geometry.location.lat;
              this.model.long = JSON.parse(JSON.stringify(data)).results[0].geometry.location.lng;
              var latlong = this.model.lat + "," + this.model.long;
              this.model.fullMap = this.geocodeService.getFullMapForLatLong(latlong);
              this.loadStreetView(addressType);
            } else {
              this.model.lat = 0.0;
              this.model.long = 0.0;
            }
          });
        } catch (error) {
          this.model.lat = 0.0;
          this.model.long = 0.0;
        }
      }
    } catch (error) {
      console.log("Error inside getGeoLocationForAddress, " + JSON.stringify(error));
    }
  }
  private setWarnings(addressType) {
    switch (addressType) {
      case 'PETITION':
        this.showPetitionerAlert = true;
        break;
      case 'IIP':
        this.showIIPAlert = true;
        break;
      case 'MANUAL':
        this.showManualAlert = true;
        break;
      default:
        /// to clear warnings
        this.showPetitionerAlert = false;
        this.showIIPAlert = false;
        this.showManualAlert = false;
        break;
    }
  }

  async loadStreetView(addressType): Promise<void> {
    try {

      this.showMap = true;
      this.setWarnings("");
      urlSettings.key = AppSettings.API_KEY;
      urlSettings.version = null;
      const Maps = await load();


      // console.log(this.model.lat + this.model.long)
      var latlong = new Maps.LatLng(this.model.lat, this.model.long);
      // Or you can use `new google.maps.Map` instead
      var svService = new Maps.StreetViewService();
      var panoRequest = {
        location: latlong,
        preference: google.maps.StreetViewPreference.NEAREST,
        radius: 50,
        source: google.maps.StreetViewSource.OUTDOOR
      };


      new Maps.Map(document.getElementById('map'), {
        center: new Maps.LatLng(0.0, 0.0),
        zoom: 14
      });
      var self = this
      var something = svService.getPanorama(panoRequest, function (panoData, status) {
        // console.log(panoData);
        // console.log(status)

        if (status.toString() == 'OK') {

          new Maps.StreetViewPanorama(
            document.getElementById('map'),
            {
              pano: panoData.location.pano,
              pov: { heading: 280, pitch: 0 },
            });

        } else {
          self.setWarnings(addressType);
          self.alertMessage = AppSettings.GOOGLEMAPS_NO_STREETVIEW;
          try {
            var map = new Maps.Map(document.getElementById('map'), {
              center: latlong,
              zoom: 14
            });
            var marker = new Maps.Marker({
              position: latlong,
              map: map,
              title: "Location"
            });

          }
          catch (error) {
            console.log(error)
            self.showMap = false;
            self.alertMessage = AppSettings.GOOGLEMAPS_NO_MAP;
          }

          //Handle other statuses here

        }
      });

    } catch (error) {
      console.log("Error inside loadStreetView, " + JSON.stringify(error));
    }
  }

  private manualSearchClick() {
    this.resubmitShowModal = !this.resubmitShowModal;
  }

  private DOLManualSearchModalCancelled() {
    this.dolSearchForm.reset();
    this.DOLManualSearchModal = false;
    this.dolAlertMessage = "";
  }
  private ExpandAll() {
    try {
      let expanded: boolean = true;
      this.expandAll = true;
      for (let i = 0; i < this.selectedRowIndexes.length; i++) {
        this.selectedRowIndexes[i].expanded = expanded;
      }
    } catch (error) {
      console.log("Error inside ExpandAll, " + JSON.stringify(error));
    }
  }
  private CollapseAll() {
    try {
      let expanded: boolean = false;

      this.expandAll = false;
      for (let i = 0; i < this.selectedRowIndexes.length; i++) {
        this.selectedRowIndexes[i].expanded = expanded;
      }
    } catch (error) {
      console.log("Error inside CollapseAll, " + JSON.stringify(error));
    }
  }



  private ExpandAllScore() {
    try {
      let expanded: boolean = true;
      this.expandAllScore = true;
      this.showAddressScore = true;
      this.showAttorneyScore = true;
    } catch (error) {
      console.log("Error inside ExpandAllScore, " + JSON.stringify(error));
    }
  }
  private CollapseAllScore() {
    try {
      let expanded: boolean = false;

      this.expandAllScore = false;
    } catch (error) {
      console.log("Error inside CollapseAllScore, " + JSON.stringify(error));
    }
  }


  private expandCollapseThisOnly(index) {
    this.selectedRowIndexes[index].expanded = !this.selectedRowIndexes[index].expanded;
  }

  private DOLManualSearchShowModal() {
    this.DOLManualSearchModal = true;
    this.visibilityChanged = true;
  }

  private updateDolInfoByCaseNumber(data: DolProxy, etaCaseId: string) {
    try {
      let dolEtaSearchParams: string[] = [];

      dolEtaSearchParams.push("");
      dolEtaSearchParams.push(data.GetDolDetailByEtaCaseNumberResponse.DolEtaFormType);
      dolEtaSearchParams.push(data.GetDolDetailByEtaCaseNumberResponse.DolEtaFormVersion);
      dolEtaSearchParams.push(etaCaseId);
      dolEtaSearchParams.push("");

      this.etaSearchComplete.emit(dolEtaSearchParams);
    } catch (error) {
      console.log("Error inside updateDolInfoByCaseNumber, " + JSON.stringify(error));
    }
  }

  private updateDolByPetitionerID(etaCaseId: string) {
    try {
      let dolEtaSearchParams: string[] = [];
      let ind: number = 0;
      if (etaCaseId && etaCaseId !== "" && etaCaseId !== null) {
        if (this.multipleDolEta.length > 1) {
          for (let i: number = 0; i < this.multipleDolSummary.length; i++) {
            if (this.vsrRecord.DOLSummary[i].EtaCaseNumber == etaCaseId) {
              ind = i;
              this.etaPetitionId = this.vsrRecord.DOLSummary[i].PetitionID;
            }
          }
        }

        dolEtaSearchParams.push(this.vsrRecord.DOLSummary[ind].PetitionID);
        dolEtaSearchParams.push(this.vsrRecord.DOLSummary[ind].DolEtaFormType);
        dolEtaSearchParams.push(this.vsrRecord.DOLSummary[ind].DolEtaFormVersion);
        dolEtaSearchParams.push(etaCaseId);
        dolEtaSearchParams.push(this.vsrRecord.DOLSummary[ind].DolEtaClobId);
        this.etaSearchComplete.emit(dolEtaSearchParams);
      }
    } catch (error) {
      console.log("Error inside updateDolByPetitionerID, " + JSON.stringify(error));
    }
  }




  private getDolCaseData(etaCaseId: string) {
    try {
      if (etaCaseId && etaCaseId !== "" && etaCaseId !== null) {
        this.loading = true;
        this.dolEtaService.getDolByCaseId(etaCaseId.toUpperCase().replace(/-/g, '')).subscribe(
          data => {
            this.loading = false;
            let clobId: string = "";
            if (data && !JSON.stringify(data).includes("Error") && !JSON.stringify(data).includes("ESB2Exception")
              && !JSON.stringify(data).includes("ESB-VIBE.STATUS.001")) {

              try {

                this.dol = <DolData>JSON.parse(data.GetDolDetailByEtaCaseNumberResponse.DolJsonData);
                this.dolEta = <DOLDATA>this.dol.DOL_DATA
                if (this.dolEta.DOL_ETA_CLOB) {
                  if (this.dolEta.DOL_ETA_CLOB.RESPONSECODE !== "NO_DATA" &&
                    !JSON.stringify(data).includes(AppSettings.VSR_EXCEPTION_CODE_0108)) {
                    if ((data.GetDolDetailByEtaCaseNumberResponse.DolEtaFormType !== '9035')) {
                      if (data.GetDolDetailByEtaCaseNumberResponse.DolEtaFormType !== '9142' 
                      && data.GetDolDetailByEtaCaseNumberResponse.DolEtaFormType !== '9142C'
                      && data.GetDolDetailByEtaCaseNumberResponse.DolEtaFormType !== '9142A'
                      && data.GetDolDetailByEtaCaseNumberResponse.DolEtaFormType !== '9142B') {
                        this.dolAlertMessage = "Unsupported DOL Form Type " + data.GetDolDetailByEtaCaseNumberResponse.DolEtaFormType
                        this.loading = false;
                        return;
                      }
                    }
                    this.DOLManualSearchModal = false;
                    this.updateDolInfoByCaseNumber(data, etaCaseId);
                  }
                  else {
                    // console.log("DOL has no data the response includes: " + JSON.stringify(data));
                    if (JSON.stringify(data).includes(AppSettings.VSR_EXCEPTION_CODE_0107))
                      this.dolAlertMessage = AppSettings.VSR_EXCEPTION_CODE_0107_DESC;
                    else
                      if (JSON.stringify(data).includes(AppSettings.VSR_EXCEPTION_CODE_0108))
                        this.dolAlertMessage = AppSettings.VSR_EXCEPTION_CODE_0108_DESC;
                      else
                        this.dolAlertMessage = "DOL case not found.";
                    this.loading = false;
                  }
                }
                else {
                  // console.log("JSON.stringify(data) is " + JSON.stringify(data));
                  if (JSON.stringify(data).includes(AppSettings.VSR_EXCEPTION_CODE_0107))
                    this.dolAlertMessage = AppSettings.VSR_EXCEPTION_CODE_0107_DESC;
                  else
                    if (JSON.stringify(data).includes(AppSettings.VSR_EXCEPTION_CODE_0108))
                      this.dolAlertMessage = AppSettings.VSR_EXCEPTION_CODE_0108_DESC;
                    else
                      this.dolAlertMessage = "DOL case not found.";
                  this.loading = false;
                }


              } catch (error) {
                console.log("error happens while retrieving dol data from the service. " + JSON.stringify(error));
                this.dolAlertMessage = JSON.stringify(error);
                this.loading = false;
              }
            }
            else {
              if (data && JSON.stringify(data).includes("ESB2Exception")) {
                this.dolAlertMessage = AppSettings.SYSTEM_EXCEPTION;
                this.loading = false;
              }
            }
          },
          error => {
            console.log("error happens while retrieving dol data from the service. " + JSON.stringify(error));
            this.dolAlertMessage = JSON.stringify(error);
            this.loading = false;
          }
        );
        this.etaCaseIdNum = "";
      }
      else {

        // console.log("the etacase number is: " + etaCaseId);
        this.dolAlertMessage = "Please enter a valid DOL Case Number.";
      }
    }
    catch (error) {
      console.log("Error inside getDolCaseData, " + JSON.stringify(error));
    }
  }


  private getPreviousFilingsByDunsAndOrgName(prevsdunsNum: string, prevsOrgName, prevsPetitionType, dolCaseNum) {

    try {
      let pfsParams: string[] = [];
      pfsParams.push(prevsdunsNum);
      pfsParams.push(prevsOrgName);
      pfsParams.push(prevsPetitionType);
      pfsParams.push(dolCaseNum);

      // console.log("Inside getPreviousFilingsByDunsAndOrgName." + pfsParams[0] + ",  " + pfsParams[1] + ",  " + pfsParams[2] + pfsParams[3])
      this.pfsSearchBegin.emit(pfsParams);
    } catch (error) {
      console.log("error while processing previous filings.")
    }

  }
  private getPreviousFilingsByDolCase(dolCaseNum: string) {
    try {

      if (dolCaseNum && dolCaseNum !== "" && dolCaseNum !== null) {
        // console.log("the dolCaseNum number is: " + dolCaseNum);
        this.loading = true;

        this.pfSvc.getPreviousFilingsByDolcase(dolCaseNum.toUpperCase().replace(/-/g, '')).subscribe(
          data => {
            try {
              if (data && !JSON.stringify(data).includes("Error") && !JSON.stringify(data).includes(AppSettings.VSR_EXCEPTION_CODE_0108)) {
                // console.log("preivious filings data returned. " + JSON.stringify(data));
                this.previousFiling = JSON.parse(JSON.stringify(data).replace("PreviousFilings-GetByDolCaseNumberResponse", "PreviousFilingsGetByDolCaseNumberResponse"));
                this.showEta = true;
                this.loading = false;
                this.pfsSearchComplete.emit(this.previousFiling);
              }
              else {
                // console.log("JSON.stringify(data) is " + JSON.stringify(data));
                this.loading = false;
              }
            } catch (error) {
              console.log("error happens while retrieving dol data from the service. " + JSON.stringify(error));
              this.loading = false;
            }
          },
          error => {
            console.log("error happens while retrieving dol data from the service. " + JSON.stringify(error));
            this.dolAlertMessage = JSON.stringify(error);
            this.loading = false;
          }
        );
      }
      else this.dolAlertMessage = "Please enter a valid DOL Case Number.";
    } catch (error) {
      console.log("Error inside getPreviousFilingsByDolCase, " + JSON.stringify(error));

    }
  }
  private getScoreResultStyle(ScoreCodeType): any {
    switch (ScoreCodeType) {
      case 'GREEN':
        return { color: 'white', 'background-color': 'green', 'font-weight': 'bold' };
      case 'RED':
        return { color: 'black', 'background-color': 'red', 'font-weight': 'bold' };
      case 'ORANGE':
        return { color: 'black', 'background-color': 'orange', 'font-weight': 'bold' };
      case 'YELLOW':
        return { color: 'black', 'background-color': 'yellow', 'font-weight': 'bold' };
      case 'BLUE':
        return { color: 'white', 'background-color': 'blue', 'font-weight': 'bold' };
      default:
        return {};
    }
  }

  private getAdjudicativeStatusStyle(): any {
    let status = this.vsrRecord.AdjudicativeStatus;
    switch (status) {
      case 'APPROVED':
        return "assets/approved.png";
      case 'PENDING':
        return "assets/pending.png";
      case 'DENIED':
        return "assets/denied.png";
      case 'DENIED FRAUD':
        return "assets/deniedFraud.png";
      case 'REJECTED':
        return "assets/rejected.png";
      case 'CLOSED':
        return "assets/closed.png";
      default:
        return "assets/unknown.svg";
    }
  }

}



export class Scorecard {
  BusinessRuleName: string;
  Score: string;
  public constructor(
    fields?: {
      BusinessRuleName: string;
      Score: string;
    }) {
    if (fields) Object.assign(this, fields);
  }
}
