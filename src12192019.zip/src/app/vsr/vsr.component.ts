import { Component, OnInit, ViewChild, ElementRef, OnDestroy, Input } from '@angular/core';
import { VsrSearchService } from '../vsr-search.service';
import { Observable, of, Subscription } from 'rxjs';
import { GeocodeService } from '../geocode.service';
import { AppSettings } from '../shared/app-settings';
import { strictEqual } from 'assert';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

import { VsrRecordEntity, Vsr } from 'src/app/shared/vsr';
import {  VsrResubmit, VsrResubmitResponse, VSRResubmitRequest } from '../shared/vsr-resubmit';
import { Dol, DOLDATA } from '../shared/dol_interfaces';
import { Previousfiling } from '../shared/previous_filings_interfaces';
import { SmartSearchBoxComponent } from '../smart-search-box/smart-search-box.component';
import { SmartSearchService } from '../smart-search.service';
import { ComponentStatus } from '../shared/service/component-status';
import { ComponentStatusService } from '../shared/service/component-status.service';
import { DolManualSearchService } from '../shared/service/dol-manual-search.service';

import { VSRResubmitAddress } from '../shared/vsr-resubmit';

@Component({
  selector: 'app-vsr',
  templateUrl: './vsr.component.html',
  styleUrls: ['./vsr.component.css'],
  providers: [GeocodeService]
})

export class VsrComponent implements OnInit {

  @Input() receiptNumber: string =""; 

  //private vsrUrl = '/vibe-plus/rest/vsr/receipt/';
  loading = false;
  predefLoading = false;
  dolManualSearch: boolean =false; //show the DOL manual search 
  dolAddress: VSRResubmitAddress = new VSRResubmitAddress(); 
  vsrDolResubmitResponse: VsrResubmitResponse;
  showVsrDolResubmitResponse:boolean = false;
  petitionerAddress: string = "";
  searchBy: string = "Receipt Number";
  showVsr: boolean = false;
  show9142: boolean = false;
  show9142C: boolean = false;
  show9142A: boolean = false;
  show9035v1: boolean = false;
  show9035v2: boolean = false;
  show9142Bv2: boolean = false;
  dolInformationAvailable: boolean = false;
  showDOL_ETAPreviousFilings: boolean = false;
  showUSCISPreviousFilings: boolean = false;
  appsAlert: string = "";
  noVsrHistory: boolean = false;
  showVsrHistory: boolean = true;
  vsrHistoryActive: boolean = true;
  historyLoadingState: boolean = false;
  vsrActive: boolean = false;
  showDOL_ETA: boolean = false;
  DOL_ETA_Active: boolean = false;
  DOL_ETAPreviousFilingsActive: boolean = false;
  USCISPreviousFilingsActive: boolean = false;
  pfDunsNum: string = "";
  pfOrganizationName: string = "";
  pfPetitionType: string = "";
  etaDOLCaseNum: string = "";
  vsr: Vsr;
  vsrDOL: DOLDATA;
  pfsShowSmartMenu: boolean = false;
  previousFiling: Previousfiling;
  etaPetitionId: string = "";
  etaFormType: string = "";
  etaFormVersion: string = "";
  dolEtaClobId: string = "";
  manualSearchCaseNum: string = "";
  selectedVsrRecord: VsrRecordEntity;
  vsrHistoryRecords: VsrRecordEntity[];
  displayManualSearchButton: boolean = true;
  searchSubscription: Subscription;
  manualReceipt: string = "";
  model = {
    searchById: "", //"WAC1802550980" //WAC1419550371 - no DOL,
    lat: 38.8977643,
    long: -77.0106754,
    streetView: '',
    fullMap: ''

  }


  private vsrSvc: VsrSearchService;

  searchTypes = ["VSR", "USCIS Previous Filings", "DOL Previous ETA Filings", "DOL ETA Lookup"];
  searchCriteria = ["Receipt Number"];



  cssSubscription: Subscription;
  cssStatusService: ComponentStatusService;
  dolManualSearchService: DolManualSearchService;

  constructor(
    private vsrSearchService: VsrSearchService,
    private geocodeService: GeocodeService,
    private ssb: SmartSearchService,
    private router: Router,
    private css: ComponentStatusService, 
    private dmss: DolManualSearchService) {

    this.vsrSvc = vsrSearchService;
    this.cssStatusService = css;
    this.dolManualSearchService=dmss; 
    this.dolManualSearch=false; 
    this.showVsrDolResubmitResponse = false;

    //  Object.assign(this, {this.single, multi})  
    this.cssSubscription = this.css.currentMessage.subscribe(message => {
    
    if ((message.destComponentName === AppSettings.CS_VSR) &&
      (message.clear)){
        console.log("css: reset message received for VSR.");
        this.model.searchById="";
        this.showVsr = false;
        this.appsAlert = "";
        console.log("ERROR=" + message.error)
        if (this.dolManualSearch) {
          this.dolManualSearch = false;
        } else  {
          this.dolManualSearch = true;
        }
        
      }

      if ((message.destComponentName === AppSettings.CS_VSR) &&
          (message.srcComponentName === AppSettings.CS_SSB)  && 
          ((this.selectedVsrRecord === undefined) || (this.selectedVsrRecord == null)) && 
          (message.data==="dolManualSearch")){
        console.log("css: dol address search ");
        this.model.searchById="";
        this.showVsr = false;
        this.appsAlert = "";
        console.log("ERROR=" + message.error)
        this.dolManualSearch = true;
      }
    });

      

    //integration point with SSB
    this.searchSubscription = this.ssb.currentMessage.subscribe(message => {
      if ((message.selectedSearchType == "vsr") && (message.selectedSearchFunction == "dolAddr")){
        this.model.searchById="";
        this.appsAlert = "";
        this.showVsr = false;
        this.dolManualSearch=true;
        this.showVsrDolResubmitResponse = true;
      }else{
        this.dolManualSearch=false;
        this.showVsrDolResubmitResponse = false;
      }

      if (
        (message.selectedSearchType == "vsr") &&
        (message.selectedSearchFunction == "receiptNumber") &&
        (message.searchById != "") &&
        (message.searchById != undefined)) {
        this.model.searchById = message.searchById        
        this.dolManualSearch=false;
        this.showVsrDolResubmitResponse = false;
        //console.log("this.model.searchById="+this.model.searchById); 
        if (message && (message.error !== undefined) && message.error !== "") {
          this.showVsr = false;
          this.appsAlert = "";
        }
        else
          this.getVsrButtonClicked();
        message.searchById = "";

      }
      else {
        this.appsAlert = "";
        if (message && (message.error !== undefined) && message.error !== "") this.showVsr = false;
      }
    }
    );
  }
  ngOnInit() {

    if (this.receiptNumber!==""){
      this.model.searchById = this.receiptNumber; 
      this.initProperties()
      this.refresh();
  
    }else if (this.model.searchById !== "") {
      console.log("starting to get vsr history data in the background...");
      this.getVsrHistoryInfoFromService();

    }else if (this.router.url.includes('receipt')) {
      var urlarr = this.router.url.split("/");
      this.model.searchById = urlarr[urlarr.length - 1];
      if (this.model.searchById.includes('sessionId'))
        this.model.searchById = sessionStorage.getItem("receiptNumber-key");
      this.initProperties()
      this.refresh();
    }

    this.manualReceipt = this.model.searchById;
    
  }

  ngOnDestroy() {
    this.searchSubscription.unsubscribe();
  }
  private initProperties() {
    this.showVsrHistory = true;
    this.dolInformationAvailable = false;
    this.showDOL_ETAPreviousFilings = false;
    this.showUSCISPreviousFilings = false;
    this.noVsrHistory = false;
    this.vsrHistoryActive = false;
    this.vsrActive = false;
    this.showDOL_ETA = false;
    this.DOL_ETA_Active = false;
    this.DOL_ETAPreviousFilingsActive = false;
    this.USCISPreviousFilingsActive = false;
    this.pfDunsNum = "";
    this.pfOrganizationName = "";
    this.pfPetitionType = "";
    this.etaDOLCaseNum = "";
    this.etaPetitionId = "";
    this.manualSearchCaseNum = "";
    this.dolManualSearch=false;
    this.showVsrDolResubmitResponse = false;

  }



  private displayHistory() {
    //console.log("there are " + this.vsrHistoryRecords.length + "history records.");
    this.showVsrHistory = true;
    this.historyLoadingState = false;
  }

  private vsrTabClicked() {
    this.vsrActive = true;

  }

  private onSelect(category) {
    this.searchBy = category;
    this.model.searchById = "";

  }

  onVsrRecordRefreshed(vsrRecord: VsrRecordEntity) {
    this.selectedVsrRecord = vsrRecord;

  }
  private async  delay(ms: number) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  private onresubmitComplete() {
    this.model.searchById = sessionStorage.getItem("receiptNumber-key");
    // try {      
    // let url =   'sessionId';
    // this.router.navigate(['/vsr/receipt/', url]);
    // } catch (error) {

    // }

    this.refresh();
    this.showVsrHistory = true;
  }


  private onGetVSRHistoryComplete(vsrRecords: VsrRecordEntity[]) {
    this.vsrHistoryRecords = vsrRecords;

  }
  private onEtaSearchComplete(pvf: string[]) {

    if (pvf) {
      console.log("there is dol inside vsr.");
      if (pvf[0] != undefined) this.etaPetitionId = pvf[0];
      if (pvf[1] != undefined && pvf[1] !== "") this.etaFormType = pvf[1];
      if (pvf[2] != undefined && pvf[2] !== "") this.etaFormVersion = pvf[2];
      if (pvf[3] != undefined && pvf[3] !== "") this.manualSearchCaseNum = pvf[3];
      if (pvf[4] != undefined && pvf[4] !== "") this.dolEtaClobId = pvf[4];
      console.log("the etaPetitionId is: " + pvf[0]);
      console.log("the etaFormType is: " + pvf[1]);
      console.log("the etaFormVersion is: " + pvf[2]);
      console.log("the manualSearchCaseNum is: " + pvf[3]);
      console.log("the dolEtaClobId is: " + pvf[4]);
      this.displayDOLEtaTab();
    }
  }

  private displayDOLEtaTab() {
    if (this.etaFormType == "9142") {
      this.show9142 = true;
      this.show9035v1 = false;
      this.show9035v2 = false;
      this.show9142C= false;
      this.show9142A = false;
      this.show9142Bv2 = false;
    }
    else if (this.etaFormType == "9035" && this.etaFormVersion == "1") {
      this.show9035v1 = true;
      this.show9142 = false;
      this.show9035v2 = false;
      this.show9142C= false;
      this.show9142A = false;
      this.show9142Bv2 = false;
    } else if (this.etaFormType == "9035" && this.etaFormVersion == "2"){
      this.show9035v2 = true;
      this.show9142 = false;
      this.show9035v1 = false;
      this.show9142C= false;
      this.show9142A = false;
      this.show9142Bv2 = false;
    } else if (this.etaFormType == "9142C"){
      this.show9142C= true;
      this.show9142= false;
      this.show9035v1=false;
      this.show9035v2=false; 
      this.show9142A = false;
      this.show9142Bv2 = false;
    } else if (this.etaFormType == "9142A"){
      this.show9142A = true;
      this.show9142C= false;
      this.show9142= false;
      this.show9035v1=false;
      this.show9035v2=false;
      this.show9142Bv2 = false;
    }else if (this.etaFormType == "9142B"){
      this.show9142Bv2 = true;
      this.show9142A = false;
      this.show9142C= false;
      this.show9142= false;
      this.show9035v1=false;
      this.show9035v2=false;
      

    }

    this.showDOL_ETA = true;
    this.DOL_ETA_Active = true;
    this.vsrActive = false;

    console.log("inside displayDOLEtaTab, the prevFilings values are: " + this.pfDunsNum + ", " + this.pfOrganizationName + ", " + this.pfPetitionType + ", " + this.dolEtaClobId);
  }

  private onPFSSearchBegin(pvf: string[]) {
    if (pvf) {
      console.log("INSIDE VSR. the etadolcasenum is: " + pvf[3] + "pvf0 is: " + pvf[0]);
      if (pvf[0] != undefined && pvf[0] !== "") this.pfDunsNum = pvf[0];
      if (pvf[1] != undefined && pvf[1] !== "") this.pfOrganizationName = pvf[1];
      if (pvf[2] != undefined && pvf[2] !== "") this.pfPetitionType = pvf[2];
      if (pvf[3] != undefined && pvf[3] !== "") this.etaDOLCaseNum = pvf[3];
      if (pvf[3] != undefined && pvf[3] !== "" && this.etaDOLCaseNum !== "")
        this.displayETAPreviousFilingsTab();
      else
        this.displayUSCISPreviousFilingsTab();
    }


    console.log("there is previous filing data inside vsr. the pfDunsNum is: " + pvf[0] + "pvf0 is: " + this.pfDunsNum);
    console.log("there is previous filing data inside vsr. the pfOrganizationName is: " + pvf[1] + "pvf0 is: " + this.pfOrganizationName);
    console.log("there is previous filing data inside vsr. the pfPetitionType is: " + pvf[2] + "pvf0 is: " + this.pfPetitionType);
    console.log("there is previous filing data inside vsr. the etaDOLCaseNum is: " + pvf[3] + "pvf0 is: " + this.etaDOLCaseNum);
  }

  private displayETAPreviousFilingsTab() {
    if (this.etaDOLCaseNum && this.etaDOLCaseNum !== "") {

      this.USCISPreviousFilingsActive = false;
      this.DOL_ETAPreviousFilingsActive = true;
      this.showDOL_ETAPreviousFilings = true;

      this.vsrActive = false;
    }


    console.log("inside displayETAPreviousFilingsTab, the prevFilings values are: " + this.pfDunsNum + ", " + this.pfOrganizationName + ", " + this.pfPetitionType + ", " + this.etaDOLCaseNum);
  }

  private displayUSCISPreviousFilingsTab() {
    if (this.pfDunsNum && this.pfDunsNum !== undefined && this.pfDunsNum !== "") {
      this.USCISPreviousFilingsActive = true;

      this.DOL_ETAPreviousFilingsActive = false;
      this.showUSCISPreviousFilings = true;
      console.log(" this.showUSCISPreviousFilings is: " +  this.showUSCISPreviousFilings);
    }
    this.vsrActive = false;
  }

  private getVsrButtonClicked(): void {
    this.appsAlert = "";
    this.initProperties();
    // console.log("inside getVsrButtonClicked this.model.searchById" + this.model.searchById);
    if (this.model.searchById !== "") {
      this.refresh();
    }
    else {
      this.appsAlert = "Please enter a valid Search Id Number.";
      this.loading = false;
      this.showVsr = false;
    }

  }

  refresh(): void {
    this.pfDunsNum = "";
    this.vsrHistoryRecords = [];
    this.showVsr = false;
    this.dolInformationAvailable = false;
    this.loading = true;
    console.log("here is the receipt. " + this.model.searchById.toUpperCase());
    this.vsrSvc.getVSR(this.model.searchById.toUpperCase()).subscribe(
      data => {
        this.loading = false;
        if (data && !JSON.stringify(data).includes("Error") && !JSON.stringify(data).includes("ESB2Exception")) {
          this.vsr = data;
            //console.log(JSON.stringify(this.vsr));
          this.selectedVsrRecord = this.vsr.VsrGetResponse.VsrResultSet.VsrRecord[0] as VsrRecordEntity;
          this.appsAlert = "";
          this.showVsr = true;
          if (this.selectedVsrRecord.DOLSummary) {
            console.log("the caseNumber in dolsummary is:  " + this.selectedVsrRecord.DOLSummary[0].EtaCaseNumber);
            this.dolInformationAvailable = true;
          }
          sessionStorage.setItem("receiptNumber-key", this.selectedVsrRecord.ReceiptNumber);

          (async () => {
            // this.loading = false;
            //await this.delay(5000);  //when simulating a long delay or timeout from a service.
            // console.log('fetching history data after 5 sec delay');
            this.getVsrHistoryInfoFromService();
          })();
        }
        else {
          
          this.loading = false;
          this.noVsrHistory = true;
          if (JSON.stringify(data).includes(AppSettings.VSR_EXCEPTION_CODE_0107))
            this.appsAlert = AppSettings.VSR_EXCEPTION_CODE_0107_DESC;
          else if (JSON.stringify(data).includes(AppSettings.VSR_EXCEPTION_CODE_0108))
            this.appsAlert = AppSettings.VSR_EXCEPTION_CODE_0108_DESC;
          else if (JSON.stringify(data).includes(AppSettings.VSR_EXCEPTION_CODE_0500))
            this.appsAlert = AppSettings.VSR_EXCEPTION_CODE_0500_DESC;
          else
          this.appsAlert = AppSettings.SYSTEM_EXCEPTION;
         
          this.loading = false;

        }
      }, error => {
        (async () => {
          // await this.delay(1000);  //when simulating a long delay or timeout from a service.

          this.loading = false;
          this.noVsrHistory = true;
          if (JSON.stringify(error).includes(AppSettings.VSR_EXCEPTION_CODE_0107))
            this.appsAlert = AppSettings.VSR_EXCEPTION_CODE_0107_DESC;
          else if (JSON.stringify(error).includes(AppSettings.VSR_EXCEPTION_CODE_0108))
            this.appsAlert = AppSettings.VSR_EXCEPTION_CODE_0108_DESC;
          else if (JSON.stringify(error).includes(AppSettings.VSR_EXCEPTION_CODE_0500))
            this.appsAlert = AppSettings.VSR_EXCEPTION_CODE_0500_DESC;
          else
          {this.appsAlert = AppSettings.SYSTEM_EXCEPTION;
         
        }


        })();
      }
    );
    this.model.searchById = "";
  }

  private switchTabs() {
  }
  private switchActiveTabs() {
    // console.log("the history records count is:  " + this.vsrHistoryRecords.length);
  }

  private getVsrHistoryInfoFromService() {
    this.historyLoadingState = true;
    this.vsrSearchService.getVSRHistory(sessionStorage.getItem("receiptNumber-key").toUpperCase()).subscribe(mainData => {
      if (mainData && !JSON.stringify(mainData).includes("Error") && !JSON.stringify(mainData).includes("ESB2Exception")) {
        this.loading = false;
        this.vsrHistoryRecords = mainData.VsrGetResponse.VsrResultSet.VsrRecord;
        this.historyLoadingState = false;
        sessionStorage.setItem("receiptNumber-key", "");
        console.log("the history records count is:  " + this.vsrHistoryRecords.length);
        if (this.vsrHistoryRecords.length > 1)
          this.displayHistory();
        else
          this.showVsrHistory = false;
      }
      else {
        this.loading = false;
        this.showVsrHistory = false;
        this.noVsrHistory = true;
        this.vsrHistoryActive = false;
        this.historyLoadingState = false;
        console.log("no history data. the this.model.searchById.toUpperCase() is: " + this.model.searchById.toUpperCase());
      }
    }, error => {
      (async () => {
        //await delay(10000);  //when simulating a long delay or timeout from a service.
        console.log('error hapened.');

        this.historyLoadingState = false;
        this.loading = false;
        this.showVsrHistory = false;
        this.appsAlert = "Error while fetching history data, " + AppSettings.SYSTEM_EXCEPTION;

      })();
    });
  }
  OnAddressInputDialogOpened(opened:boolean)
  {
    console.log("it's opened.");
    if(opened) {      
      this.showUSCISPreviousFilings = false;
      this.pfDunsNum = "";
      this.appsAlert = "";
      this.showVsr = false;
    }
  }

  dolManualSearchHandler(address) {
    console.log("!!!Search received address");
    console.log(address);

    let reqAddress: VSRResubmitRequest = new VSRResubmitRequest(); 
    reqAddress.sourceSystemID = "";
    reqAddress.sourceTransactionID = "";
    reqAddress.receiptNumber = "";
    reqAddress.duns = "";
    reqAddress.endUserID = "";
    reqAddress.address = address;


    let response : VsrResubmit; 
    this.loading = true;
    //response = this.dolManualSearchService.dolManualRequestInJson(address); 
    this.dolManualSearchService.dolManualRequestInJson(reqAddress)
          .subscribe(resubmitResponse => {
              this.returnResubmitDolResponse(resubmitResponse, reqAddress);
          },
              error => {
                  (async () => {

                    this.loading = false;
                      console.log("error is thrown: " + error);
                  })();

                  this.loading = false;
              }
          );
  }


  private returnResubmitDolResponse(resubmitResponse: VsrResubmit, reqAddress:VSRResubmitRequest) {
    this.loading = false;
    this.vsrDolResubmitResponse = resubmitResponse.VsrResubmitResponse;
    if (this.vsrDolResubmitResponse.VsrResultSet.totalRecordCount < 1) {
      this.appsAlert = AppSettings.VSR_STATUS_CODE_001_DESC;      
      this.loading = false;
    }
    else {
      this.selectedVsrRecord = this.vsrDolResubmitResponse.VsrResultSet.VsrRecord[0] as VsrRecordEntity;
      console.log("the vsrDolResubmitResponse is: " + this.selectedVsrRecord);
      this.appsAlert = "";
      this.showVsr = true;
      this.showVsrDolResubmitResponse = true;
      
      this.loading = false;
    }

  }
  

  private removelastCommaCharacter(str: string): string {
    if (str !== null && str.length > 0 && str.charAt(str.length - 1) == ',') {
      str = str.substring(0, str.length - 1);
    }
    return str;
  }
}
