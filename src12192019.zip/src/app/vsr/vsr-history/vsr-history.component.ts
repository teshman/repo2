import { Component, OnInit, SimpleChanges, OnChanges, Input, Output, EventEmitter } from '@angular/core';
import { ClrDatagridSortOrder } from '@clr/angular';
import { delay } from 'rxjs/operators';
import { VsrRecordEntity } from '../../shared/vsr';
import { VsrSearchService } from '../../vsr-search.service';
import { VsrProxy } from '../../shared/vsr-proxy';
import { AppSettings } from '../../shared/app-settings';
import { VsrComponent } from '../vsr.component';

@Component({
  selector: 'app-vsr-history',
  templateUrl: './vsr-history.component.html',
  styleUrls: ['./vsr-history.component.css']
})
export class VsrHistoryComponent implements OnInit, OnChanges {
  @Input() vsrRecords: VsrRecordEntity[];
  @Output() getVSRHistoryComplete: EventEmitter<VsrRecordEntity[]> = new EventEmitter<VsrRecordEntity[]>();
  vsrSelectedRecords: VsrRecordEntity[] = [];
  vsrSortedRecords: VsrRecordEntity[] = [];
  sortDirection = "arrow right";

  organizationDataSourceSortDirection: string = "two-way-arrows";
  scoreRunTimeStampSortDirection: string = "two-way-arrows";
  scoreSortDirection: string = "two-way-arrows";
  organizationDataSourceSortStyle: string = "transform: rotate(90deg);";
  scoreRunTimeStampSortStyle: string = "transform: rotate(90deg);";
  scoreSortStyle: string = "transform: rotate(90deg);";
  organizationDataSourceTitle: string = "";
  scoreRunTitle: string = "";
  scoreTitle: string = "";
  appsAlert: string = "";
  loading: boolean = false;
  viewMode: boolean = false;
  showHistory: boolean = true;
  rowSelection: boolean = true;
  compareMessage: string = AppSettings.MAX_RECORDS_TO_COMPARE_WARNING;
  maxRecordsToComparePrompt: string = AppSettings.MAX_RECORDS_TO_COMPARE_PROMPT;
  checkedColor: string = 'black';
  selectedIndex: number = 0;
  displayManualSearchButton: boolean = false;
  model = {
    receiptNumber: "", //"WAC1802550980" //WAC1419550371 - no DOL,
    lat: 38.8977643,
    long: -77.0106754,
    streetView: '',
    fullMap: ''
  }
  p: number = 1;
  recordsPerPage: number = 10;
  // pageSizeLabel: string = "10";
  vsrRows: any[] = [];
  nextRowNum: number = 0;

  constructor(private vsrSearchService: VsrSearchService) { }

  ngOnInit() {
    this.model.receiptNumber = sessionStorage.getItem("receiptNumber-key");
    if (this.model.receiptNumber !== "" || !this.vsrRecords || this.vsrRecords.length < 1) {
      this.displayManualSearchButton = false;
      this.refresh();
    }
    else
      if (this.vsrRecords.length > 0) {
        this.getVsrHistoryInfoFromInputData();
        console.log("no receipt.");
      }

    for (let i = 0; i < this.vsrRecords.length; i++) {
      let vsrRow = {
        disabled: false
      };
      this.vsrRows.push(vsrRow);


    }
  }

  ngOnChanges(changes: SimpleChanges) {
  }


  private async  delay(ms: number) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  private refresh(): void {
    this.model.receiptNumber = sessionStorage.getItem("receiptNumber-key");
    if (
      ((!this.vsrRecords || this.vsrRecords.length < 1) && (this.model.receiptNumber !== ""))
      ||
      ((this.vsrRecords.length >= 1) && (this.model.receiptNumber !== ""))

    )
      this.getVsrHistoryInfoFromService();
    else
      this.getVsrHistoryInfoFromInputData();
  }

  private getVsrHistoryInfoFromService() {

    (async () => {
      this.loading = true;
      await this.delay(5000);  //wait for 5 seconds to allow vsr main page complete processing history data.      

      if (
        ((!this.vsrRecords || this.vsrRecords.length < 1) && (this.model.receiptNumber !== ""))
        ||
        ((this.vsrRecords.length >= 1) && (this.model.receiptNumber !== ""))

      ) {
        this.vsrSearchService.getVSRHistory(this.model.receiptNumber.toUpperCase()).subscribe(
          mainData => {
            this.loading = false;
            try {
              if (mainData && !JSON.stringify(mainData).includes("Error") && !JSON.stringify(mainData).includes("ESB2Exception")) {
                this.loading = false;


                this.getVSRHistoryComplete.emit(this.vsrRecords);

                console.log("inside vsr-history - getting vsr history data from service.");
                this.vsrRecords = mainData.VsrGetResponse.VsrResultSet.VsrRecord;
                this.reverseSortVSRrecords();
              }
              else if (JSON.stringify(mainData).includes("Error") || JSON.stringify(mainData).includes("ESB2Exception")) {
                this.loading = false;
                this.appsAlert = "Error while fetching history data, " + AppSettings.SYSTEM_EXCEPTION;
                sessionStorage.setItem("receiptNumber-key", "");
              }
              else {
                this.loading = false;
                this.appsAlert = "No records found matching this receipt number.";
                sessionStorage.setItem("receiptNumber-key", "");
              }
            } catch (error) {
              this.loading = false;
              if(JSON.stringify(error).includes("AppSettings.HTTP_STATUS_401"))              
              this.appsAlert = "Error while fetching history data, " + AppSettings.HTTP_STATUS_401;
              else
              this.appsAlert = "Error while fetching history data, " + AppSettings.SYSTEM_EXCEPTION;
              console.log("Error while fetching history data from service call, " + JSON.stringify(error));
            }

          }, error => {
            this.loading = false;
            this.appsAlert = "Error while fetching history data, " + AppSettings.SYSTEM_EXCEPTION;
          });
      }
      else if ((this.vsrRecords && this.vsrRecords.length > 1) && (this.model.receiptNumber !== "")) {
        this.reverseSortVSRrecords();
        this.loading = false;
      }
    })();
  }


   onPageChange(e)
  {
    if (e)
      this.p = e;
  }

  private reverseSortVSRrecords() {
    let ind = this.vsrRecords.length - 1;
    for (let i: number = 0; i < this.vsrRecords.length; i++) {
      this.vsrSortedRecords.push(this.vsrRecords[ind]);
      ind -= 1;
    }
    this.loading = false;
    sessionStorage.setItem("receiptNumber-key", "");
    this.vsrSelectedRecords[0] = this.vsrSortedRecords[this.vsrRecords.length - 1];
  }

  toggleEditable(event, record) {
    let ind = this.vsrSelectedRecords.indexOf(record);

    if (event.target.checked) {
      if (ind < 0)
        this.vsrSelectedRecords.push(record)
    }
    else {
      this.vsrSelectedRecords.splice(ind, 1);
    }
  }

  private setPageSize(pageSize:number){
this.recordsPerPage = pageSize;
// this.pageSizeLabel = pageSize == 100 ? 'All' : pageSize.toString();
  }


  private onSorted(criteria: HistorySearchCriteria) {
    let primaryColumn: string = "";
    // console.log("criteria.sortColumn " + criteria.sortColumn);
    if (criteria.sortColumn === 'OrganizationDataSource') primaryColumn = 'PetitionInformation';
    else primaryColumn = 'VIBEScoreResult';

    if (criteria.sortDirection === 'asc') {
      this.vsrRecords = this.vsrRecords.sort((b, a) => a[primaryColumn][criteria.sortColumn].localeCompare(b[primaryColumn][criteria.sortColumn]));
      this.sortDirection = "arrow right";
    }
    else {
      this.vsrRecords = this.vsrRecords.sort((b, a) => b[primaryColumn][criteria.sortColumn].localeCompare(a[primaryColumn][criteria.sortColumn]));
      this.sortDirection = "arrow left";
    }
    this.setDirectionStyle(criteria);
    // console.log(" the current direction is: " + this.sortDirection);
  }


  private setDirectionStyle(criteria: HistorySearchCriteria) {
    this.organizationDataSourceSortDirection = "two-way-arrows";
    this.scoreRunTimeStampSortDirection = "two-way-arrows";
    this.scoreSortDirection = "two-way-arrows";
    this.scoreTitle = "";
    this.organizationDataSourceTitle = "" ;
    this.scoreRunTitle = "" ;
    let sortOrder = this.sortDirection == "arrow right"? "descending" : "ascending";
    if (criteria.sortColumn === 'ScoreRunTimeStamp') {
      this.scoreRunTimeStampSortDirection = this.sortDirection;
      this.scoreRunTitle = " Score Run Date sorted " + sortOrder;
    }
    if (criteria.sortColumn === 'OrganizationDataSource') {
      this.organizationDataSourceSortDirection = this.sortDirection;      
      this.organizationDataSourceTitle = "Data Source sorted " + sortOrder;
    }
    if (criteria.sortColumn === 'Score') {
      this.scoreSortDirection = this.sortDirection;
      this.scoreTitle = " Overall Score sorted " + sortOrder;
    }

  }


  private getSortDirectionStyle(sortedColum): any {
    switch (sortedColum) {
      case 'OrganizationDataSource':
        return this.organizationDataSourceSortStyle;
      case 'ScoreRunTimeStamp':
        return this.scoreRunTimeStampSortStyle
      case 'Score':
        return this.scoreSortStyle;
      default:
        return {};
    }
  }





  private selectionChanged($event) {
  }
  private getVsrHistoryInfoFromInputData() {

    if (this.vsrRecords && this.vsrRecords.length > 0) {
      console.log("the number of records retrieved from the input data is: " + this.vsrRecords.length);
      this.reverseSortVSRrecords();
    }
    this.loading = false;
    sessionStorage.setItem("receiptNumber-key", "");

  }
  private addLabel(id) {
    this.nextRowNum += 1;
    return "clr-checkbox-" + id;
  }
  private getScorecardStyle(ScoreCodeType): any {
    switch (ScoreCodeType) {
      case 'GREEN':
        return { color: 'white', 'background-color': 'green', 'font-weight': 'bold' };
      case 'RED':
        return { color: 'black', 'background-color': 'red', 'font-weight': 'bold' };
      case 'ORANGE':
        return { color: 'black', 'background-color': 'orange', 'font-weight': 'bold' };
      case 'YELLOW':
        return { color: 'black', 'background-color': 'yellow', 'font-weight': 'bold' };
      case 'BLUE':
        return { color: 'white', 'background-color': 'blue', 'font-weight': 'bold' };
      default:
        return {};
    }
  }

  disableRows() {
  }

}




export class HistorySearchCriteria {
  sortColumn: string;
  sortDirection: string;
}