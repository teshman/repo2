import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VsrHistoryComponent } from './vsr-history.component';

describe('VsrHistoryComponent', () => {
  let component: VsrHistoryComponent;
  let fixture: ComponentFixture<VsrHistoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VsrHistoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VsrHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
