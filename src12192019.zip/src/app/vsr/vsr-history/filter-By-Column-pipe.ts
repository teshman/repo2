import { Pipe, PipeTransform } from '@angular/core';
import { VsrRecordEntity } from 'src/app/shared/vsr';

@Pipe({ name: 'searchByColumnName' })
export class FilterByColumnPipe implements PipeTransform {

  transform(historyRecords: VsrRecordEntity[], searchText: string) {

    let multipleFilters: string[] = [];
    if (searchText) {      
      // console.log("THE SEARCH TEXT IS: " + searchText.toUpperCase());
      multipleFilters = searchText.split(',');
      if (multipleFilters[0] !== undefined && multipleFilters[0].trim() !== 'undefined' && multipleFilters[0].trim() !== '') {
        // console.log("THE multipleFilters0 TEXT IS: " + multipleFilters[0]);
        historyRecords = historyRecords.filter(vsrRecord => vsrRecord.PetitionInformation.OrganizationDataSource.indexOf(multipleFilters[0].trim()) !== -1);
      }
      if (multipleFilters[1] !== undefined && multipleFilters[1].trim() !== 'undefined'  && multipleFilters[1].trim() !== '') {
        // console.log("THE multipleFilters1 TEXT IS: " + multipleFilters[1]);
        historyRecords = historyRecords.filter(vsrRecord2 => vsrRecord2.VIBEScoreResult.Score.indexOf(multipleFilters[1].trim().toUpperCase()) !== -1);
      }
    }
    
    return historyRecords;
  }


  
}

