import { Component, OnInit, Input, Output, EventEmitter, OnDestroy, HostListener } from '@angular/core';
import { Subscription } from 'rxjs/Subscription';

import { SortService } from './sort.service';

@Component({
    selector: '[sortable-column]',
    templateUrl: './sortable-column.component.html'
})
export class SortableColumnComponent {

    constructor(private sortService: SortService) { } 

    @Input('sort-direction') sortDirection: string = '';
    @Input('sortable-column')
    columnName: string;

    @HostListener('click')
    sort() {
        this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
        this.sortService.columnSorted({ sortColumn: this.columnName, sortDirection: this.sortDirection });
    } 

    // @HostListener("focus", ["$event.target"])
    // onFocus(target) {
    //   console.log("focus")
      
    //   this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
    //   this.sortService.columnSorted({ sortColumn: this.columnName, sortDirection: this.sortDirection });
    // }
  
    @HostListener('keydown', ['$event'])
    public handleKeyboardEvent(event: KeyboardEvent): void {
        if (event.key === "Enter"){
        this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
        this.sortService.columnSorted({ sortColumn: this.columnName, sortDirection: this.sortDirection });
      }
    } 

//     @HostListener('document:keydown', ['$event'])
//   public handleKeyboardEvent(event: KeyboardEvent): void {
//       if (event.key === "Enter"){
//       this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
//       this.sortService.columnSorted({ sortColumn: this.columnName, sortDirection: this.sortDirection });
//     }
//   }

}
