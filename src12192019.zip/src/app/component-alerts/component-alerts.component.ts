import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-component-alerts',
  templateUrl: './component-alerts.component.html',
  styleUrls: ['./component-alerts.component.css']
})
export class ComponentAlertsComponent implements OnInit {

  @Input() topLevelAlert:string = "";
  
  constructor() { }
  ngOnInit() {
  }

}
