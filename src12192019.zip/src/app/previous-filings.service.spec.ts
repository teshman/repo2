import { TestBed } from '@angular/core/testing';

import { PreviousFilingsService } from './previous-filings.service';

describe('PreviousFilingsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PreviousFilingsService = TestBed.get(PreviousFilingsService);
    expect(service).toBeTruthy();
  });
});
