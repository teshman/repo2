import { Component, OnInit, Input, NgModule, AfterViewInit } from '@angular/core';
import { keyframes } from '@angular/animations';
import { DolEtaSearchService } from '../dol-eta-search.service';
import { ClrDatagridSortOrder } from '@clr/angular';
import { GetDolDetailByEtaCaseNumberResponse, dolResponse , DOLETACLOB, DOLDATA, DolJsonData, DOLETAWORKSITESEntity, DOLETAFRNRECEntity } from '../shared/9142Bv2_interfaces'
import { dolResponseProxy } from '../shared/9142Bv2_proxies'
import { dol9142Bv2PetResponseProxy, GetDolDetailByPetitionIDResponseProxy } from '../shared/9142Bv2Petition_proxies'
//import { GetDolDetailByPetitionIDResponse,dolPetitionResponse9142A, DolJsonData as DolJsonDataByPet }  from '../shared/9142AByPetition_interfaces'
import { AppSettings } from '../shared/app-settings'
import { Router } from '@angular/router';
import { SmartSearchService } from "../smart-search.service"
import { SmartSearchModel } from "../shared/smart-search-model"
import { Subscription } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { ComponentStatusService } from '../shared/service/component-status.service';
import { ComponentStatus } from '../shared/service/component-status';
@Component({
  selector: 'app-dol-eta-form9142-bv2',
  templateUrl: './dol-eta-form9142-bv2.component.html',
  styleUrls: ['./dol-eta-form9142-bv2.component.css']
})
export class DolEtaForm9142Bv2Component implements OnInit {
  @Input() petitionId: string = "";
  @Input() dolEtaFormType: string = "";
  @Input() dolEtaFormVersion: string = "";
  @Input() dolEtaClobId: string = "";
  @Input() etacaseNumber: string = "";
  petitionNumber: string = "";
  cssSubscription: Subscription;
  cssStatusService: ComponentStatusService;
  private dolSvc: DolEtaSearchService;
  appsAlert: string;
  showAndHideSl: boolean = false;
  showDol: boolean;
  showAppA: boolean;
  showAppC: boolean;
  showApproval: boolean;
  loading: boolean;
  showSummary: boolean;
  dolData: DolJsonData; //| DolJsonDataByPet;
  dolClobArray: (DOLETACLOB)[];
  dolWorksites: (DOLETAWORKSITESEntity)[];
  dolFnRec: (DOLETAFRNRECEntity)[]
  APP_IS_STATEMENT_ATTACHED: any;
  APP_IS_PWD_ATTACHED: any;
  EMP_JOIN_APDX_A_ATTACHED: any;
  EMP_IS_CONTRACT_ATTACHED: any;
  ATTY_IS_AGREEMENT_ATTACHED: any;
  JOB_APDX_B_ATTACHED: any;
  caseArray: any;
  constructor(private dolSearchService: DolEtaSearchService, private ssb: SmartSearchService, private router: Router, private css: ComponentStatusService) {
    this.dolSvc = dolSearchService

    //integration point with SSB
    this.cssSubscription = this.css.currentMessage.subscribe(message => {
      this.resetComponent()
      if (message.destComponentName == AppSettings.CS_DOL_ETA_9142BV2) {

        console.log(message.data);
        
        try{
          this.showDol = true
          this.showSummary = false;
          this.parseDolData(message.data)
        }catch(error){
          console.error(error) 
          this.appsAlert = AppSettings.VSR_STATUS_CODE_001_DESC;
          this.showDol = false;
          this.loading = false;
          this.showSummary = false;
         }


      }});
    
      }
  resetComponent(){
    this.showDol = false;
    this.loading = false;
    this.showSummary = false;
    this.appsAlert = "";
  }
  ngOnInit() {
    this.showAndHideSl = false;
    this.loading = true;
    if (this.petitionId !== "" && this.dolEtaFormType !== "") {
      this.petitionNumber = this.petitionId
      this.dolSvc.getDolByPettitionId9142A(this.petitionNumber, this.dolEtaClobId).subscribe(data => {
        
        try{
        this.parseDolDataByPetition(data)
        this.loading = false
        this.showSummary = true;
        this.showDol = true;
        
        }catch(error){
          console.error(error) 
          this.appsAlert = AppSettings.VSR_STATUS_CODE_001_DESC;
          this.showDol = false;
          this.loading = false;
          this.showSummary = false;
         }
      });
      this.loading = false;
      return;
    }
    if(this.etacaseNumber !="" && this.dolEtaFormType == "9142B"){
      this.dolSvc.getDolByCaseId(this.etacaseNumber).subscribe(data => {
        try{
          this.parseDolData(data)
        }catch(error){
          console.error(error) 
          this.appsAlert = AppSettings.VSR_STATUS_CODE_001_DESC;
          this.showDol = false;
          this.loading = false;
         }
      })
    }
    this.loading = false;
  }

  parseDolData(data: dolResponseProxy){
    this.dolClobArray = [];
    this.dolWorksites = [];
    this.dolData = <DolJsonData>JSON.parse(data.GetDolDetailByEtaCaseNumberResponse.DolJsonData)
    console.log(data)
    console.log((this.dolData.DOL_DATA.DOL_ETA_CLOB))
    this.splitdolData();
  } 
  
  parseDolDataByPetition(data: dol9142Bv2PetResponseProxy){

    this.dolClobArray = [];
    this.dolWorksites = [];
    this.dolFnRec = [];
    console.log(data)
    this.dolData = <DolJsonData> JSON.parse(data.GetDolDetailByPetitionIDResponse.DolJsonData)
    console.log(data)
    console.log((this.dolData.DOL_DATA.DOL_ETA_CLOB))
    this.splitdolData();

  }

  splitdolData(){
    //console.log(this.dolData.DOL_DATA.DOL_ETA_FD_CERT[0].CASE_DETERMIN_DATE)

    //Check for Clob
    if (Array.isArray(this.dolData.DOL_DATA.DOL_ETA_CLOB)) {
      this.dolClobArray = this.dolData.DOL_DATA.DOL_ETA_CLOB
      this.loading = false;
      this.showDol = true
      this.showSummary = true;
    } else if (JSON.stringify(this.dolData.DOL_DATA.DOL_ETA_CLOB).includes("RESPONSECODE")) {
      this.dolClobArray = []
      this.showDol = false;
    } else {
      this.dolClobArray.push(this.dolData.DOL_DATA.DOL_ETA_CLOB);
      this.loading = false;
      this.showDol = true
      this.showSummary = true;
    }

    //Check for Worksites
    if (Array.isArray(this.dolData.DOL_DATA.DOL_ETA_WORKSITES)){
      this.dolWorksites = this.dolData.DOL_DATA.DOL_ETA_WORKSITES
      this.loading= false;
      this.showAppA = true;
    } else if (JSON.stringify(this.dolData.DOL_DATA.DOL_ETA_WORKSITES).includes("RESPONSECODE")){
      this.dolWorksites = [];
      this.showAppA = false;
    }else {
      this.dolWorksites.push(this.dolData.DOL_DATA.DOL_ETA_WORKSITES)
      this.loading = false;
      this.showAppA = true
    }

    //Check for FinRec
    if (Array.isArray(this.dolData.DOL_DATA.DOL_ETA_FRN_REC)){
      this.dolFnRec = this.dolData.DOL_DATA.DOL_ETA_FRN_REC
      this.loading= false;
      this.showAppC = true;
    } else if (JSON.stringify(this.dolData.DOL_DATA.DOL_ETA_FRN_REC).includes("RESPONSECODE")){
      this.dolFnRec = [];
      this.showAppC = false;
    }else {
      this.dolFnRec.push(this.dolData.DOL_DATA.DOL_ETA_FRN_REC)
      this.loading = false;
      this.showAppC = true
    }


}

}
