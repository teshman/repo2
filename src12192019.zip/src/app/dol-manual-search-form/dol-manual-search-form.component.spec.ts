import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DolManualSearchFormComponent } from './dol-manual-search-form.component';

describe('DolManualSearchFormComponent', () => {
  let component: DolManualSearchFormComponent;
  let fixture: ComponentFixture<DolManualSearchFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DolManualSearchFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DolManualSearchFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
