import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FouoComponent } from './fouo.component';

describe('FouoComponent', () => {
  let component: FouoComponent;
  let fixture: ComponentFixture<FouoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FouoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FouoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
