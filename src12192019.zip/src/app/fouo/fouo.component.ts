import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
@Component({
  selector: 'app-fouo',
  templateUrl: './fouo.component.html',
  styleUrls: ['./fouo.component.css']
})
export class FouoComponent implements OnInit {

  currentDateTime:number;

    constructor() {
        setInterval(() => {
          this.currentDateTime = Date.now();
        }, 5000);
    }
  showFormModal: boolean = false;
  formAccessibility;

  ngOnInit() {
    this.formAccessibility = new FormGroup({});  
  }

  toggleFormAccessibility(){
    
    this.showFormModal = !this.showFormModal;
    console.log("this.showFormModal: " + this.showFormModal);
  }
}
