import { TestBed } from '@angular/core/testing';

import { UserInRoleService } from './user-in-role.service';

describe('UserInRoleService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: UserInRoleService = TestBed.get(UserInRoleService);
    expect(service).toBeTruthy();
  });
});
