import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { VsrComponent } from "./vsr/vsr.component";
import { HelpfulLinksComponent } from "./helpful-links/helpful-links.component";
import { RedReportsComponent } from "./red-reports/red-reports.component";
import { DolEtaSearchComponent } from "./dol-eta-search/dol-eta-search.component";
import { DolEtaFormV1Component } from "./dol-eta-form-v1/dol-eta-form-v1.component";
import { PreviousFilingsImqComponent } from "./previous-filings-imq/previous-filings-imq.component";
import { PreviousFilingsComponent } from './previous-filings/previous-filings.component';
import { UserProfilesComponent } from './user-profile/user-profile.component';
import { PredefinedInfoComponent } from './predefined-info/predefined-info.component';
import { DataInquiryComponent } from './data-inquiry/data-inquiry.component';



const routes: Routes = [
  {path: '', redirectTo: 'vsr', pathMatch: 'full'},

  //admin 
  //{path: 'admin', component: AdminComponent},

  //user profile
  {path: 'user-profile', component: UserProfilesComponent},

  //helpful links
  {path: 'helpful-links', component: HelpfulLinksComponent},

  //vsr
  {path: 'vsr', component: VsrComponent},
  {path: 'vsr/receipt/:id', component: VsrComponent },

  //red report
  {path: 'red-reports', component: RedReportsComponent},
  
  //predefined info
  {path: 'predefined-info', component: PredefinedInfoComponent},


  {path: 'dol-eta-lookup', component: DolEtaSearchComponent },
  {path: 'dol-eta-lookupv1', component: DolEtaFormV1Component},
  {path: 'previous-eta-filings', component: PreviousFilingsComponent},
  {path: 'previous-eta-filings/petition/receipt/:id', component: DolEtaSearchComponent },

  {path: 'previous-filings', component: PreviousFilingsImqComponent},
  {path: 'previous-filings/dolcase/:id', component: PreviousFilingsComponent},
  {path: 'previous-filings/duns/:id/:id2/:id3', component: PreviousFilingsComponent},
  {path: 'previous-filings/duns/:id', component: PreviousFilingsComponent},
  
  {path: 'data-inquiry', component: DataInquiryComponent}
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {onSameUrlNavigation: 'reload'})],
  exports: [RouterModule],
})
export class AppRoutingModule { 

}
