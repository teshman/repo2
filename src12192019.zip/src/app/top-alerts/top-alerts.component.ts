import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-top-alerts',
  templateUrl: './top-alerts.component.html',
  styleUrls: ['./top-alerts.component.css']
})
export class TopAlertsComponent implements OnInit {

  @Input() topLevelAlert:string = "VIBE Plus is a newly modernized user interface for the VIBE system.  This site is still under beta testing.  Please do not access this VIBE Plus site until further notice. Please use Google Chrome for best user experience.  Thank you for your support!";
  constructor() { 
    //this.topLevelAlert = "System is going down"; 
  }
 
  closeAlert(){
    console.log("clear top level alert");
    this.topLevelAlert="";
  }
  ngOnInit() {
  }

 
}
