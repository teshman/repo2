import { Observable, of } from 'rxjs';
import { Injectable } from '@angular/core';
import { DolProxy } from './shared/dol_proxy';
import { GetDolDetailByPetitionIDResponseProxy} from './shared/dolPetitionResponse_proxy'
import { GetDolDetailByPetitionIDResponseProxy as dol9035v1Proxy} from './shared/9035v1_proxies'
import { GetDolDetailByPetitionIDResponseProxy as dol9035v2Proxy} from './shared/9035v2_proxies'
import { dol9142APetResponseProxy as dol9142AProxy } from './shared/9142AByPetition_proxies'
import { catchError, map, tap } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';
import { AppSettings } from './shared/app-settings'
import { Component, Input, OnInit } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DolEtaSearchService {

  private petitionURL = '/vibe-plus/rest/dol/petition-id/';
  private caseURL = '/vibe-plus/rest/dol/case-id/';
  constructor(private http: HttpClient) { }

  getDolByCaseId(caseId: string): Observable<DolProxy> {
    caseId = caseId.replace(/-/g, '')
    const url = `${this.caseURL}${caseId}`;
    return this.http.get<DolProxy>(url).pipe(
      tap(_ => console.log(`get Case #=${caseId}`)),
      catchError(this.handleError<DolProxy>(`error get Case # ${caseId}`))
    );
  }
  getDolByPettitionId(petitionId: string, DolEtaClobId: string): Observable<GetDolDetailByPetitionIDResponseProxy> {
    const url = `${this.petitionURL}${petitionId}/clob-id/${DolEtaClobId}`;
    return this.http.get<GetDolDetailByPetitionIDResponseProxy>(url).pipe(
      tap(_ => console.log(`get Petition #=${petitionId}`)),
      catchError(this.handleError<GetDolDetailByPetitionIDResponseProxy>(`error get Petition # ${petitionId}`))
    );
  }
  getDolByPettitionId9035v1(petitionId: string, DolEtaClobId: string): Observable<dol9035v1Proxy> {
    const url = `${this.petitionURL}${petitionId}/clob-id/${DolEtaClobId}`;
    return this.http.get<dol9035v1Proxy>(url).pipe(
      tap(_ => console.log(`get Petition #=${petitionId}`)),
      catchError(this.handleError<dol9035v1Proxy>(`error get Petition # ${petitionId}`))
    );
  }
  getDolByPettitionId9035v2(petitionId: string, DolEtaClobId: string): Observable<dol9035v2Proxy> {
    const url = `${this.petitionURL}${petitionId}/clob-id/${DolEtaClobId}`;
    return this.http.get<dol9035v2Proxy>(url).pipe(
      tap(_ => console.log(`get Petition #=${petitionId}`)),
      catchError(this.handleError<dol9035v2Proxy>(`error get Petition # ${petitionId}`))
    );
  }
  getDolByPettitionId9142A(petitionId: string, DolEtaClobId: string): Observable<dol9142AProxy> {
    const url = `${this.petitionURL}${petitionId}/clob-id/${DolEtaClobId}`;
    return this.http.get<dol9142AProxy>(url).pipe(
      tap(_ => console.log(`get Petition #=${petitionId}`)),
      catchError(this.handleError<dol9142AProxy>(`error get Petition # ${petitionId}`))
    );
  }
  getDolByPettitionId9035v2ByFile(petitionId: string): Observable<dol9035v2Proxy> {
    const url = AppSettings.DOL_9035V2_JSON2;
    return this.http.get<dol9035v2Proxy>(url).pipe(
      tap(_ => console.log(`get Petition #=${petitionId}`)),
      catchError(this.handleError<dol9035v2Proxy>(`error get Petition # ${petitionId}`))
    );
  }
  getDolByPettitionIdByFile(petitionId: string, DolEtaClobId: string): Observable<GetDolDetailByPetitionIDResponseProxy> {
    const url = AppSettings.DOL_DATA_JSON;
    return this.http.get<GetDolDetailByPetitionIDResponseProxy>(url).pipe(
      tap(_ => console.log(`get Petition #=${petitionId}`)),
      catchError(this.handleError<GetDolDetailByPetitionIDResponseProxy>(`error get Petition # ${petitionId}`))
    );
  }
  getDolByCaseIdFile(petitionId: string): Observable<DolProxy>  {

    const url = AppSettings.DOL_DATA_JSON;
    return this.http.get<DolProxy>(url).pipe(
      tap(data =>
        this.log("The fetched ETA CASE SourceTransactionID is: " + data)
      ));
  }
   /**
   * Handle Http operation that failed.
   * Let the app continue.
   * @param operation - name of the operation that failed
   * @param result - optional value to return as the observable result
   */
  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // TODO: better job of transforming error for user consumption
      console.log(`${operation} failed: ${error.message}`);

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }
  private log(message: string) {
    console.log(`ETA: ${message}`);

  }
}
