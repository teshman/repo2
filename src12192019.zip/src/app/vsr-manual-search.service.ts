import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/toPromise';
import { Vsr } from './shared/vsr';
import { VSRResubmitRequest, VsrResubmitResponse, VsrResubmit, PredefOrgLookupRequest } from './shared/vsr-resubmit';
import { HttpClient } from '@angular/common/http';
import { tap } from 'rxjs/operators';
import { OrganizationLookupResponseProxy, OcrResponse } from './predefined-info/OrganizationLookupResponse';
import { AppSettings } from './shared/app-settings';
import { PredefinedInformationWorkflowRequest, WorkflowResponse } from './shared/predefined-Info-request';
import { SpecialCharactersPipe } from './shared/pipes/special-characters.pipe'
@Injectable({
    providedIn: 'root'
})
export class VsrManualSearchService {
    url = '/vibe-plus/rest/vsr';
    orgLookupUrl = '/vibe-plus/rest/beqs/orglookup';
    workflowUrl = '/vibe-plus/rest/predef-info/workflow';
    vsr: Vsr;
    constructor(private http: Http, private httpc: HttpClient, private spChars: SpecialCharactersPipe) { }

    getOrganizationInfo(resubmitRequest: PredefOrgLookupRequest): Observable<OrganizationLookupResponseProxy> {
        // console.log("the request is: " + JSON.stringify(resubmitRequest));
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers });
        return this.http.post(this.orgLookupUrl, resubmitRequest, options)
            .map(this.extractData)
            .catch(this.handleErrorObservable);
    }

    getOCRStatus(): Observable<OcrResponse> {
        let url: string = '/vibe-plus/rest/ocr/status';
        return this.httpc.get<OcrResponse>(url).pipe(
            tap(data =>
                this.log("The OCR STATUS is: " + JSON.stringify(data.OcrGetStatusResponse))
            ));
    }

    saveWorkFlowRequestInJson(workflowRequest: PredefinedInformationWorkflowRequest): Observable<WorkflowResponse> {
        // console.log("the request is: " + JSON.stringify(workflowRequest));
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers });
        if(workflowRequest.predefinedInformationComment){
            workflowRequest.predefinedInformationComment = this.spChars.transform(workflowRequest.predefinedInformationComment)
        }
        if(workflowRequest.justificationComment){
            workflowRequest.justificationComment = this.spChars.transform(workflowRequest.justificationComment)
        }
        
        
        return this.http.post(this.workflowUrl, workflowRequest, options)
            .map(this.extractData)
            .catch(this.handleErrorObservable);
    }

    getOrganizationInfoFromFile(): Observable<OrganizationLookupResponseProxy> {
        let url: string = AppSettings.PREDEF_INFO_ORGANIZATION_LOOKUP_JSON;
        return this.httpc.get<OrganizationLookupResponseProxy>(url).pipe(
            tap(data =>
                this.log("The fetched VsrResubmitResponse org name is: " + data.OrganizationName)
            ));
    }

    resubmitVSRRequestInJson(resubmitRequest: VSRResubmitRequest): Observable<VsrResubmit> {
        // console.log("the request is: " + JSON.stringify(resubmitRequest));
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers });
        return this.http.post(this.url, resubmitRequest, options)
            .map(this.extractData)
            .catch(this.handleErrorObservable);
    }


    resubmitVSRRequest(resubmitRequest: VSRResubmitRequest): Observable<Vsr> {
        let headers = new Headers({ 'Content-Type': 'application/x-www-form-urlencoded' });
        let options = new RequestOptions({ headers: headers });
        return this.http.post(this.url, resubmitRequest, options)
            .map(this.extractData)
            .catch(this.handleErrorObservable);
    }

    resubmitVSRRequestPromise(resubmitRequest: VSRResubmitRequest): Promise<VsrResubmitResponse> {
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers });
        return this.http.post(this.url, resubmitRequest, options).toPromise()
            .then(this.extractData)
            .catch(this.handleErrorPromise);
    }

    private extractData2(res: Response) {
        let body = JSON.parse(res.toString());
        return body || {};

    }


    getResubmitFromFile(url): Observable<VsrResubmit> {
        return this.httpc.get<VsrResubmit>(url).pipe(
            tap(data =>
                this.log("The fetched VsrResubmitResponse SourceTransactionID is: " + data.VsrResubmitResponse.SourceTransactionID)
            ));
    }

    private log(message: string) {
        console.log(message)
    }
    private extractData(res: Response) {
        //console.log("the data is: " + JSON.stringify(res.json()));       
        let body = res.json();
        return body || {};
    }
    private handleErrorObservable(error: Response | any) {
        console.error(error.message || error);
        return Observable.throw(error.message || error);
    }

    private handleErrorPromise(error: Response | any) {
        console.error(error.message || error);
        return Promise.reject(error.message || error);
    }

} 
