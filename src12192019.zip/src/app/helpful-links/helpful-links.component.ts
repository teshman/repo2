import { Component, OnInit } from '@angular/core';
import { SmartSearchService }  from "../smart-search.service"
import { SmartSearchModel }  from "../shared/smart-search-model"
import { UserInRoleService } from '../user-profile/user-in-role.service';

@Component({
  selector: 'app-helpful-links',
  templateUrl: './helpful-links.component.html',
  styleUrls: ['./helpful-links.component.css']
})

export class HelpfulLinksComponent implements OnInit {

  showRole : boolean = false; 
  isDol: boolean = false; 
  isBA:  boolean = false; 

  toggleShowRoleInfo(){
    this.showRole = !this.showRole; 
  }
  message: SmartSearchModel; 
  constructor(private ssb: SmartSearchService, private userInRoleService: UserInRoleService) {
    if (this.userInRoleService.userInRole.dolUser) {
      console.log("HelpfulLinksComponent: dolUser");
      this.isDol=true;
    }
    if (this.userInRoleService.userInRole.businessAdministrator) {
      console.log("HelpfulLinksComponent: isBA");
      this.isBA=true;
    }
   }
  ngOnInit() {
    this.ssb.currentMessage.subscribe(message => this.message = message);
  }
}
