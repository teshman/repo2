import { TestBed } from '@angular/core/testing';

import { IndependentManualQueryService } from './independent-manual-query.service';

describe('IndependentManualQueryService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: IndependentManualQueryService = TestBed.get(IndependentManualQueryService);
    expect(service).toBeTruthy();
  });
});
