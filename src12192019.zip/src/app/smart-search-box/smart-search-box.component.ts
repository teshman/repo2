import { Component, OnInit, ViewChild, ElementRef, Output, EventEmitter, Renderer2, Renderer } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { SearchTypes } from './search-types';
import { Router, Event, NavigationStart, NavigationEnd, NavigationError } from '@angular/router';
import { SmartSearchService } from '../smart-search.service';
import { ComponentStatusService } from '../shared/service/component-status.service';
import { ComponentStatus } from '../shared/service/component-status';
import { Subscription } from 'rxjs';
import { DolEtaSearchService } from '../dol-eta-search.service'
import { SmartSearchModel } from '../shared/smart-search-model';
import { ClrForm } from '@clr/angular';
// import { stringify } from '@angular/core/src/render3/util';
import { VSRResubmitAddress } from '../shared/vsr-resubmit';
import { AppSettings } from '../shared/app-settings';
// import { containsElement } from '@angular/animations/browser/src/render/shared';
import { FocusDirective } from '../shared/directives/focus.directive';
import { UserInRoleService } from '../user-profile/user-in-role.service';
import { UserProfileService } from '../user-profile.service';


@Component({
  selector: 'app-smart-search-box',
  templateUrl: './smart-search-box.component.html',
  styleUrls: ['./smart-search-box.component.css']
})
export class SmartSearchBoxComponent implements OnInit {

  userInRoeleDol: boolean = false;
  userInRoeleBA: boolean = false;
  currentUrl: string;

  model: SmartSearchModel;
  pfAddress: VSRResubmitAddress;
  appsAlert = "";
  searchTypes: SearchTypes[];
  appRouter: Router;
  showModal: boolean = true;
  loading: boolean = false;

  //reactive forms 
  ssb: FormGroup;


  //address search 
  addressInputForm = this.fb.group({
    org: ["", Validators.required],
    street: ["", Validators.required],
    city: [""],
    state: ["", Validators.required],
    zip: [""],
    country: ["", Validators.required]
  });


  cssStatusService: ComponentStatusService;
  cssSubscription: Subscription;
  private dolSvc: DolEtaSearchService;

  newMessage() {
    // console.log("sending new message");
    this.model.searchById = this.model.searchById.toUpperCase();
    this.data.changeMessage(this.model);
  }


  @ViewChild("inputBox", { static: false }) _el: ElementRef;

  @ViewChild("searchById", { static: true }) searchByIdInput: ElementRef;



  constructor(private router: Router, private data: SmartSearchService, private fb: FormBuilder, private css: ComponentStatusService, private dolSearchService: DolEtaSearchService,
    private userProfileService: UserProfileService, private userInRoleService: UserInRoleService) {
    this.appRouter = router;  //save router handle so we can switch pages based on function selection
    this.cssStatusService = css;
    this.dolSvc = dolSearchService
    // console.log("in ssb constructor");
    this.userProfileService.getUserProfile().subscribe(
      data => {
        if (data) {
          this.userInRoleService.userInRole = data;
          this.updatecssSubscription();
        }
        else {
        }
      },
      error => {
        (async () => {
          window.location.href = "/vibe-plus";
        })();
      }
    );





    //select he default secondary search function based on the first dropdown 
    this.router.events.subscribe((event: Event) => {

      //      if(!this.router.url.startsWith('/vsr')) {
      if (event instanceof NavigationStart) {
        // Show loading indicator
        // console.log("loading url=" + event.url);
        // console.log("this.router.url=" + this.router.url);

        this.currentUrl = event.url;
        if (event.url === this.router.url) {
          //do nothing
        } else if (event.url.startsWith('/vsr')) {
          // console.log("VSR URL LOADED");
          this.model.selectedSearchType = "vsr";
          this.model.selectedSearchTypeIndex = 0;
          this.model.selectedSearchFunction = "receiptNumber";
          this.model.functionDescription = this.searchTypes[this.model.selectedSearchTypeIndex].functions[0].description;
          this.model.searchById = "";
          this.model.error = "";
          this.setupSsbForRole();


        }
        else if (event.url.startsWith('/previous-filings')) {
          // console.log("PREVIOUS FILINGS URL LOADED");
          this.model.selectedSearchType = "previousFilings";
          this.model.selectedSearchTypeIndex = 1;
          this.model.selectedSearchFunction = "pfFein";
          this.model.functionDescription = this.searchTypes[this.model.selectedSearchTypeIndex].functions[0].description;
          this.model.searchById = "";
          this.model.error = "";

        }
        else if (event.url.startsWith('/dol-eta-lookup')) {
          // console.log("DOL ETA SEARCH LOADED");
          this.model.selectedSearchType = "dolEtaLookup";
          this.model.selectedSearchTypeIndex = 2;
          this.model.selectedSearchFunction = "dolEta";
          this.model.functionDescription = this.searchTypes[this.model.selectedSearchTypeIndex].functions[0].description;
          this.model.searchById = "";
          this.model.error = "";

        }
        else if (event.url.startsWith('/red-reports')) {
          // console.log("RED REPORTS");
          this.model.selectedSearchType = "";
          this.model.selectedSearchTypeIndex = 0;
          this.model.selectedSearchFunction = "";
          this.model.functionDescription = null;
          this.model.searchById = "";
          this.model.error = "";

        }
        else if (event.url.startsWith('/predefined-info')) {
          // console.log("PRE DEFINED INFO ");
          this.model.selectedSearchType = "";
          this.model.selectedSearchTypeIndex = 0;
          this.model.selectedSearchFunction = "";
          this.model.functionDescription = null;
          this.model.searchById = "";
          this.model.error = "";

        }
        else if (event.url.startsWith('/data-inquiry')) {
          console.log("Data Inquiry");
          this.model.selectedSearchType = "";
          this.model.selectedSearchTypeIndex = 0;
          this.model.selectedSearchFunction = "";
          this.model.functionDescription = null;
          this.model.searchById = "";
          this.model.error = "";

        }
        else if (event.url.startsWith('/helpful-links')) {
          // console.log("HELPFUL LINKS ");
          this.model.selectedSearchType = "";
          this.model.selectedSearchTypeIndex = 0;
          this.model.selectedSearchFunction = "";
          this.model.functionDescription = null;
          this.model.searchById = "";
          this.model.error = "";

        }
        else if (event.url.startsWith('/user-profile')) {
          // console.log("USER PROFILE");
          this.model.selectedSearchType = "";
          this.model.selectedSearchTypeIndex = 0;
          this.model.selectedSearchFunction = "";
          this.model.functionDescription = null;
          this.model.searchById = "";
          this.model.error = "";

        }
        else {
          //by default 
          // console.log("SSB: INVALID ROUTE, SETTING IT TO VSR ");
          this.model.selectedSearchType = "vsr";
          this.model.selectedSearchTypeIndex = 0;
          this.model.selectedSearchFunction = "receiptNumber";
          this.model.functionDescription = this.searchTypes[this.model.selectedSearchTypeIndex].functions[0].description;
          this.model.searchById = "";
          this.model.error = "";
          this.appRouter.navigate(['/vsr']);
          this.setupSsbForRole();
        }

      }
      if (event instanceof NavigationEnd) {
        // Hide loading indicator
        // console.log(this.model);

        this.model.disabledSearchById = false;
        if ((this.model.selectedSearchType === "vsr") && (this.model.selectedSearchFunction === "dolAddr")) {
          this.model.disabledSearchById = true;
        } else if ((this.model.selectedSearchType === "previousFilings") && (this.model.selectedSearchFunction === "pfBA")) {
          this.model.disabledSearchById = true;
        }
        // console.log("SSB: done with NavigationEnd loading");

      }

      if (event instanceof NavigationError) {
        // Hide loading indicator
        // console.log("loading error");
        // Present error to user
        // console.log(event.error);
      }
    });

  }

  private setupSsbForRole() {
    //    console.log("SSB: in setupSsbForRole: userInRoeleDol="+this.userInRoeleDol+", startsWith /vsr="+ this.currentUrl.startsWith('/vsr') + ", url=" +  this.currentUrl);

    // console.log("SSB: in setupSsbForRole");
    // console.log("SSB: currentUrl=" + this.currentUrl);
    // console.log("SSB: router.url=" + this.router.url);

    if (this.userInRoeleDol) {
      if ((this.currentUrl === "/") && (this.router.url == "/vsr")) {
        this.setupVSRForDOLUsers();
      } else if (this.currentUrl === "/vsr") {
        this.setupVSRForDOLUsers();
      }
    } else {
      if ((this.currentUrl === "/") && (this.router.url == "/vsr")) {
        this.setupVSRForOtherUsers();
      } else if (this.currentUrl === "/vsr") {
        //this.setupVSRForOtherUsers();
      }


    }

    // if ((this.currentUrl!=undefined) && (this.userInRoeleDol) && (this.currentUrl.startsWith('/vsr'))) {
    //   console.log("SSB: making dol address search default for DOL user ");
    //   this.setupVSRForDOLUser();

    // }
    // if ((this.currentUrl===undefined) && (this.userInRoeleDol) && (this.router.url.startsWith('/vsr'))) {
    //   this.model.selectedSearchType = "vsr";
    //   this.model.selectedSearchFunction = "dolAddr";
    //   this.model.functionDescription=AppSettings.SSB_dolAddr_DESCRIPTION; 

    //   this.model.selectedSearchTypeIndex = 0;
    //   this.model.disabledSearchById=true;
    //   this.model.searchById = '';

    //   let cStatus = new ComponentStatus();
    //   cStatus.srcComponentName = AppSettings.CS_SSB;
    //   cStatus.destComponentName = AppSettings.CS_VSR;
    //   cStatus.data="dolManualSearch"; 
    //   this.cssStatusService.changeMessage(cStatus);

    // }
    // else {
    //   this.model.selectedSearchType = "vsr";
    //   this.model.selectedSearchTypeIndex = 0;
    //   this.model.selectedSearchFunction = "receiptNumber";
    //   this.model.functionDescription = this.searchTypes[this.model.selectedSearchTypeIndex].functions[0].description;
    //   this.model.searchById = "";
    //   this.model.error = "";
    // }
  }

  private updatecssSubscription() {
    if (this.userInRoleService.userInRole && this.userInRoleService.userInRole.dolUser) this.userInRoeleDol = true;
    if (this.userInRoleService.userInRole && this.userInRoleService.userInRole.businessAdministrator) this.userInRoeleBA = true;

    // console.log("*** SSB: userInRoleService=" + JSON.stringify(this.userInRoleService));
    // console.log("*** SSB: this.userInRoeleDol=" + this.userInRoeleDol);
    // console.log("*** SSB: this.userInRoeleBA =" + this.userInRoeleBA);

    this.setDefaultSSBOptions();

    this.cssSubscription = this.css.currentMessage.subscribe(message => {
      if ((message.destComponentName === AppSettings.CS_SSB) &&
        (message.error)) {
        console.log("error received: " + message.error);
        this.model.error = message.error;
        let x = document.getElementById("globalerror");
        if (x) {
          console.log("global-error found and placing focus on it");
          x.scrollIntoView();
          x.focus();
        }
        else
          setTimeout(() => {
            let x = document.getElementById("globalerror");
            x.scrollIntoView();
            x.focus();
          }, 500);
      }
      if (message.clear) {
        this.loading = false;
        // message.data = null;
        this.model.error = "";
        if (this.model.address) {
          this.model.address = undefined;
        }
      }
    });
  }

  private setDefaultSSBOptions() {

    // console.log("SSB: setDefaultSSBOptions");

    if (this.userInRoeleDol || this.userInRoeleBA) {
      // console.log("SSB: setDefaultSSBOptions, user is DOL or BA");
      this.searchTypes = [
        {
          id: "vsr", display: AppSettings.SSB_vsr_DISPLAY, functions: [
            { id: "receiptNumber", display: AppSettings.SSB_receiptNumber_DISPLAY, description: AppSettings.SSB_receiptNumber_DESCRIPTION },
            { id: "dolAddr", display: AppSettings.SSB_dolAddr_DISPLAY, description: AppSettings.SSB_dolAddr_DESCRIPTION }
          ]
        },
        {
          id: "previousFilings", display: AppSettings.SSB_previousFilings_DISPLAY, functions: [{ id: "pfFein", display: AppSettings.SSB_pfFein_DISPLAY, description: AppSettings.SSB_pfFein_DESCRIPTION },
          { id: "pfDuns", display: AppSettings.SSB_pfDuns_DISPLAY, description: AppSettings.SSB_pfDuns_DESCRIPTION },
          { id: "pfEta", display: AppSettings.SSB_pfEta_DISPLAY, description: AppSettings.SSB_pfEta_DESCRIPTION },
          { id: "pfBA", display: AppSettings.SSB_pfBA_DISPLAY, description: AppSettings.SSB_pfBA_DESCRIPTION }
          ]
        },
        //{ id: "prevEtaFilings", display: AppSettings.SSB_prevEtaFilings_DISPLAY, functions: [{ id: "pfEta", display: AppSettings.SSB_pfEta_DISPLAY, description:  AppSettings.SSB_pfEta_DESCRIPTION}] },
        { id: "dolEtaLookup", display: AppSettings.SSB_dolEtaLookup_DISPLAY, functions: [{ id: "dolEta", display: AppSettings.SSB_dolEta_DISPLAY, description: AppSettings.SSB_dolEta_DESCRIPTION }] }
      ];
    }
    else {
      // console.log("SSB: setDefaultSSBOptions, user is not  DOL or BA");

      this.searchTypes = [
        {
          id: "vsr", display: AppSettings.SSB_vsr_DISPLAY, functions: [
            { id: "receiptNumber", display: AppSettings.SSB_receiptNumber_DISPLAY, description: AppSettings.SSB_receiptNumber_DESCRIPTION }
          ]
        },
        {
          id: "previousFilings", display: AppSettings.SSB_previousFilings_DISPLAY, functions: [{ id: "pfFein", display: AppSettings.SSB_pfFein_DISPLAY, description: AppSettings.SSB_pfFein_DESCRIPTION },
          { id: "pfDuns", display: AppSettings.SSB_pfDuns_DISPLAY, description: AppSettings.SSB_pfDuns_DESCRIPTION },
          { id: "pfEta", display: AppSettings.SSB_pfEta_DISPLAY, description: AppSettings.SSB_pfEta_DESCRIPTION },
          { id: "pfBA", display: AppSettings.SSB_pfBA_DISPLAY, description: AppSettings.SSB_pfBA_DESCRIPTION }
          ]
        },
        //{ id: "prevEtaFilings", display: AppSettings.SSB_prevEtaFilings_DISPLAY, functions: [{ id: "pfEta", display: AppSettings.SSB_pfEta_DISPLAY, description:  AppSettings.SSB_pfEta_DESCRIPTION}] },
        { id: "dolEtaLookup", display: AppSettings.SSB_dolEtaLookup_DISPLAY, functions: [{ id: "dolEta", display: AppSettings.SSB_dolEta_DISPLAY, description: AppSettings.SSB_dolEta_DESCRIPTION }] }
      ];
    }


    this.setupSsbForRole();
    // console.log("*SSB userInRoeleDol: ");
    // if (this.userInRoeleDol) {
    //   console.log("*SSB: user role is dol");
    //   this.model.selectedSearchType = "vsr";
    //   this.model.selectedSearchFunction = "dolAddr";
    //   this.model.selectedSearchTypeIndex = 0;
    //   this.model.functionDescription=AppSettings.SSB_dolAddr_DESCRIPTION; 
    // }

  }

  pfAddressSearchEventHandler(address) {
    // console.log("Search received address");
    // console.log(address);
    this.model.selectedSearchType = "previousFilings";
    this.model.selectedSearchFunction = "pfBA";
    this.model.searchById = "";
    this.model.address = address;
    this.newMessage();

  }

  setFocus() {
    //this._el.nativeElement.focus();
  }
  ngAfterViewInit() {
    //this._el.nativeElement.focus();
  }



  ngOnInit() {

    // this.pfAddressSearched = pfAddressSearched();
    this.data.currentMessage.subscribe(message => this.model = message);
    console.log("in ssb ngInit");

    this.setDefaultSSBOptions();

    //this.functionDescription = this.searchCriteriaDescriptions[fn.selectedIndex];
    this.setFocus();


    //Reactive Forms
    this.ssb = this.fb.group({
      receiptNumber: [null, Validators.pattern('^[A-Z]{3}\d{10}$')],
      peviousFilingsDuns: [null, Validators.pattern('^\d{9}$')],
      peviousFilingsFein: [null, Validators.pattern('^\d{9}$')],
      peviousFilingsAddress: this.fb.group({
        org: [null, Validators.required],
        street: [null, Validators.required],
        city: [],
        state: [null, Validators.required],
        zip: [],
        country: [null, Validators.required],
      }),
      dolPreviousEtaFilingsCaseNumber: [null, Validators.pattern('^H|^I-\d{14}$')],
      dolEtaLookupCaseNumber: [],
    });


  }


  //executed when the first search drop down changes 
  onSearchTypeSelect(selectedOption) {
    console.log("searchType=" + selectedOption.target.value);
    switch (selectedOption.target.value) {
      case "vsr":
        this.model.selectedSearchType = "vsr";
        this.model.selectedSearchTypeIndex = 0;
        this.model.selectedSearchFunction = "receiptNumber";
        this.model.functionDescription = this.searchTypes[this.model.selectedSearchTypeIndex].functions[0].description;
        this.appRouter.navigate(['/vsr']);
        break;
      case "previousFilings":
        console.log("in prev filings hub");
        this.model.selectedSearchType = "previousFilings";
        this.model.selectedSearchTypeIndex = 1;
        this.model.selectedSearchFunction = "pfDuns";
        this.model.functionDescription = this.searchTypes[this.model.selectedSearchTypeIndex].functions[0].description;
        this.appRouter.navigate(['/previous-filings']);
        break;
      // case "prevEtaFilings":
      //   this.model.selectedSearchType = "prevEtaFilings";
      //   this.model.selectedSearchTypeIndex = 2;
      //   this.model.selectedSearchFunction = "pfEta";
      //   this.model.functionDescription = this.searchTypes[this.model.selectedSearchTypeIndex].functions[0].description;
      //   this.appRouter.navigate(['/previous-eta-filings']); 
      //   break;
      case "dolEtaLookup":
        this.model.selectedSearchType = "dolEtaLookup";
        this.model.selectedSearchTypeIndex = 2;
        this.model.selectedSearchFunction = "dolEta";
        this.model.functionDescription = this.searchTypes[this.model.selectedSearchTypeIndex].functions[0].description;
        this.appRouter.navigate(['/dol-eta-lookup']);
        break;
      default:

        break;

    }

    this.setFocus();
    this.model.searchById = "";
  }


  setupVSRForDOLUsers() {
    // console.log("SSB: setupVSRForDOLUser");
    this.model.selectedSearchType = "vsr";
    this.model.selectedSearchFunction = "dolAddr";
    this.model.functionDescription = AppSettings.SSB_dolAddr_DESCRIPTION;

    this.model.selectedSearchTypeIndex = 0;
    this.model.disabledSearchById = true;
    this.model.searchById = '';

    let cStatus = new ComponentStatus();
    cStatus.srcComponentName = AppSettings.CS_SSB;
    cStatus.destComponentName = AppSettings.CS_VSR;
    cStatus.data = "dolManualSearch";
    this.cssStatusService.changeMessage(cStatus);
  }

  setupVSRForOtherUsers() {
    this.model.selectedSearchType = "vsr";
    this.model.selectedSearchFunction = "receiptNumber";
    this.model.functionDescription = AppSettings.SSB_receiptNumber_DESCRIPTION;
    this.model.selectedSearchTypeIndex = 0;
    this.model.disabledSearchById =false;
    this.model.searchById = '';
    this.model.error="";

  }


  private async  delay(ms: number) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  searchButtonClicked(event): void {
    this.model.searchById = this.model.searchById.trim().toUpperCase();
    let cStatus = new ComponentStatus();
    cStatus.srcComponentName = AppSettings.CS_SSB;
    cStatus.clear = true;


    // console.log("Search button clicked: " + JSON.stringify(this.model));
    switch (this.model.selectedSearchFunction) {
      case "receiptNumber":
        cStatus.destComponentName = AppSettings.CS_VSR;
        this.cssStatusService.changeMessage(cStatus);

        if (this.validateReceiptNumber(this.model.searchById)) this.newMessage();
        else this.newMessage();
        break;
      // case "dolAddress":
      //   cStatus.destComponentName = AppSettings.CS_VSR;
      //   this.cssStatusService.changeMessage(cStatus);

      //   if (this.validateReceiptNumber(this.model.searchById)) this.newMessage();
      //   else this.newMessage();
      //   break;
      case "pfDuns":
        cStatus.destComponentName = AppSettings.CS_PREVIOUS_FILINGS_HUB;
        this.cssStatusService.changeMessage(cStatus);
        if (this.validateDuns(this.model.searchById)) this.newMessage();
        break;
      case "pfBA":
        cStatus.destComponentName = AppSettings.CS_PREVIOUS_FILINGS_HUB;
        this.cssStatusService.changeMessage(cStatus);
        if (this.validateAddress(this.model.address)) this.newMessage();
        break;
      case "pfFein":
        cStatus.destComponentName = AppSettings.CS_PREVIOUS_FILINGS_HUB;
        this.cssStatusService.changeMessage(cStatus);
        if (this.validateFein(this.model.searchById)) this.newMessage();
        break;

      case "pfEta":
        cStatus.destComponentName = AppSettings.CS_PREVIOUS_FILINGS_HUB;
        this.cssStatusService.changeMessage(cStatus);

        if (this.validateEtaCaseNumber(this.model.searchById)) this.newMessage();
        break;

      case "dolEta":
        // cStatus.destComponentName = AppSettings.CS_DOL_ETA_LOOKUP
        // this.cssStatusService.changeMessage(cStatus);
        this.cssStatusService.changeMessage(cStatus);
        if (this.validateEtaCaseNumber(this.model.searchById)) {
          this.loading = true;
          this.dolSvc.getDolByCaseId(this.model.searchById.replace(/-/g, '')).subscribe(data => {

            if (data.GetDolDetailByEtaCaseNumberResponse.ResponseStatusMessage.StatusCode == "-1") {
              this.model.error = AppSettings.VSR_STATUS_CODE_001_DESC
              this.loading = false;
              return;
            }
            if (data.GetDolDetailByEtaCaseNumberResponse) {
              if (data.GetDolDetailByEtaCaseNumberResponse.DolEtaFormType == '9142') {
                cStatus.destComponentName = AppSettings.CS_DOL_ETA_LOOKUP
              }
              else if (data.GetDolDetailByEtaCaseNumberResponse.DolEtaFormType == '9142C') {
                cStatus.destComponentName = AppSettings.CS_DOL_ETA_9142C
              } else if (data.GetDolDetailByEtaCaseNumberResponse.DolEtaFormType == '9142A') {
                cStatus.destComponentName = AppSettings.CS_DOL_ETA_9142A
              } else if (data.GetDolDetailByEtaCaseNumberResponse.DolEtaFormType == '9142B') {
                cStatus.destComponentName = AppSettings.CS_DOL_ETA_9142BV2
              } else if (data.GetDolDetailByEtaCaseNumberResponse.DolEtaFormType == '9035') {
                if (data.GetDolDetailByEtaCaseNumberResponse.DolEtaFormVersion == '1') {
                  cStatus.destComponentName = AppSettings.CS_DOL_ETA_9035V1
                } else if (data.GetDolDetailByEtaCaseNumberResponse.DolEtaFormVersion == '2') {
                  cStatus.destComponentName = AppSettings.CS_DOL_ETA_9035V2
                }
              } else {
                this.model.error = "Unsupported DOL Form Type " + data.GetDolDetailByEtaCaseNumberResponse.DolEtaFormType
                this.loading = false;
                // console.log("Unsupported Type " + data.GetDolDetailByEtaCaseNumberResponse.DolEtaFormType)
                return;

              }
              cStatus.data = data
              // console.log("making call")
              this.cssStatusService.changeMessage(cStatus);
              //this.loading = false;
            }
          });
          //this.loading=false;

          var searchById = this.model.searchById

          //this.newMessage();
        }
        break;

      default:
        this.newMessage();
        break;
        this.setFocus();
    }
  }

  onSelectFunction(event): void {


    let cStatus = new ComponentStatus();
    cStatus.srcComponentName = AppSettings.CS_SSB;
    cStatus.clear = true;


    // console.log("Search function selected: " + JSON.stringify(this.model));
    switch (this.model.selectedSearchFunction) {
      case "receiptNumber":
        this.model.functionDescription = "vsr"
        this.model.functionDescription = AppSettings.SSB_receiptNumber_DESCRIPTION;
        this.model.error = "";
        this.model.searchById = "";
        this.model.disabledSearchById = false;

        cStatus.destComponentName = AppSettings.CS_VSR;
        this.cssStatusService.changeMessage(cStatus);

        break;
      case "dolAddr":
        this.model.functionDescription = AppSettings.SSB_dolAddr_DESCRIPTION;
        this.model.selectedSearchFunction = "dolAddr";
        this.model.error = "";
        this.model.searchById = "";
        this.model.disabledSearchById = true;

        cStatus.destComponentName = AppSettings.CS_VSR;
        this.cssStatusService.changeMessage(cStatus);


        break;
      case "pfDuns":
        this.model.functionDescription = AppSettings.SSB_pfDuns_DESCRIPTION;
        this.model.selectedSearchFunction = "pfDuns";
        this.model.error = "";
        this.model.searchById = "";
        this.model.disabledSearchById = false;

        cStatus.destComponentName = AppSettings.CS_PREVIOUS_FILINGS_HUB;
        this.cssStatusService.changeMessage(cStatus);


        break;
      case "pfBA":
        this.model.functionDescription = AppSettings.SSB_pfBA_DESCRIPTION;
        this.model.selectedSearchFunction = "pfBA";
        this.model.disabledSearchById = true;
        this.model.searchById = "";
        this.model.error = "";
        // console.log("pfBA Clicked: sending message");

        cStatus.destComponentName = AppSettings.CS_PREVIOUS_FILINGS_HUB;
        this.cssStatusService.changeMessage(cStatus);
        this.newMessage();

        break;
      case "pfFein":
        this.model.functionDescription = AppSettings.SSB_pfFein_DESCRIPTION;
        this.model.selectedSearchFunction = "pfFein";
        this.model.searchById = "";
        this.model.error = "";
        this.model.disabledSearchById = false;

        cStatus.destComponentName = AppSettings.CS_PREVIOUS_FILINGS_HUB;
        this.cssStatusService.changeMessage(cStatus);

        break;

      case "pfEta":
        this.model.functionDescription = AppSettings.SSB_pfEta_DESCRIPTION;
        this.model.selectedSearchFunction = "pfEta";
        this.model.searchById = "";
        this.model.error = "";
        this.model.disabledSearchById = false;

        cStatus.destComponentName = AppSettings.CS_PREVIOUS_FILINGS_HUB;
        this.cssStatusService.changeMessage(cStatus);
        break;

      case "dolEta":
        this.model.functionDescription = "DOL ETA Search";
        this.model.selectedSearchFunction = "dolEta";
        this.model.searchById = "";
        this.model.error = "";

        cStatus.destComponentName = AppSettings.CS_DOL_ETA_LOOKUP
        this.cssStatusService.changeMessage(cStatus);

        break;

      default:
        this.model.functionDescription = "Receipt Number";
        this.model.selectedSearchFunction = "vsr";
        this.model.searchById = "";
        this.model.error = "";

        cStatus.destComponentName = AppSettings.CS_VSR;
        this.cssStatusService.changeMessage(cStatus);
        this.setFocus();
        break;

    }
  }

  ngOnDestroy() {
    if(this.cssSubscription){
    this.cssSubscription.unsubscribe();
    }
  }


  validateEtaCaseNumber(etaCaseId: string): boolean {
    var etaCaseId = etaCaseId.trim().replace(/-/g, "").toUpperCase();
    if ((etaCaseId != '') && (etaCaseId.length == 15) && ((etaCaseId.indexOf("H") == 0) || (etaCaseId.indexOf("I") == 0) || (etaCaseId.indexOf("C") == 0)) && (Number(etaCaseId.substring(1)))) {
      // console.log("valid dol case #");
      this.model.error = "";
      return true;
    } else {
      // console.log("invalid dol case #" + etaCaseId);
      this.model.error = "Required format: {H|I|C}-000-00000-000000";
      return false;
    }
  }


  validateDuns(duns: string): boolean {
    duns = duns.trim();

    if (duns.length == 9 && duns.match(/\d{9}/g)) {
      // console.log("valid duns #");
      this.model.error = "";
      return true;
    }
    // console.log("invalid duns #");
    this.model.error = AppSettings.INVALID_DUNS;

    return false;
  }

  validateAddress(searchAddress: VSRResubmitAddress): boolean {
    // console.log("imq address to search: ")
    if ((searchAddress.organizationName.trim.length != 0) &&
      (searchAddress.streetFull.trim.length != 0) &&
      (searchAddress.state.trim.length != 0) &&
      (searchAddress.country.trim.length != 0)) {
      return true;
    }

    return false;
  }

  validateFein(fein: string): boolean {
    fein = fein.trim();

    if (fein.length == 9 && fein.match(/\d{9}/g)) {
      // console.log("valid fein #");
      this.model.error = "";
      return true;
    }
    // console.log("invalid fein #");
    this.model.error = AppSettings.INVALID_FEIN_NUMBER;

    return false;
  }



  validateReceiptNumber(receiptNumber: string): boolean {
    receiptNumber = receiptNumber.trim();

    if (receiptNumber.length == 13 && receiptNumber.match(/[A-Z]{3}\d{10}/g)) {
      this.model.error = "";
      return true;
    }
    // console.log("invalid receipt #");
    this.model.error = AppSettings.INVALID_RECEIPT_NUMBER;
    return false;
  }


  refresh(): void {

  }


  clearGlobalError(): void {
    this.model.searchById = ""; //clear the search box  
    this.model.error = "";    //clear the error
  }


  onGlobalErrorChange(): boolean {

    let x = document.getElementById("globalerror");
    if (this.model.error) {
      if (x) {
        x.scrollIntoView();
        x.focus();
        return true;
      } else setTimeout(() => {
        x = document.getElementById("globalerror");
        if (x) {
          x.scrollIntoView();
          x.focus();
          return true;
        } else return false;
      }, 500);
      return false;
    }
    else return false;
  }

  onKeyDownEnter(event) {
    if (document.activeElement.getAttribute("id") === "searchById") {
      this.searchButtonClicked(event)
    }
  }

  onAllKeyDown(event: KeyboardEvent) {

    // console.log(event.shiftKey);
    // console.log("***key=" + event.key);
    // console.log("***keyCode=" + event.keyCode);
    // console.log("***which=" + event.which);
    // console.log("***code=" + event.code);
    // console.log("key down: event.code=" + event.code);
    // console.log(this.model.selectedSearchFunction)

    if (event.keyCode == 116) {
      // console.log("Stop reloading the page Kokil.");
      this.appRouter.navigate(['/']);
    }
    if (this.router.url.startsWith("/vsr")) {

      //enter = 13

      if ((event.keyCode != 13) &&
        (!event.shiftKey) &&
        (event.keyCode != 9) &&   //tab

        (event.keyCode != 37) &&   //left
        (event.keyCode != 38) &&   //up
        (event.keyCode != 39) &&   //rigth
        (event.keyCode != 40) &&   //down
        (event.keyCode != 17) &&   //down
        (!event.altKey) &&
        !((event.ctrlKey || event.metaKey) && event.keyCode == 67) &&
        !((event.ctrlKey || event.metaKey) && event.keyCode == 86)) {

        console.log("tagname=" + document.activeElement.tagName);


        // if ((document.activeElement.getAttribute("id") === "searchById") &&
        //     (document.activeElement.getAttribute("id") === "searchById")) {
        if ((document.activeElement.tagName == "INPUT") ||
          (document.activeElement.tagName == "SELECT") ||
          (document.activeElement.tagName == "TEXTAREA") ||
          (document.activeElement.tagName == "BUTTON")) {
          return
        } else {
          console.log("on vsr page, lets put foucs on the input");
          document.getElementById("searchById").focus();
        }
      }
      // if ((event.code != "Enter") && 
      //     (event.code != "Tab") && 
      //     (event.code != "Space") &&
      //     (event.code != "ControlLeft") &&
      //     (event.code != "ControlRight") &&
      //     (event.code != "ArrowDown") &&
      //     (event.code != "ArrowUp") &&
      //     (event.code != "ArrowLeft") &&
      //     (event.code != "ArrowLeft") &&
      //     !((event.ctrlKey || event.metaKey) && event.keyCode == 67) &&
      //     !((event.ctrlKey || event.metaKey) && event.keyCode == 86)){
      //   if (document.activeElement.tagName == "INPUT") {
      //     return
      //   } else {
      //     console.log("on vsr page, lets put foucs on the input"); 
      //     document.getElementById("searchById").focus();
      //   }


    }

  }

  onInput(event) {

    this.model.searchById = this.model.searchById.trim();

    // console.log(this.model.selectedSearchFunction)
    if ((this.model.selectedSearchFunction == "dolEta") ||
      (this.model.selectedSearchFunction == "pfEta")) {
      console.log(this.model.searchById)
      if (this.model.searchById.length == 15 && this.match2(this.model.searchById, '-').length == 0) {
        var searchById = this.model.searchById
        this.model.searchById = this.model.searchById.charAt(0) + "-" + this.model.searchById.substr(1, 3) + "-" + this.model.searchById.substr(4, 5) + "-" + this.model.searchById.substr(9, 6)
        this.validateEtaCaseNumber(searchById)
      }
      else if (this.model.searchById.length == 16 && (this.match2(this.model.searchById, '-').length == 1)) {
        var searchById = this.model.searchById
        this.model.searchById = this.model.searchById.replace(/-/g, '')
        this.model.searchById = this.model.searchById.charAt(0) + "-" + this.model.searchById.substr(1, 3) + "-" + this.model.searchById.substr(4, 5) + "-" + this.model.searchById.substr(9, 6)
        this.validateEtaCaseNumber(searchById)

      }
      else if (this.model.searchById.length == 17 && (this.match2(this.model.searchById, '-').length == 2)) {
        var searchById = this.model.searchById
        this.model.searchById = this.model.searchById.replace(/-/g, '')
        this.model.searchById = this.model.searchById.charAt(0) + "-" + this.model.searchById.substr(1, 3) + "-" + this.model.searchById.substr(4, 5) + "-" + this.model.searchById.substr(9, 6)
        this.validateEtaCaseNumber(searchById)

      } else if (this.model.searchById.length == 18 && (this.match2(this.model.searchById, '-').length == 3)) {
        var searchById = this.model.searchById
        this.model.searchById = this.model.searchById.replace(/-/g, '')
        this.model.searchById = this.model.searchById.charAt(0) + "-" + this.model.searchById.substr(1, 3) + "-" + this.model.searchById.substr(4, 5) + "-" + this.model.searchById.substr(9, 6)
        this.validateEtaCaseNumber(searchById)

      } else if ((this.model.searchById.length > 18 && (this.model.searchById.search('-') && this.match2(this.model.searchById, '-').length >= 3)) || (this.model.searchById.length > 15 && !this.model.searchById.search('-'))) {
        this.validateEtaCaseNumber(this.model.searchById)
      }
    }
  }
  onKeyUp() {
    if ((this.model.selectedSearchFunction == "dolEta") ||
      (this.model.selectedSearchFunction == "pfEta")) {
      // console.log(this.model.searchById)
      if (this.model.searchById.length == 15 && this.match2(this.model.searchById, '-').length == 0) {
        var searchById = this.model.searchById
        this.model.searchById = this.model.searchById.charAt(0) + "-" + this.model.searchById.substr(1, 3) + "-" + this.model.searchById.substr(4, 5) + "-" + this.model.searchById.substr(9, 6)
        this.validateEtaCaseNumber(searchById)
      }
      else if (this.model.searchById.length == 16 && (this.match2(this.model.searchById, '-').length == 1)) {
        var searchById = this.model.searchById
        this.model.searchById = this.model.searchById.replace(/-/g, '')
        this.model.searchById = this.model.searchById.charAt(0) + "-" + this.model.searchById.substr(1, 3) + "-" + this.model.searchById.substr(4, 5) + "-" + this.model.searchById.substr(9, 6)
        this.validateEtaCaseNumber(searchById)

      }
      else if (this.model.searchById.length == 17 && (this.match2(this.model.searchById, '-').length == 2)) {
        var searchById = this.model.searchById
        this.model.searchById = this.model.searchById.replace(/-/g, '')
        this.model.searchById = this.model.searchById.charAt(0) + "-" + this.model.searchById.substr(1, 3) + "-" + this.model.searchById.substr(4, 5) + "-" + this.model.searchById.substr(9, 6)
        this.validateEtaCaseNumber(searchById)

      } else if (this.model.searchById.length == 18 && (this.match2(this.model.searchById, '-').length == 3)) {
        var searchById = this.model.searchById
        this.model.searchById = this.model.searchById.replace(/-/g, '')
        this.model.searchById = this.model.searchById.charAt(0) + "-" + this.model.searchById.substr(1, 3) + "-" + this.model.searchById.substr(4, 5) + "-" + this.model.searchById.substr(9, 6)
        this.validateEtaCaseNumber(searchById)

      } else if ((this.model.searchById.length > 18 && (this.model.searchById.search('-') && this.match2(this.model.searchById, '-').length >= 3)) || (this.model.searchById.length > 15 && !this.model.searchById.search('-'))) {
        this.validateEtaCaseNumber(this.model.searchById)
      }
    }
  }
  match2(str: string, srch: string) {
    var result = []
    for (let char of str) {
      if (char == srch) {
        result.push(char)
      }
    }
    return result
  }
}
