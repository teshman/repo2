import { SearchFunctions } from "./search-functions";

export class SearchTypes{
    public id: string;
    public display: string;
    public functions: SearchFunctions[]=[]; 

}

