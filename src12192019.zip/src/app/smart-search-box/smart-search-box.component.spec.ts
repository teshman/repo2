import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { SmartSearchBoxComponent } from './smart-search-box.component';

describe('SmartSearchBoxComponent', () => {
  let component: SmartSearchBoxComponent;
  let fixture: ComponentFixture<SmartSearchBoxComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SmartSearchBoxComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SmartSearchBoxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
