import { Injectable } from '@angular/core';
import { catchError, map, tap } from 'rxjs/operators';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AppSettings} from './shared/app-settings'
import { Observable, of , throwError, Subject, BehaviorSubject} from 'rxjs';
import { RedReportGetAdvancedResponseProxy, RedReportMarkSendResponseProxy} from './shared/RedReport_proxies';
import {RedReportDateRequest, RedReportMarkRequest, UpdateRedListPetitionSet} from './shared/RedReport_interfaces'

@Injectable({
  providedIn: 'root'
})
export class RedReportsService {
  private redReportDateUrl = AppSettings.RED_REPORTS_DATE_URL
  private redReportMarkUrl = AppSettings.RED_REPORTS_MARK_URL
  redReportDatePost: RedReportDateRequest;
  redReportMarkPost: RedReportMarkRequest;
  
  request = `POST DATA: 
  {
    "sourceSystemID":"swagger",
    "sourceTransactionID":"23453425435436436",
    "endUserID":"akumar",
    "updateRedListPetitionSet":{
      "updateRedListPetition":[
        {
          "receiptNumber":"WAC1419650037",
          "deliverToCFDO":true,
          "petitionID":"0"
        }
      ]
    }
  }


Response: 

{
    "RedReportMarkSendToCFDOResponse": {
        "SourceSystemID": "VIBEServices",
        "SourceTransactionID": "d0ef263f-28dd-4387-9a6e-32d908ed99f0",
        "ServiceRequestTimestamp": "2019-05-16T09:13:54.132-05:00",
        "ServiceResponseTimestamp": "2019-05-16T09:13:54.441-05:00",
        "AuditCorrelationID": "d0ef263f-28dd-4387-9a6e-32d908ed99f0",
        "UpdateMessage": "SUCCESS"
    }
}
`

  constructor(private http: HttpClient) { }


  getRedReportByDateRange(startDate: string, endDate: string, serviceCenter: string = null): Observable<RedReportGetAdvancedResponseProxy> {
    const url = `${this.redReportDateUrl}`;
    this.redReportDatePost = <RedReportDateRequest>{};
    this.redReportDatePost.sourceSystemID = "swagger";
    this.redReportDatePost.sourceTransactionID = "asdfasdfsd";
    this.redReportDatePost.endUserID = "akumar";
    this.redReportDatePost.startDate = startDate;
    this.redReportDatePost.endDate = endDate;
    this.redReportDatePost.serviceCenter = serviceCenter;
    console.log(this.redReportDatePost)
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/json'
        // 'Authorization': 'my-auth-token'
      })
    };
//
    return this.http.post<RedReportGetAdvancedResponseProxy>(url,JSON.stringify(this.redReportDatePost),httpOptions).pipe(
      tap(_ => console.log(`get RedReport for Dates #=${startDate} and ${endDate}`)),
      catchError(this.handleError<RedReportGetAdvancedResponseProxy>(`error get Red Report for Dates #=${startDate} and ${endDate}`))
    );
  }

  updateRedlistPetitionSet(petitionSet: UpdateRedListPetitionSet): Observable<RedReportMarkSendResponseProxy> {
    const url = `${this.redReportMarkUrl}`;
    this.redReportMarkPost = <RedReportMarkRequest>{};
    this.redReportMarkPost.sourceSystemID = "swagger";
    this.redReportMarkPost.sourceTransactionID = "asdfasdfsd";
    this.redReportMarkPost.endUserID = "akumar";
    this.redReportMarkPost.updateRedListPetitionSet = petitionSet;
    console.log(this.redReportMarkPost)
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/json'
        // 'Authorization': 'my-auth-token'
      })
    };
//
    return this.http.post<RedReportMarkSendResponseProxy>(url,JSON.stringify(this.redReportMarkPost),httpOptions).pipe(
      tap(_ => console.log(`update RedList for Petition Set #=${petitionSet}`)),
      catchError(this.handleError<RedReportMarkSendResponseProxy>(`error update RedList for Petition Set #=${petitionSet}`))
    );
  }


  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // TODO: better job of transforming error for user consumption
      console.log(`${operation} failed: ${error.message}`);

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }
  private handleErrorObservable(error: Response | any) {
    console.error("the error thrown is: " + (error.message));
    let statusMessage: string = "";
    // return Observable.throw(error.message || error);
    //return Observable.throw(new Error(error.status));
    let status: string = JSON.stringify(error.status);
    switch (status) {
      case '400':
        statusMessage = AppSettings.HTTP_STATUS_400;
        break;
      case '404':
        statusMessage = AppSettings.HTTP_STATUS_404;
        break;
      case '500':
        statusMessage = AppSettings.HTTP_STATUS_500;
        break;
      case '503':
        statusMessage = AppSettings.HTTP_STATUS_503;
        break;
      case '502':
        statusMessage = AppSettings.HTTP_STATUS_502;
        break;
      case '599':
        statusMessage = AppSettings.HTTP_STATUS_599;
        break;
      case '408':
        statusMessage = AppSettings.HTTP_STATUS_408;
        break;
      default:
        statusMessage = AppSettings.HTTP_STATUS_UNKNOWN;
  }
    return throwError(statusMessage);
  }
}
