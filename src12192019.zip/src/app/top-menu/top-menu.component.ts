import { Component, OnInit } from '@angular/core';
import {TopMenuService} from './top-menu.service'
import { UserProfile } from '../shared/user-profile';
import { UserProfileService } from '../user-profile.service';
import { Router } from '@angular/router';



@Component({
  selector: 'app-top-menu',
  templateUrl: './top-menu.component.html',
  styleUrls: ['./top-menu.component.css'], 
  providers: [TopMenuService]
})

export class TopMenuComponent implements OnInit {

  displayName : string = "";
  userProfile: UserProfile; 
  myTabs : any; 
  
  private myUserProfileService : UserProfileService; 

  
  // constructor(private userProfileService: UserProfileService,
  //   private router: Router,
  //   private userInRoleService: UserInRoleService,
  //   private userIdleService: UserIdleService, 
  //   private loginHistoryService: LoginHistoryService) {

  constructor(private userProfileService: UserProfileService, private router: Router) {
    this.myUserProfileService = userProfileService;
    this.myUserProfileService.getUserProfile().subscribe(
      data => {
        if (data) {
          this.userProfile = data;
          this.displayName = data.displayName;
          localStorage.setItem("currentUser",data.displayName);
          this.myTabs = data.topLevelNavigationBasedOnUserRole; 
          
          console.log("userName="+this.displayName);
          console.log("data="+JSON.stringify(data)); 
          
        }
        else {
          console.log("No user profile data");           
        }
      },
      error => {
        (async () => {
          console.log("User Not logged in"); 
          //this.appsAlert = AppSettings.VSR_STATUS_CODE_003_DESC + ", " + JSON.stringify(error);
        })();
      }
    );

   }

   
  toContent() {
    if ((this.router.url.match('/helpful-links')) ||
      (this.router.url.match('/user-profile')) ||
      (this.router.url.match('/admin'))) {

        let x = document.getElementById("content");
        if (x) {
          console.log("content area found and placing focus on it");
          x.scrollIntoView();
          x.focus();
  
        }
    } else {
      let x = document.getElementById("searchType");
      if (x) {
        console.log("searchType found and placing focus on it");
        x.scrollIntoView();
        x.focus();

      }

    }
  }
  ngOnInit() {
    
  }

}
