import { Component, OnInit , Input, ViewChild } from '@angular/core';
import {AppSettings } from '../shared/app-settings'
import { Router } from '@angular/router';
import {Previousfiling} from '../shared/previous_filings_interfaces'
import {pfDunsResponse} from '../shared/dunsResponse_interfaces'
import { PreviousFilingsService } from '../previous-filings.service';
import { SmartSearchModel }  from "../shared/smart-search-model";
import { SmartSearchBoxComponent } from '../smart-search-box/smart-search-box.component';
import { SmartSearchService } from '../smart-search.service';
import { Subscription } from 'rxjs';
import { ClrDatagridStateInterface, ClrDatagridPagination, ClrDatagrid} from '@clr/angular'
import { ComponentStatusService } from '../shared/service/component-status.service';
import { dateFilter } from '../previous-filings-imq/date-filter/date-filter.component';
import { StatusFilter} from '../previous-filings-imq/status-filter/status-filter.component';
import { ExcelService } from '../excel.service';


@Component({
  selector: 'app-previous-filings',
  templateUrl: './previous-filings.component.html',
  styleUrls: ['./previous-filings.component.css']
})
export class PreviousFilingsComponent implements OnInit {
  @Input() orgShowSmartMenu: boolean = true;
  @Input() dunsNum: string = "";
  @Input() organizationName:string = "";
  @Input() petitionType: string = "";
  @Input() dolCaseNum: string = "";
  @ViewChild('dateFilter', { static: false }) datechild:dateFilter;
  @ViewChild('StatusFilter', { static: false }) statuschild:StatusFilter;

  showvsrmodal: boolean = false;

  previousFiling: Previousfiling;
  pfDuns: pfDunsResponse;
  pfDunsTemp: pfDunsResponse;
  searchSubscription: Subscription;
  showEta = false;
  showDuns = false;
  showReport = false;
  showAlert = false;
  appsAlert = '';
  count: number;
  filteredResults: number = 1;
  showCount = false;
  loading = false;
  loadingeta = false;
  alertMessage = "Visa Type Selection Required"
  showValidationAlert = false;
  typeTitle = "Form Type:"
  show129 = false;
  show140 = false;
  masterSelected = true;
  ajudicativeStatus = "";
  timePeriod = "12";
  visaTypes = [];
  resultset = [];
  checkboxes = [
    {
      "name": "1B1",
      "checked": true,
      "visible": true,
      "type": "I-129"
    },
    {
      "name": "1B2",
      "checked": true,
      "visible": true,
      "type": "I-129"
    },
    {
      "name": "1B3",
      "checked": true,
      "visible": true,
      "type": "I-129"
    },
    {
      "name": "HSC",
      "checked": true,
      "visible": true,
      "type": "I-129"
    },
    {
      "name": "L1A",
      "checked": true,
      "visible": true,
      "type": "I-129"
    },
    {
      "name": "L1B",
      "checked": true,
      "visible": true,
      "type": "I-129"
    },
    {
      "name": "R1",
      "checked": true,
      "visible": true,
      "type": "I-129"
    },
    {
      "name": "TN1",
      "checked": true,
      "visible": true,
      "type": "I-129"
    },
    {
      "name": "TN2",
      "checked": true,
      "visible": true,
      "type": "I-129"
    },
    {
      "name": "E1",
      "checked": true,
      "visible": true,
      "type": "I-129"
    },
    {
      "name": "E2",
      "checked": true,
      "visible": true,
      "type": "I-129"
    },
    {
      "name": "E3",
      "checked": true,
      "visible": true,
      "type": "I-129"
    },
    {
      "name": "H2A",
      "checked": true,
      "visible": true,
      "type": "I-129"
    },
    {
      "name": "H2B",
      "checked": true,
      "visible": true,
      "type": "I-129"
    },    
    {
      "name": "H3",
      "checked": true,
      "visible": true,
      "type": "I-129"
    },
    {
      "name": "LZ",
      "checked": true,
      "visible": true,
      "type": "I-129"
    },
    {
      "name": "Q1",
      "checked": true,
      "visible": true,
      "type": "I-129"
    },
    {
      "name": "CW1",
      "checked": true,
      "visible": true,
      "type": "I-129"
    },
    {
      "name": "E12",
      "checked": true,
      "visible": true,
      "type": "I-140"
    },
    {
      "name": "E13",
      "checked": true,
      "visible": true,
      "type": "I-140"
    },
    {
      "name": "E21",
      "checked": true,
      "visible": true,
      "type": "I-140"
    },
    {
      "name": "E31",
      "checked": true,
      "visible": true,
      "type": "I-140"
    },
    {
      "name": "E32",
      "checked": true,
      "visible": true,
      "type": "I-140"
    },
    {
      "name": "EW3",
      "checked": true,
      "visible": true,
      "type": "I-140"
    }
  ]
  
  reciptNumber = ""; 
  displayManualSearchButton: boolean = false;
  displayVsr: boolean = true;

  private pfSvc: PreviousFilingsService;
  cssSubscription: Subscription;

  constructor(
    private router: Router, 
    private pfSearchSearvice: PreviousFilingsService, 
    private ssb: SmartSearchService, 
    private css: ComponentStatusService,
    private excelService:ExcelService) { 
    this.pfSvc = pfSearchSearvice;


    this.cssSubscription = this.css.currentMessage.subscribe(message => {

      if ((message.destComponentName === AppSettings.CS_PREVIOUS_FILINGS_HUB) &&
        (message.clear)){
          console.log("css: reset message received for hub (since I am hub I will reset myself).");
          this.resetComponent();
    
        }
    });



    //integration point with SSB
    this.searchSubscription = this.ssb.currentMessage.subscribe(message => {
      console.log("search box: " + JSON.stringify(message));
      
      //Check if Duns
      if ((message.selectedSearchType=="previousFilings") && 
          (message.selectedSearchFunction=="pfDuns") && 
          (message.searchById!="") && 
          (message.searchById!=undefined)){
            this.dunsNum = message.searchById
            console.log("this.dunsNum="+this.dunsNum); 
            this.onDuns(this.dunsNum);
            message.searchById="";

      }

        //Check if Dolcase
        if ((message.selectedSearchType=="previousFilings") && 
        (message.selectedSearchFunction=="pfEta") && 
        (message.searchById!="") && 
        (message.searchById!=undefined)){
          this.dolCaseNum = message.searchById
          console.log("this.dolCaseNum ="+this.dolCaseNum); 
          this.getPfByDolcase(this.dolCaseNum);
          message.searchById="";

        }
      


    }
    );

  }

  message: SmartSearchModel; 
  ngOnInit() {

    this.showAlert = false;
    this.showEta = false;
    this.showDuns =false;
    
    //DolCase
    if (this.router.url.includes('previous-filings/dolcase') || ( this.dolCaseNum && this.dolCaseNum !== "")) {

      this.loadingeta = true;
      console.log("inside prev filings the this.router.url is: " + this.router.url);
      console.log("Inside prev filings the dolcasenum is: " + this.dolCaseNum );
      var urlarr = this.router.url.split("/");
      if (this.dolCaseNum === ""){
      this.dolCaseNum = urlarr[urlarr.length - 1];
      }
      this.pfSvc.getPreviousFilingsByDolcase(this.dolCaseNum.toUpperCase().replace(/-/g, '')).subscribe(
        data => {
          if (data) {
            try{
              if (JSON.stringify(data).includes("ESB2Exception")) throw new Error(JSON.stringify(data));
        } catch (error) {
              this.appsAlert = AppSettings.SYSTEM_EXCEPTION;
              this.showAlert = true
              this.showEta = false;
              this.loadingeta= false;
              console.log(error);
              return;
        }
        this.previousFiling = JSON.parse(JSON.stringify(data).replace("PreviousFilings-GetByDolCaseNumberResponse", "PreviousFilingsGetByDolCaseNumberResponse"));
        console.log(this.previousFiling);
          if (this.previousFiling.PreviousFilingsGetByDolCaseNumberResponse.PreviousFilingsDolResultSet.totalRecordCount == 0){
      
            
            this.showEta = false;
            this.appsAlert = AppSettings.VSR_STATUS_CODE_001_DESC;
            this.showAlert = true;
            this.loadingeta = false;
            return;
          }
          this.showEta = true;
          }
          
          this.loadingeta = false;
        }
        
      );
      
    } //Duns /previous-filings/duns/I-129/
    if (this.router.url.includes('previous-filings/duns') || (this.dunsNum !== "" && this.petitionType !== "")) {
      var urlarr = this.router.url.split("/");
      if (this.router.url.includes('previous-filings/duns')) {
        this.organizationName = decodeURI(urlarr[urlarr.length - 1]);
        this.dunsNum = urlarr[urlarr.length - 2];
        this.petitionType = urlarr[urlarr.length - 3];
      }
      if (this.petitionType == "I-129") {
        this.checkUncheck(this.petitionType);
        this.show129 = true;
      }else if (this.petitionType == "I-140"){
        this.checkUncheck(this.petitionType);
        this.show140 = true;
      }else if (this.petitionType == "I-485J"){
        this.typeTitle = "Form Type:"
        this.checkUncheck("");
      }
      else {this.checkUncheck("")};
      this.showDuns = true;
      this.buildReport();
    }

  }

  ngOnDestroy(){
    this.searchSubscription.unsubscribe();
    this.cssSubscription.unsubscribe();
  }

  buildReport(){
    this.reciptNumber = null;
    this.showEta = false;
    this.showAlert = false;
    this.count = null;
    this.showValidationAlert = false;
    this.showReport = false;
    this.resultset = [];
    this.showCount = false;
    this.getCheckedVisas();
    if(this.validateCheckedVisas() == false){
      this.showValidationAlert = true;
      
      return;
    }
    this.loading = true;
    console.log(this.visaTypes);
    this.pfSvc.getPreviousFilingsByDuns(this.dunsNum.toUpperCase(),this.organizationName,this.petitionType, this.timePeriod, this.ajudicativeStatus.split(","), this.visaTypes).subscribe(
      data => {
        if (data)
           {
            try{
              if (JSON.stringify(data).includes("ESB2Exception")) throw new Error(JSON.stringify(data));
        } catch (error) {
              this.appsAlert = AppSettings.SYSTEM_EXCEPTION;
              this.showEta = false;
              this.showAlert = false;
              this.count = null;
              this.showValidationAlert = false;
              this.showReport = false;
              this.resultset = [];
              this.showCount = false;
              console.log(error);
              return;
        }
             this.pfDuns = JSON.parse(JSON.stringify(data).replace("PreviousFilingsGetByDunsNumber-Response","PreviousFilingsGetByDunsNumberResponse"));
           this.count = this.pfDuns.PreviousFilingsGetByDunsNumberResponse.PreviousFilingsResultSet.totalRecordCount
           console.log("Count" + this.count)
           this.resultset = this.resultset.concat(this.pfDuns.PreviousFilingsGetByDunsNumberResponse.PreviousFilingsResultSet.PreviousFilingRecord)
           this.showReport = true;
          
          }else{ this.count = 0;}

          if (this.count == 0)
          {  this.appsAlert = AppSettings.VSR_STATUS_CODE_001_DESC
            this.showAlert = true;}
        
          this.loading = false;
          //reset filters
          this.datechild.clearDateFilter(); 
          this.statuschild.initializeFilter();
               
         }

    );
    //this.count = this.resultset.length
    //console.log("Count: " + this.count)
    this.showCount = true;
     this.delay(5000);
     
  }
  getPfByDolcase(dolCaseNum: string) {
    this.showAlert = false;
    this.showEta = false;
    this.showDuns = false;
    this.loadingeta = true;
    console.log("inside prev filings the this.router.url is: " + this.router.url);
    console.log("Inside prev filings the dolcasenum is: " + dolCaseNum);
    var urlarr = this.router.url.split("/");
    this.dolCaseNum = dolCaseNum;

    this.pfSvc.getPreviousFilingsByDolcase(this.dolCaseNum.toUpperCase().replace(/-/g, '')).subscribe(
      data => {
        if (data) {
          try {
            if (JSON.stringify(data).includes("ESB2Exception")) throw new Error(JSON.stringify(data));
          } catch (error) {
            this.appsAlert = AppSettings.VSR_STATUS_CODE_001_DESC;
            this.showAlert = true
            this.showEta = false;
            this.loadingeta = false;
            console.log(error);
            return;
          }
          this.previousFiling = JSON.parse(JSON.stringify(data).replace("PreviousFilings-GetByDolCaseNumberResponse", "PreviousFilingsGetByDolCaseNumberResponse"));
          console.log(this.previousFiling);
          if (this.previousFiling.PreviousFilingsGetByDolCaseNumberResponse.PreviousFilingsDolResultSet.totalRecordCount == 0) {


            this.showEta = false;
            this.appsAlert = AppSettings.VSR_STATUS_CODE_001_DESC;
            this.showAlert = true;
            this.loadingeta = false;
            return;
          }
          this.showEta = true;
        }

        this.loadingeta = false;
      }



    );

  }
  checkUncheck(petitionType){
    for (let box of this.checkboxes){
      if(box.type == petitionType){
        box.checked = true;
        box.visible = true;
      }else {
        box.checked = false;
        box.visible =false;
      }
    }
  }
  checkUncheckAll(){
    for (let box of this.checkboxes){
      if (this.masterSelected && box.visible){
        box.checked = true;
      }else box.checked = false;
    }
  }
  getCheckedVisas(){
    this.visaTypes = []
    for (let box of this.checkboxes){
      if (box.checked && box.visible)
      {this.visaTypes.push(box.name)}
    }
  }
  validateCheckedVisas(){
    if(this.visaTypes.length == 0){
      if (this.petitionType == 'I-129' || this.petitionType == 'I-140' ){
        return false;
      }
    }
    return true;
  }
  setAjudicativeStatus(){
    
  }
  onDuns(duns: string) {

    this.resultset = [];
    this.showDuns = true;
    this.show129 = true;
    this.petitionType = "I-129"
    this.ajudicativeStatus = ""
    this.count = 0;
    this.dunsNum = duns;
    this.timePeriod = "12";
    //make I-129 Call
    this.showReport = false;
    this.loading = true;
    this.checkUncheck(this.petitionType)
    this.getCheckedVisas();
    this.pfSvc.getPreviousFilingsByDuns(this.dunsNum.toUpperCase(), this.organizationName, this.petitionType, this.timePeriod, this.ajudicativeStatus.split(","), this.visaTypes).subscribe(
      data => {
        if (data) {
          this.pfDunsTemp = JSON.parse(JSON.stringify(data).replace("PreviousFilingsGetByDunsNumber-Response", "PreviousFilingsGetByDunsNumberResponse"));
          if (this.pfDunsTemp.PreviousFilingsGetByDunsNumberResponse.PreviousFilingsResultSet.PreviousFilingRecord){
          this.resultset = this.resultset.concat(this.pfDunsTemp.PreviousFilingsGetByDunsNumberResponse.PreviousFilingsResultSet.PreviousFilingRecord)
          console.log(this.resultset)
          this.count = this.count + this.pfDunsTemp.PreviousFilingsGetByDunsNumberResponse.PreviousFilingsResultSet.totalRecordCount
          this.showReport =true;  
        }
        }
      }
    );
    //make I-140 Call
    this.petitionType = "I-140"
    this.checkUncheck(this.petitionType);
    this.getCheckedVisas();
    this.pfSvc.getPreviousFilingsByDuns(this.dunsNum.toUpperCase(), this.organizationName, this.petitionType, this.timePeriod, this.ajudicativeStatus.split(","), this.visaTypes).subscribe(
      data => {
        if (data) {
          this.pfDunsTemp = JSON.parse(JSON.stringify(data).replace("PreviousFilingsGetByDunsNumber-Response", "PreviousFilingsGetByDunsNumberResponse"));
          if (this.pfDunsTemp.PreviousFilingsGetByDunsNumberResponse.PreviousFilingsResultSet.PreviousFilingRecord){
          this.resultset = this.resultset.concat(this.pfDunsTemp.PreviousFilingsGetByDunsNumberResponse.PreviousFilingsResultSet.PreviousFilingRecord)
          console.log(this.resultset)
          this.count = this.count + this.pfDunsTemp.PreviousFilingsGetByDunsNumberResponse.PreviousFilingsResultSet.totalRecordCount
          this.showReport =true;
          this.loading = false;  
        }
        }
      }
    );
    //make I-140 Call

    this.petitionType = "I-485J"
    this.checkUncheck("");
    this.getCheckedVisas();
    this.pfSvc.getPreviousFilingsByDuns(this.dunsNum.toUpperCase(), this.organizationName, this.petitionType, this.timePeriod, this.ajudicativeStatus.split(","), this.visaTypes).subscribe(
      data => {
        if (data) {
          this.pfDunsTemp = JSON.parse(JSON.stringify(data).replace("PreviousFilingsGetByDunsNumber-Response", "PreviousFilingsGetByDunsNumberResponse"));
          if (this.pfDunsTemp.PreviousFilingsGetByDunsNumberResponse.PreviousFilingsResultSet.PreviousFilingRecord){
          this.resultset = this.resultset.concat(this.pfDunsTemp.PreviousFilingsGetByDunsNumberResponse.PreviousFilingsResultSet.PreviousFilingRecord)
          console.log(this.resultset)
          this.count = this.count + this.pfDunsTemp.PreviousFilingsGetByDunsNumberResponse.PreviousFilingsResultSet.totalRecordCount
          this.showReport =true;
          this.loading = false;  
        }
        }
      }
    
    );
    this.petitionType = "I-360"
    this.checkUncheck("");
    this.getCheckedVisas();
    var res = this.pfSvc.getPreviousFilingsByDuns(this.dunsNum.toUpperCase(), this.organizationName, this.petitionType, this.timePeriod, this.ajudicativeStatus.split(","), this.visaTypes).subscribe(
      data => {
        if (data) {
          this.pfDunsTemp = JSON.parse(JSON.stringify(data).replace("PreviousFilingsGetByDunsNumber-Response", "PreviousFilingsGetByDunsNumberResponse"));
          if (this.pfDunsTemp.PreviousFilingsGetByDunsNumberResponse.PreviousFilingsResultSet.PreviousFilingRecord){
          this.resultset = this.resultset.concat(this.pfDunsTemp.PreviousFilingsGetByDunsNumberResponse.PreviousFilingsResultSet.PreviousFilingRecord)
          console.log(this.resultset)
          this.count = this.count + this.pfDunsTemp.PreviousFilingsGetByDunsNumberResponse.PreviousFilingsResultSet.totalRecordCount
          this.showReport =true;
          this.loading = false;
          }
        }
      }
    );
    if (this.loading){
      this.loading = false;
    }
    console.log("Count: " + this.count)
    this.showCount = true;
    this.petitionType = "I-129"
    this.show129 = true;
    this.checkUncheck("I-129");
  }
  setReceipt(receipt: string) {
    this.showvsrmodal = true;
    this.reciptNumber = receipt;
  }
  refresh(state: ClrDatagridStateInterface) {
    this.showExportAlert=false;
    console.log(state);

  }
  resetComponent(){
    this.reciptNumber = null;
    this.showAlert=false;
    this.showDuns=false; 
    this.showEta=false;
    this.showReport=false;
    this.show129=false; 
    this.show140=false; 

  }
  clearReceipt(clear: string){
    this.reciptNumber = null;
  }
  setFirstItem(cnt){
    this.filteredResults = cnt;
  }
  close() {
    document.getElementById(this.reciptNumber).focus();
    this.showvsrmodal = false;
  }

  showExportAlert: boolean = false;
  exporting : boolean = false; 
  
  @ViewChild('pagination1', { static: false }) pager: ClrDatagridPagination;
  @ViewChild('datagrid', { static: false }) datagrid: ClrDatagrid;
  styleExp = "all"
  pageNum = Number(AppSettings.PAGINATION_COUNT);
  datagridHtml: HTMLElement;
  exportOptions: string = "EXCEL";
  export = []
  

  async exportReport(){
    this.styleExp = "none"
    this.pageNum = this.pager.totalItems
    this.datagrid.refresh.next();
    await this.delay(2000)
    
    if (this.pager.totalItems== 0){
      this.showExportAlert = true
      return
    }
    //console.log("this.pager.totalItems="+this.pager.totalItems);
    this.updateExport('prevFilingsHubGrid');
    if(this.exportOptions  == "CSV"){
      this.exporting=true;
      console.log("exporting csv, exporting="+this.exporting);
      this.excelService.exportAsCSVFile(this.export, "prevFilingsHubGrid")
    }else if(this.exportOptions  == "EXCEL"){
      this.exporting=true;
      console.log("exporting EXCEL, exporting="+this.exporting);
      this.excelService.exportAsExcelFile(this.export, "prevFilingsHubGrid")
    }
    this.exporting=false;
    this.styleExp = "block"
  }

  delay(ms: number) {
    return new Promise( resolve => setTimeout(resolve, ms) );
}

updateExport(tableid) {
  //Query Dom for Cells and Headers
  this.datagridHtml = document.getElementById(tableid)
  var headers = this.datagridHtml.getElementsByClassName("datagrid-column-title")
  this.export = []
  console.log(headers)
  var headerArr: HTMLElement[] = [].slice.call(headers);
  var headerRow = []
  var f = 0;
  for (var header of headerArr) {
    var text = <HTMLElement>header as HTMLElement
    headerRow[f] = text.textContent.trim()
    f++;
  }
  this.datagridHtml = document.getElementById(tableid)
  let cells: HTMLCollection = this.datagridHtml.getElementsByClassName("datagrid-cell") as HTMLCollection
  console.log('CELLS Length!! size: ' + cells.length)
  console.log(cells)
  var row = [];
  var rowCounter = 0;
  var j = 0;
  var expRow = {};
  for (var j = 0; j < cells.length; j++) {
    //Push Cell to Row Array
    console.log(j)
    console.log(cells)
    console.log(cells.item(j).textContent)

    row.push(cells.item(j).textContent.trim())
    rowCounter = rowCounter + 1;
    //Indicates the end of a Row Processing.
    if (rowCounter >= headers.length) {
      //working on creating object for export
      //Change to create object with page headers
      var k = 0;
      expRow = {}
      var propnames: string[]
      propnames = Object.getOwnPropertyNames(expRow);
      console.log(row)
      //Load Row Array Data into JSON Object
      for (k = 0; k < row.length; k++) {
        expRow[headerRow[k]] = row[k];
      }

      row = [];
      console.log(expRow);
      //Push Row Object to Export array
      this.export.push(expRow)
      rowCounter = 0;
    }
  }
  console.log(this.export)
  //this.addColumnstoExport()
  this.pageNum = Number(AppSettings.PAGINATION_COUNT)
}

addColumnstoExport(){
  
  this.resultset.forEach(rec => {
    let i = 0;
    this.export.forEach(row => {
      if(rec.ReceiptNumber == row["Receipt Number"]){
        row["Company Name"] = rec.OrganizationName
        row["Form Type"]= rec.PetitionType
        row["Visa Type"] = rec.VisaType
        row["Adjudicative Status"] = rec.AdjudicativeStatus
        row["Confidence Code"] = rec.ConfidenceFactor
        row["Date Added"] = rec.DateAdded
      }
      console.log(row)

    })
  })
}
}

