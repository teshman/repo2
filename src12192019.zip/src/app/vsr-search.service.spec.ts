import { TestBed } from '@angular/core/testing';

import { VsrSearchService } from './vsr-search.service';

describe('VsrSearchService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: VsrSearchService = TestBed.get(VsrSearchService);
    expect(service).toBeTruthy();
  });
});
