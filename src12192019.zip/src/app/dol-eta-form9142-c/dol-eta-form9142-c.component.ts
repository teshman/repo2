import { Component, OnInit, Input, NgModule, AfterViewInit } from '@angular/core';
import { keyframes } from '@angular/animations';
import { DolEtaSearchService } from '../dol-eta-search.service';
import { ClrDatagridSortOrder } from '@clr/angular';
import { GetDolDetailByEtaCaseNumberResponse, DOLDATA, DOLETACLOB, DolData } from '../shared/9142C_interfaces'
import { dol9142CProxy } from '../shared/9142C_proxies'
import { AppSettings } from '../shared/app-settings'
import { Router } from '@angular/router';
import { SmartSearchService } from "../smart-search.service"
import { SmartSearchModel } from "../shared/smart-search-model"
import { Subscription } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { ComponentStatusService } from '../shared/service/component-status.service';
import { ComponentStatus } from '../shared/service/component-status';
import { dolResponseProxy } from '../shared/9142A_proxies';
import { DolDataProxy } from '../shared/dol_proxy';
@Component({
  selector: 'app-dol-eta-form9142-c',
  templateUrl: './dol-eta-form9142-c.component.html',
  styleUrls: ['./dol-eta-form9142-c.component.css']
})
export class DolEtaForm9142CComponent implements OnInit, AfterViewInit {
  @Input() petitionId: string = "";
  @Input() dolEtaFormType: string = "";
  @Input() dolEtaFormVersion: string = "";
  @Input() dolEtaClobId: string = "";
  @Input() etacaseNumber: string = "";
  cssSubscription: Subscription;
  cssStatusService: ComponentStatusService;
  private dolSvc: DolEtaSearchService;
  appsAlert: string;
  showDol: boolean;
  showAppA: boolean;
  showAppB: boolean;
  showApproval: boolean;
  loading: boolean;
  showSummary: boolean;
  dolData: any;
  dolClobArray: (DOLETACLOB)[];
  APP_IS_STATEMENT_ATTACHED: any;
  APP_IS_PWD_ATTACHED: any;
  EMP_JOIN_APDX_A_ATTACHED: any;
  EMP_IS_CONTRACT_ATTACHED: any;
  ATTY_IS_AGREEMENT_ATTACHED: any;
  JOB_APDX_B_ATTACHED: any;
  caseArray: any;
  constructor(private dolSearchService: DolEtaSearchService, private ssb: SmartSearchService, private router: Router, private css: ComponentStatusService) {
    this.dolSvc = dolSearchService

    //integration point with SSB
    this.cssSubscription = this.css.currentMessage.subscribe(message => {
      this.resetComponent()
      if (message.destComponentName == AppSettings.CS_DOL_ETA_9142C) {

        console.log(message.data);
        
        try{
          this.parseDolData(message.data)
        }catch(error){
          console.error(error) 
          this.appsAlert = AppSettings.VSR_STATUS_CODE_001_DESC;
          this.showDol = false;
          this.loading = false;
         }


      }});
    
      }
  ngOnInit() {
    if (this.petitionId !== "" && this.dolEtaFormType !== "") {
      this.dolSvc.getDolByPettitionId(this.petitionId, this.dolEtaClobId).subscribe( data => {

      });
      return
    }
    if(this.etacaseNumber !="" && this.dolEtaFormType == "9142C"){
      this.dolSvc.getDolByCaseId(this.etacaseNumber).subscribe(data => {
        try{
          this.parseDolData(data)
        }catch(error){
          console.error(error) 
          this.appsAlert = AppSettings.VSR_STATUS_CODE_001_DESC;
          this.showDol = false;
          this.loading = false;
         }
      })
    }
  }
  ngAfterViewInit(): void {
     
     
  }
  resetComponent(){
    this.showDol = false;
    this.loading = false;
    this.showSummary = false;
  }

  parseDolData(data: dolResponseProxy){
    this.dolClobArray = [];
    this.caseArray = [];
    this.dolData = <DolData>JSON.parse(data.GetDolDetailByEtaCaseNumberResponse.DolJsonData)
    
    console.log(data)
    console.log((this.dolData.DOL_DATA.DOL_ETA_CLOB))
    //console.log(this.dolData.DOL_DATA.DOL_ETA_FD_CERT[0].CASE_DETERMIN_DATE)

    if (this.dolData.DOL_DATA.DOL_ETA_CLOB) {
      this.APP_IS_STATEMENT_ATTACHED = this.makeBooleans(this.dolData.DOL_DATA.DOL_ETA_CLOB.APP_IS_STATEMENT_ATTACHED);
      this.APP_IS_PWD_ATTACHED = this.makeBooleans(this.dolData.DOL_DATA.DOL_ETA_CLOB.APP_IS_PWD_ATTACHED)
      this.EMP_JOIN_APDX_A_ATTACHED = this.makeBooleans(this.dolData.DOL_DATA.DOL_ETA_CLOB.EMP_JOIN_APDX_A_ATTACHED)
      this.EMP_IS_CONTRACT_ATTACHED = this.makeBooleans(this.dolData.DOL_DATA.DOL_ETA_CLOB.EMP_IS_CONTRACT_ATTACHED)
      this.ATTY_IS_AGREEMENT_ATTACHED = this.makeBooleans(this.dolData.DOL_DATA.DOL_ETA_CLOB.ATTY_IS_AGREEMENT_ATTACHED)
      this.JOB_APDX_B_ATTACHED = this.makeBooleans(this.dolData.DOL_DATA.DOL_ETA_CLOB.JOB_APDX_B_ATTACHED)
          this.dolClobArray.push(this.dolData.DOL_DATA.DOL_ETA_CLOB);
          this.loading = false;
          this.showDol = true
          this.showSummary = true;
          this.showAppA = this.showAppendixA();
          this.showAppB = this.showAppendixB();
          this.showApproval = this.showApprove();
          
          //document.querySelector("ul").setAttribute("style","background-color: red;")
        }
        
    
    
  }
  parseDolDatabyPetitionId(data){

  }
  makeBooleans(input: string){
    return input;
  }

  showAppendixA(): boolean {
    var propString = this.dolData.DOL_DATA.DOL_ETA_CLOB.APDA_LEGAL_NAME
      + this.dolData.DOL_DATA.DOL_ETA_CLOB.APDA_TRADE_NAME + this.dolData.DOL_DATA.DOL_ETA_CLOB.APDA_EMP_ADDR1
      + this.dolData.DOL_DATA.DOL_ETA_CLOB.APDA_EMP_ADDR2 + this.dolData.DOL_DATA.DOL_ETA_CLOB.APDA_EMP_CITY
      + this.dolData.DOL_DATA.DOL_ETA_CLOB.APDA_EMP_STATE + this.dolData.DOL_DATA.DOL_ETA_CLOB.APDA_EMP_POSTCODE
      + this.dolData.DOL_DATA.DOL_ETA_CLOB.APDA_EMP_COUNTRY + this.dolData.DOL_DATA.DOL_ETA_CLOB.APDA_EMP_PROVINCE
      + this.dolData.DOL_DATA.DOL_ETA_CLOB.APDA_EMP_PHONE + this.dolData.DOL_DATA.DOL_ETA_CLOB.APDA_EMP_PHONEEXT 
      + this.dolData.DOL_DATA.DOL_ETA_CLOB.APDA_EMP_FEIN  + this.dolData.DOL_DATA.DOL_ETA_CLOB.APDA_EMP_NAICS 
      + this.dolData.DOL_DATA.DOL_ETA_CLOB.APDA_POC_LASTNAME + this.dolData.DOL_DATA.DOL_ETA_CLOB.APDA_POC_FIRSTNAME
      + this.dolData.DOL_DATA.DOL_ETA_CLOB.APDA_POC_MIDDLENAME + this.dolData.DOL_DATA.DOL_ETA_CLOB.APDA_POC_JOBTITLE 
      + this.dolData.DOL_DATA.DOL_ETA_CLOB.APDA_POC_ADDR1 + this.dolData.DOL_DATA.DOL_ETA_CLOB.APDA_POC_ADDR2 
      + this.dolData.DOL_DATA.DOL_ETA_CLOB.APDA_POC_CITY + this.dolData.DOL_DATA.DOL_ETA_CLOB.APDA_POC_STATE
      + this.dolData.DOL_DATA.DOL_ETA_CLOB.APDA_POC_POSTCODE + this.dolData.DOL_DATA.DOL_ETA_CLOB.APDA_POC_COUNTRY
      + this.dolData.DOL_DATA.DOL_ETA_CLOB.APDA_POC_PROVINCE + this.dolData.DOL_DATA.DOL_ETA_CLOB.APDA_POC_PHONE 
      + this.dolData.DOL_DATA.DOL_ETA_CLOB.APDA_POC_PHONEEXT + this.dolData.DOL_DATA.DOL_ETA_CLOB.APDA_POC_EMAIL
    console.log(propString)
    if(propString.length == 0){
      return false;
    }else return true;
  }

showAppendixB(): boolean{
  console.log(this.dolData.DOL_DATA.DOL_ETA_WORKSITES)
  if(!(this.dolData.DOL_DATA.DOL_ETA_WORKSITES) || JSON.stringify(this.dolData.DOL_DATA.DOL_ETA_WORKSITES).includes("NO_DATA")){
    return false;
  }else return true;
}

showApprove(): boolean {
  var checkstring = this.dolData.DOL_DATA.DOL_ETA_CLOB.FINAL_DETERM_LTR_ISSUED
  console.log(checkstring)
  if (checkstring.toUpperCase() == "YES" || checkstring.toUpperCase() == "Y"){
  return true; 
  }else return false;
}
}
  
