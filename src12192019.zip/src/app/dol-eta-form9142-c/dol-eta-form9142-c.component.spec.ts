import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DolEtaForm9142CComponent } from './dol-eta-form9142-c.component';

describe('DolEtaForm9142CComponent', () => {
  let component: DolEtaForm9142CComponent;
  let fixture: ComponentFixture<DolEtaForm9142CComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DolEtaForm9142CComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DolEtaForm9142CComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
