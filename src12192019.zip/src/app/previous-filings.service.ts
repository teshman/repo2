import { Injectable } from '@angular/core';
import { Observable, of , Subject, BehaviorSubject} from 'rxjs';
import { previousfilingProxy } from './shared/previous_filings_proxy';
import { pfDunsResponseProxy} from './shared/dunsResponseProxies'
import { catchError, map, tap } from 'rxjs/operators';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AppSettings} from './shared/app-settings'

@Injectable({
  providedIn: 'root'
})
export class PreviousFilingsService {
  private previousFilingDolURL = '/vibe-plus/rest/previous-filings/dolcase/';
  private previousFilingDunsUrl = '/vibe-plus/rest/previous-filings/duns';
  private previousFilingFeinUrl = '/vibe-plus/rest/previous-filings/fein';
  private visaTypesI129 = ["1B1","1B2","1B3","HSC","L1A","L1B","R1","TN1","TN2","E1","E2","E3","H2A","H2B","H3","LZ","Q1"];
  private visaTypesI104 = ["CW1","E12","E13","E21","E31","E32","EW3"];

  constructor(private http: HttpClient) { }

  getPreviousFilingsByDolcase(dolcase: string): Observable<previousfilingProxy> {
    const url = `${this.previousFilingDolURL}${dolcase}`;
    return this.http.get<previousfilingProxy>(url).pipe(
      tap(_ => console.log(`get PreviousFiling #=${dolcase}`)),
      catchError(this.handleError<previousfilingProxy>(`error get Case # ${dolcase}`))
    );
  }
  getPreviousFilingsByDuns(duns: string, orgName: string, petitionType: string, timePeriod:string, ajudicativeStatus: Array<string>, visaTypes: Array<string>): Observable<pfDunsResponseProxy> {
    const url = `${this.previousFilingDunsUrl}`;
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/json'
        // 'Authorization': 'my-auth-token'
      })
    };
    var statusString = ajudicativeStatus.length === 0 ? "" : "\"" + ajudicativeStatus.join("\",\"") + "\"";
    var visaString = visaTypes.length === 0 ? "" : "\"" + visaTypes.join("\",\"") + "\"";
    return this.http.post<pfDunsResponseProxy>(url,`{ "sourceSystemID":"VIBE UI", "sourceTransactionID":"534253425345435", "endUserID":"akumar@dhs.gov", "startRecordNumber":"1", "endRecordNumber":"100000", "sortByColumnNamePrevFilings":"DATE_ADDED", "sortOrder":"DESC", "organizationName":"${orgName}", "dunsNumber":"${duns}", "petitionType":"${petitionType.replace('-','')}", "timePeriod":"${timePeriod}", "c3StatusCode":[ ${statusString} ], "visaType":[${visaString}] } `,httpOptions).pipe(
      tap(_ => console.log(`get Duns #=${duns}`)),
      catchError(this.handleError<pfDunsResponseProxy>(`error get Duns # ${duns}`))
    );
  }

  async getAllByDuns(duns: string, timePeriod = "36", ajudicativeStatus: Array<string> = ['A']): Promise<any[]> {
    const url = `${this.previousFilingDunsUrl}`;
    var orgName =""
    var results = [];
    var record: pfDunsResponseProxy;
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/json'
        // 'Authorization': 'my-auth-token'
      })
    };
    var statusString = ajudicativeStatus.length === 0 ? "" : "\"" + ajudicativeStatus.join("\",\"") + "\"";
    var visaStringI129 = this.visaTypesI129.length === 0 ? "" : "\"" + this.visaTypesI129.join("\",\"") + "\"";
    var visaStringI140 = this.visaTypesI104.length === 0 ? "" : "\"" + this.visaTypesI104.join("\",\"") + "\"";
    await this.http.post<pfDunsResponseProxy>(url,`{ "sourceSystemID":"VIBE UI", "sourceTransactionID":"534253425345435", "endUserID":"akumar@dhs.gov", "startRecordNumber":"1", "endRecordNumber":"100000", "sortByColumnNamePrevFilings":"DATE_ADDED", "sortOrder":"DESC", "organizationName":"${orgName}", "dunsNumber":"${duns}", "petitionType":"ALL", "timePeriod":"${timePeriod}", "c3StatusCode":[  ], "visaType":[] } `,httpOptions).toPromise()
    .then(value => {
      results.push(value)
      
    })

    
    
    console.log("Here are the total records:")
    console.log(results)
    return results 
      //catchError(this.handleError<pfDunsResponseProxy>(`error get Duns # ${duns}`))
    
  }


  async getAllByFein(fein: string, timePeriod = "36", ajudicativeStatus: Array<string> = ['A']): Promise<any[]> {
    const url = `${this.previousFilingFeinUrl}`;
    var orgName =""
    var results = [];
    var record: pfDunsResponseProxy;
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/json'
        // 'Authorization': 'my-auth-token'
      })
    };
    var statusString = ajudicativeStatus.length === 0 ? "" : "\"" + ajudicativeStatus.join("\",\"") + "\"";
    var visaStringI129 = this.visaTypesI129.length === 0 ? "" : "\"" + this.visaTypesI129.join("\",\"") + "\"";
    var visaStringI140 = this.visaTypesI104.length === 0 ? "" : "\"" + this.visaTypesI104.join("\",\"") + "\"";
    await this.http.post<pfDunsResponseProxy>(url,`{ "sourceSystemID":"VIBE UI", "sourceTransactionID":"534253425345435", "endUserID":"akumar@dhs.gov", "startRecordNumber":"1", "endRecordNumber":"1000000", "sortByColumnNamePrevFilings":"DATE_ADDED", "sortOrder":"DESC", "organizationName":"${orgName}", "fein":"${fein}", "petitionType":"ALL", "timePeriod":"${timePeriod}", "c3StatusCode":[  ], "visaType":[] } `,httpOptions).toPromise()
    .then(value => results.push(value))

    
    console.log("Here are the total records" + results)
    return results 
      //catchError(this.handleError<pfDunsResponseProxy>(`error get Duns # ${duns}`))
    
  }

  getPreviousFilingsByDunsFile(duns: string, orgName: string, petitionType: string, timePeriod:string, ajudicativeStatus: Array<string>, visaTypes: Array<string>): Observable<pfDunsResponseProxy> {

    const url = AppSettings.PREVIOUS_FILING_RESPONSE;
    return this.http.get<pfDunsResponseProxy>(url).pipe(
      tap(data =>
        this.log("The fetched VsrResubmitResponse SourceTransactionID is: " + data)
      ));
  }

  private messageSource = new Subject
  public currentMessage = this.messageSource.asObservable(); 



  changeMessage(message: string){
    console.log(" changeMessage >>" + JSON.stringify(message));
    this.messageSource.next(message);
  }
   /**
   * Handle Http operation that failed.
   * Let the app continue.
   * @param operation - name of the operation that failed
   * @param result - optional value to return as the observable result
   */
  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // TODO: better job of transforming error for user consumption
      console.log(`${operation} failed: ${error.message}`);

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }
  private log(message: string) {
    console.log(`VSR: ${message}`);

  }
}
