import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DolEtaFormV2Component } from './dol-eta-form-v2.component';

describe('DolEtaFormV2Component', () => {
  let component: DolEtaFormV2Component;
  let fixture: ComponentFixture<DolEtaFormV2Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DolEtaFormV2Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DolEtaFormV2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
