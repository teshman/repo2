import { Component, OnInit, Input, NgModule } from '@angular/core';
import { keyframes } from '@angular/animations';
import { DolEtaSearchService } from '../dol-eta-search.service';
import { ClrDatagridSortOrder } from '@clr/angular';
import { GetDolDetailByPetitionIDResponse, DolData, DOLDATA, DOLETACLOB } from '../shared/9035v2_interfaces'
import { DOLDATAProxy } from '../shared/dolPetitionResponse_proxy'
import { AppSettings } from '../shared/app-settings'
import { Router } from '@angular/router';
import { SmartSearchService } from "../smart-search.service"
import { SmartSearchModel } from "../shared/smart-search-model"
import { Subscription } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { ComponentStatusService } from '../shared/service/component-status.service';
import { ComponentStatus } from '../shared/service/component-status';

@Component({
  selector: 'app-dol-eta-form-v2',
  templateUrl: './dol-eta-form-v2.component.html',
  styleUrls: ['./dol-eta-form-v2.component.css']
})
export class DolEtaFormV2Component implements OnInit {
  @Input() petitionId: string = "";//"147973101";147973069;147973259
  @Input() dolEtaFormType: string = "";
  @Input() dolEtaFormVersion: string = "";
  @Input() dolEtaClobId: string = "";
  @Input() etacaseNumber: string = "";
  FA12A_DOLPWD: boolean;
  FA13_OESPW: boolean;
  F14_OTHERPW: boolean;
  worksites: any[] = [];
  showDol = false
  loading = false
  showEducation = false
  showWorkSites = false
  showAddendum = false
  showSummary = false
  searchSubscription: Subscription;
  showStatemnts = false
  showStatemnts2 = false
  showStatemnts3 = false
  root: GetDolDetailByPetitionIDResponse;
  dol: DolData
  dolEta: DOLDATA
  dolEtaResult: DOLETACLOB;
  descSort = ClrDatagridSortOrder.DESC
  ascSort = ClrDatagridSortOrder.ASC
  appsAlert: string
  model = {
    DolEtaResults: [],
    caseNumber: '', //H30014321198839
    petitionNumber: '' //146845314
  }
  cssSubscription: Subscription;
  cssStatusService: ComponentStatusService;
  private dolSvc: DolEtaSearchService;
  showWorkGrid: boolean = true;
  showEduGrid: boolean = false;
  constructor(private dolSearchService: DolEtaSearchService, private ssb: SmartSearchService, private router: Router, private css: ComponentStatusService) {
    this.dolSvc = dolSearchService

    //integration point with SSB
    this.cssSubscription = this.css.currentMessage.subscribe(message => {
      this.resetComonpnent()
      if (message.destComponentName == AppSettings.CS_DOL_ETA_9035V2) {

        console.log(message.data);
        
        try{
          this.parseDolData(message.data)
        }catch(error){ 
          this.appsAlert = AppSettings.VSR_STATUS_CODE_001_DESC;
          this.showDol = false;
          this.loading = false;
          this.showAddendum = false
          this.showWorkSites = false
          this.showEducation = false
          this.showSummary = false;}
         }


      });
    
      }
  ngOnInit() {
    this.showSummary = false
    this.showDol = false
    this.showAddendum = false
    this.showWorkSites = false
    this.showEducation = false
    this.model.petitionNumber = this.petitionId;
    console.log(this.petitionId)
    if (this.petitionId !== "" && this.dolEtaFormType !== "") {
      this.getDolSearchByPetitionID(this.model.petitionNumber, this.dolEtaClobId);
    }else if (this.etacaseNumber !== "" && this.dolEtaFormType == '9035' && this.dolEtaFormVersion == '2'){
      this.getDolSearchByCaseNumber(this.etacaseNumber)
    }
    console.log("In 9035 v2 Init")

  }
  ngOnDestroy() {
    if (this.cssSubscription) {
      this.cssSubscription.unsubscribe();
      console.log("In 9035 v2 Destroy")
    }
    this.resetComonpnent()
  }

  getDolSearchByCaseNumber(caseNumber: string) {
    this.showSummary = false;
    this.loading = true
    this.showDol = false
    this.showAddendum = false
    this.showWorkSites = false
    this.showEducation = false
    this.appsAlert = ""
    //Start service Call
    this.dolSvc.getDolByCaseId(caseNumber.replace(/-/g, '')).subscribe(data => {
      console.log(data)
      this.parseDolData(data)
    }, error => {
      (async () => {
        //await delay(10000);  //when simulating a long delay or timeout from a service.
        //console.log('after delay');
        this.appsAlert = AppSettings.VSR_STATUS_CODE_001_DESC;
        this.showDol = false;
        this.loading = false;
        this.showAddendum = false
        this.showWorkSites = false
        this.showEducation = false
        this.showSummary = false;
      })();
    }
    )
  }
  getDolSearchByPetitionID(petitionNumber: string, dolEtaClobId: string) {
    this.showSummary = false;
    this.loading = true
    this.showDol = false
    this.showAddendum = false
    this.showWorkSites = false;
    this.showEducation = false
    this.appsAlert = ""
    //Start service Call
    this.dolSvc.getDolByPettitionId9035v2(petitionNumber, dolEtaClobId).subscribe(data => {
      console.log(data)
      if (data.GetDolDetailByPetitionIDResponse.DolEtaFormType !== '9035'){
        console.log("Unsupported DOL Form Type " + data.GetDolDetailByPetitionIDResponse.DolEtaFormType)
        this.appsAlert = "Unsupported DOL Form Type " + data.GetDolDetailByPetitionIDResponse.DolEtaFormType
        this.showDol = false;
        this.loading = false;
        this.showAddendum = false
        this.showWorkSites = false
        this.showEducation= false
        this.showSummary = false;
        return;
      }
      try {
        if (JSON.stringify(data).includes("ESB2Exception")) throw new Error(JSON.stringify(data));
      } catch (error) {
        this.appsAlert = AppSettings.SYSTEM_EXCEPTION;
        this.showDol = false;
        this.loading = false;
        this.showAddendum = false
        this.showWorkSites = false
        this.showEducation = false
        this.showSummary = false;
        console.log(error);
        return;
      }
      // console.log(data.DolJsonData)
      // this.root = data;
      // console.log(this.root.DolJsonData)
      this.dol = <DolData>JSON.parse(data.GetDolDetailByPetitionIDResponse.DolJsonData)
      console.log(this.dol)
      this.dolEta = <DOLDATA>this.dol.DOL_DATA
      console.log(this.dolEta)
      //this.dolEta = <DOLDATA> this.dol

      if (Array.isArray(this.dolEta.DOL_ETA_WORKSITES)){
        this.FA12A_DOLPWD = this.makeBooleans(this.dolEta.DOL_ETA_WORKSITES[0].FA12A_DOLPWD)
        this.FA13_OESPW = this.makeBooleans(this.dolEta.DOL_ETA_WORKSITES[0].FA13_OESPW)
        this.F14_OTHERPW = this.makeBooleans(this.dolEta.DOL_ETA_WORKSITES[0].F14_OTHERPW)
        if (this.dolEta.DOL_ETA_WORKSITES.length > 1) {
        
        this.showWorkSites = true;
      }
    }

      if (Array.isArray(this.dolEta.DOL_ETA_EDUCATION)) {
        this.showEducation = true
      }
      if (this.dolEta.DOL_ETA_CLOB) {

        if (Array.isArray(this.dolEta.DOL_ETA_CLOB)) {
          var clob = this.dolEta.DOL_ETA_CLOB;
          console.log


          this.loading = false
          this.showDol = true

        } else {
          if (this.dolEta.DOL_ETA_CLOB.CASE_NUMBER == "remove") {
            this.loading = false
            this.showDol = false
            this.appsAlert = AppSettings.VSR_STATUS_CODE_001_DESC;

          } else {


            this.dolEtaResult = this.dolEta.DOL_ETA_CLOB;
            this.dolEta.DOL_ETA_CLOB = [];
            this.dolEta.DOL_ETA_CLOB.push(this.dolEtaResult)
            this.loading = false;
            this.showDol = true
          }

        }

      }
      //For Loading Animation
      this.showAddendum = this.showEducation || this.showWorkSites
      this.showSummary = true
      this.loading = false
    },
      error => {
        (async () => {
          //await delay(10000);  //when simulating a long delay or timeout from a service.
          //console.log('after delay');
          this.appsAlert = AppSettings.VSR_STATUS_CODE_001_DESC + ", " + JSON.stringify(error);
          this.showDol = false;
          this.loading = false;
          this.showAddendum = false
          this.showWorkSites = false
          this.showEducation = false
          this.showSummary = false;
        })();
      }
    )

  }
  parseDolData(data) {
    try {
      if (JSON.stringify(data).includes("ESB2Exception")) throw new Error(JSON.stringify(data));
    } catch (error) {
      this.appsAlert = AppSettings.SYSTEM_EXCEPTION;
      this.showDol = false;
      this.loading = false;
      this.showAddendum = false
      this.showWorkSites = false
      this.showEducation = false
      this.showSummary = false;
      console.log(error);
      return;
    }
    // console.log(data.DolJsonData)
    // this.root = data;
    // console.log(this.root.DolJsonData)
    this.dol = <DolData>JSON.parse(data.GetDolDetailByEtaCaseNumberResponse.DolJsonData)
    console.log(this.dol)
    this.dolEta = <DOLDATA>this.dol.DOL_DATA
    console.log(this.dolEta)
    //this.dolEta = <DOLDATA> this.dol

    if (Array.isArray(this.dolEta.DOL_ETA_WORKSITES)){
      this.FA12A_DOLPWD = this.makeBooleans(this.dolEta.DOL_ETA_WORKSITES[0].FA12A_DOLPWD)
      this.FA13_OESPW = this.makeBooleans(this.dolEta.DOL_ETA_WORKSITES[0].FA13_OESPW)
      this.F14_OTHERPW = this.makeBooleans(this.dolEta.DOL_ETA_WORKSITES[0].F14_OTHERPW)
      if (this.dolEta.DOL_ETA_WORKSITES.length > 1) {
      
      this.showWorkSites = true;
    }
  }

    if (Array.isArray(this.dolEta.DOL_ETA_EDUCATION)) {
      this.showEducation = true
    }
    if (this.dolEta.DOL_ETA_CLOB) {

      if (Array.isArray(this.dolEta.DOL_ETA_CLOB)) {
        var clob = this.dolEta.DOL_ETA_CLOB;
        this.loading = false
        this.showDol = true

      } else {
        if (this.dolEta.DOL_ETA_CLOB.CASE_NUMBER == "remove") {
          this.loading = false
          this.showDol = false
          this.appsAlert = AppSettings.VSR_STATUS_CODE_001_DESC;

        } else {
          this.dolEtaResult = this.dolEta.DOL_ETA_CLOB;
          this.dolEta.DOL_ETA_CLOB = [];
          this.dolEta.DOL_ETA_CLOB.push(this.dolEtaResult)
          this.loading = false;
          this.showDol = true
        }

      }

    }
    //For Loading Animation
    this.showAddendum = this.showEducation || this.showWorkSites
    //Hide Summary when search by case Number
    //this.showSummary = true  
    this.loading = false
  }
  toggleStmnts() {
    this.showStatemnts = !this.showStatemnts
  }
  toggleStmnts2() {
    this.showStatemnts2 = !this.showStatemnts2
  }
  toggleStmnts3() {
    this.showStatemnts3 = !this.showStatemnts3
  }
  makeBooleans(answer: any) {
    console.log(answer)
    if ((answer) && answer.toUpperCase() == "Y") {
      return true;
    }
    else return false;

  }
  resetComonpnent() {
    this.showDol = false;
    this.loading = false;
    this.showAddendum = false
    this.showWorkSites = false
    this.showEducation = false
    this.showSummary = false;
  }
    //Needed to Handle 1 page double pagination issue.
  showEducationGrid(){
    this.showWorkGrid = false;
    this.showEduGrid = true;
  }
  showWorksiteGrid(){
    this.showEduGrid = false;
    this.showWorkGrid = true; 
  }
}
