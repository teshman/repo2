import { Component,EventEmitter, OnInit, AfterViewInit, ViewChild,NgZone, Directive, ElementRef, Input, Output, Renderer2 } from '@angular/core';
import { ClrDatagridFilterInterface } from '@clr/angular';
import { formatDate} from '@angular/common'
import { pfDunsResponse, PreviousFilingRecordEntity } from '../../shared/dunsResponse_interfaces'
import { Subject} from 'rxjs'
import { DeprecatedI18NPipesModule } from '@angular/common';


@Component({
  selector: 'app-date-filter',
  templateUrl:'./date-filter.component.html',
  styleUrls: ['./date-filter.component.css']
})

export class dateFilter implements ClrDatagridFilterInterface<PreviousFilingRecordEntity> , OnInit, AfterViewInit{
 
  allPetitions = ["ALL","I-129", "I-140", "I-130", "I-485J"];
  nbPetitions=0;
  beginDate: any;
  endDate: any;
  selectedPetitions: { [petition: string]: boolean } = {};
  active = false;
  showAlert = false;
  alertMessage = "Invalid Date Range.  End Date cannot be before Start Date"
  changes: EventEmitter<any> = new EventEmitter<any>(false);
  endDate2= "";
  beginDate2="";
  @Output() clear = new EventEmitter<string>();
  @Output() results = new EventEmitter<number>();
  @Input() totalRecords: number;
  filteredResults: number = 0;
  filterCounter: number = 0;
  // listSelected(): string[] {
  //   const list: string[] = [];
  //   for (const petition in this.selectedPetitions) {
  //     if (this.selectedPetitions[petition]) {
  //       list.push(petition);
  //     }
  //   }
  //   return list;
  // }

  constructor(private el: ElementRef, private zone: NgZone, private renderer: Renderer2) {}

  ngOnInit(): void {
    this.clearDateFilter()
  }
  testClick(): boolean{
    //console.log("clicked")
    return true;
  }
  ngAfterViewInit(): void {
    // var elements = document.getElementsByClassName("datepicker-trigger");

    // for(var i = 0; i<elements.length; i++){
    //   var input = elements.item(i);
    //   input.toggleAttribute("title", true)
    //   input.toggleAttribute("id", true)
    //   input.setAttribute("id", "datebutton" + i)
    //   if (i == 0){
    //     input.setAttribute("title", "Select Start Date")
        
    //   }else {input.setAttribute("title", "Select End Date")}
    // }
    // let date1:Element = document.getElementById("datebutton0")
    // let date2:Element = document.getElementById("datebutton1")
    // date1.addEventListener('click',($event) => {this.testClick()})
    // date2.addEventListener('click',($event) => {this.testClick()})
    
  //   this.zone.runOutsideAngular(() => setTimeout(() => {
  //     console.log("************SetMyLabelDirective directive called");
  //     console.log(this.el.nativeElement.getElementsByClassName("clr-input-group-icon-action"));
  //     this.el.nativeElement.getElementsByClassName("clr-input-group-icon-action")[0].setAttribute('title','Title Goes here')
  //     //this.renderer.selectRootElement(this.el.nativeElement.getElementsByTagName("clr-input-group-icon-action")).setAttribute('title','Fuck You');
     
  //    //console.log(this.el.nativeElement.getElementsByClassName("clr-input-group-icon-action"));


  // }, 0));

  }
  clearDateFilter() {

    this.active = !this.active
    let startDate = new Date(); 
    startDate.setMonth(startDate.getMonth()-36); 

    this.beginDate = startDate;
    this.endDate = formatDate(Date.now(),'MM/dd/yyyy','en-US');
    this.beginDate = formatDate(this.beginDate,'MM/dd/yyyy','en-US');
    this.alertMessage="";
    this.showAlert=false;
    this.filterCounter = 0
    this.filteredResults = 0
    this.changes.emit(true)
    this.clear.emit("") 
    return
    
  }
  
  isMoreThan36Months(bDate: Date, eDate: Date): boolean{
  
    let milisecDiffBetweenTwoDates = (eDate.getTime() - bDate.getTime())/2.628e+9;

    if(milisecDiffBetweenTwoDates>36){
      return true;
    } else {
      return false; 
    }


    // let start36Months = eDate; 
    // start36Months.setMonth(eDate.getMonth()-36);
    
    // if ((eDate.getTime() - start36Months.getTime()) > milisecDiffBetweenTwoDates) {
    //   return true ; 
    // }else {
    //   return false;
    // }

  }

  applyDatePetition(petition: string) {
    // this.active = !this.active
    this.alertMessage = ""
    this.showAlert = false;
   
    if((!this.endDate)|| (!this.beginDate)){
      this.alertMessage = "Please fill out both Dates."
      this.showAlert = true;
      return
    }

    this.beginDate = new Date(formatDate(this.beginDate,'MM/dd/yyyy','en-US'))
    console.log("Begin Date: " + this.beginDate)
    this.endDate = new Date(formatDate(this.endDate,'MM/dd/yyyy','en-US'))
    console.log("End Date: " + this.endDate)
    try{
      
      if(this.isMoreThan36Months(this.beginDate, this.endDate)){
        this.alertMessage = "Invalid Date Range.  Selected Date Range is greater than 36 months."
        this.showAlert = true;
        return
          
      }
    if(this.endDate.getTime() < this.beginDate.getTime()){
      this.alertMessage = "Invalid Date Range.  End Date cannot be before Start Date"
      this.showAlert = true;
      return
    }
  }catch(error){
    this.alertMessage = "Invalid Dates."
    this.showAlert = true;
    return
  }

    //Logic deciding which petition to show
    if(petition == 'ALL'){
      var inputs = document.getElementsByTagName("input")
      for(var i = 0; i<inputs.length; i++){
        var input = inputs.item(i)
        input.value = ""
      }
      this.nbPetitions = 0;
      this.alertMessage="";
      this.showAlert=false;

      this.changes.emit(true)
      this.clear.emit("")
      return
    }
    for (var pet of this.allPetitions){
      this.selectedPetitions[pet] = false;
    }
    this.selectedPetitions[petition] = true;
    this.selectedPetitions[petition] ? this.nbPetitions++ : this.nbPetitions--;
    
    this.alertMessage="";
    this.showAlert=false;
    this.changes.emit(true);
    this.clear.emit("");
  }

  togglePetition(petition: string) {
    this.active = !this.active
    console.log("selecte petition="+petition);
    console.log("Selected Petitions Before: " +  JSON.stringify(this.selectedPetitions))

    if(this.endDate == null || this.beginDate == null){
      this.alertMessage = "Please fill out both Dates."
      this.showAlert = true;
      
      return
    }
    if(this.endDate.getTime() < this.beginDate.getTime()){
      this.alertMessage = "Invalid Date Range.  End Date cannot be before Start Date"
      this.showAlert = true;
      return
    }
    //Logic deciding which petition to show
    if(petition == 'ALL'){
      var inputs = document.getElementsByTagName("input")
      for(var i = 0; i<inputs.length; i++){
        var input = inputs.item(i)
        input.value = ""
      }
      this.nbPetitions = 0;
      this.changes.emit(true)
      return
    }
    for (var pet of this.allPetitions){
      this.selectedPetitions[pet] = false;
    }
    this.selectedPetitions[petition] = true;
    this.selectedPetitions[petition] ? this.nbPetitions++ : this.nbPetitions--;
    this.changes.emit(true);
  }
  // testVals(){
  //   console.log(this.beginDate)
  //   console.log(this.endDate)
  //   this.selectedPetitions["beginDate"] = this.beginDate;
  //   this.selectedPetitions["endDate"] = this.endDate;
    
  //   this.changes.emit(true);
  // }

  //changes = new Subject<any>();
  isActive(): boolean {
    //console.log("isActive: "+ this.nbPetitions)
    return this.nbPetitions > 0;
  }
  accepts(previousFilingRecordEntity: PreviousFilingRecordEntity): boolean {
    this.filterCounter++;
    console.log("Total: " + this.totalRecords)
    console.log("Counter: " + this.filterCounter)
    console.log("Date Added from Data: " + previousFilingRecordEntity.DateAdded)

    var newDateAdded = new Date(previousFilingRecordEntity.DateAdded + "GMT-4")
    this.beginDate = new Date(this.beginDate)//
    this.endDate = new Date(this.endDate)//
    console.log("Date Added " + newDateAdded)
    console.log("Begin Date: " + this.beginDate)
    console.log("End Date: " + this.endDate)
    var afterBegin = (newDateAdded >= this.beginDate)
    var beforeEnd = (newDateAdded <= this.endDate)
    console.log("Is new date after begin date? " + afterBegin)
    console.log("Is new date before end date? " + beforeEnd)
    // this.endDate = formatDate(this.endDate,'MM/dd/yyyy','en-US');
    // this.beginDate = formatDate(this.beginDate,'MM/dd/yyyy','en-US');
    if(afterBegin && beforeEnd){
      this.filteredResults++;
    }
    console.log("Results: " + this.filteredResults)
    if(this.filterCounter == this.totalRecords){
      console.log("EMIT HERE")
      this.results.emit(this.filteredResults)
      console.log(this.filteredResults)
      this.filterCounter = 0
      this.filteredResults = 0
    }
    //return (newDateAdded > this.beginDate) && (newDateAdded < this.endDate)
    return (afterBegin  && beforeEnd) //|| this.nbPetitions == 0
  }
  
}
