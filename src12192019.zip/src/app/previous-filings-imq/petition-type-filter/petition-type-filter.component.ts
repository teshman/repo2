import { Component,EventEmitter, OnInit, Output, Input } from '@angular/core';
import { ClrDatagridFilterInterface } from '@clr/angular';
import { pfDunsResponse, PreviousFilingRecordEntity } from '../../shared/dunsResponse_interfaces'
import { Subject} from 'rxjs'


@Component({
  selector: 'app-petition-type-filter',
  templateUrl:'./petition-type-filter.component.html',
  styleUrls: ['./petition-type-filter.component.css']
})

export class PetitionTypeFilter implements ClrDatagridFilterInterface<PreviousFilingRecordEntity> {
  allPetitions = ["ALL","I-129", "I-140", "I-130", "I-485J"];
  nbPetitions=0;
  selectedPetitions: { [petition: string]: boolean } = {};
  options = 'option0'
  changes: EventEmitter<any> = new EventEmitter<any>(false);
  @Output() clear = new EventEmitter<string>();
  @Output() results = new EventEmitter<number>();
  @Input() totalRecords: number;
  filteredResults: number = 0;
  filterCounter: number = 0;
  listSelected(): string[] {
    const list: string[] = [];
    for (const petition in this.selectedPetitions) {
      if (this.selectedPetitions[petition]) {
        list.push(petition);
      }
    }
    return list;
  }

  togglePetition(petition: string) {
    console.log("selecte petition="+petition);
    console.log("Selected Petitions Before: " +  JSON.stringify(this.selectedPetitions))

    //Logic deciding which petition to show
    if(petition == 'ALL'){
      this.nbPetitions = 0;

      if(this.totalRecords>0){
      this.results.emit(1)
      }else{this.results.emit(0)}
      
      this.changes.emit(true)
      this.clear.emit("")
      return
    }
    for (var pet of this.allPetitions){
      this.selectedPetitions[pet] = false;
    }
    this.selectedPetitions[petition] = true;
    this.selectedPetitions[petition] ? this.nbPetitions++ : this.nbPetitions--;
    this.changes.emit(true);
    this.clear.emit("")
  }


  //changes = new Subject<any>();
  isActive(): boolean {
    //console.log("isActive: "+ this.nbPetitions)
    return this.nbPetitions > 0;
  }
  accepts(previousFilingRecordEntity: PreviousFilingRecordEntity) {
    this.filterCounter++;
    console.log("Total: " + this.totalRecords)
    console.log("Counter: " + this.filterCounter)
    console.log("Selected Positions after: " + JSON.stringify(this.selectedPetitions)); 
    console.log(previousFilingRecordEntity.PetitionType)
    if(this.nbPetitions === 0 || this.selectedPetitions[previousFilingRecordEntity.PetitionType]){
      this.filteredResults++;
    }
    console.log("Results: " + this.filteredResults)
    if(this.filterCounter == this.totalRecords){
      console.log("EMIT HERE")
      this.results.emit(this.filteredResults)
      console.log(this.filteredResults)
      this.filterCounter = 0
      this.filteredResults = 0
    }
    return this.nbPetitions === 0 || this.selectedPetitions[previousFilingRecordEntity.PetitionType];
  }
  
}
