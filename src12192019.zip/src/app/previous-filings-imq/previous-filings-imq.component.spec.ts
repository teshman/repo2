import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PreviousFilingsImqComponent } from './previous-filings-imq.component';

describe('ImqComponent', () => {
  let component: PreviousFilingsImqComponent;
  let fixture: ComponentFixture<PreviousFilingsImqComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PreviousFilingsImqComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PreviousFilingsImqComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
