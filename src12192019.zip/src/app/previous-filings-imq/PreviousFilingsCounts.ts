export class PreviousFilingsCounts {
    name: String;
    value: number;

    constructor(name, value) {
        this.name = name;
        this.value = value;
    }
}