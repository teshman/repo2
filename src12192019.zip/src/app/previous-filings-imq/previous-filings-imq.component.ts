import { Component, ElementRef, OnInit, ViewChild, ChangeDetectionStrategy, EventEmitter, Input, Output, AfterViewInit, SimpleChanges, OnChanges } from '@angular/core';

import { SmartSearchModel } from "../shared/smart-search-model";
import { SmartSearchBoxComponent } from '../smart-search-box/smart-search-box.component';
import { SmartSearchService } from '../smart-search.service';
import { ComponentStatusService } from '../shared/service/component-status.service';
import { ComponentStatus } from '../shared/service/component-status';

import { IndependentManualQueryService } from '../independent-manual-query.service';
import { Router } from '@angular/router';
//import { AddressProxy } from '../shared/vsr-resubmit-proxy';
import { VSRResubmitAddress } from '../shared/vsr-resubmit';
import { IndependentManualQueryResponse1Proxy } from '../shared/independent-manual-query-response-proxy';
import { PreviousFilingsService } from '../previous-filings.service';
import { Subscription } from 'rxjs';
import { pfDunsResponseProxy } from '../shared/dunsResponseProxies'
import { pfDunsResponse, PreviousFilingRecordEntity } from '../shared/dunsResponse_interfaces'
import { pfFeinResponse } from '../shared/feinResponse_interfaces';
import { PreviousFilingsCounts } from './PreviousFilingsCounts';
import { AppSettings } from '../shared/app-settings';
import { ClrDatagridFilterInterface, ClrDatagridStateInterface, ClrDatagridPagination, ClrDatagrid } from "@clr/angular";
import { Subject } from 'rxjs/Subject';
import { MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { ExcelService } from '../excel.service';

//import * as $ from 'jquery';


@Component({
  changeDetection: ChangeDetectionStrategy.Default,
  selector: 'app-previous-filings-imq',
  templateUrl: './previous-filings-imq.component.html',
  styleUrls: ['./previous-filings-imq.component.css']
})

export class PreviousFilingsImqComponent implements OnInit, AfterViewInit {
  displayBranchMatchMessage: boolean = false;
  showvsrmodal: boolean = false;

  ngAfterViewInit() {
    console.log('AfterViewInit');
    console.log("HERE");
    var elements = document.getElementsByClassName('clr-dg-table-wrapper');
    for (var i = 0; i < elements.length; ++i) {
      elements[i].setAttribute('role', 'table');
      console.log("updated = " + i);
    }

    var e = document.getElementsByTagName('clr-dg-table-wrapper');
    for (var i = 0; i < e.length; ++i) {
      e[i].setAttribute('role', 'table');
      console.log("e = " + i);
    }

  }

  loading: boolean = false;
  searchStarted: boolean = false;
  showpage = false;

  gridFilter = "";
  displayManualSearch = false;
  reciptNumber = "";//EAC1807951580
  message: SmartSearchModel;
  duns: string = "";
  searchDuns: string = "";
  fein: string = "";
  address: VSRResubmitAddress = new VSRResubmitAddress();
  searchSubscription: Subscription;
  cssSubscription: Subscription;


  imqResponse: IndependentManualQueryResponse1Proxy;
  pfDunsResponse: pfDunsResponse[];
  pfFeinResponse: pfFeinResponse[];
  addressStr: string = "";
  searchResponseMessage: string = "";

  //-----------------chart
  view: any[] = [225, 225];
  data = [];
  count: number = 0;
  filteredResults: number = 1;
  colorScheme = {
    domain: ['#4C2C92', '#A10A28', '#1B75BC', '#193300']
  };
  //-----------------chart
  //selected on the UI
  selectedReceipt;
  resultset: PreviousFilingRecordEntity[] = [];

  constructor(
    private router: Router,
    private imqService: IndependentManualQueryService,
    private prevFilingsService: PreviousFilingsService,
    private ssb: SmartSearchService,
    private css: ComponentStatusService,
    private excelService:ExcelService
  ) {

    //  Object.assign(this, {this.single, multi})  
    this.cssSubscription = this.css.currentMessage.subscribe(message => {

      if ((message.destComponentName === AppSettings.CS_PREVIOUS_FILINGS_HUB) &&
        (message.clear)) {
        console.log("css: reset message received for hub.");
        this.resetComponent();

      }
    });


    //integration point with SSB
    this.searchSubscription = this.ssb.currentMessage.subscribe(message => {
      console.log("PreviousFilingsImqComponent: search box: " + JSON.stringify(message));
      this.message = message;
      if ((message.selectedSearchType == "previousFilings") &&
        (message.selectedSearchFunction == "pfDuns") &&
        (message.searchById != "") &&
        (message.searchById != undefined)) {
        this.duns = message.searchById
        console.log("this.duns=" + this.duns);

        //call method
        this.showpage = true;
        this.searchByDUNS();
        message.searchById = "";

      } else if ((message.selectedSearchType == "previousFilings") &&
        (message.selectedSearchFunction == "pfFein") &&
        (message.searchById != "") &&
        (message.searchById != undefined)) {
        this.fein = message.searchById
        console.log("this.fein=" + this.fein);

        //call method
        this.searchByFFIN();
        message.searchById = "";


      } else if ((message.selectedSearchType == "previousFilings") &&
        (message.selectedSearchFunction == "pfBA")) {
        console.log("message: ");
        console.log(message);

        if (message.address != undefined) {
          this.address = message.address;
          this.searchByAddress()
        }
        //console.log(this.address);
        //console.log(message.address);
        //this.address = message.address;
        //this.searchByAddress()
      }
    });
  }

  ngOnInit() {
    console.log("ng On Init");
  }

  displayManualSearchButton: boolean = false;
  displayVsr: boolean = true;
  ReceiptNumber: string = "";


  ngOnDestroy() {
    this.searchSubscription.unsubscribe();
    this.cssSubscription.unsubscribe();
  }

  searchByDUNS() {
    this.resetComponent()
    console.log("search by DUNS");
    this.fein = "";
    this.resultset = [];
    this.showpage = false;
    this.loading = true;
    this.displayBranchMatchMessage = false;

    this.imqService.getImqByDuns(this.duns).subscribe(data => {
      this.imqResponse = data.IndependentManualQueryResponse;

      // this.data.push(new PreviousFilingsCounts("I-129", (this.imqResponse.I129CountInLast36Month) ? (this.imqResponse.I129CountInLast36Month, this.showpage = true) : 0));
      // this.data.push(new PreviousFilingsCounts("I-140", (this.imqResponse.I140CountInLast36Month) ? (this.imqResponse.I140CountInLast36Month, this.showpage = true) : 0));
      // this.data.push(new PreviousFilingsCounts("I-360", (this.imqResponse.I360CountInLast36Month) ? (this.imqResponse.I360CountInLast36Month, this.showpage = true) : 0));
      // this.data.push(new PreviousFilingsCounts("I-485J", (this.imqResponse.I485JCountInLast36Month) ? (this.imqResponse.I485JCountInLast36Month, this.showpage = true) : 0));

      this.data.push(new PreviousFilingsCounts("I-129", (this.imqResponse.I129CountInLast36Month) ? (this.imqResponse.I129CountInLast36Month) : 0));
      this.data.push(new PreviousFilingsCounts("I-140", (this.imqResponse.I140CountInLast36Month) ? (this.imqResponse.I140CountInLast36Month) : 0));
      this.data.push(new PreviousFilingsCounts("I-360", (this.imqResponse.I360CountInLast36Month) ? (this.imqResponse.I360CountInLast36Month) : 0));
      this.data.push(new PreviousFilingsCounts("I-485J", (this.imqResponse.I485JCountInLast36Month) ? (this.imqResponse.I485JCountInLast36Month) : 0));

      console.log(data);

      if (this.imqResponse.I129CountInLast36Month || this.imqResponse.I140CountInLast36Month || this.imqResponse.I360CountInLast36Month || this.imqResponse.I485JCountInLast36Month) {
        this.showpage = true
        this.searchDuns = this.imqResponse.DunsNumber;
        this.searchStarted = true;
        this.count = this.imqResponse.I129CountInLast36Month + this.imqResponse.I140CountInLast36Month + this.imqResponse.I360CountInLast36Month + this.imqResponse.I485JCountInLast36Month
      } else {
        this.searchResponseMessage = AppSettings.PREV_FILINGS_HUB_NOT_FOUND;
        this.showpage = false;
        this.loading = false;
        return;
      }

      if (this.imqResponse.DunsNumber == undefined) {
        this.message.error = "No record matches for this company name/address.";
        this.searchStarted = false;
      } else if (this.imqResponse.DunsNumber != undefined) {
        this.searchStarted = true;
        if (this.duns != this.imqResponse.DunsNumber) {
          this.displayBranchMatchMessage = true;
          console.log("branch alert2!");
        }
        this.prevFilingsService.getAllByDuns(this.imqResponse.DunsNumber)
          .then(data => {
            if (data) {
              this.pfDunsResponse = JSON.parse(JSON.stringify(data));
              console.log(this.pfDunsResponse);


              if (this.pfDunsResponse[0].PreviousFilingsGetByDunsNumberResponse.PreviousFilingsResultSet.PreviousFilingRecord) {
                for (let i of this.pfDunsResponse[0].PreviousFilingsGetByDunsNumberResponse.PreviousFilingsResultSet.PreviousFilingRecord) {
                  console.log(i);
                  console.log(this.resultset);
                  i.PetitionType = this.getPetitionType(i.VisaType);
                  this.resultset.push(i);
                }
                this.count = this.resultset.length
              }
              this.loading = false;
            }
          })
          .catch(error => {
            console.log(error);
            this.message.error = AppSettings.SYSTEM_EXCEPTION;
            this.loading = false;
          });

      }

      console.log(this.imqResponse.DunsNumber);

    });

    // console.log("looking up prevFilingsService.getAllByDuns()");
    // this.prevFilingsService.getAllByDuns(this.searchDuns)
    //   .then(data => {
    //     if (data) {
    //       this.pfDunsResponse = JSON.parse(JSON.stringify(data));
    //       console.log(this.pfDunsResponse);

    //       if (this.pfDunsResponse[0].PreviousFilingsGetByDunsNumberResponse.PreviousFilingsResultSet.PreviousFilingRecord) {
    //         for (let i of this.pfDunsResponse[0].PreviousFilingsGetByDunsNumberResponse.PreviousFilingsResultSet.PreviousFilingRecord) {
    //           i.PetitionType = this.getPetitionType(i.VisaType);
    //           this.resultset.push(i);
    //           // console.log(this.resultset);
    //         }
    //       }
    //     }
    //     this.loading = false;


    //   })
    //   .catch(error => {
    //     this.loading = false;
    //     console.log("Error in getAllByDuns()");
    //   });

  }

  getPetitionType(visaType: String): string {
    for (let vType of AppSettings.i129) {
      if (vType === visaType) return "I-129";
    }
    for (let vType of AppSettings.i140) {
      if (vType === visaType) return "I-140";
    }
    for (let vType of AppSettings.i360) {
      if (vType === visaType) return "I-360";
    }
    return "I-485J"; //if not I129, I140 or I-360  return I485J
  }


  searchByFFIN() {
    this.resetComponent()
    console.log("search by FEIN");
    this.duns = "";
    this.loading = true;
    this.showpage = false;
    this.resultset = [];

    this.imqService.getImqByFein(this.fein).subscribe(data => {
      this.imqResponse = data.IndependentManualQueryResponse;
      this.data.push(new PreviousFilingsCounts("I-129", (this.imqResponse.I129CountInLast36Month) ? (this.imqResponse.I129CountInLast36Month) : 0));
      this.data.push(new PreviousFilingsCounts("I-140", (this.imqResponse.I140CountInLast36Month) ? (this.imqResponse.I140CountInLast36Month) : 0));
      this.data.push(new PreviousFilingsCounts("I-360", (this.imqResponse.I360CountInLast36Month) ? (this.imqResponse.I360CountInLast36Month) : 0));
      this.data.push(new PreviousFilingsCounts("I-485J", (this.imqResponse.I485JCountInLast36Month) ? (this.imqResponse.I485JCountInLast36Month) : 0));

      console.log("data");
      console.log(data);
      if (this.imqResponse.I129CountInLast36Month || this.imqResponse.I140CountInLast36Month || this.imqResponse.I360CountInLast36Month || this.imqResponse.I485JCountInLast36Month) {
        this.showpage = true;
        this.searchStarted = true;
        this.searchDuns = this.imqResponse.DunsNumber;
      } else {
        this.searchResponseMessage = AppSettings.PREV_FILINGS_HUB_NOT_FOUND;
        this.showpage = false;
        this.loading = true;

      }

      console.log("back from imqResponse getImqByFEIN())");
      console.log(this.imqResponse);
      console.log("looking up prevFilingsService.getAllByFein()");
      this.prevFilingsService.getAllByFein(this.fein)
        .then(data => {
          if (data) {
            this.pfFeinResponse = JSON.parse(JSON.stringify(data));
            console.log(this.pfFeinResponse);

            if (this.pfFeinResponse[0].PreviousFilingsGetByFeinNumberResponse.PreviousFilingsResultSet.PreviousFilingRecord) {
              for (let i of this.pfFeinResponse[0].PreviousFilingsGetByFeinNumberResponse.PreviousFilingsResultSet.PreviousFilingRecord) {
                console.log(i);
                console.log(this.resultset);
                i.PetitionType = this.getPetitionType(i.VisaType);
                this.resultset.push(i);
              }
              this.count = this.resultset.length
            }
          }
          this.loading = false;
        })
        .catch(error => {
          console.log(error);
          this.message.error = AppSettings.SYSTEM_EXCEPTION;
          this.loading = false;
        });

    });


  }




  searchByAddress() {
    console.log("in searchByAddress");
    this.fein = "";
    this.duns = "";
    this.resultset = [];
    this.showpage = false;
    this.loading = true;

    this.imqService.getImqByAddress(this.address).subscribe(data => {
      this.imqResponse = data.IndependentManualQueryResponse;


      console.log(data);

      this.data.push(new PreviousFilingsCounts("I-129", (this.imqResponse.I129CountInLast36Month) ? (this.imqResponse.I129CountInLast36Month) : 0));
      this.data.push(new PreviousFilingsCounts("I-140", (this.imqResponse.I140CountInLast36Month) ? (this.imqResponse.I140CountInLast36Month) : 0));
      this.data.push(new PreviousFilingsCounts("I-360", (this.imqResponse.I360CountInLast36Month) ? (this.imqResponse.I360CountInLast36Month) : 0));
      this.data.push(new PreviousFilingsCounts("I-485J", (this.imqResponse.I485JCountInLast36Month) ? (this.imqResponse.I485JCountInLast36Month) : 0));


      //There was a match
      if (this.imqResponse.I129CountInLast36Month || this.imqResponse.I140CountInLast36Month || this.imqResponse.I360CountInLast36Month || this.imqResponse.I485JCountInLast36Month) {
        console.log("Address matched to a company/org");
        this.showpage = true
        this.searchDuns = this.imqResponse.DunsNumber;
      } else {
        //no match for the address
        console.log("Address did not match to a company/org");
        this.showpage = false;
        this.searchStarted = false;
        this.loading = false;

        this.searchResponseMessage = AppSettings.PREV_FILINGS_HUB_NOT_FOUND;
        return;
      }


      if (this.imqResponse.DunsNumber == undefined) {
        // this.message.error = "No record matches for this company name/address.";
        this.searchResponseMessage = AppSettings.PREV_FILINGS_HUB_NOT_FOUND;
        this.loading = false;
        this.searchStarted = false;

      } else if (this.imqResponse.DunsNumber != undefined) {
        this.searchStarted = true;

        //address searched is a branch
        if ((this.imqResponse.ResponseStatusMessage) && this.imqResponse.ResponseStatusMessage.StatusCode === "HQ") {
          this.displayBranchMatchMessage = true;
        }
        setTimeout(() => {
          this.prevFilingsService.getAllByDuns(this.imqResponse.DunsNumber)
            .then(data => {
              if (data) {
                this.pfDunsResponse = JSON.parse(JSON.stringify(data));
                console.log(this.pfDunsResponse);

                if (this.pfDunsResponse[0].PreviousFilingsGetByDunsNumberResponse.PreviousFilingsResultSet.PreviousFilingRecord) {
                  for (let i of this.pfDunsResponse[0].PreviousFilingsGetByDunsNumberResponse.PreviousFilingsResultSet.PreviousFilingRecord) {
                    console.log(i);
                    console.log(this.resultset);
                    i.PetitionType = this.getPetitionType(i.VisaType);
                    this.resultset.push(i);
                  }
                  this.count = this.resultset.length
                }
                this.loading = false;

              }
            })
            .catch(error => {
              console.log(error);
              this.message.error = AppSettings.SYSTEM_EXCEPTION;
              this.loading = false;
            });

        }, 30 * 1000);


      }

      console.log(this.imqResponse.DunsNumber);

    });

  }

  getAddress(): String {
    //console.log(address);
    if (this.address) {
      if (this.address.streetFull) {
        this.addressStr = this.address.streetFull.trim();
      }
      if (this.address.city) {
        this.addressStr = this.addressStr + ", " + this.address.city.trim();
      }
      if (this.address.state) {
        this.addressStr = this.addressStr + ", " + this.address.state.trim();
      }
      if (this.address.postalCode) {
        this.addressStr = this.addressStr + ", " + this.address.postalCode.trim();
      }
      if (this.address.country) {
        this.addressStr = this.addressStr + ", " + this.address.country.trim();
      }
    }
    return this.addressStr;

  }

  onReceiptNumberSelected(): String {
    return this.selectedReceipt.ReceiptNumber
  }
  setReceipt(receipt: string) {
    this.reciptNumber = receipt;
    this.showvsrmodal = true;
  }

  onPieSliceSelect(event) {
    console.log("pie chart clicked:");
    console.log(event);
    this.gridFilter = event.name;
  }

  dataTotal(): String {

    return (this.data[0].value + this.data[1].value + this.data[2].value + this.data[3].value)

  }



  resetComponent() {
    this.searchStarted = false;
    this.gridFilter = "";
    this.searchResponseMessage = "";
    this.data = [];
    this.imqResponse = null;
    this.showpage = false;
    this.displayManualSearch = false;
    this.reciptNumber = ""
    this.searchDuns = "";
    //this.duns  = "";
    //this.fein = "";
    //this.address = null;
    this.imqResponse = Object();
    this.loading = false;
    this.pfDunsResponse = [];
    this.pfFeinResponse = [];
    this.addressStr = "";
    //-----------------chart
    this.view = [];
    this.data = [];
    this.selectedReceipt = "";
    this.resultset = [];

    this.imqResponse = null;
    this.pfDunsResponse = [];
    this.pfFeinResponse = [];
    this.displayBranchMatchMessage = false;
    this.addressStr = "";
    this.address = null;

  }

  refresh(state: ClrDatagridStateInterface) {
    console.log(state);
    this.showExportAlert=false;

  }
  clearReceipt(clear: string) {
    this.reciptNumber = null;
  }
  setFirstItem(cnt) {
    this.filteredResults = cnt;
  }


  close() {
    document.getElementById(this.reciptNumber).focus();
    this.showvsrmodal = false;
  }
  
  showExportAlert: boolean = false;
  exporting : boolean = false; 
  
  @ViewChild('pagination', { static: false }) pager: ClrDatagridPagination;
  @ViewChild('datagrid', { static: false }) datagrid: ClrDatagrid;
  styleExp = "all"
  pageNum = Number(AppSettings.PAGINATION_COUNT);
  datagridHtml: HTMLElement;
  exportOptions: string = "EXCEL";
  export = []
  

  async exportReport(){
    this.styleExp = "none"
    this.pageNum = this.pager.totalItems
    this.datagrid.refresh.next();
    await this.delay(2000)
    
    if (this.pager.totalItems== 0){
      this.showExportAlert = true
      return
    }
    //console.log("this.pager.totalItems="+this.pager.totalItems);
    this.updateExport('prevFilingsHubGrid');
    if(this.exportOptions  == "CSV"){
      this.exporting=true;
      console.log("exporting csv, exporting="+this.exporting);
      this.excelService.exportAsCSVFile(this.export, "prevFilingsHubGrid")
    }else if(this.exportOptions  == "EXCEL"){
      this.exporting=true;
      console.log("exporting EXCEL, exporting="+this.exporting);
      this.excelService.exportAsExcelFile(this.export, "prevFilingsHubGrid")
    }
    this.exporting=false;
    this.styleExp = "block"
  }
  delay(ms: number) {
    return new Promise( resolve => setTimeout(resolve, ms) );
}

updateExport(tableid) {
  //Query Dom for Cells and Headers
  this.datagridHtml = document.getElementById(tableid)
  var headers = this.datagridHtml.getElementsByClassName("datagrid-column-title")
  this.export = []
  console.log(headers)
  var headerArr: HTMLElement[] = [].slice.call(headers);
  var headerRow = []
  var f = 0;
  for (var header of headerArr) {
    var text = <HTMLElement>header as HTMLElement
    headerRow[f] = text.textContent.trim()
    f++;
  }
  this.datagridHtml = document.getElementById(tableid)
  let cells: HTMLCollection = this.datagridHtml.getElementsByClassName("datagrid-cell") as HTMLCollection
  console.log('CELLS Length!! size: ' + cells.length)
  console.log(cells)
  var row = [];
  var rowCounter = 0;
  var j = 0;
  var expRow = {};
  for (var j = 0; j < cells.length; j++) {
    //Push Cell to Row Array
    console.log(j)
    console.log(cells)
    console.log(cells.item(j).textContent)

    row.push(cells.item(j).textContent.trim())
    rowCounter = rowCounter + 1;
    //Indicates the end of a Row Processing.
    if (rowCounter >= headers.length) {
      //working on creating object for export
      //Change to create object with page headers
      var k = 0;
      expRow = {}
      var propnames: string[]
      propnames = Object.getOwnPropertyNames(expRow);
      console.log(row)
      //Load Row Array Data into JSON Object
      for (k = 0; k < row.length; k++) {
        expRow[headerRow[k]] = row[k];
      }

      row = [];
      console.log(expRow);
      //Push Row Object to Export array
      this.export.push(expRow)
      rowCounter = 0;
    }
  }
  console.log(this.export)
  //this.addColumnstoExport()
  this.pageNum = Number(AppSettings.PAGINATION_COUNT)
}

addColumnstoExport(){
  
  this.resultset.forEach(rec => {
    let i = 0;
    this.export.forEach(row => {
      if(rec.ReceiptNumber == row["Receipt Number"]){
        row["Company Name"] = rec.OrganizationName
        row["Form Type"]= rec.PetitionType
        row["Visa Type"] = rec.VisaType
        row["Adjudicative Status"] = rec.AdjudicativeStatus
        row["Confidence Code"] = rec.ConfidenceFactor
        row["Date Added"] = rec.DateAdded
      }
      console.log(row)

    })
  })
}
}

