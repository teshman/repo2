import { Component,EventEmitter, OnInit } from '@angular/core';
import { ClrDatagridFilterInterface } from '@clr/angular';
import { pfDunsResponse, PreviousFilingRecordEntity } from '../../shared/dunsResponse_interfaces'
import { Subject} from 'rxjs'


@Component({
  selector: 'app-confidence-code-filter',
  templateUrl:'./confidence-code-filter.component.html',
  styleUrls: ['./confidence-code-filter.component.css']
})

export class confidenceCodeFilter implements ClrDatagridFilterInterface<PreviousFilingRecordEntity> {
  allPetitions = ["ALL","I-129", "I-140", "I-130", "I-485J"];
  nbPetitions=0;
  start: number;
  end: number;
  selectedPetitions: { [petition: string]: boolean } = {};
  active = false;
  changes: EventEmitter<any> = new EventEmitter<any>(false);
  // listSelected(): string[] {
  //   const list: string[] = [];
  //   for (const petition in this.selectedPetitions) {
  //     if (this.selectedPetitions[petition]) {
  //       list.push(petition);
  //     }
  //   }
  //   return list;
  // }

  togglePetition(petition: string) {
    this.active = !this.active
    console.log("selecte petition="+petition);
    console.log("Selected Petitions Before: " +  JSON.stringify(this.selectedPetitions))

    //Logic deciding which petition to show
    if(petition == 'ALL'){
      this.nbPetitions = 0;
      var inputs = document.getElementsByTagName("input")
      for(var i = 0; i<inputs.length; i++){
        var input = inputs.item(i)
        input.value = ""
      }
      this.changes.emit(true)
      return
    }
    for (var pet of this.allPetitions){
      this.selectedPetitions[pet] = false;
    }
    this.selectedPetitions[petition] = true;
    this.selectedPetitions[petition] ? this.nbPetitions++ : this.nbPetitions--;
    this.changes.emit(true);
  }
  // testVals(){
  //   console.log(this.beginDate)
  //   console.log(this.endDate)
  //   this.selectedPetitions["beginDate"] = this.beginDate;
  //   this.selectedPetitions["endDate"] = this.endDate;
    
  //   this.changes.emit(true);
  // }

  //changes = new Subject<any>();
  isActive(): boolean {
    //console.log("isActive: "+ this.nbPetitions)
    return this.nbPetitions > 0;
  }
  accepts(previousFilingRecordEntity: PreviousFilingRecordEntity): boolean {
    console.log("Begin: " + JSON.stringify(this.start)); 
    console.log("End: " + JSON.stringify(this.end));
    console.log(previousFilingRecordEntity.ConfidenceFactor)
    var newConfidenceCode = new Number(previousFilingRecordEntity.ConfidenceFactor)
    console.log("New Confidence Code " + newConfidenceCode)
    console.log("Confidence Start: " + (newConfidenceCode > this.start))
    console.log("Confidence End: " + (newConfidenceCode < this.end))
    //return (newDateAdded > this.beginDate) && (newDateAdded < this.endDate)
    return ((newConfidenceCode >= this.start)  && (newConfidenceCode <= this.end)) || this.nbPetitions == 0
  }
  
}
