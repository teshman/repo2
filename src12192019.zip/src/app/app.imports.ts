import { BrowserModule, Title } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule }    from '@angular/common/http';
import { AgmCoreModule } from '@agm/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ClarityModule, ClrFormsNextModule } from '@clr/angular';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { TopMenuComponent } from './top-menu/top-menu.component';
import { TopAlertsComponent } from './top-alerts/top-alerts.component';
import { SideNavigationComponent } from './side-navigation/side-navigation.component';
import { VsrComponent } from './vsr/vsr.component';
import { ScoreCardComponent } from './score-card/score-card.component';
import { RedReportsComponent } from './red-reports/red-reports.component';
import { GoogleMapsComponent } from './google-maps/google-maps.component';
import { DolEtaSearchComponent } from './dol-eta-search/dol-eta-search.component';
import { HttpModule } from '@angular/http';
import { ManualSearchModalComponent } from './manual-resubmit/manual-search-modal.component';
import { vsrCompareFormComponent } from './vsr/vsr-compare-form/vsr-compare-form.component';
import { DateFormatPipe } from './shared/dateFormat-pipe';
import { PreviousFilingsComponent } from './previous-filings/previous-filings.component';
import { VsrHistoryComponent } from './vsr/vsr-history/vsr-history.component';
import { vsrPrimaryFormComponent } from './vsr/vsr-primary-form/vsr-primary-form.component';
import { FouoComponent } from './fouo/fouo.component';
import { UserProfilesComponent } from './user-profile/user-profile.component';

import { SmartSearchBoxComponent } from './smart-search-box/smart-search-box.component';
import { HelpfulLinksComponent } from './helpful-links/helpful-links.component';
import { PreviousFilingsImqComponent } from './previous-filings-imq/previous-filings-imq.component';
import { WaitSpinnerComponent } from './wait-spinner/wait-spinner.component';
import { AddressInputFormComponent } from './address-input-form/address-input-form.component';
import { GeocodeService } from './geocode.service';
import { UserInRoleService } from './user-profile/user-in-role.service';
import { DolEtaFormV1Component } from './dol-eta-form-v1/dol-eta-form-v1.component'
import { NumberTransformRoman } from './dol-eta-form-v1/dol-eta-form-v1.pipe'
import { ScrollToModule } from '@nicky-lenaers/ngx-scroll-to';
import { DolEtaFormV2Component } from './dol-eta-form-v2/dol-eta-form-v2.component';
import { UserIdleModule } from 'angular-user-idle';
import { AppSettings} from './shared/app-settings';
import { HostListener } from '@angular/core';
import { PetitionTypeFilter } from './previous-filings-imq/petition-type-filter/petition-type-filter.component';
import { dateFilter } from './previous-filings-imq/date-filter/date-filter.component'
import { PetitionTypeGridFilter } from './previous-filings-imq/petition-type-gridfilter/petition-type-gridfilter.component'
import {confidenceCodeFilter } from './previous-filings-imq/confidence-code-filter/confidence-code-filter.component';
import { FocusDirective } from './shared/directives/focus.directive';
import { InputFocusDirective } from './shared/input-focus.directive';
import { StatusFilter } from './previous-filings-imq/status-filter/status-filter.component';
import { ChangeGridRoleToTableDirective } from './shared/directives/change-grid-role-to-table.directive';
import { ComponentAlertsComponent } from './component-alerts/component-alerts.component';
import { WarningAlertComponent } from './shared/warning-alert/warning-alert.component'
import { A11yModule} from '@angular/cdk/a11y';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { PortalModule } from '@angular/cdk/portal';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { CdkStepperModule } from '@angular/cdk/stepper';
import { CdkTableModule } from '@angular/cdk/table';
import { CdkTreeModule } from '@angular/cdk/tree';
import { SortableColumnDirective } from './vsr/vsr-history/sortable-colum.directive';
import { SortableColumnComponent } from './vsr/vsr-history/sortable-column.component';
import { SortService } from './vsr/vsr-history/sort.service';
import { FilterByColumnPipe } from './vsr/vsr-history/filter-By-Column-pipe';
import { NgxPaginationModule} from 'ngx-pagination';
import { PrevFillingsColumnPipe } from './shared/pipes/prev-filing-filter-pipe';
import { PrevFillingsHubColumnPipe } from './shared/pipes/prev-filing-hub-filter-pipe';
import { ExcelService } from './excel.service';
import { SetLabelCalendarIconDirective } from './shared/directives/set-label-calendar-icon.directive';
import { DolManualSearchFormComponent } from './dol-manual-search-form/dol-manual-search-form.component';
import { RedReportStringFilter } from './red-reports/string-filter/string-filter.component';
import { FormTypeFilter } from './red-reports/form-type-filter/form-type-filter.component';
import { IdentifierFilter } from './red-reports/identifier-filter/identifier-filter.component';
import { RedReportDateFilter } from './red-reports/red-report-date-filter/red-report-date-filter.component'
import { DataInquiryComponent } from './data-inquiry/data-inquiry.component';
import { MatNativeDateModule, MatFormFieldModule, MatCardModule, MatProgressSpinnerModule, MatMenuModule, MatIconModule, MatToolbarModule, MatButtonModule, MatInputModule, MatSelectModule, MatSortModule, MatTableModule, MatPaginatorModule, MatDatepickerModule, MatExpansionModule } from '@angular/material';
export const imports = [
    BrowserModule,
    HttpModule,
    ReactiveFormsModule,
    FormsModule,
    AppRoutingModule,
    ClarityModule,
    ClrFormsNextModule,
    BrowserAnimationsModule,
    HttpClientModule,
    NgxPaginationModule,
    ScrollToModule.forRoot(),
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    HttpClientModule,
    MatNativeDateModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    AppRoutingModule,
    MatCardModule,
    MatProgressSpinnerModule,
    MatMenuModule,
    MatIconModule,
    MatToolbarModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatSortModule,
    MatTableModule,
    MatPaginatorModule,
    MatDatepickerModule,
    MatExpansionModule,
    //UserIdleModule.forRoot({idle: 60, timeout: 30, ping: 5}),    
    //UserIdleModule.forRoot({ idle: AppSettings.USER_IDLE_TIME, timeout: AppSettings.USER_TIMEOUT, ping: AppSettings.USER_PING_INTERVAL })

]