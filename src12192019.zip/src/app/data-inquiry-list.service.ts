import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/toPromise';
import { Vsr } from './shared/vsr';
import { VSRResubmitRequest, VsrResubmitResponse, VsrResubmit, PredefOrgLookupRequest } from './shared/vsr-resubmit';
import { HttpClient } from '@angular/common/http';
import { tap } from 'rxjs/operators';
import { OrganizationLookupResponseProxy, OcrResponse } from './predefined-info/OrganizationLookupResponse';
import { AppSettings } from './shared/app-settings';
import { PredefinedInformationWorkflowRequest, WorkflowResponse } from './shared/predefined-Info-request';
import { SpecialCharactersPipe } from './shared/pipes/special-characters.pipe'
import { DataInquiryRequest } from './data-inquiry/data-inquiry';
import { DataInquiryList } from './data-inquiry/data-inquiry-list';
@Injectable({
    providedIn: 'root'
})
export class DataInquiryListService {
    url = '/vibe-plus/rest/data-inquiry/get-list';
    vsr: Vsr;
    constructor(private http: Http, private httpc: HttpClient, private spChars: SpecialCharactersPipe) { }

    getDataInquiryListInJson<T>(diRequest: DataInquiryRequest): Observable<T> {
        // console.log("the request is: " + JSON.stringify(resubmitRequest));
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers });
        return this.http.post(this.url, diRequest, options)
            .map(this.extractData)
            .catch(this.handleErrorObservable);
    }




    private log(message: string) {
        console.log(message)
    }
    private extractData(res: Response) {
        //console.log("the data is: " + JSON.stringify(res.json()));       
        let body = res.json();
        return body || {};
    }
    private handleErrorObservable(error: Response | any) {
        console.error(error.message || error);
        return Observable.throw(error.message || error);
    }


} 
