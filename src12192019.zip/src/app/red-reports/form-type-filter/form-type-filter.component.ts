import { Component,EventEmitter, OnInit, Output, Input } from '@angular/core';
import { ClrDatagridFilterInterface } from '@clr/angular';
import { RedReportRecordEntity } from '../../shared/RedReport_interfaces'
import { Subject} from 'rxjs'


@Component({
  selector: 'app-form-type-filter',
  templateUrl:'./form-type-filter.component.html',
  styleUrls: ['./form-type-filter.component.css']
})

export class FormTypeFilter implements ClrDatagridFilterInterface<RedReportRecordEntity> {
  allPetitions = ["ALL","I129", "I140", "I360", "I485J"];
  nbPetitions=0;
  selectedPetitions: { [petition: string]: boolean } = {};
  statusoptions = true;
  changes: EventEmitter<any> = new EventEmitter<any>(false);
  @Output() clear = new EventEmitter<string>();
  @Output() results = new EventEmitter<number>();
  @Input() totalRecords: number;
  filteredResults: number = 0;
  filterCounter: number = 0;
  constructor(){
    for (var pet of this.allPetitions){
      console.log(pet);
      if (pet == "ALL"){
        this.selectedPetitions[pet] = true;
      }else
       this.selectedPetitions[pet] = false;
    }
    console.log(this.selectedPetitions)
  }

  initializeFilter(){
    for (var pet of this.allPetitions){
      console.log(pet);
      if (pet == "ALL"){
        this.selectedPetitions[pet] = true;
      }else
       this.selectedPetitions[pet] = false;
    }
    console.log(this.selectedPetitions)
  }
  listSelected(): string[] {
    const list: string[] = [];
    for (const petition in this.selectedPetitions) {
      if (this.selectedPetitions[petition]) {
        list.push(petition);
      }
    }
    return list;
  }
  clearFilter(){
    
      for (var pet of this.allPetitions){
        if(pet !== 'ALL')
            this.selectedPetitions[pet] = false;
         }
         this.selectedPetitions["ALL"] = true;
         this.changes.emit(true)
  }
  togglePetition(petition: string) {
    console.log("selecte petition="+petition);
    

    //Logic deciding which petition to show
    if(petition == 'ALL'){
      for (var pet of this.allPetitions){
        if(pet !== 'ALL')
            this.selectedPetitions[pet] = false;
         }
         this.selectedPetitions["ALL"] = !this.selectedPetitions["ALL"];
         console.log("Selected Petitions Before: " +  JSON.stringify(this.selectedPetitions))

      if(this.totalRecords>0){
      this.results.emit(1)
      }else{this.results.emit(0)}
      this.changes.emit(true)
      this.clear.emit("")
      return;
        }
    if(petition !== "ALL"){
      this.selectedPetitions["ALL"] = false;
    }
    this.selectedPetitions[petition] = !this.selectedPetitions[petition];
    this.selectedPetitions[petition] ? this.nbPetitions++ : this.nbPetitions--;
    console.log("Selected Petitions Before: " +  JSON.stringify(this.selectedPetitions))
    this.changes.emit(true);
    this.clear.emit("")
  }


  //changes = new Subject<any>();
  isActive(): boolean {
    //console.log("isActive: "+ this.nbPetitions)
    return this.nbPetitions > 0;
  }
  accepts(redReport: RedReportRecordEntity) {
    this.filterCounter++;
    console.log("Total: " + this.totalRecords)
    console.log("Counter: " + this.filterCounter)
    console.log("Selected Positions after: " + JSON.stringify(this.selectedPetitions)); 
    console.log(redReport.PetitionType)
    if(this.selectedPetitions[redReport.PetitionType] || this.selectedPetitions["ALL"] == true){
      this.filteredResults++;
    }
    console.log("Results: " + this.filteredResults)
    if(this.filterCounter == this.totalRecords){
      console.log("EMIT HERE")
      this.results.emit(this.filteredResults)
      console.log(this.filteredResults)
      this.filterCounter = 0
      this.filteredResults = 0
    }
    return this.selectedPetitions[redReport.PetitionType] || this.selectedPetitions["ALL"] == true ; 
  }
  
}
