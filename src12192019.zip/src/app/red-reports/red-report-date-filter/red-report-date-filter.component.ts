import { Component,EventEmitter, OnInit, AfterViewInit, ViewChild,NgZone, OnChanges, ElementRef, Input, Output, Renderer2, SimpleChanges } from '@angular/core';
import { ClrDatagridFilterInterface } from '@clr/angular';
import { formatDate, DatePipe} from '@angular/common'
import { Subject} from 'rxjs'
import { DeprecatedI18NPipesModule } from '@angular/common';
import { RedReportRecordEntity } from 'src/app/shared/RedReport_interfaces';
import { MatInput } from '@angular/material';
import { FormGroup, FormControl, Validators } from '@angular/forms';


@Component({
  selector: 'app-red-report-date-filter',
  templateUrl:'./red-report-date-filter.component.html',
  styleUrls: ['./red-report-date-filter.component.css']
})

export class RedReportDateFilter implements ClrDatagridFilterInterface<RedReportRecordEntity> , OnInit, OnChanges, AfterViewInit{
 
  allPetitions = ["ALL","I-129", "I-140", "I-130", "I-485J"];
  nbPetitions=0;
  beginDate: any;
  endDate: any;
  selectedPetitions: { [petition: string]: boolean } = {};
  active = false;
  showAlert = false;
  alertMessage = "Invalid Date Range.  End Date cannot be before Start Date"
  changes: EventEmitter<any> = new EventEmitter<any>(false);
  endDate2= "";
  beginDate2="";
  @Output() clear = new EventEmitter<string>();
  @Output() results = new EventEmitter<number>();
  @Input() totalRecords: number;
  @Input() initialStart: Date;
  @Input() initialEnd: Date;
  filteredResults: number = 0;
  filterCounter: number = 0;
  datePipe: DatePipe;
  isValidDate: boolean;
  error: { isError: boolean; errorMessage: string; };
  @ViewChild('startInput', {
    read: MatInput,
    static: true
}) startInput: MatInput;
  
  @ViewChild('endInput', {
    read: MatInput,
    static: true
}) endInput: MatInput;
  // listSelected(): string[] {
  //   const list: string[] = [];
  //   for (const petition in this.selectedPetitions) {
  //     if (this.selectedPetitions[petition]) {
  //       list.push(petition);
  //     }
  //   }
  //   return list;
  // }

  constructor(private el: ElementRef, private zone: NgZone, private renderer: Renderer2) {
    this.beginDate = this.initialStart
    this.endDate = this.initialEnd

  }

  ngOnInit(): void {
    this.clearDateFilter()
  }
  ngOnChanges(changes: SimpleChanges){
    this.beginDate = this.initialStart
    this.endDate = this.initialEnd
    console.log("Start Date Passed Through: " + this.initialStart + "End Date Passed Through " + this.initialEnd)
  }
  testClick(): boolean{
    //console.log("clicked")
    return true;
  }
  clearPlaceholders(){
    // this.startInput.placeholder = "Start Date: "
    // this.endInput.placeholder = "End Date: "
  }
  ngAfterViewInit(): void {
 

  }
theForm = new FormGroup({
filterStartDate: new FormControl(),
filterEndDate: new FormControl()
});
sDateError: boolean = false;
eDateError: boolean= false;
checkValidity(datetype: string){
  if(datetype == 'start'){
    if(this.theForm.controls["filterStartDate"].status !== 'VALID'){
    this.sDateError = true;
    }
    return
  }
  if(datetype == 'end'){
    if(this.theForm.controls["filterEndDate"].status !== 'VALID'){
    this.eDateError = true;
    }
    return
  }

}

  clearDateFilter() {
    console.log("In clear data filter")
    this.active = false
    this.beginDate = this.initialStart
    this.endDate = this.initialEnd
    this.theForm.controls["filterStartDate"].updateValueAndValidity()
    this.theForm.controls["filterEndDate"].updateValueAndValidity()
    this.nbPetitions = 0;
    this.alertMessage="";
    this.showAlert=false;
    this.filterCounter = 0
    this.filteredResults = 0
    this.changes.emit(true)
    this.clear.emit("") 
    return
    
  }
  
  isMoreThan36Months(bDate: Date, eDate: Date): boolean{
  
    let milisecDiffBetweenTwoDates = eDate.getTime() - bDate.getTime();

    let start36Months = eDate; 
    start36Months.setMonth(eDate.getMonth()-36);
    
    if ((eDate.getTime() - start36Months.getTime()) > milisecDiffBetweenTwoDates) {
      return true ; 
    }else {
      return false;
    }

  }

  applyDatePetition(petition: string) {
    // this.active = !this.active
    this.alertMessage = ""
    this.showAlert = false;
   
    if((!this.endDate)|| (!this.beginDate)){
      this.alertMessage = "Please fill out both Dates."
      this.showAlert = true;
      return
    }
    let start = new Date(formatDate(this.initialStart,'MM/dd/yyyy','en-US'))
    let end = new Date(formatDate(this.initialEnd,'MM/dd/yyyy','en-US'))

    try{
    this.initialStart.setHours(0)
    this.initialStart.setMinutes(0)
    this.initialStart.setSeconds(0)
    this.initialStart.setMilliseconds(0)
    this.initialEnd.setHours(0)
    this.initialEnd.setMinutes(0)
    this.initialEnd.setSeconds(0)
    this.initialEnd.setMilliseconds(0)
    
    if(start.getTime() > end.getTime()){
      this.alertMessage = "Invalid Date Range.  End Date cannot be before Start Date"
      // this.beginDate = null
      // this.endDate = null
      this.showAlert = true;
      return
    }
    console.log("Start Time: "+ this.beginDate + "\nInitial Start" + this.initialStart)
    console.log("End Time: "+ this.endDate + "\nInitial End: " + this.initialStart)
    if(this.beginDate < this.initialStart || this.endDate < this.initialStart || this.endDate > this.initialEnd || this.beginDate > this.initialEnd){
      this.alertMessage = "Filter Dates Outside of Report Range"
      this.showAlert = true;
      return
    }
  }catch(error){
    this.alertMessage = "Invalid Dates."
    this.showAlert = true;
    return
  }

    //Logic deciding which petition to show
    if(petition == 'ALL'){
      var inputs = document.getElementsByTagName("input")
      for(var i = 0; i<inputs.length; i++){
        var input = inputs.item(i)
        input.value = ""
      }
      this.nbPetitions = 0;
      this.alertMessage="";
      this.showAlert=false;

      this.changes.emit(true)
      this.clear.emit("")
      return
    }
    for (var pet of this.allPetitions){
      this.selectedPetitions[pet] = false;
    }
    this.selectedPetitions[petition] = true;
    this.selectedPetitions[petition] ? this.nbPetitions++ : this.nbPetitions--;
    this.showAlert=false;
    this.changes.emit(true);
    this.clear.emit("");
  }

  togglePetition(petition: string) {
    this.active = !this.active
    console.log("selecte petition="+petition);
    console.log("Selected Petitions Before: " +  JSON.stringify(this.selectedPetitions))

    if(this.endDate == null || this.beginDate == null){
      this.alertMessage = "Please fill out both Dates."
      this.showAlert = true;
      
      return
    }
    if(this.endDate.getTime() < this.beginDate.getTime()){
      this.alertMessage = "Invalid Date Range.  End Date cannot be before Start Date"
      this.showAlert = true;
      return
    }
    //Logic deciding which petition to show
    if(petition == 'ALL'){
      var inputs = document.getElementsByTagName("input")
      for(var i = 0; i<inputs.length; i++){
        var input = inputs.item(i)
        input.value = ""
      }
      this.nbPetitions = 0;
      this.changes.emit(true)
      return
    }
    for (var pet of this.allPetitions){
      this.selectedPetitions[pet] = false;
    }
    this.selectedPetitions[petition] = true;
    this.selectedPetitions[petition] ? this.nbPetitions++ : this.nbPetitions--;
    this.changes.emit(true);
  }

  isActive(): boolean {

    return this.nbPetitions > 0;
  }
  accepts(redReport: RedReportRecordEntity): boolean {
    this.filterCounter++;
    console.log("Total: " + this.totalRecords)
    console.log("Counter: " + this.filterCounter)
    console.log("Date Added from Data: " + redReport.ReceiptDate)

    var newDateAdded = new Date(redReport.ReceiptDate + "GMT-4")
    var beginDate = new Date(this.beginDate + "GMT-4")
    var endDate = new Date(this.endDate + "GMT-4")
    console.log("Date Added " + newDateAdded)
    console.log("Begin Date: " + beginDate)
    console.log("End Date: " + endDate)
    var afterBegin = (newDateAdded >= beginDate)
    var beforeEnd = (newDateAdded <= endDate)
    console.log("Is new date after begin date? " + afterBegin)
    console.log("Is new date before end date? " + beforeEnd)
    // this.endDate = formatDate(this.endDate,'MM/dd/yyyy','en-US');
    // this.beginDate = formatDate(this.beginDate,'MM/dd/yyyy','en-US');
    if(afterBegin && beforeEnd){
      this.filteredResults++;
    }
    console.log("Results: " + this.filteredResults)
    if(this.filterCounter == this.totalRecords){
      console.log("EMIT HERE")
      this.results.emit(this.filteredResults)
      console.log(this.filteredResults)
      this.filterCounter = 0
      this.filteredResults = 0
    }
    //return (newDateAdded > this.beginDate) && (newDateAdded < this.endDate)
    return (afterBegin  && beforeEnd) || this.nbPetitions == 0
  }
  onDateInput(event: Event){
    console.log(event)
    let start: string;
    let end: string;
    if(this.endDate && this.beginDate){
    end = formatDate(this.endDate,'MM/dd/yyyy','en-US');
    start = formatDate(this.beginDate,'MM/dd/yyyy','en-US');
    console.log("In Date Input")
    console.log("Check if dates exist " + (((end) && (start))))
    if((start.length > 8 && end.length > 8)){
      console.log("Validating Dates" + start + " And " + end)
      this.validateDates(start,end)
      if(this.isValidDate){
        console.log("Valid Dates")
        this.applyDatePetition('I-129')
      }  
    }
  }
  }
  validateDates(sDate: string, eDate: string){
    console.log("Start Date: " + sDate)
    console.log("End Date: " + eDate)
    var date_regex = /^\d{2}\/\d{2}\/\d{4}$/ ;
    console.log("Value of Validity Check Start: " + date_regex.test(sDate))
    console.log("Value of Validity Check End: " + date_regex.test(eDate))
    this.isValidDate = false;
    
    if(date_regex.test(sDate) && date_regex.test(eDate)){
      this.isValidDate = true
    
  }else this.isValidDate = false;

  } 
}
