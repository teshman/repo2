import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {imports } from '../app.imports'
import {declarations} from '../app.declarations'
import { providers } from '../app.providers';
import { RedReportsComponent } from './red-reports.component';

describe('RedReportsComponent', () => {
  let component: RedReportsComponent;
  let fixture: ComponentFixture<RedReportsComponent>;

  beforeEach(() => {

    TestBed.configureTestingModule({
      imports: imports,
      declarations: declarations,
      providers: providers,//{provide: APP_BASE_HREF, useValue: '/dol-eta-search'}
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RedReportsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  
  fit('should have time period', () => {
    const compiled = fixture.debugElement.nativeElement
    console.log(compiled.querySelector('select'))
    expect(compiled.querySelector('select').textContent).toContain("15 Days");
  });
  
  fit('should have build report button', ()=>{
    const compiled = fixture.debugElement.nativeElement
    console.log(compiled.querySelectorAll('button').textContent)
    let content: string;
   let buttons: NodeListOf<HTMLButtonElement> = compiled.querySelectorAll('button')
   buttons.forEach(element => {
      if (element.textContent == "Build Report"){
        content = element.textContent
        //element.click()
      }
    });
    expect(content).toEqual("Build Report")
    //expect(fixture.componentInstance.showTable).toEqual(true)
  });

  fit('should click build report', async(() => {
    spyOn(component, 'buildReport');
  
    const compiled = fixture.debugElement.nativeElement;
    let buttons: NodeListOf<HTMLButtonElement> = compiled.querySelectorAll('button')
    let finalbutton: HTMLButtonElement;
    buttons.forEach(button => {
      if (button.textContent == "Build Report"){
        finalbutton = button
        //element.click()
      }
    }
    );
    console.log("Build Report Button" + finalbutton)
    finalbutton.click();
  
    fixture.whenStable().then(() => {
      expect(component.buildReport).toHaveBeenCalled();
    });
  }));
  
});
