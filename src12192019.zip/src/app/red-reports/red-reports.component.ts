import { Component, OnInit, ViewChild, ViewChildren , QueryList, Renderer2, ChangeDetectorRef} from '@angular/core';
import { Title } from '@angular/platform-browser';
import { AppSettings } from '../shared/app-settings';
import { RedReportsService } from '../red-reports.service';
import { RedReportGetDateResponse, RedReportMarkSendResponse, RedReportRecordEntity, RedReportExportSchema, UpdateRedListPetitionSet,UpdateRedListPetition } from '../shared/RedReport_interfaces'
import {ExcelService } from '../excel.service'
import { ClrDatagrid, ClrDatagridCell, ClrDatagridRow, ClrDatagridPagination, ClrDatagridStateInterface, ClrDatagridColumn, ClrCheckboxModule, ClrDatagridSortOrder } from "@clr/angular";
import { Subscription, Subject } from 'rxjs';
import { formatDate} from '@angular/common'
import { PaginatePipe } from 'ngx-pagination';
import {RedReportStringFilter} from './string-filter/string-filter.component'
import { IdentifierFilter} from './identifier-filter/identifier-filter.component';
import {RedReportDateFilter} from './red-report-date-filter/red-report-date-filter.component';
import {FormTypeFilter} from './form-type-filter/form-type-filter.component';
import { FormGroup, FormBuilder } from '@angular/forms';
import { RedReportGetDateResponseProxy } from '../shared/RedReport_proxies';
import { getMatIconFailedToSanitizeLiteralError, MatInput } from '@angular/material';

@Component({
  selector: 'app-red-reports',
  templateUrl: './red-reports.component.html',
  styleUrls: ['./red-reports.component.css']
})
export class RedReportsComponent implements OnInit {
  redReportDateResponse: RedReportGetDateResponse = <RedReportGetDateResponse>{};
  redReportRecords: RedReportRecordEntity[] = [];
  redReportMarkSendResponse: RedReportMarkSendResponse;
  petitionSet: UpdateRedListPetitionSet = <UpdateRedListPetitionSet>{};
  allpetitions: UpdateRedListPetition[] = [];
  petition: UpdateRedListPetition = <UpdateRedListPetition>{}
  showTable: boolean = false;
  exportOptions: string = "EXCEL";
  exportData: RedReportRecordEntity[];
  pageNum = Number(AppSettings.PAGINATION_COUNT);
  loading: boolean = false;
  modalloading: boolean = false;
  finalExport: RedReportExportSchema[]=[];
  descSort = ClrDatagridSortOrder.DESC
  export = []
  styleExp = "all"
  filterSubject: Subject<ClrDatagridStateInterface> = new Subject<ClrDatagridStateInterface>();
  appsAlert = ""
  confirm = true;
  selectAll = false;
  showConfirm = false;
  prevVal: boolean
  recIndex: number
  receiptNum: string
  expRow: RedReportExportSchema = <RedReportExportSchema>{
    ReceivedIn: "",
    Entity: "",
    Identifier: "",
     Score: "",
    ReceiptNumber: "",
     FormType: "",
    VisaType: "",
    DateAdded: ""
};
status: string = "false"
endDate: Date;
beginDate: Date;
office: string = "ALL";
timeperiod: number = 15;//Number of days back
timeperiodSelect: FormGroup;
searchBytimeperiod: boolean = true;
filterStart: Date;
filterEnd: Date;
filteredRows: number = 0;
  @ViewChild('datagrid', { static: false }) datagrid: ClrDatagrid;
  @ViewChildren(RedReportStringFilter) stringFilters: QueryList<RedReportStringFilter>;
  @ViewChildren(ClrDatagridColumn) columns: QueryList<ClrDatagridColumn>;
  @ViewChildren(ClrDatagridRow) rows: QueryList<ClrDatagridRow>;
  @ViewChild(RedReportStringFilter, { static: false }) processStatusFilter:RedReportStringFilter;
  @ViewChild(IdentifierFilter, { static: false }) identifierFilter: IdentifierFilter;
  @ViewChild(RedReportDateFilter, { static: false }) dateFilter: RedReportDateFilter;
  @ViewChild(FormTypeFilter, { static: false }) formTypeFilter: FormTypeFilter;
  datagridHtml: HTMLElement;
  numCheckboxes: number = 0;
  @ViewChild('pagination', { static: false }) pager: ClrDatagridPagination;
  fbox: string = "none";
  private redReportSvc: RedReportsService;
  private rawMarkSendResponse = `{
    "RedReportMarkSendToCFDOResponse": {
        "SourceSystemID": "VIBEServices",
        "SourceTransactionID": "d0ef263f-28dd-4387-9a6e-32d908ed99f0",
        "ServiceRequestTimestamp": "2019-05-16T09:13:54.132-05:00",
        "ServiceResponseTimestamp": "2019-05-16T09:13:54.441-05:00",
        "AuditCorrelationID": "d0ef263f-28dd-4387-9a6e-32d908ed99f0",
        "UpdateMessage": "SUCCESS"
    }
}`
  private rawDateResponse =  `{
    "RedReportGetAdvancedResponse":{
      "SourceSystemID":"VIBEService",
      "SourceTransactionID":"51de840d-b435-4524-b19a-9231ad1f5d08",
      "ServiceRequestTimestamp":"2019-06-19T14:56:13.462-05:00",
      "ServiceResponseTimestamp":"2019-06-19T14:56:21.837-05:00",
      "AuditCorrelationID":"51de840d-b435-4524-b19a-9231ad1f5d08",
      "RedReportResultSet":{
        "totalRecordCount":595,
        "lastRecordIndex":1000000,
        "recordCountInThisResultSet":595,
        "RedReportRecord":[
          {
            "OrganizationName":"CEDENT CONSULTING INC",
            "Score":"RED",
            "ReceiptNumber":"WAC1922550135",
            "ReceiptDate":"2019-06-19",
            "DeliverToCFDO":true,
            "PetitionID":0,
            "PetitionType":"I129",
            "Fein":"392076011",
            "DunsNumber":"958420882",
            "FDNSDSNumber":"RFA 1-318478351",
            "AddressID":"329458083",
            "VisaType":"1B1",
            "ConfidenceFactor":"10",
            "RedAttorneyID":"0",
            "AttorneyFraud":"N",
            "AttorneyDoj":"N",
            "RedPetitionAddressID":"0",
            "Entity":"IBM CORPORATION",
            "Identifier":"Company"
          },
          {
            "OrganizationName":"E BASE TECHNOLOGIES INC",
            "Score":"RED",
            "ReceiptNumber":"WAC1922550107",
            "ReceiptDate":"2019-06-19",
            "DeliverToCFDO":false,
            "PetitionID":0,
            "PetitionType":"I129",
            "Fein":"770548159",
            "DunsNumber":"175982433",
            "FDNSDSNumber":"CASE 1-298106440",
            "AddressID":"329458083",
            "VisaType":"1B1",
            "ConfidenceFactor":"10",
            "RedAttorneyID":"0",
            "AttorneyFraud":"N",
            "AttorneyDoj":"N",
            "RedPetitionAddressID":"0",
            "Entity":"IBM CORPORATION",
            "Identifier":"Company"
          },
          {
            "OrganizationName":"V SOFT CONSULTING GROUP INC",
            "Score":"RED",
            "ReceiptNumber":"WAC1922550183",
            "ReceiptDate":"2019-06-19",
            "DeliverToCFDO":false,
            "PetitionID":0,
            "PetitionType":"I129",
            "Fein":"760532643",
            "DunsNumber":"027170732",
            "FDNSDSNumber":"LEAD 1-196029541",
            "AddressID":"329458083",
            "VisaType":"1B1",
            "ConfidenceFactor":"10",
            "RedAttorneyID":"0",
            "AttorneyFraud":"N",
            "AttorneyDoj":"N",
            "RedPetitionAddressID":"0",
            "Entity":"IBM CORPORATION",
            "Identifier":"Company"
          },
          {
            "OrganizationName":"TRIBOLATECH INC",
            "Score":"RED",
            "ReceiptNumber":"WAC1922550132",
            "ReceiptDate":"2019-06-19",
            "DeliverToCFDO":false,
            "PetitionID":0,
            "PetitionType":"I129",
            "Fein":"273438525",
            "DunsNumber":"065692637",
            "FDNSDSNumber":"RFA 1-317152268",
            "AddressID":"329458083",
            "VisaType":"1B1",
            "ConfidenceFactor":"10",
            "RedAttorneyID":"0",
            "AttorneyFraud":"N",
            "AttorneyDoj":"N",
            "RedPetitionAddressID":"0",
            "Entity":"IBM CORPORATION",
            "Identifier":"Company"
          }, {
            "OrganizationName":"IBM CORPORATION",
            "Score":"RED",
            "ReceiptNumber":"EAC1419951216",
            "ReceiptDate":"2015-09-20",
            "DeliverToCFDO":false,
            "PetitionID":146819185,
            "PetitionType":"I129",
            "Fein":null,
            "DunsNumber":"001368083",
            "FDNSDSNumber":"FDNS456LUUTEST",
            "AddressID":"329458083",
            "VisaType":"1B1",
            "ConfidenceFactor":"10",
            "RedAttorneyID":"0",
            "AttorneyFraud":"N",
            "AttorneyDoj":"N",
            "RedPetitionAddressID":"0",
            "Entity":"IBM CORPORATION",
            "Identifier":"Company"
          }
            ]
        }
    }
}`
  alertMessage: string;
  showAlert: boolean;
  reciptNumber: string = "";
  showvsrmodal: boolean = false;
  constructor(private ref: ChangeDetectorRef,
    private titleService: Title,
    private redReportSearchSvc: RedReportsService,private fb: FormBuilder, private excelService:ExcelService, renderer: Renderer2) {
      this.redReportSvc = redReportSearchSvc;
      
  }
 
 
 
  public setTitle( newTitle: string) {
    this.titleService.setTitle( newTitle );
  }

  ngOnInit() {
    this.timeperiodSelect = this.fb.group({timeperiod: [""]});
    this.exportOptions = 'EXCEL'
    this.titleService.setTitle( AppSettings.RED_REPORT_TITLE);
    
      //this.parseRedReportDateResponse(this.rawDateResponse)
    //  this.parseRedReportMarkSendResponse(this.rawMarkSendResponse)


  }


  // ngAfterViewChecked(){
    
  //   }
  onDateInput(evt){
    if(this.beginDate || this.endDate){
      this.timeperiodSelect.controls["timeperiod"].disable();
      this.searchBytimeperiod = false;
    }
  }

  parseRedReportDateResponse(data){
    
    this.redReportDateResponse = data;
    //this.redReportDateResponse = <RedReportGetDateResponse>JSON.parse(data);
    if(this.redReportDateResponse.RedReportGetAdvancedResponse.RedReportResultSet.RedReportRecord){
    this.redReportRecords = this.redReportDateResponse.RedReportGetAdvancedResponse.RedReportResultSet.RedReportRecord
    }
    console.log(this.redReportDateResponse.RedReportGetAdvancedResponse.RedReportResultSet.RedReportRecord)
    
  }

  parseRedReportMarkSendResponse(data){
    this.redReportMarkSendResponse = data;
    //console.log(this.redReportMarkSendResponse.RedReportMarkSendToCFDOResponse.UpdateMessage)
  }
  //Method for Build Report button in Search
  buildReport(){
    //"2010-11-16-06:00", "2019-05-15-06:00"
    this.showExportAlert = false;
    this.fbox = "block" //shows Filter Box
    this.showTable = false
    this.loading = true;
    this.appsAlert = "";
    this.showAlert = false
    this.redReportRecords = [];
    console.log(this.beginDate)
    console.log(this.endDate)
    let start: string;
    let end: string;
    let off: string;
    if (this.searchBytimeperiod){
      let today = new Date(Date.now())
      end = formatDate(today,'yyyy-MM-dd','en-US').concat("-04:00");
      let startDate = new Date(); 
      startDate.setDate(today.getDate()-this.timeperiod); 
      start = formatDate(startDate,'yyyy-MM-dd','en-US').concat("-04:00");
      this.filterStart = startDate;
      this.filterEnd = today;
    }else{
      if((!this.endDate)|| (!this.beginDate)){
        this.alertMessage = "Please fill out both Dates."
        this.showAlert = true;
        this.loading = false;
        return
      }
      try{
        if(this.endDate.getTime() < this.beginDate.getTime()){
          this.alertMessage = "Invalid Date Range.  End Date cannot be before Start Date"
          this.showAlert = true;
          this.loading = false;
          return
        }
      }catch(error){
        this.alertMessage = "Invalid Dates."
        this.showAlert = true;
        this.loading = false;
        return
      }

      start = formatDate(this.beginDate,"yyyy-MM-dd", 'en-US').concat("-06:00")
      end = formatDate(this.endDate,"yyyy-MM-dd", 'en-US').concat("-06:00")
      this.filterStart = this.beginDate
      this.filterEnd = this.endDate
    }

    console.log("Start Date: " + start)
    console.log("End Date: " + end)
    if(this.office == "ALL"){
      off = null;
    }else off = this.office
    // Need for Testing when service is down
    //  this.parseRedReportDateResponse(this.rawDateResponse)
    //  this.showTable = true;
    // this.filterProcessStatus(true)
    //  this.loading = false;

    this.redReportSvc.getRedReportByDateRange(start,end, off).subscribe(data => {
      console.log(data)
      if ((data) && (!JSON.stringify(data).includes("Error") || !JSON.stringify(data).includes("ESB2Exception"))){
        console.log("data from service")
        this.parseRedReportDateResponse(data)
        this.showTable = true;
        this.filterProcessStatus(true)
        this.loading = false;
        this.refresh(0)

      }else{ 
        console.log("data from service")
        this.loading=false
        this.appsAlert = AppSettings.HTTP_STATUS_503
        this.showTable= false;
        this.loading=false

 }

      
    })
   }
   @ViewChild('fromInput', {
    read: MatInput,
    static: false
}) fromInput: MatInput;
  
  @ViewChild('toInput', {
    read: MatInput,
    static: false
}) toInput: MatInput;
  resetSearchCriteria(){
    
    this.timeperiodSelect.controls["timeperiod"].enable();
      this.searchBytimeperiod = true;
      this.office = "ALL";
      this.beginDate = null
      this.endDate = null
      this.fromInput.value = '';
      this.toInput.value = '';
      this.timeperiod = 15;
      this.redReportRecords = [];
      this.appsAlert = "";
      this.showAlert = false;
      this.showExportAlert = false;
  }
  resetFilters(){
    console.log(this.stringFilters)
    this.stringFilters.forEach(filter => filter.clear())
    this.status = "false"
    this.processStatusFilter.resetFilter()
    this.dateFilter.clearDateFilter()   
    this.identifierFilter.clearFilter()
    this.formTypeFilter.clearFilter()
    this.reciptNumber=""
    this.appsAlert = "";
    this.showExportAlert = false;
    // this.columns.forEach(column => column.filterValue = "");
    
  }
  refresh(state) {
    console.log('refresh fired!');
    this.calculateFilteredRows()
    
    this.addTitlesToCheckboxes();
  }

  checkConfirm(prevVal: boolean, receipt: string, index: number, all: boolean = false){
  console.log(this.confirm)
  this.showAlert = false;
  this.numCheckboxes = (this.getCheckboxes().length - 1)
  if(all){
    if(this.confirm){
    this.showConfirm = true;
    }else this.confirmAll();
    return;
  }
  if(this.confirm){
    this.showConfirm = true
    this.prevVal = prevVal
    this.receiptNum = receipt
    this.recIndex = index
  }else this.updateReport(prevVal, receipt)
  }

  confirmButton(){
    this.updateReport(this.prevVal, this.receiptNum)
    this.showConfirm = false;

  }
  confirmAll(){
    this.allpetitions = []
    
    let checkboxes: NodeListOf<HTMLInputElement>  = this.getCheckboxes()
    checkboxes.forEach( cbox => {
      this.petition = <UpdateRedListPetition>{}
      cbox.checked = true
      console.log(cbox.parentElement.id)
      if(cbox.parentElement.id !== "selectAll"){
        //id = receiptNum
        //petid = PetitionID
        //name =  Deliver
        console.log()
        this.petition.petitionID = cbox.parentElement.getAttribute("petid")
        this.petition.deliverToCFDO = true
        this.petition.receiptNumber = cbox.parentElement.id
        if(this.petition.receiptNumber !== ""){
        this.allpetitions.push(this.petition)
        }
      }
    })
    //When Service Down
    // this.redReportRecords.forEach(rec => {

    //   this.allpetitions.forEach(pet =>{
    //     if(rec.ReceiptNumber == pet.receiptNumber){
    //       rec.DeliverToCFDO = true;
    //     }
    //   })
    //   })
    //   this.filterProcessStatus(true)
    //   this.selectAll = false;

    //Send the Set to service
    this.petitionSet.updateRedListPetition = this.allpetitions
    this.redReportSvc.updateRedlistPetitionSet(this.petitionSet).subscribe(data => {
      console.log(data)
      if ((data) && (!JSON.stringify(data).includes("Error") || !JSON.stringify(data).includes("ESB2Exception"))){
          this.parseRedReportMarkSendResponse(data)
          //Update Values on Existing Dataset
          
        this.redReportRecords.forEach(rec => {

          this.allpetitions.forEach(pet =>{
            if(rec.ReceiptNumber == pet.receiptNumber){
              rec.DeliverToCFDO = true;
            }
            })
          })
          this.filterProcessStatus(true)
          this.datagrid.refresh.next()
    }else{
      this.appsAlert = AppSettings.MARK_SENT_UPDATE_ERROR
      //this.showAlert = true
      this.closeConfirmAll()
    }
      this.selectAll = false;
     

})

this.showConfirm = false;
  }

closeConfirmAll(){
  let checkboxes = this.getCheckboxes()
  this.redReportRecords.forEach(rec =>{
    checkboxes.forEach(cbox => {
      if(cbox.parentElement.id == "selectAll"){
        cbox.checked = false
        this.selectAll = false

      }
      if(cbox.parentElement.id == rec.ReceiptNumber){
        cbox.checked = rec.DeliverToCFDO
      }
    })
  })
  this.selectAll = false;
  this.showConfirm = false;
}
  getCheckboxes(id: string = ""){
    let datagrid = document.getElementById("redReport")
    if(datagrid){
    let checkboxes: NodeListOf<HTMLInputElement> = datagrid.querySelectorAll('input[type="checkbox"]')
    console.log(checkboxes);
    return checkboxes;
    }
  }
  //Method for OnClick Received In
  updateReport(prevVal: boolean, receipt: string){
    let redRecTemp: RedReportRecordEntity[];
    let rec: RedReportRecordEntity
    console.log("Receipt: " + receipt + " Previous Value: " + prevVal)
    this.allpetitions = [];
    this.redReportRecords.forEach(rec  => {
      if (rec.ReceiptNumber.trim() == receipt){
        rec.DeliverToCFDO = !prevVal
        this.petition.receiptNumber = rec.ReceiptNumber.trim()
        this.petition.deliverToCFDO = !prevVal
        this.petition.petitionID = rec.PetitionID.toString();

        this.allpetitions.push(this.petition)

      }
    })
    console.log(this.redReportRecords)
    this.datagrid.dataChanged()
    this.datagrid.refresh.next()
    // console.log(this.redReportDateResponse.RedReportGetAdvancedResponse.RedReportResultSet.RedReportRecord)
    // this.redReportRecords = this.redReportDateResponse.RedReportGetAdvancedResponse.RedReportResultSet.RedReportRecord
    
    // this.datagrid.dataChanged()
    // this.datagrid.refresh.next()
    // this.status = "ALL"
    // this.filterProcessStatus(event)
    // this.status = "false"
    // this.filterProcessStatus(event)
    this.petitionSet.updateRedListPetition = this.allpetitions
    console.log(this.allpetitions)
    this.redReportSvc.updateRedlistPetitionSet(this.petitionSet).subscribe(data => {
      console.log(data)
      this.parseRedReportMarkSendResponse(data)
      //this.datagrid.refresh.next()
})

  }

  showExportAlert: boolean = false;
  async saveButton(){
    this.showExportAlert = false;
    if(this.getCheckboxes().length <= 1){
      this.showExportAlert = true;
      return
    }
    this.modalloading = true;
    this.styleExp = "none"
    this.pageNum = this.pager.totalItems
    this.datagrid.refresh.next();
    await this.delay(2000)
    
    this.updateExport('redReport');
    if(this.exportOptions  == "CSV"){
      this.excelService.exportAsCSVFile(this.export, "redReport")
    }else this.excelService.exportAsExcelFile(this.export, "redReport")

    this.styleExp = "block"
    this.modalloading = false;
  }

  updateExport(tableid) {
    //Query Dom for Cells and Headers
    this.datagridHtml = document.getElementById(tableid)
    var headers = this.datagridHtml.getElementsByClassName("datagrid-column-title")
    this.export = []
    console.log(headers)
    var headerArr: HTMLElement[] = [].slice.call(headers);
    var headerRow = []
    var f = 0;
    for (var header of headerArr) {
      var text = <HTMLElement>header as HTMLElement
      if(text.textContent.trim() == "Received In"){
        headerRow[f] = "Received by CFDO"

      }else headerRow[f] = text.textContent.trim()
      f++;
    }
    this.datagridHtml = document.getElementById(tableid)
    let cells: HTMLCollection = this.datagridHtml.getElementsByClassName("datagrid-cell") as HTMLCollection
    console.log('CELLS Length!! size: ' + cells.length)
    console.log(cells)
    var row = [];
    var rowCounter = 0;
    var j = 0;
    var expRow = {};
    for (var j = 0; j < cells.length; j++) {
      //Push Cell to Row Array
      console.log(j)
      console.log(cells)
      console.log(cells.item(j).textContent)

      row.push(cells.item(j).textContent.trim())
      rowCounter = rowCounter + 1;
      //Indicates the end of a Row Processing.
      if (rowCounter >= headers.length) {
        //working on creating object for export
        //Change to create object with page headers
        var k = 0;
        expRow = {}
        var propnames: string[]
        propnames = Object.getOwnPropertyNames(expRow);
        console.log(row)
        //Load Row Array Data into JSON Object
        for (k = 0; k < row.length; k++) {
          expRow[headerRow[k]] = row[k];
        }

        row = [];
        console.log(expRow);
        //Push Row Object to Export array
        this.export.push(expRow)
        rowCounter = 0;
      }
    }
    console.log(this.export)
    this.addColumnstoExport()
    this.pageNum = Number(AppSettings.PAGINATION_COUNT)
  }
addColumnstoExport(){
  
  this.redReportRecords.forEach(rec => {
    let i = 0;
    this.export.forEach(row => {
      if(rec.ReceiptNumber == row["Receipt Number"]){
        row["FEIN"] = rec.Fein
        row["DUNS NUMBER"]= rec.DunsNumber
        row["FDNS DS NUMBER"] = rec.FDNSDSNumber
        row["Received by CFDO"] = rec.DeliverToCFDO
      }
      console.log(row)

    })
  })
}
  delay(ms: number) {
      return new Promise( resolve => setTimeout(resolve, ms) );
  }
  filterProcessStatus(evt){
    let event: Event;
    console.log(this.status)
    if(this.status=="ALL"){
      this.processStatusFilter.clear();
      return;
    }
    if(this.status == "true"){
    this.processStatusFilter.status = true;
    }else this.processStatusFilter.status = false;
    this.processStatusFilter.filter(event);
    if(this.datagrid){
    this.datagrid.refresh.next()
    }
  }
  setReceipt(receipt: string) {
    this.reciptNumber = receipt;
    this.showvsrmodal =true;
  }
  close(){
    document.getElementById(this.reciptNumber).focus();
    this.showvsrmodal = false;
  }
  getFilterStyle(){
    return {display: this.fbox}
  }
  addTitlesToCheckboxes(){
    let checkboxes = this.getCheckboxes();
    let i = 0;
    if(checkboxes){
      checkboxes.forEach(chk => {
        let title = "gridcheckbox_" + i
        chk.setAttribute("title",title)
        i++
      })
    }
  }
  calculateFilteredRows(){
    if(this.getCheckboxes()){
    if(!this.pager){
      //Logic For Initial Search
      let checkboxes = this.getCheckboxes().length
      console.log("Checkboxes on Page" + checkboxes)
      if (document.querySelector('button[class="pagination-next"]')){
        this.filteredRows = 21
        console.log("Filter Results " + this.filteredRows)
      }else if (checkboxes == 1){
        this.filteredRows = 0;
        console.log("Filter Results " + this.filteredRows)
      }else if (checkboxes > 1){
        this.filteredRows = checkboxes - 1;
        console.log("Filter Results " + this.filteredRows)
      }

    }else{
      if(this.pager.lastPage > 1){
        this.filteredRows = 21
        console.log("Filter Results " + this.filteredRows)
      }else if(this.pager.lastItem == 0){
        this.filteredRows = 1;
      }else if(this.pager.lastItem > 0){
        this.filteredRows = this.pager.totalItems
      }
    }

    this.ref.markForCheck()
  
}  
}
  private getScoreResultStyle(ScoreCodeType): any {
    switch (ScoreCodeType) {
      case 'GREEN':
        return { color: 'white', 'background-color': 'green', 'font-weight': 'bold' };
      case 'RED':
        return { color: 'black', 'background-color': 'red', 'font-weight': 'bold' };
      case 'ORANGE':
        return { color: 'black', 'background-color': 'orange', 'font-weight': 'bold' };
      case 'YELLOW':
        return { color: 'black', 'background-color': 'yellow', 'font-weight': 'bold' };
      case 'BLUE':
        return { color: 'white', 'background-color': 'blue', 'font-weight': 'bold' };
      default:
        return {};
    }
  }
  }
