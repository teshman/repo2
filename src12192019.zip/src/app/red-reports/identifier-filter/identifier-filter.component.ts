import { Component,EventEmitter, OnInit, Output, Input } from '@angular/core';
import { ClrDatagridFilterInterface } from '@clr/angular';
import { RedReportRecordEntity } from '../../shared/RedReport_interfaces'
import { Subject} from 'rxjs'


@Component({
  selector: 'app-identifier-filter',
  templateUrl:'./identifier-filter.component.html',
  styleUrls: ['./identifier-filter.component.css']
})

export class IdentifierFilter implements ClrDatagridFilterInterface<RedReportRecordEntity> {
  allIdentifiers = ["Company","Attorney-Fraud", "Address"];
  nbIdentifiers=3;
  selectedIdentifiers: { [identifier: string]: boolean } = {};
  changes: EventEmitter<any> = new EventEmitter<any>(false);
  @Output() clear = new EventEmitter<string>();
  @Output() results = new EventEmitter<number>();
  @Input() totalRecords: number;
  filteredResults: number = 0;
  filterCounter: number = 0;
  constructor(){
    for (var pet of this.allIdentifiers){
      console.log(pet);

        this.selectedIdentifiers[pet] = true;

    }
    console.log(this.selectedIdentifiers)
  }

  initializeFilter(){
    for (var pet of this.allIdentifiers){
      console.log(pet);
        this.selectedIdentifiers[pet] = true;
    }
    console.log(this.selectedIdentifiers)
  }
  listSelected(): string[] {
    const list: string[] = [];
    for (const identifier in this.selectedIdentifiers) {
      if (this.selectedIdentifiers[identifier]) {
        list.push(identifier);
      }
    }
    return list;
  }
  clearFilter(){
    
    for (var pet of this.allIdentifiers){
      console.log(pet);
        this.selectedIdentifiers[pet] = true;
    }
         this.changes.emit(true)
  }
  toggleidentifier(identifier: string) {
    console.log("selecte identifier="+identifier);
    

    //Logic deciding which identifier to show
    this.selectedIdentifiers[identifier] = !this.selectedIdentifiers[identifier];
    this.selectedIdentifiers[identifier] ? this.nbIdentifiers++ : this.nbIdentifiers--;
    console.log("Selected Identifiers Before: " +  JSON.stringify(this.selectedIdentifiers))
    this.changes.emit(true);
    this.clear.emit("")
  }


  //changes = new Subject<any>();
  isActive(): boolean {
    //console.log("isActive: "+ this.nbIdentifiers)
    return this.nbIdentifiers < 3;
  }
  accepts(redReport: RedReportRecordEntity) {
    this.filterCounter++;
    console.log("Total: " + this.totalRecords)
    console.log("Counter: " + this.filterCounter)
    console.log("Selected Identifiers after: " + JSON.stringify(this.selectedIdentifiers)); 
    console.log(redReport.Identifier)
    if(this.selectedIdentifiers[redReport.Identifier]){
      this.filteredResults++;
    }
    console.log("Results: " + this.filteredResults)
    if(this.filterCounter == this.totalRecords){
      console.log("EMIT HERE")
      this.results.emit(this.filteredResults)
      console.log(this.filteredResults)
      this.filterCounter = 0
      this.filteredResults = 0
    }
    return this.selectedIdentifiers[redReport.Identifier]; 
  }
  
}
