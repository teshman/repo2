import { Component,EventEmitter, OnInit, Input } from '@angular/core';
import { ClrDatagridFilterInterface } from '@clr/angular';
import { pfDunsResponse, PreviousFilingRecordEntity } from '../../shared/dunsResponse_interfaces'
import { Subject} from 'rxjs'
import { RedReportRecordEntity } from 'src/app/shared/RedReport_interfaces';


@Component({
  selector: 'app-red-report-stringfilter',
  templateUrl:'./string-filter.component.html',
  styleUrls: ['./string-filter.component.css']
})

export class RedReportStringFilter implements ClrDatagridFilterInterface<RedReportRecordEntity> {
  name="";
  @Input() status: boolean;

  changes: EventEmitter<any> = new EventEmitter<any>(false);
  nbPetitions: number;
  @Input() label: string =  "LABEL";
  @Input() hidden: string = "false"


  filter(event: Event) {
    if (this.name !=="" || this.label == "Process Status"){
    this.nbPetitions = 1;
    this.changes.emit(true);
  }else{
    this.nbPetitions = 0;
    this.changes.emit(true);
  }
}

resetFilter() {
  
  if (this.label == "Process Status"){
  this.status = false
  this.nbPetitions = 1;
  this.changes.emit(true);

}
}
  clear(){
    this.name=""
    this.nbPetitions = 0
    this.changes.emit(true)
  }
  //changes = new Subject<any>();
  isActive(): boolean {
    //console.log("isActive: "+ this.nbPetitions)
    return this.nbPetitions > 0;
  }
  accepts(redReport: RedReportRecordEntity) {
    console.log("Selected Positions after: " + JSON.stringify(this.name)); 
    console.log(redReport.ReceiptNumber)
    if(this.label == "Receipt Number"){
    return redReport.ReceiptNumber.toLowerCase().includes(this.name.toLowerCase().trim())
    }
    if(this.label == "Entity Search"){
      return (redReport.Entity.toLowerCase().includes(this.name.toLowerCase().trim()) && (redReport.Identifier == "Company"))
    }
    if(this.label =="Process Status"){
      return redReport.DeliverToCFDO == this.status || this.nbPetitions ==0;
    }

  }
  
}
