import { TestBed } from '@angular/core/testing';

import { RedReportsService } from './red-reports.service';

describe('RedReportsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: RedReportsService = TestBed.get(RedReportsService);
    expect(service).toBeTruthy();
  });
});
