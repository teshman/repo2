import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DolEtaForm9142AComponent } from './dol-eta-form9142-a.component';

describe('DolEtaForm9142AComponent', () => {
  let component: DolEtaForm9142AComponent;
  let fixture: ComponentFixture<DolEtaForm9142AComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DolEtaForm9142AComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DolEtaForm9142AComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
