import { Component, EventEmitter, Output, OnInit, Input,  } from '@angular/core';
import { FormControl, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AppSettings } from '../shared/app-settings';
import { HttpClient } from '@angular/common/http';
import { VSRResubmitAddress } from '../shared/vsr-resubmit';
import { SmartSearchModel } from '../shared/smart-search-model';
import { SmartSearchService } from '../smart-search.service';
import { ComponentStatusService } from '../shared/service/component-status.service';
import { ComponentStatus } from '../shared/service/component-status';
import { Subject } from 'rxjs/Subject';
import { Subscription } from 'rxjs';


@Component({
  selector: 'app-address-input-form',
  templateUrl: './address-input-form.component.html',
  styleUrls: ['./address-input-form.component.css']
})
export class AddressInputFormComponent implements OnInit {

  //@Output() address: EventEmitter<VSRResubmitAddress> = new EventEmitter<VSRResubmitAddress>();
  @Output() pfAddress : EventEmitter<VSRResubmitAddress> = new EventEmitter<VSRResubmitAddress>();
  addressInputForm: FormGroup; 
  model: SmartSearchModel = new SmartSearchModel;
  opened = false;

  private disableState = true;
  countries: CountryStatesProvinces[];
  defaultCountry: string = "United States"
  selectedCountry: CountryStatesProvinces;
  selectedProvince: CountryStatesProvinces;
  statesOrProvinces: CountryStatesProvinces[];

  cssSubscription: Subscription; 
  cssStatusService: ComponentStatusService;

  constructor(private httpService: HttpClient, private fb: FormBuilder,  private data: SmartSearchService, private css: ComponentStatusService) {
    this.populateCountries();
    this.populateStates();
    this.cssStatusService = css; 

    
    //  Object.assign(this, {this.single, multi})  
    this.cssSubscription = this.css.currentMessage.subscribe(message => {

      if ((message.srcComponentName === AppSettings.CS_SSB) &&
        (message.destComponentName === AppSettings.CS_PREVIOUS_FILINGS_HUB) &&
        (message.clear)){
          console.log("css: reset message received.");
          this.initForm();
        }
    });



  }


  newMessage(){
    console.log("sending new message, from address search:");
    console.log(this.model);
    this.data.changeMessage(this.model);
  }

  ngOnInit() {

    addressInputForm: FormGroup;
    this.addressInputForm = this.fb.group({
      org: ["", Validators.required],
      street: ["", Validators.required],
      city: [""],
      state: new FormControl({ value: '', disabled: false }, Validators.required),
      zip: [""],
      country: ["US", Validators.required]
    });
    this.initForm();
  }

  private populateStates() {
    const url = AppSettings.US_STATES_JSON;
    this.httpService.get(url).subscribe(
      data => {
        this.statesOrProvinces = data as CountryStatesProvinces[];
      }
    );
  }

  private populateCountries() {
    const url = AppSettings.COUNTRIES_JSON;
    this.httpService.get(url).subscribe(
      data => {
        this.countries = data as CountryStatesProvinces[];

      }
    );
  }

  private cancel(){
    this.opened=false;
    this.model.disabledSearchById=false;
    this.addressInputForm.reset();
    this.initForm();

    let c = new ComponentStatus(); 
    c.srcComponentName="pfBA";
    c.destComponentName=AppSettings.CS_SSB;
    c.clear=true;
    this.cssStatusService.changeMessage(c); 
  }
  
  private imqAddressSearch(){
    console.log("imq Search by Address");
    console.log(this.addressInputForm); 
  
    var searchAddress: VSRResubmitAddress = new VSRResubmitAddress;
    
    if (this.addressInputForm.status=="VALID"){
      searchAddress.organizationName=this.addressInputForm.value.org; 
      searchAddress.streetFull=this.addressInputForm.value.street; 
      searchAddress.city=this.addressInputForm.value.city; 
      searchAddress.state=this.addressInputForm.value.state;
      searchAddress.postalCode=this.addressInputForm.value.zip;
      //searchAddress.country=this.addressInputForm.value.country; 
      searchAddress.country=this.addressInputForm.value.country; 
      let cStr: string =  searchAddress.country=this.addressInputForm.value.country; 
      let splitStr =  cStr.split(":",1); 
      searchAddress.country=splitStr[1];

      this.model.address = searchAddress;
      this.opened=false;
      
      console.log("model: ");
      console.log(this.model);
      this.model.selectedSearchType = "previousFilings";
      this.model.selectedSearchTypeIndex=1;
      this.model.selectedSearchFunction="pfBA";
      this.model.functionDescription=AppSettings.SSB_pfBA_DESCRIPTION;
      this.model.disabledSearchById=true;
      
      //this.pfAddress.emit(searchAddress); 
      this.model.error="";
      this.newMessage();
      this.addressInputForm.reset();
      this.opened=false;
      this.initForm();
  
    }else {
      let c = new ComponentStatus(); 
      c.srcComponentName="pfBA";
      c.destComponentName=AppSettings.CS_SSB;
      c.error=AppSettings.INVALID_ADDRESS;
      this.cssStatusService.changeMessage(c); 
      
    }
    
  }
  

  
  public onOpenAddressInputDialog(): boolean{
    this.model.error="";
    this.opened=true;
    this.addressInputForm.reset();
    this.initForm();
     
    let c = new ComponentStatus(); 
    c.srcComponentName="pfBA";
    c.destComponentName=AppSettings.CS_PREVIOUS_FILINGS_HUB;
    c.clear=true;
    this.cssStatusService.changeMessage(c); 
      
    console.log("onOpenSearchDialog called"); 

    return this.opened; 


  }

  
  private onCancelAddressInputDialog():boolean{
    this.opened=false;
    this.model.disabledSearchById=false;
    this.addressInputForm.reset();
    console.log("onCancelAddressInputDialog called"); 

    return this.opened; 

  }
  
  private onCountrySelect(countryId: string) {
    console.log("countryId="+countryId); 
    if (countryId.trim().toUpperCase() == "212: CA"){
      this.populateProvinces();
      this.addressInputForm.controls["state"].enable()

    }else if (countryId.trim().toUpperCase() == "211: US"){
      this.populateStates();
      this.addressInputForm.controls["state"].enable()
    }else {
      this.statesOrProvinces = [];
      this.addressInputForm.controls["state"].disable();
      this.disableState=true;
      
  
    }

}

  private initForm(){
    this.populateCountries();
    this.populateStates();        
    this.addressInputForm = this.fb.group({
      org: ["", Validators.required],
      street: ["", Validators.required],
      city: [""],
      state: new FormControl({value: '', disabled: false}, Validators.required),   
      zip: [""],
      country: ["US", Validators.required]
    });
    this.addressInputForm.controls["country"].setValue("211: US");
    //this.addressInputForm.controls["state"].disable;
  }

  private populateProvinces() {
    console.log("CANADA selected");
    const url = AppSettings.PROVINCES_JSON;
    this.httpService.get(url).subscribe(
        data => {
            if (data)
                this.statesOrProvinces = data as CountryStatesProvinces[];
            else
                this.statesOrProvinces = [];
        }
    );
}


}

export class CountryStatesProvinces {
  name: string;
  abbreviation: string;
}

