import {Injectable} from '@angular/core';
import {Http} from '@angular/http';
import { PredefinedInformationProxy } from './shared/predefined-Information-Proxy';
import { AppSettings } from './shared/app-settings';
import 'rxjs/add/operator/map';
import { CountryStatesProvinces } from './predefined-info/predefined-info-business-search-form.component';
import { HttpClient } from '@angular/common/http';
import { PredefinedInformation, PredefinedInformationRecordEntity } from './shared/predefined-Information';
import { formatDate } from '@angular/common';
import { ComponentStatusService } from './shared/service/component-status.service';
import { ComponentStatus } from './shared/service/component-status';
import { Timestamp } from 'rxjs/internal/operators/timestamp';

@Injectable({
    // we declare that this service should be created
    // by the root application injector.
    providedIn: 'root',
  })
export class PredefinedInfoProvider {

    private predefinedInfo: PredefinedInformation = null;
    private predefUrl = AppSettings.PREDEF_URL;
    private predefDetailUrl = AppSettings.PREDEF_DETAIL_URL;
    private countries: CountryStatesProvinces[];
    private message = new ComponentStatus();
    private cssService: ComponentStatusService;
    private states: CountryStatesProvinces[];
    private provinces: CountryStatesProvinces[];
    constructor(private httpc: HttpClient,  private css: ComponentStatusService) {
        this.cssService = css;
    }

    public getPredefInfo(): PredefinedInformation {
        return this.predefinedInfo;
    }

    load() {
        let time = new Date()
        console.log("Start Load: " + time.getTime())
        console.log("loading all predefined information")
        let url = this.predefUrl + "ALL"
        return new Promise((resolve, reject) => {
            this.httpc
                .get(url)
                .map(res => res)
                .subscribe(response => {
                    console.log("response")
                    console.log(response)
                    this.predefinedInfo = <PredefinedInformation>response;
                    console.log("predefined info loading complete")
                    let time = new Date();
                    console.log("End Load: " + time.getTime())
                    this.message.destComponentName = "PREDEF_INFO"
                    this.message.srcComponentName = "PROVIDER"
                    this.message.data = JSON.stringify(this.predefinedInfo)
                    // console.log("Sending Message\n " + JSON.stringify(this.message))
                    this.cssService.changeMessage(this.message)
                    console.log(this.predefinedInfo)
                    resolve(true);
                })
        })
    }

    public refreshPredefInfo() {
        
        let today = formatDate(Date.now(),'yyyy-MM-dd','en-US');
        console.log("Today's Date is " + today)
        let url = this.predefUrl + today
        let data: PredefinedInformation
        this.httpc.get(url)
        .map(res => res).subscribe(response => {
            data = response as PredefinedInformation
            console.log(data)
            if(data.PredefinedInformationGetListResponse){
            if(data.PredefinedInformationGetListResponse.PredefinedInformationResultSet.totalRecordCount == 0){
                console.log("No New Records")
                return;
            }
            let j = 0
            let newinfoRecords: PredefinedInformationRecordEntity[];
            if(data){
                newinfoRecords = data.PredefinedInformationGetListResponse.PredefinedInformationResultSet.PredefinedInformationRecord
            }else return;
            let currentinfoRecords: PredefinedInformationRecordEntity[]
            if(this.predefinedInfo){
                currentinfoRecords = this.predefinedInfo.PredefinedInformationGetListResponse.PredefinedInformationResultSet.PredefinedInformationRecord
            }else return;
            
            console.log("Current Result set Length: " + currentinfoRecords.length)
            let index = -1
            newinfoRecords.forEach(rec => {
                let id =  rec.ExceptionID
                index = currentinfoRecords.findIndex(item => item.ExceptionID == id)
                if(index > -1){
                    currentinfoRecords[index] = rec
                    index = -1;
                }else{
                    currentinfoRecords.push(rec)
                    index = -1
                }
                

                
            })
            this.predefinedInfo.PredefinedInformationGetListResponse.PredefinedInformationResultSet.PredefinedInformationRecord = currentinfoRecords;
            console.log("Final Result Set")
            console.log(this.predefinedInfo.PredefinedInformationGetListResponse.PredefinedInformationResultSet.PredefinedInformationRecord)
            this.message.destComponentName = "PREDEF_INFO"
            this.message.srcComponentName = "PROVIDER"
            this.message.data = JSON.stringify(this.predefinedInfo)
            // console.log("Sending Message\n " + JSON.stringify(this.message))
            this.cssService.changeMessage(this.message)
            
        }})
        

    }
    public getCountries(): CountryStatesProvinces[] {
        return this.countries
    }
    public getStates(): CountryStatesProvinces[] {
        return this.states;
    }
    public getProvinces(): CountryStatesProvinces[] {
        return this.provinces;
    }
    
    populateCountries() {
        console.log("loading countries")
        const url = AppSettings.COUNTRIES_JSON;
        this.httpc.get(url).subscribe(
          data => {
            this.countries = data as CountryStatesProvinces[];
    
          }
        );
      }

    populateStates() {
        const url = AppSettings.US_STATES_JSON;
        this.httpc.get(url).subscribe(
          data => {
            this.states = data as CountryStatesProvinces[];
    
          }
        );
      }
    
      populateProvinces() {
        const url = AppSettings.PROVINCES_JSON;
        this.httpc.get(url).subscribe(
          data => {
            if (data) {
              this.provinces = data as CountryStatesProvinces[];
            }

          });
      }
}