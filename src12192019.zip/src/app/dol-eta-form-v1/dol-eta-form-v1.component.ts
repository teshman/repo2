import { Component, OnInit, Input, NgModule } from '@angular/core';
import { keyframes } from '@angular/animations';
import { DolEtaSearchService } from '../dol-eta-search.service';
import { ClrDatagridSortOrder } from '@clr/angular';
import {GetDolDetailByPetitionIDResponse,DolData, DOLDATA, DOLETACLOB} from '../shared/9035v1_interfaces'
import { DOLDATAProxy} from '../shared/dolPetitionResponse_proxy'
import { AppSettings } from '../shared/app-settings'
import { Router } from '@angular/router';
import { SmartSearchService }  from "../smart-search.service"
import { SmartSearchModel }  from "../shared/smart-search-model"
import { Subscription } from 'rxjs';
import { NumberTransformRoman } from './dol-eta-form-v1.pipe'
import { catchError } from 'rxjs/operators';
import { ComponentStatusService } from '../shared/service/component-status.service';
import { ComponentStatus } from '../shared/service/component-status';


@Component({
  selector: 'app-dol-eta-form-v1',
  templateUrl: './dol-eta-form-v1.component.html',
  styleUrls: ['./dol-eta-form-v1.component.css'],
  providers: [ NumberTransformRoman ]
})
export class DolEtaFormV1Component implements OnInit {
  @Input() petitionId: string = "";//"147973101";147973069,147973128
  @Input() dolEtaFormType: string = "";
  @Input() dolEtaFormVersion: string = "";
  @Input() dolEtaClobId: string = "";
  @Input() etacaseNumber: string = "";
  empAgree : boolean;
  attest : boolean;
  electronic : boolean;
  worksites: any[] = [];
  showDol = false
  loading = false
  showEmployers = false
  showWorksites = false
  showAddendum = false
  showSummary = false
  searchSubscription: Subscription;
  showStatemnts = false
  showStatemnts2 = false
  root: GetDolDetailByPetitionIDResponse;
  dol: DolData
  dolEta: DOLDATA
  DolEtaResult: DOLETACLOB;
  descSort = ClrDatagridSortOrder.DESC
  ascSort = ClrDatagridSortOrder.ASC
  appsAlert: string
  model = {
    DolEtaResults: [],
    caseNumber: '', //H30014321198839
    petitionNumber: '' //146845314
  }
  cssSubscription: Subscription; 
  cssStatusService: ComponentStatusService;
  private dolSvc: DolEtaSearchService;
  constructor(private dolSearchService: DolEtaSearchService, private ssb: SmartSearchService, private router: Router, private toRomanNumeral: NumberTransformRoman, private css: ComponentStatusService) {
    this.dolSvc = dolSearchService

     //integration point with SSB

    this.cssSubscription = this.css.currentMessage.subscribe(message => {
      this.resetComponent();
        if(message.destComponentName ==  AppSettings.CS_DOL_ETA_9035V1){
          console.log("IN 9035 V1")
          console.log(message.data);
          
          try{
            this.parseDolData(message.data)
          }catch(error){
        this.appsAlert = AppSettings.VSR_STATUS_CODE_001_DESC;
        this.showDol = false;
        this.loading = false;
        this.showAddendum = false
        this.showWorksites = false
        this.showEmployers = false
        this.showSummary = false;}
      }


    });
  
    }

  ngOnInit() 
  {
    this.showDol = false
    this.showAddendum = false
    this.showWorksites = false
    this.showEmployers = false
    this.model.petitionNumber = this.petitionId;
    console.log(this.petitionId)
  
    if(this.petitionId !== "" && this.dolEtaFormType !== ""){
    this.getDolSearchByPetitionID(this.model.petitionNumber, this.dolEtaClobId);
    }else if (this.etacaseNumber !== "" && this.dolEtaFormType == '9035' && this.dolEtaFormVersion == '1'){
      this.getDolSearchByCaseNumber(this.etacaseNumber)
    }


  }
  ngOnDestroy(){
    this.cssSubscription.unsubscribe();}
  getDolSearchByCaseNumber(caseNumber: string) {
    this.showSummary = false;
    this.loading = true
    this.showDol = false
    this.showAddendum = false
    this.showWorksites = false
    this.showEmployers = false
    this.appsAlert = ""
    //Start service Call
    this.dolSvc.getDolByCaseId(caseNumber.replace(/-/g, '')).subscribe(data => {
      console.log(data)
      try{
        if (JSON.stringify(data).includes("ESB2Exception")) throw new Error(JSON.stringify(data));
  } catch (error) {
        this.appsAlert = AppSettings.SYSTEM_EXCEPTION;
        this.showDol = false;
        this.loading = false;
        this.showAddendum = false
        this.showWorksites = false
        this.showEmployers = false
        this.showSummary = false;
        console.log(error);
        return;
  }
      // console.log(data.DolJsonData)
      // this.root = data;
      // console.log(this.root.DolJsonData)
      this.dol = <DolData>JSON.parse(data.GetDolDetailByEtaCaseNumberResponse.DolJsonData)
      console.log(this.dol)
      this.dolEta = <DOLDATA> this.dol.DOL_DATA
      console.log(this.dolEta)
      //this.dolEta = <DOLDATA> this.dol
      this.worksites = [];
      this.createWorksitesArray()
      if (Array.isArray(this.worksites) && (this.worksites.length > 1)) {//
        
        this.showWorksites = true
      }
      
      if (Array.isArray(this.dolEta.DOL_ETA_EMPLOYERS)) {
        this.showEmployers = true
      }
      if (this.dolEta.DOL_ETA_CLOB) {

        if (Array.isArray(this.dolEta.DOL_ETA_CLOB)) {
          var clob = this.dolEta.DOL_ETA_CLOB;
          console.log
          
          this.attest = this.makeBooleans(this.dolEta.DOL_ETA_CLOB[0].PRE_ATTESTTRUE)
          this.electronic = this.makeBooleans(this.dolEta.DOL_ETA_CLOB[0].PRE_ELECTRONIC)
          this.empAgree = this.makeBooleans(this.dolEta.DOL_ETA_CLOB[0].PRE_EMPAGREE)
          this.loading = false
          this.showDol = true

        } else {
            if(this.dolEta.DOL_ETA_CLOB.CASE_NUMBER == "remove"){
              this.loading = false
              this.showDol = false
              this.appsAlert = AppSettings.VSR_STATUS_CODE_001_DESC;
              
            }else {
              
              
              this.attest = this.makeBooleans(this.dolEta.DOL_ETA_CLOB.PRE_ATTESTTRUE)
              this.electronic = this.makeBooleans(this.dolEta.DOL_ETA_CLOB.PRE_ELECTRONIC)
              this.empAgree = this.makeBooleans(this.dolEta.DOL_ETA_CLOB.PRE_EMPAGREE)
              this.DolEtaResult = this.dolEta.DOL_ETA_CLOB;
              this.dolEta.DOL_ETA_CLOB = [];
              this.dolEta.DOL_ETA_CLOB.push(this.DolEtaResult)
              this.loading = false;
              this.showDol = true
            }
          
        }
        
      }
      //For Loading Animation
    this.showAddendum = this.showEmployers||this.showWorksites 
    //this.showSummary = true     
      this.loading=false
    },
    error => {
      (async () => {
        //await delay(10000);  //when simulating a long delay or timeout from a service.
        //console.log('after delay');
        this.appsAlert = AppSettings.VSR_STATUS_CODE_001_DESC;
        this.showDol = false;
        this.loading = false;
        this.showAddendum = false
        this.showWorksites = false
        this.showEmployers = false
        this.showSummary = false;
      })();
      }
    )

  }
  getDolSearchByPetitionID(petitionNumber: string, dolEtaClobId: string) {
    this.showSummary = false;
    this.loading = true
    this.showDol = false
    this.showAddendum = false
    this.showWorksites = false
    this.showEmployers = false
    this.appsAlert = ""
    //Start service Call
    this.dolSvc.getDolByPettitionId9035v1(petitionNumber, dolEtaClobId).subscribe(data => {
      console.log(data)
      if (data.GetDolDetailByPetitionIDResponse.DolEtaFormType !== '9035'){
        console.log("Unsupported DOL Form Type " + data.GetDolDetailByPetitionIDResponse.DolEtaFormType)
        this.appsAlert = "Unsupported DOL Form Type " + data.GetDolDetailByPetitionIDResponse.DolEtaFormType
        this.showDol = false;
        this.loading = false;
        this.showAddendum = false
        this.showWorksites = false
        this.showEmployers= false
        this.showSummary = false;
        return;
      }
      try{
        if (JSON.stringify(data).includes("ESB2Exception")) throw new Error(JSON.stringify(data));
  } catch (error) {
        this.appsAlert = AppSettings.SYSTEM_EXCEPTION;
        this.showDol = false;
        this.loading = false;
        this.showAddendum = false
        this.showWorksites = false
        this.showEmployers = false
        this.showSummary = false;
        console.log(error);
        return;
  }
      // console.log(data.DolJsonData)
      // this.root = data;
      // console.log(this.root.DolJsonData)
      this.dol = <DolData>JSON.parse(data.GetDolDetailByPetitionIDResponse.DolJsonData)
      console.log(this.dol)
      this.dolEta = <DOLDATA> this.dol.DOL_DATA
      console.log(this.dolEta)
      //this.dolEta = <DOLDATA> this.dol
      this.worksites = [];
      this.createWorksitesArray()
      if (Array.isArray(this.worksites) && (this.worksites.length > 1)) {
        
        this.showWorksites = true
      }
      
      if (Array.isArray(this.dolEta.DOL_ETA_EMPLOYERS)) {
        this.showEmployers = true
      }
      if (this.dolEta.DOL_ETA_CLOB) {

        if (Array.isArray(this.dolEta.DOL_ETA_CLOB)) {
          var clob = this.dolEta.DOL_ETA_CLOB;
          console.log
          
          this.attest = this.makeBooleans(this.dolEta.DOL_ETA_CLOB[0].PRE_ATTESTTRUE)
          this.electronic = this.makeBooleans(this.dolEta.DOL_ETA_CLOB[0].PRE_ELECTRONIC)
          this.empAgree = this.makeBooleans(this.dolEta.DOL_ETA_CLOB[0].PRE_EMPAGREE)
          this.loading = false
          this.showDol = true

        } else {
            if(this.dolEta.DOL_ETA_CLOB.CASE_NUMBER == "remove"){
              this.loading = false
              this.showDol = false
              this.appsAlert = AppSettings.VSR_STATUS_CODE_001_DESC;
              
            }else {
              
              
              this.attest = this.makeBooleans(this.dolEta.DOL_ETA_CLOB.PRE_ATTESTTRUE)
              this.electronic = this.makeBooleans(this.dolEta.DOL_ETA_CLOB.PRE_ELECTRONIC)
              this.empAgree = this.makeBooleans(this.dolEta.DOL_ETA_CLOB.PRE_EMPAGREE)
              this.DolEtaResult = this.dolEta.DOL_ETA_CLOB;
              this.dolEta.DOL_ETA_CLOB = [];
              this.dolEta.DOL_ETA_CLOB.push(this.DolEtaResult)
              this.loading = false;
              this.showDol = true
            }
          
        }
        
      }
      //For Loading Animation
    this.showAddendum = this.showEmployers||this.showWorksites 
    this.showSummary = true     
      this.loading=false
    },
    error => {
      (async () => {
        //await delay(10000);  //when simulating a long delay or timeout from a service.
        //console.log('after delay');
        this.appsAlert = AppSettings.VSR_STATUS_CODE_001_DESC;
        this.showDol = false;
        this.loading = false;
        this.showAddendum = false
        this.showWorksites = false
        this.showEmployers = false
        this.showSummary = false;
      })();
      }
    )

  }

parseDolData(data){
  try{
    if (JSON.stringify(data).includes("ESB2Exception")) throw new Error(JSON.stringify(data));
} catch (error) {
    this.appsAlert = AppSettings.SYSTEM_EXCEPTION;
    this.showDol = false;
    this.loading = false;
    this.showAddendum = false
    this.showWorksites = false
    this.showEmployers = false
    this.showSummary = false;
    console.log(error);
    return;
}
  // console.log(data.DolJsonData)
  // this.root = data;
  // console.log(this.root.DolJsonData)
  this.dol = <DolData>JSON.parse(data.GetDolDetailByEtaCaseNumberResponse.DolJsonData)
  console.log(this.dol)
  this.dolEta = <DOLDATA> this.dol.DOL_DATA
  console.log(this.dolEta)
  //this.dolEta = <DOLDATA> this.dol
  this.worksites = [];
  this.createWorksitesArray()
  if ((Array.isArray(this.worksites)) && (this.worksites.length > 1)) {
    
    this.showWorksites = true
  }
  
  if (Array.isArray(this.dolEta.DOL_ETA_EMPLOYERS)) {
    this.showEmployers = true
  }
  if (this.dolEta.DOL_ETA_CLOB) {

    if (Array.isArray(this.dolEta.DOL_ETA_CLOB)) {
      var clob = this.dolEta.DOL_ETA_CLOB;
      console.log
      
      this.attest = this.makeBooleans(this.dolEta.DOL_ETA_CLOB[0].PRE_ATTESTTRUE)
      this.electronic = this.makeBooleans(this.dolEta.DOL_ETA_CLOB[0].PRE_ELECTRONIC)
      this.empAgree = this.makeBooleans(this.dolEta.DOL_ETA_CLOB[0].PRE_EMPAGREE)
      this.loading = false
      this.showDol = true

    } else {
        if(this.dolEta.DOL_ETA_CLOB.CASE_NUMBER == "remove"){
          this.loading = false
          this.showDol = false
          this.appsAlert = AppSettings.VSR_STATUS_CODE_001_DESC;
          
        }else {
          
          
          this.attest = this.makeBooleans(this.dolEta.DOL_ETA_CLOB.PRE_ATTESTTRUE)
          this.electronic = this.makeBooleans(this.dolEta.DOL_ETA_CLOB.PRE_ELECTRONIC)
          this.empAgree = this.makeBooleans(this.dolEta.DOL_ETA_CLOB.PRE_EMPAGREE)
          this.DolEtaResult = this.dolEta.DOL_ETA_CLOB;
          this.dolEta.DOL_ETA_CLOB = [];
          this.dolEta.DOL_ETA_CLOB.push(this.DolEtaResult)
          this.loading = false;
          this.showDol = true
        }
      
    }
    
  }
  //For Loading Animation
this.showAddendum = this.showEmployers||this.showWorksites 
//Hide Summary for search by Case Number
//this.showSummary = true     
  this.loading=false
  }
  toggleStmnts(){
    this.showStatemnts = !this.showStatemnts
  }
  toggleStmnts2(){
    this.showStatemnts2 = !this.showStatemnts2
  }
  makeBooleans(answer: string){
    console.log(answer)
    if (answer.toUpperCase() == "Y"){
    return true;
    }
    else return false;

  }
  createWorksitesArray() {

    if (!this.dolEta.DOL_ETA_CLOB) {
      return this.worksites;
    }
    try {
      //loop over CLOB keys
      var site = {}
      var i = 1;
      var previouskey = "";
      for (let key in this.dolEta.DOL_ETA_CLOB) {
        // console.log(i)
        if (key.startsWith("WRK") || (previouskey.startsWith("WRK") && previouskey !== key)) {
          


            try {
            var ki = Number(key.toString().substring(3, 4));
            } catch{ continue; }

              if (ki !== i) {
                i = ki;
                if (!i) i = 4;
                let addr2Key = "WRK"+(i-1)+"_ADDR1"
                console.log("Address 2 Key: " + addr2Key)
                if((this.dolEta.DOL_ETA_CLOB[addr2Key]) && this.dolEta.DOL_ETA_CLOB[addr2Key] !== ''){
                  this.worksites.push(site)
                }
                  site = {};
                  site[key.replace(key.charAt(3),'')] = this.dolEta.DOL_ETA_CLOB[key]
                
              } else {
                  site[key.replace(key.charAt(3),'')] = this.dolEta.DOL_ETA_CLOB[key]
                }
              }
              previouskey = key;
          }
          } catch (error) {
            console.log("Error in create Worksites" + error)
            this.worksites = [];
            return this.worksites;
    }
    console.log(this.worksites)
    return this.worksites

  }
  resetComponent(){
    this.showSummary = false;
    this.loading = false;
    this.showDol = false
    this.showAddendum = false
    this.showWorksites = false
    this.showEmployers = false
    this.appsAlert = ""
  }
}
