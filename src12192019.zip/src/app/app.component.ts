import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { UserProfileService } from './user-profile.service';
import { FormGroup, FormControl } from '@angular/forms';
import { Router, Event, NavigationStart } from '@angular/router';
import { UserInRoleService } from './user-profile/user-in-role.service';
import { UserIdleService } from 'angular-user-idle';
import { LoginHistoryService } from './login-history.service'
import { fromEvent, merge } from 'rxjs';
import { LoginHistoryRequestProxy, LoginHistoryRequest1Proxy } from './shared/login-history-request'
import { AppSettings } from './shared/app-settings';
import { ComponentStatus } from './shared/service/component-status';
import { ComponentStatusService } from './shared/service/component-status.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: [UserProfileService]
})
export class AppComponent {
  displayTimeOutMessage: boolean = false;

  display: boolean = true;
  title = 'VIBE PLUS';
  notification: string;
  showNotification: boolean;
  displayName = "";
  showFormModal: boolean = false;
  formAccessibility;
  currentDateTime: Date;
  showSystemNotification: boolean=false;   

  @ViewChild("searchType", { static: false }) searchTypeField: ElementRef;

  private myUserProfileService: UserProfileService;

  constructor(private userProfileService: UserProfileService,
    private router: Router,
    private userInRoleService: UserInRoleService,
    private userIdleService: UserIdleService, 
    private loginHistoryService: LoginHistoryService, 
    private css: ComponentStatusService) {
    

    this.notification = "VIBE Plus is a newly modernized user interface for the VIBE system.  This site is still under beta testing.  Please do not access this VIBE Plus site until further notice.  Thank you for your support!"
    //document.addEventListener('keyup', this.restart);
    //document.addEventListener('click', this.restart);

    console.log("In app component constructor");

    this.displayTimeOutMessage = false;
    this.myUserProfileService = userProfileService;

    this.myUserProfileService.getUserProfile().subscribe(
      data => {
        if (data) {
          this.displayName = data.displayName;
          this.userInRoleService.userInRole = data;
          if (this.userInRoleService.userInRole.dolUser){
            this.showSystemNotification=false;   
          }
      
          // TODO: call user history logging service here
          //this.loginHistoryService.updateUserLoginHistoryData(); 

        }
        else {
          //console.log("ac: No user profile data");
        }
      },
      error => {
        (async () => {
          //console.log("ac: User Not logged in");
          window.location.href = "/vibe-plus";

          //this.appsAlert = AppSettings.VSR_STATUS_CODE_003_DESC + ", " + JSON.stringify(error);
        })();
      }
    );

    let c = new ComponentStatus(); 
    c.srcComponentName=AppSettings.CS_APP;
    c.destComponentName=AppSettings.CS_SSB;
    c.clear=true;
    
    //This controls where the SSB is displayed 
    this.router.events.subscribe((event: Event) => {
      if (event instanceof NavigationStart) {
        this.css.changeMessage(c); 

        if ((event.url.match('/helpful-links')) ||
          (event.url.match('/user-profile')) ||
          (event.url.match('/red-reports')) ||
          (event.url.match('/predefined-info')) ||
          (event.url.match('/data-inquiry')) ||

          (event.url.match('/admin'))) {
          this.display = false;

          console.log("hide search box");

        } else if (event.url.match('/') ||
          event.url.startsWith('/vsr') ||
          event.url.startsWith('/previous-filings') ||
          event.url.startsWith('/previous-eta-filings') ||
          event.url.startsWith('/dol-eta-lookup')) {
          console.log("show search box");
          this.display = true;
        } else {
          this.display = false;
          console.log("hide search box");
        }
      }
    });

  }

  ngOnInit() {

    console.log("In app component ngOnInit()");
    this.formAccessibility = new FormGroup({});
    this.currentDateTime = new Date();


    //===============================
    //global event listner 
    // var self = this;
    // document.addEventListener('keyup', function () {
    //   console.log('keys pressed');
    //   self.restart();
    //   //  this.displayTimeOutMessage=true;
    // });
    // document.addEventListener('click', function () {
    //   self.restart()
    //   console.log('mouse clicked');
    // });



    //Start watching for user inactivity.
    console.log(this.userIdleService);
    console.log("start watching for user inactivity");

    //this.userIdleService.setCustomActivityEvents(merge(fromEvent(document, 'keys pressed'), fromEvent(document, 'mouse clicked') ) ); 

    this.userIdleService.startWatching();

    // Start watching when user idle is starting.
    this.userIdleService.onTimerStart().subscribe(count => {
      console.log("user was idle for a long long time, display warning");
      console.log(new Date()+ "\t"+ count);
      this.displayTimeOutMessage = true;
    });

    // Start watch when time is up.
    this.userIdleService.onTimeout().subscribe(() => {
      console.log("start invalidate user session due to inactivity.");
      window.location.href = AppSettings.USER_LOGOUT_URL; 
    });

    this.userIdleService.ping$.subscribe(() => {

        if (this.displayTimeOutMessage){
          console.log(new Date()+ "\t Outage notification displayed on the screen... do not call the ping service.");
        }else {
          this.myUserProfileService.getUserProfile().subscribe(
            data => {
              console.log(new Date() + "\t PING SERVICE CALLED");
              if (data) {
                this.displayName = data.displayName;
                this.userInRoleService.userInRole = data;
    
                //console.log("ac:  data=" + JSON.stringify(data));
    
              }
              else {
                //console.log("ac: No user profile data");
              }
            },
            error => {
              (async () => {
                //console.log("ac: User Not logged in");
                window.location.href = AppSettings.VIBE_PLUS_URL;
    
                //this.appsAlert = AppSettings.VSR_STATUS_CODE_003_DESC + ", " + JSON.stringify(error);
              })();
            }
          )    
        }
      
    });

  }




  stop() {
    console.log("stop timer ");
    this.userIdleService.stopTimer();
  }

  stopWatching() {

    this.userIdleService.stopWatching();
  }

  startWatching() {
    this.userIdleService.startWatching();
  }

  restart() {
    console.log("RESET");
    this.userIdleService.resetTimer();
  }



  extendSession() {
    this.restart();
    this.displayTimeOutMessage = false;
  }


  toggleFormAccessibility() {

    this.showFormModal = !this.showFormModal;
    console.log("this.showFormModal: " + this.showFormModal);
  }


  // toContent() {
  //   if ((this.router.url.match('/helpful-links')) ||
  //     (this.router.url.match('/user-profile')) ||
  //     (this.router.url.match('/admin'))) {

  //       let x = document.getElementById("content");
  //       if (x) {
  //         console.log("content area found and placing focus on it");
  //         x.scrollIntoView();
  //         x.focus();
  
  //       }
  //   } else {
  //     let x = document.getElementById("searchType");
  //     if (x) {
  //       console.log("searchType found and placing focus on it");
  //       x.scrollIntoView();
  //       x.focus();

  //     }

  //   }
  // }

}
