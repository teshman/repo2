import { TestBed } from '@angular/core/testing';

import { DataInquiryListService } from './data-inquiry-list.service';

describe('DataInquiryListService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: DataInquiryListService = TestBed.get(DataInquiryListService);
    expect(service).toBeTruthy();
  });
});
