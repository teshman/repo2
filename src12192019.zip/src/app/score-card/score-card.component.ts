import { Component, OnInit, Input, OnChanges, SimpleChanges } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ScoreCard, ScoreCardRecordEntity } from '../shared/score-card';
import { ScoreCardService } from './score-card.service';
import { AppSettings } from '../shared/app-settings';

@Component({
  selector: 'app-score-card',
  templateUrl: './score-card.component.html',
  styleUrls: ['./score-card.component.css']
})
export class ScoreCardComponent implements OnInit, OnChanges {

  @Input() scoreCardID: any;
  @Input() scRecords: ScoreCardRecordEntity[];
  private scoreCardUrl = AppSettings.SCORE_CARD_URL;
  // private scoreCardUrl = "https://esb2ui.esb2-dev.devtecc.uscis.dhs.gov/vibe-plus/rest/SCORE/scorecard";
  scoreCard: ScoreCard;

  constructor(private http: HttpClient, private scoreCardService: ScoreCardService) {
  }
  

  ngOnChanges(changes: SimpleChanges) {
    if (this.scoreCardID)

    this.getScoreCardById(this.scoreCardID);
  }

  ngOnInit() {
    if (this.scoreCardID)
      this.getScoreCardById(this.scoreCardID);
      
    else
      // this.getScoreCardById("1253120");// to be used only in DEV environment for debugging, otherwise set the value to null.
     { 
       this.scRecords =  this.scRecords;
      this.scRecords.forEach(element => {
        if((element.BusinessRuleName==="Legal Status Code" && element.Score==="N/A") )
        this.scRecords.splice(this.scRecords.indexOf(element),1);  
      });

      this.scRecords.forEach(element => {
        if(element.BusinessRuleName==="Foreign Affiliate Indicator" && element.Score==="N/A")             
      this.scRecords.splice(this.scRecords.indexOf(element),1); 
      });
    }
  }


    
  private getScoreCardById(scoreCardId: any) {
    const url = `${this.scoreCardUrl}/${scoreCardId}`;
    // console.log("the card url is: " + url);
    // const url = `/vibe-plus/rest/score/scorecard/1253100`;
    this.scoreCardService.getCards(url).subscribe(data => {    

      if (data && !JSON.stringify(data).includes("Error") && !JSON.stringify(data).includes("ESB2Exception") 
      && !JSON.stringify(data).includes("ESB-VIBE.STATUS.001") ) {
        this.scoreCard = data;
      this.scRecords = this.scoreCard.ScoreCardGetResponse.ScoreCardResultSet.ScoreCardRecord;
      this.scRecords.forEach(element => {
        if((element.BusinessRuleName==="Legal Status Code" && element.Score==="N/A") )
        this.scRecords.splice(this.scRecords.indexOf(element),1);  
      });

      this.scRecords.forEach(element => {
        if(element.BusinessRuleName==="Foreign Affiliate Indicator" && element.Score==="N/A")             
      this.scRecords.splice(this.scRecords.indexOf(element),1); 
      });
      }
      else{

      }
    });
  }

  private getScoreCardStyle(ScoreCodeType): any {
     switch (ScoreCodeType) {
      case 'GREEN':
        return { color: 'white', 'background-color': 'green', 'font-weight': 'bold' };
      case 'RED':
        return { color: 'black',  'background-color': 'red', 'font-weight': 'bold' };
      case 'ORANGE':
        return { color: 'black', 'background-color': 'orange', 'font-weight': 'bold' };
      case 'YELLOW':
        return { color: 'black', 'background-color': 'yellow', 'font-weight': 'bold' };
      case 'BLUE':
        return { color: 'white', 'background-color': 'blue', 'font-weight': 'bold' };
      default:
        return {};
    }
  }
}
