import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import {IndependentManualQueryResponseProxy} from './shared/independent-manual-query-response-proxy'
import { catchError, map, tap } from 'rxjs/operators';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AppSettings} from './shared/app-settings'
import { VSRResubmitAddress, VSRResubmitRequest } from './shared/vsr-resubmit';


@Injectable({
  providedIn: 'root'
})
export class IndependentManualQueryService {
  private imqDunsUrl = '/vibe-plus/rest/imq/duns/';
  private imqFeinUrl = '/vibe-plus/rest/imq/fein/';
  private imqAddressUrl = '/vibe-plus/rest/imq/address';

  constructor(private http: HttpClient) { }

  getImqByDuns(duns: string): Observable<IndependentManualQueryResponseProxy> {
    const url = `${this.imqDunsUrl}${duns}`;
    return this.http.get<IndependentManualQueryResponseProxy>(url).pipe(
      tap(_ => console.log(`get IMQ by DUNS #=${duns}`)),
      catchError(this.handleError<IndependentManualQueryResponseProxy>(`error get duns # ${duns}`))
    );
  }

  getImqByFein(fein: string): Observable<IndependentManualQueryResponseProxy> {
    const url = `${this.imqFeinUrl}${fein}`;
    return this.http.get<IndependentManualQueryResponseProxy>(url).pipe(
      tap(_ => console.log(`get IMQ by FEIN #=${fein}`)),
      catchError(this.handleError<IndependentManualQueryResponseProxy>(`error get duns # ${fein}`))
    );
  }


 // VSRResubmitAddress
//   getImqByAddress(address: VSRResubmitAddress): Observable<IndependentManualQueryResponseProxy> {
// //  getImqByAddress(orgnanizationName: string, street: string, city: string, state: string, zip: string, country: string): Observable<IndependentManualQueryResponseProxy> {
//     const url = `${this.imqAddressUrl}org/${address.organizationName}/street/${address.streetFull}/city/${address.city}/state/${address.state}/zip/${address.postalCode}/country/${address.country}`;
//     return this.http.get<IndependentManualQueryResponseProxy>(url).pipe(
//       tap(_ => console.log(`get IMQ by address #=${url}`)),
//       catchError(this.handleError<IndependentManualQueryResponseProxy>(`get IMQ by address #=${url}`))
//     );
//   }


  getImqByAddress(address: VSRResubmitAddress): Observable<IndependentManualQueryResponseProxy>{
        
    let request : VSRResubmitRequest = new VSRResubmitRequest();
    request.endUserID=""; 
    request.address = address; 
    request.sourceSystemID="";
    request.sourceTransactionID=""; 

    console.log("imqAddress: ");
    console.log(request); 

      return this.http.post<IndependentManualQueryResponseProxy>(this.imqAddressUrl, request, {
        headers: new HttpHeaders({
          'Content-Type' : 'application/json'
        })
      }).pipe(tap(_ => console.log(`get IMQ by address #=${this.imqAddressUrl}`)),
         catchError(this.handleError<IndependentManualQueryResponseProxy>(`get IMQ by address #=${this.imqAddressUrl}`)));
  }

  /**
   * Handle Http operation that failed.
   * Let the app continue.
   * @param operation - name of the operation that failed
   * @param result - optional value to return as the observable result
   */
  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // TODO: better job of transforming error for user consumption
      console.log(`${operation} failed: ${error.message}`);

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }
  private log(message: string) {
    console.log(`VSR: ${message}`);

  }
}
