import { Component, Input, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { AppSettings } from '../shared/app-settings'
import { MapsAPILoader } from "@agm/core";
import { load, urlSettings } from 'google-maps-promise';
import { catchError, map, tap } from 'rxjs/operators';

@Component({
  selector: 'app-google-maps',
  templateUrl: './google-maps.component.html',
  styleUrls: ['./google-maps.component.css']
})
export class GoogleMapsComponent implements OnInit {
@Input() address: string = "";
// @Input() latitude : number = 51.678418;
// @Input() longitude : number = 7.809007;
showPetitionerAlert = false;
showIIPAlert = false;
showManualAlert = false;
alertMessage = AppSettings.GOOGLEMAPS_NO_STREETVIEW;
loadingmap = false;
  model = {
    lat: 0.0,
    long: 0.0  
  }

  geoInfo = [];
  constructor(private http: HttpClient) { }

  ngOnInit() { 
    this.getGeoLocationForAddress(this.address,'')
  }

  getGeoLocationForAddress(address, addressType) {
    try {
      this.getLatLongForAddress(address).subscribe(data => {

        if (data) {
          this.model.lat = JSON.parse(JSON.stringify(data)).results[0].geometry.location.lat;
          this.model.long = JSON.parse(JSON.stringify(data)).results[0].geometry.location.lng;
          var latlong = this.model.lat + "," + this.model.long;
          console.log("calling to load streetview.");
          this.loadStreetView(addressType);
        } else {
          this.model.lat = 0.0;
          this.model.long = 0.0;
        }
      });
    } catch (error) {
      this.model.lat = 0.0;
      this.model.long = 0.0;
    }
  }

  getLatLongForAddress(address = "111 Massachusetts Ave NW Washington, DC 20529") {


    var endpoint = `https://maps.googleapis.com/maps/api/geocode/json?address=${address}&key=${AppSettings.API_KEY}`;
    //var endpoint = `https://maps.googleapis.com/maps/api/geocode/json?address=${address}`;

   // console.log("endpoint="+endpoint)
    return this.http.get(endpoint).pipe(map(data => data))

}

private setWarnings(addressType) {
  switch (addressType) {
    case 'PETITION':

      this.showPetitionerAlert = true;
      break;

    case 'IIP':
      this.showIIPAlert = true;
      break;

    case 'MANUAL':
      this.showManualAlert = true;
      break;

    default:
      /// to clear warnings
      this.showPetitionerAlert = false;
      this.showIIPAlert = false;
      this.showManualAlert = false;
      break;

  }
}

async loadStreetView(addressType): Promise<void> {
  // if (document.getElementById('street-view').innerHTML) {
  //   return;
  // }

  this.setWarnings("");
  urlSettings.key = AppSettings.API_KEY;
  urlSettings.version = null;
  const Maps = await load();


  console.log(this.model.lat + this.model.long)
  var latlong = new Maps.LatLng(this.model.lat, this.model.long);
  // Or you can use `new google.maps.Map` instead
  var svService = new Maps.StreetViewService();
  var panoRequest = {
    location: latlong,
    preference: google.maps.StreetViewPreference.NEAREST,
    radius: 50,
    source: google.maps.StreetViewSource.OUTDOOR
  };


  new Maps.Map(document.getElementById('map'), {
    center: new Maps.LatLng(0.0, 0.0),
    zoom: 14
  });
  var self = this
  var something = svService.getPanorama(panoRequest, function (panoData, status) {
    console.log(panoData);
    console.log(status)

    if (status.toString() == 'OK') {

      new Maps.StreetViewPanorama(
        document.getElementById('map'),
        {
          pano: panoData.location.pano,
          pov: { heading: 280, pitch: 0 },
        });

    } else {
      console.log(addressType);
      self.setWarnings(addressType);
      self.alertMessage = AppSettings.GOOGLEMAPS_NO_STREETVIEW;
      console.log(self.showPetitionerAlert)


      try {
        var map = new Maps.Map(document.getElementById('map'), {
          center: latlong,
          zoom: 14
        });
        var marker = new Maps.Marker({
          position: latlong,
          map: map,
          title: "Location"
        });

      }
      catch (error) {
        console.log(error)
        self.alertMessage = AppSettings.GOOGLEMAPS_NO_MAP;
      }

      // this.showMap = true;
      //Handle other statuses here

    }
  });
}
}
