import { Title } from '@angular/platform-browser';
import { GeocodeService } from './geocode.service';
import { UserInRoleService } from './user-profile/user-in-role.service';
import { APP_BASE_HREF} from '@angular/common';
import { ExcelService } from './excel.service';

export const providers = [Title, GeocodeService, UserInRoleService, ExcelService, {provide: APP_BASE_HREF, useValue: '/vibe-plus'}  ];