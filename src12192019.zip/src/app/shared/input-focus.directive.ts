import { Directive, ElementRef, EventEmitter, Input } from '@angular/core';

@Directive({ selector: '[focus]' })
export class InputFocusDirective {
  private focusEmitterSubscription: any;

  @Input('focus')
  set focus(focusEmitter: EventEmitter<boolean>) {
    const self = this;
    if (this.focusEmitterSubscription) {
      this.focusEmitterSubscription.unsubscribe();
    }
    this.focusEmitterSubscription = focusEmitter.subscribe((focus: boolean) => {
      self.setFocus(focus);
    });
  }

  constructor(private element: ElementRef) {
  }

  private setFocus(focus: boolean) {
    if (focus) {
      this.element.nativeElement.focus();
    } else {
      this.element.nativeElement.blur();
    }
  }
}
