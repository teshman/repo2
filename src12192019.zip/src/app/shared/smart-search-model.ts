import { VSRResubmitAddress } from "./vsr-resubmit";

export class SmartSearchModel {
   
      searchById: string;
      disabledSearchById: boolean;
      searchType: string;
      searchByIdRegex: string;
      selectedSearchType: string;
      selectedSearchTypeIndex: number;
      selectedSearchFunction: string;
      helperText: string;
      functionDescription: string;
      error: string;
      address: VSRResubmitAddress;
      
  
}
