let obj: any = null;
export class PredefinedInformationProxy {
  public readonly PredefinedInformationGetListResponse: PredefinedInformationGetListResponseProxy;
  public static Parse(d: string): PredefinedInformationProxy {
    return PredefinedInformationProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): PredefinedInformationProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    d.PredefinedInformationGetListResponse = PredefinedInformationGetListResponseProxy.Create(d.PredefinedInformationGetListResponse, field + ".PredefinedInformationGetListResponse");
    return new PredefinedInformationProxy(d);
  }
  private constructor(d: any) {
    this.PredefinedInformationGetListResponse = d.PredefinedInformationGetListResponse;
  }
}


export class PredefinedInformationGetListResponseProxy {
    public readonly SourceSystemID: string;
    public readonly SourceTransactionID: string;
    public readonly ServiceRequestTimestamp: string;
    public readonly ServiceResponseTimestamp: string;
    public readonly AuditCorrelationID: string;
    public readonly PredefinedInformationResultSet: PredefinedInformationResultSetProxy;
  
    public static Parse(d: string): PredefinedInformationGetListResponseProxy {
      return PredefinedInformationGetListResponseProxy.Create(JSON.parse(d));
    }
    public static Create(d: any, field: string = 'root'): PredefinedInformationGetListResponseProxy {
      if (!field) {
        obj = d;
        field = "root";
      }
      if (d === null || d === undefined) {
        throwNull2NonNull(field, d);
      } else if (typeof(d) !== 'object') {
        throwNotObject(field, d, false);
      } else if (Array.isArray(d)) {
        throwIsArray(field, d, false);
      }
      checkString(d.SourceSystemID, false, field + ".SourceSystemID");
      checkString(d.SourceTransactionID, false, field + ".SourceTransactionID");
      checkString(d.ServiceRequestTimestamp, false, field + ".ServiceRequestTimestamp");
      checkString(d.ServiceResponseTimestamp, false, field + ".ServiceResponseTimestamp");
      checkString(d.AuditCorrelationID, false, field + ".AuditCorrelationID");
      d.PredefinedInformationResultSet = PredefinedInformationResultSetProxy.Create(d.PredefinedInformationResultSet, field + ".PredefinedInformationResultSet");
      return new PredefinedInformationGetListResponseProxy(d);
    }
    private constructor(d: any) {
      this.SourceSystemID = d.SourceSystemID;
      this.SourceTransactionID = d.SourceTransactionID;
      this.ServiceRequestTimestamp = d.ServiceRequestTimestamp;
      this.ServiceResponseTimestamp = d.ServiceResponseTimestamp;
      this.AuditCorrelationID = d.AuditCorrelationID;
      this.PredefinedInformationResultSet = d.PredefinedInformationResultSet;
    }
  }
  


  
export class PredefinedInformationResultSetProxy {
    public readonly lastRecordIndex: number;
    public readonly recordCountInThisResultSet: number;
    public readonly totalRecordCount: number;
    public readonly PredefinedInformation: PredefinedInformationEntityProxy[] | null;
    public static Parse(d: string): PredefinedInformationResultSetProxy {
      return PredefinedInformationResultSetProxy.Create(JSON.parse(d));
    }
    public static Create(d: any, field: string = 'root'): PredefinedInformationResultSetProxy {
      if (!field) {
        obj = d;
        field = "root";
      }
      if (d === null || d === undefined) {
        throwNull2NonNull(field, d);
      } else if (typeof(d) !== 'object') {
        throwNotObject(field, d, false);
      } else if (Array.isArray(d)) {
        throwIsArray(field, d, false);
      }
      checkNumber(d.lastRecordIndex, false, field + ".lastRecordIndex");
      checkNumber(d.recordCountInThisResultSet, false, field + ".recordCountInThisResultSet");
      checkNumber(d.totalRecordCount, false, field + ".totalRecordCount");
      checkArray(d.PredefinedInformation, field + ".PredefinedInformation");
      if (d.PredefinedInformation) {
        for (let i = 0; i < d.PredefinedInformation.length; i++) {
          d.PredefinedInformation[i] = PredefinedInformationEntityProxy.Create(d.PredefinedInformation[i], field + ".PredefinedInformation" + "[" + i + "]");
        }
      }
      if (d.PredefinedInformation === undefined) {
        d.PredefinedInformation = null;
      }
      return new PredefinedInformationResultSetProxy(d);
    }
    private constructor(d: any) {
      this.lastRecordIndex = d.lastRecordIndex;
      this.recordCountInThisResultSet = d.recordCountInThisResultSet;
      this.totalRecordCount = d.totalRecordCount;
      this.PredefinedInformation = d.PredefinedInformation;
    }
  }

  export class PredefinedInformationEntityProxy {
    public readonly PredefinedInformation: string;
    public readonly PivUpn: string;
  
  
  
    public static Parse(d: string): PredefinedInformationEntityProxy {
      return PredefinedInformationEntityProxy.Create(JSON.parse(d));
    }
    public static Create(d: any, field: string = 'root'): PredefinedInformationEntityProxy {
      if (!field) {
        obj = d;
        field = "root";
      }
      if (d === null || d === undefined) {
        throwNull2NonNull(field, d);
      } else if (typeof(d) !== 'object') {
        throwNotObject(field, d, false);
      } else if (Array.isArray(d)) {
        throwIsArray(field, d, false);
      }
      checkString(d.PredefinedInformation, false, field + ".PredefinedInformation");
      checkString(d.PivUpn, false, field + ".PivUpn");return new PredefinedInformationEntityProxy(d);
    }
    private constructor(d: any) {
      this.PredefinedInformation = d.PredefinedInformation;
      this.PivUpn = d.PivUpn;
    }
  }

  

  function throwNull2NonNull(field: string, d: any): never {
    return errorHelper(field, d, "non-nullable object", false);
  }
  function throwNotObject(field: string, d: any, nullable: boolean): never {
    return errorHelper(field, d, "object", nullable);
  }
  function throwIsArray(field: string, d: any, nullable: boolean): never {
    return errorHelper(field, d, "object", nullable);
  }
  function checkArray(d: any, field: string): void {
    if (!Array.isArray(d) && d !== null && d !== undefined) {
      errorHelper(field, d, "array", true);
    }
  }
  function checkNumber(d: any, nullable: boolean, field: string): void {
    if (typeof(d) !== 'number' && (!nullable || (nullable && d !== null && d !== undefined))) {
      errorHelper(field, d, "number", nullable);
    }
  }
  function checkBoolean(d: any, nullable: boolean, field: string): void {
    if (typeof(d) !== 'boolean' && (!nullable || (nullable && d !== null && d !== undefined))) {
      errorHelper(field, d, "boolean", nullable);
    }
  }
  function checkString(d: any, nullable: boolean, field: string): void {
    if (typeof(d) !== 'string' && (!nullable || (nullable && d !== null && d !== undefined))) {
      errorHelper(field, d, "string", nullable);
    }
  }
  function checkNull(d: any, field: string): void {
    if (d !== null && d !== undefined) {
      errorHelper(field, d, "null or undefined", false);
    }
  }
  function errorHelper(field: string, d: any, type: string, nullable: boolean): never {
    if (nullable) {
      type += ", null, or undefined";
    }
    throw new TypeError('Expected ' + type + " at " + field + " but found:\n" + JSON.stringify(d) + "\n\nFull object:\n" + JSON.stringify(obj));
  }
  