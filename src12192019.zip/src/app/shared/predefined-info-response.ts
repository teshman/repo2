import { ValidUntilDateRange, PredfinedInfoRequestAddress } from "./predefined-Info-request";

export class PredefinedInformationGetDetailResponse {
    duns: string;
    organizationName: string;
    address: PredfinedInfoRequestAddress;
    overrideScore: string;
    validUntilDateRange:ValidUntilDateRange;
    fdnsdsNumber: string;
    justificationComment: string;
    predefinedInformationComment: string;
    siteVisitProgram: string;
    nominationSource: string; 
    addedBy: string;
    processStatus: string;
    dateAdded: string;
    approvalDate: string;
    approvedBy: string;
    preDefFormCommentType: string;
    lastWizardStep: string;
    receiptNumber: string;
    fein: string;
    agn: string;
    iipConfidenceCode:number;
    office: string;
    operationCode: string;
    addressId: string;
    preDefCommentType: string;
    exceptionId: string;


    public constructor(
        fields?: {
            duns: string;
    organizationName: string;
    address: PredfinedInfoRequestAddress;
    overrideScore: string;
    validUntilDateRange:ValidUntilDateRange;
    fdnsdsNumber: string;
    justificationComment: string;
    predefinedInformationComment: string;
    siteVisitProgram: string;
    nominationSource: string; 
    AddedBy: string;
    ProcessStatus: string;
    DateAdded: string;
    ApprovalDate: string;
    ApprovedBy: string;
    preDefFormCommentType: string;
    lastWizardStep: string;

    receiptNumber: string;
    fein: string;
    agn: string;
    iipConfidenceCode:number;
    office: string;
    operationCode: string;
    addressId: string;
    exceptionId: string;
    preDefCommentType: string;
        }) {
        if (fields) Object.assign(this, fields);
    }
    public setValidUntilDateRange(startDate:string, endDate:string){
        this.validUntilDateRange = new ValidUntilDateRange();
        this.validUntilDateRange.startDate = startDate;
        this.validUntilDateRange.endDate = endDate;
    }
}

 