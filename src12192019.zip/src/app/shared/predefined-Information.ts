export interface PredefinedInformation {
    PredefinedInformationGetListResponse: PredefinedInformationGetListResponse;
  }
  export interface PredefinedInformationGetListResponse {
    SourceSystemID: string;
    SourceTransactionID: string;
    ServiceRequestTimestamp: string;
    ServiceResponseTimestamp: string;
    AuditCorrelationID: string;
    PredefinedInformationResultSet: PredefinedInformationResultSet;
  }
  export interface PredefinedInformationResultSet {
    lastRecordIndex: number;
    recordCountInThisResultSet: number;
    totalRecordCount: number;
    PredefinedInformationRecord?: (PredefinedInformationRecordEntity)[] | null;
  }
  export interface PredefinedInformationRecordEntity {   
    AddedBy: string;
    AgnID: string;
    ApprovalDate: string;
    ApprovedBy: string;
    Comment: string;
    DateAdded: string;
    DunsNumber: string;
    ExceptionID: string;
    FDNSDSNumber: string;
    LockedBy: string;
    LockedTime: string;
    OrganizationName: string;
    OverrideScore: string;
    preDefCommentT: string;
    preDefFormCommentT: string;
    ProcessStatus: string;
    ValidEndDate: string;
    ValidStartDate: string;
  }
  