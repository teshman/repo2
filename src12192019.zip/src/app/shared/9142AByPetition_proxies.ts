// Stores the currently-being-typechecked object for error messages.
let obj: any = null;
export class dol9142APetResponseProxy {
  public readonly GetDolDetailByPetitionIDResponse: GetDolDetailByPetitionIDResponseProxy;
  public static Parse(d: string): dol9142APetResponseProxy {
    return dol9142APetResponseProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): dol9142APetResponseProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    d.GetDolDetailByPetitionIDResponse = GetDolDetailByPetitionIDResponseProxy.Create(d.GetDolDetailByPetitionIDResponse, field + ".GetDolDetailByPetitionIDResponse");
    return new dol9142APetResponseProxy(d);
  }
  private constructor(d: any) {
    this.GetDolDetailByPetitionIDResponse = d.GetDolDetailByPetitionIDResponse;
  }
}

export class GetDolDetailByPetitionIDResponseProxy {
  public readonly SourceSystemID: string;
  public readonly SourceTransactionID: string;
  public readonly ServiceRequestTimestamp: string;
  public readonly ServiceResponseTimestamp: string;
  public readonly AuditCorrelationID: string;
  public readonly DolEtaFormType: string;
  public readonly DolEtaFormVersion: string;
  public readonly DolJsonData: string;
  public static Parse(d: string): GetDolDetailByPetitionIDResponseProxy {
    return GetDolDetailByPetitionIDResponseProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): GetDolDetailByPetitionIDResponseProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    checkString(d.SourceSystemID, false, field + ".SourceSystemID");
    checkString(d.SourceTransactionID, false, field + ".SourceTransactionID");
    checkString(d.ServiceRequestTimestamp, false, field + ".ServiceRequestTimestamp");
    checkString(d.ServiceResponseTimestamp, false, field + ".ServiceResponseTimestamp");
    checkString(d.AuditCorrelationID, false, field + ".AuditCorrelationID");
    checkString(d.DolEtaFormType, false, field + ".DolEtaFormType");
    checkString(d.DolEtaFormVersion, false, field + ".DolEtaFormVersion");
    checkString(d.DolJsonData, false, field + ".DolJsonData");
    return new GetDolDetailByPetitionIDResponseProxy(d);
  }
  private constructor(d: any) {
    this.SourceSystemID = d.SourceSystemID;
    this.SourceTransactionID = d.SourceTransactionID;
    this.ServiceRequestTimestamp = d.ServiceRequestTimestamp;
    this.ServiceResponseTimestamp = d.ServiceResponseTimestamp;
    this.AuditCorrelationID = d.AuditCorrelationID;
    this.DolEtaFormType = d.DolEtaFormType;
    this.DolEtaFormVersion = d.DolEtaFormVersion;
    this.DolJsonData = d.DolJsonData;
  }
}




function throwNull2NonNull(field: string, d: any): never {
  return errorHelper(field, d, "non-nullable object", false);
}
function throwNotObject(field: string, d: any, nullable: boolean): never {
  return errorHelper(field, d, "object", nullable);
}
function throwIsArray(field: string, d: any, nullable: boolean): never {
  return errorHelper(field, d, "object", nullable);
}
function checkArray(d: any, field: string): void {
  if (!Array.isArray(d) && d !== null && d !== undefined) {
    errorHelper(field, d, "array", true);
  }
}
function checkString(d: any, nullable: boolean, field: string): void {
  if (typeof(d) !== 'string' && (!nullable || (nullable && d !== null && d !== undefined))) {
    errorHelper(field, d, "string", nullable);
  }
}
function errorHelper(field: string, d: any, type: string, nullable: boolean): never {
  if (nullable) {
    type += ", null, or undefined";
  }
  throw new TypeError('Expected ' + type + " at " + field + " but found:\n" + JSON.stringify(d) + "\n\nFull object:\n" + JSON.stringify(obj));
}
