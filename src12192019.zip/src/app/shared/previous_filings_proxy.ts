// Stores the currently-being-typechecked object for error messages.
let obj: any = null;
export class previousfilingProxy {
  public readonly PreviousFilings_GetByDolCaseNumberResponse: PreviousFilings_GetByDolCaseNumberResponseProxy;
  public static Parse(d: string): previousfilingProxy {
    return previousfilingProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): previousfilingProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    d.PreviousFilings_GetByDolCaseNumberResponse = PreviousFilings_GetByDolCaseNumberResponseProxy.Create(d.PreviousFilings_GetByDolCaseNumberResponse, field + ".PreviousFilings-GetByDolCaseNumberResponse");
    return new previousfilingProxy(d);
  }
  private constructor(d: any) {
    this.PreviousFilings_GetByDolCaseNumberResponse = d.PreviousFilings_GetByDolCaseNumberResponse;
  }
}

export class PreviousFilings_GetByDolCaseNumberResponseProxy {
  public readonly SourceSystemID: string;
  public readonly SourceTransactionID: string;
  public readonly ServiceRequestTimestamp: string;
  public readonly ServiceResponseTimestamp: string;
  public readonly AuditCorrelationID: string;
  public readonly PreviousFilingsDolResultSet: PreviousFilingsDolResultSetProxy;
  public static Parse(d: string): PreviousFilings_GetByDolCaseNumberResponseProxy {
    return PreviousFilings_GetByDolCaseNumberResponseProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): PreviousFilings_GetByDolCaseNumberResponseProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    checkString(d.SourceSystemID, false, field + ".SourceSystemID");
    checkString(d.SourceTransactionID, false, field + ".SourceTransactionID");
    checkString(d.ServiceRequestTimestamp, false, field + ".ServiceRequestTimestamp");
    checkString(d.ServiceResponseTimestamp, false, field + ".ServiceResponseTimestamp");
    checkString(d.AuditCorrelationID, false, field + ".AuditCorrelationID");
    d.PreviousFilingsDolResultSet = PreviousFilingsDolResultSetProxy.Create(d.PreviousFilingsDolResultSet, field + ".PreviousFilingsDolResultSet");
    return new PreviousFilings_GetByDolCaseNumberResponseProxy(d);
  }
  private constructor(d: any) {
    this.SourceSystemID = d.SourceSystemID;
    this.SourceTransactionID = d.SourceTransactionID;
    this.ServiceRequestTimestamp = d.ServiceRequestTimestamp;
    this.ServiceResponseTimestamp = d.ServiceResponseTimestamp;
    this.AuditCorrelationID = d.AuditCorrelationID;
    this.PreviousFilingsDolResultSet = d.PreviousFilingsDolResultSet;
  }
}

export class PreviousFilingsDolResultSetProxy {
  public readonly lastRecordIndex: number;
  public readonly recordCountInThisResultSet: number;
  public readonly totalRecordCount: number;
  public readonly PreviousFilingDolRecord: PreviousFilingDolRecordEntityProxy[] | null;
  public static Parse(d: string): PreviousFilingsDolResultSetProxy {
    return PreviousFilingsDolResultSetProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): PreviousFilingsDolResultSetProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    checkNumber(d.lastRecordIndex, false, field + ".lastRecordIndex");
    checkNumber(d.recordCountInThisResultSet, false, field + ".recordCountInThisResultSet");
    checkNumber(d.totalRecordCount, false, field + ".totalRecordCount");
    checkArray(d.PreviousFilingDolRecord, field + ".PreviousFilingDolRecord");
    if (d.PreviousFilingDolRecord) {
      for (let i = 0; i < d.PreviousFilingDolRecord.length; i++) {
        d.PreviousFilingDolRecord[i] = PreviousFilingDolRecordEntityProxy.Create(d.PreviousFilingDolRecord[i], field + ".PreviousFilingDolRecord" + "[" + i + "]");
      }
    }
    if (d.PreviousFilingDolRecord === undefined) {
      d.PreviousFilingDolRecord = null;
    }
    return new PreviousFilingsDolResultSetProxy(d);
  }
  private constructor(d: any) {
    this.lastRecordIndex = d.lastRecordIndex;
    this.recordCountInThisResultSet = d.recordCountInThisResultSet;
    this.totalRecordCount = d.totalRecordCount;
    this.PreviousFilingDolRecord = d.PreviousFilingDolRecord;
  }
}

export class PreviousFilingDolRecordEntityProxy {
  public readonly ReceiptNumber: string;
  public readonly DolEtaCaseNumber: string;
  public readonly NumberOfBen: string;
  public readonly NumberOfApprBen: string;
  public readonly ReceiptDate: string;
  public readonly OrganizationName: string;
  public readonly FormType: string;
  public readonly EtaStatus: string;
  public static Parse(d: string): PreviousFilingDolRecordEntityProxy {
    return PreviousFilingDolRecordEntityProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): PreviousFilingDolRecordEntityProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    checkString(d.ReceiptNumber, false, field + ".ReceiptNumber");
    checkString(d.DolEtaCaseNumber, false, field + ".DolEtaCaseNumber");
    checkString(d.NumberOfBen, false, field + ".NumberOfBen");
    checkString(d.NumberOfApprBen, false, field + ".NumberOfApprBen");
    checkString(d.ReceiptDate, false, field + ".ReceiptDate");
    checkString(d.OrganizationName, false, field + ".OrganizationName");
    checkString(d.FormType, false, field + ".FormType");
    checkString(d.EtaStatus, false, field + ".EtaStatus");
    return new PreviousFilingDolRecordEntityProxy(d);
  }
  private constructor(d: any) {
    this.ReceiptNumber = d.ReceiptNumber;
    this.DolEtaCaseNumber = d.DolEtaCaseNumber;
    this.NumberOfBen = d.NumberOfBen;
    this.NumberOfApprBen = d.NumberOfApprBen;
    this.ReceiptDate = d.ReceiptDate;
    this.OrganizationName = d.OrganizationName;
    this.FormType = d.FormType;
    this.EtaStatus = d.EtaStatus;
  }
}

function throwNull2NonNull(field: string, d: any): never {
  return errorHelper(field, d, "non-nullable object", false);
}
function throwNotObject(field: string, d: any, nullable: boolean): never {
  return errorHelper(field, d, "object", nullable);
}
function throwIsArray(field: string, d: any, nullable: boolean): never {
  return errorHelper(field, d, "object", nullable);
}
function checkArray(d: any, field: string): void {
  if (!Array.isArray(d) && d !== null && d !== undefined) {
    errorHelper(field, d, "array", true);
  }
}
function checkNumber(d: any, nullable: boolean, field: string): void {
  if (typeof(d) !== 'number' && (!nullable || (nullable && d !== null && d !== undefined))) {
    errorHelper(field, d, "number", nullable);
  }
}
function checkString(d: any, nullable: boolean, field: string): void {
  if (typeof(d) !== 'string' && (!nullable || (nullable && d !== null && d !== undefined))) {
    errorHelper(field, d, "string", nullable);
  }
}
function errorHelper(field: string, d: any, type: string, nullable: boolean): never {
  if (nullable) {
    type += ", null, or undefined";
  }
  throw new TypeError('Expected ' + type + " at " + field + " but found:\n" + JSON.stringify(d) + "\n\nFull object:\n" + JSON.stringify(obj));
}
