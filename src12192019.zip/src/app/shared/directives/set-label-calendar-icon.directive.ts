import { NgZone, Directive, ElementRef, AfterContentInit, Renderer2, Input } from '@angular/core';

@Directive({
  selector: '[thisIsCalendarParent]'
})
export class SetLabelCalendarIconDirective implements AfterContentInit{
 
  constructor(private el: ElementRef, private zone: NgZone, private renderer: Renderer2) {}

  ngAfterContentInit() {
    this.zone.runOutsideAngular(() => setTimeout(() => {
       
      
      if (this.el.nativeElement.getElementsByClassName("clr-input-group-icon-action")[0]!=undefined || ""){
        this.el.nativeElement.getElementsByClassName("clr-input-group-icon-action")[0].setAttribute('title','Start Date')
      }
      if (this.el.nativeElement.getElementsByClassName("clr-input-group-icon-action")[1]!=undefined || ""){
        this.el.nativeElement.getElementsByClassName("clr-input-group-icon-action")[1].setAttribute('title','End Date')
      }
        //this.renderer.selectRootElement(this.el.nativeElement).focus();
        // this.el.nativeElement.focus();

    }, 0));
}

}
