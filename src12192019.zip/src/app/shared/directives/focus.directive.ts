import { NgZone, Directive, ElementRef, AfterContentInit, Renderer2 } from '@angular/core';

@Directive({
  selector: '[focusOnMe]'
})


@Directive({
    selector: '[focusOnMe]'
})
export class FocusDirective implements AfterContentInit {
    constructor(private el: ElementRef, private zone: NgZone, private renderer: Renderer2) {}

    ngAfterContentInit() {
        this.zone.runOutsideAngular(() => setTimeout(() => {
            console.log("focusOnMe directive called");
            //this.renderer.selectRootElement(this.el.nativeElement).focus();
            this.el.nativeElement.focus();

        }, 0));
    }
}
