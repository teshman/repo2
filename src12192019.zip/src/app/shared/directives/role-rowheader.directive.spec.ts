import { RoleRowheaderDirective } from './role-rowheader.directive';

describe('RoleRowheaderDirective', () => {
  it('should create an instance', () => {
    const directive = new RoleRowheaderDirective();
    expect(directive).toBeTruthy();
  });
});
