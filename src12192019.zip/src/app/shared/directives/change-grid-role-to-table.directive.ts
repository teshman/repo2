import { NgZone, Directive, ElementRef, AfterContentInit, Renderer2 } from '@angular/core';

@Directive({
  selector: '[changeGridRoleToTable]'
})
export class ChangeGridRoleToTableDirective implements AfterContentInit {

    constructor(private el: ElementRef, private zone: NgZone, private renderer: Renderer2) {}

    ngAfterContentInit() {
        this.zone.runOutsideAngular(() => setTimeout(() => {
            console.log("changeGridRoleToTable directive called");
            //this.renderer.selectRootElement(this.el.nativeElement).focus();
            let e =this.el.nativeElement.querySelector(".datagrid-table-wrapper").setAttribute("role","table")
        }, 0));
    }
}
