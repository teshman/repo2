import { Directive, AfterContentInit, ElementRef, NgZone, Renderer2 } from '@angular/core';

@Directive({
  selector: '[roleRowheader]'
})
export class RoleRowheaderDirective implements AfterContentInit {

  constructor(private el: ElementRef, private zone: NgZone, private renderer: Renderer2) { }

  ngAfterContentInit() {
    this.zone.runOutsideAngular(() => setTimeout(() => {
      // console.log("roleRowheader directive called");
      // console.log(this);
      //this.renderer.selectRootElement(this.el.nativeElement).focus();
      let e = this.el.nativeElement.setAttribute("role", "rowheader")

    }, 0));
  }
}

