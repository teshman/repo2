import { NgZone, Directive, ElementRef, AfterContentInit, Renderer2, SimpleChanges, AfterViewChecked } from '@angular/core';

@Directive({
  selector: '[arrow-title-fix]'
})
export class ArrowTitleFixDirective implements AfterContentInit, AfterViewChecked{

  ngAfterViewChecked(): void {
    // console.log("pagination ... something changed."); 
  
    this.zone.runOutsideAngular(() => setTimeout(() => {
      //  console.log("pagination arrow-title-fix called");
      //querySelector('button[class="pagination-next"]') 
      if (document.querySelector('button[class="pagination-next"]')){
        // console.log("pagination found > ... called");
        this.el.nativeElement.querySelector('button[class="pagination-next"]').setAttribute('title','NEXT')
      }

      if (document.querySelector('button[class="pagination-previous"]')){
        // console.log("pagination found < ... called");
        this.el.nativeElement.querySelector('button[class="pagination-previous"]').setAttribute('title','PREVIOUS')
      }
        //this.renderer.selectRootElement(this.el.nativeElement).focus();
        // this.el.nativeElement.focus();

    }, 0));
    
  }

  ngAfterContentInit(): void {
   // throw new Error("Method not implemented.");
  }
 
  constructor(private el: ElementRef, private zone: NgZone, private renderer: Renderer2) {}

  
  ngOnChanges(changes: SimpleChanges) {
    // console.log("ngOnChanges called.... "); 

  }
}


