import { Directive, ElementRef, NgZone, Renderer2 } from '@angular/core';

@Directive({
  selector: '[appClick]'
})
export class ClickThis {

  constructor(private el: ElementRef, private zone: NgZone, private renderer: Renderer2) {}

    ngAfterContentInit() {
        this.zone.runOutsideAngular(() => setTimeout(() => {
            console.log("appClick directive called");
            //this.renderer.selectRootElement(this.el.nativeElement).focus();
            this.el.nativeElement.click();

        }, 0));
    }
    public clickThisNow(){
      console.log("appClick method called");
      this.el.nativeElement.click();
    }

}
