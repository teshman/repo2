// Stores the currently-being-typechecked object for error messages.
let obj: any = null;
export class LoginHistoryRequestProxy {
  public readonly LoginHistoryRequest: LoginHistoryRequest1Proxy;
  public static Parse(d: string): LoginHistoryRequestProxy {
    return LoginHistoryRequestProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): LoginHistoryRequestProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    d.LoginHistoryRequest = LoginHistoryRequest1Proxy.Create(d.LoginHistoryRequest, field + ".LoginHistoryRequest");
    return new LoginHistoryRequestProxy(d);
  }
  private constructor(d: any) {
    this.LoginHistoryRequest = d.LoginHistoryRequest;
  }
}

export class LoginHistoryRequest1Proxy {
  public readonly sourceSystemID: string;
  public readonly sourceTransactionID: string;
  public readonly endUserID: string;
  public readonly cisUser: string;
  public readonly pivUpn: string;
  public readonly picsID: string;
  public readonly email: string;
  public readonly nameFirst: string;
  public readonly nameLast: string;
  public readonly nameDisplay: string;
  public readonly cisRoles: string;
  public readonly cisRegion: string;
  public readonly cisSite: string;
  public readonly cisDistrict: string;
  public readonly organizationName: string;
  public static Parse(d: string): LoginHistoryRequest1Proxy {
    return LoginHistoryRequest1Proxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): LoginHistoryRequest1Proxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    checkString(d.sourceSystemID, false, field + ".sourceSystemID");
    checkString(d.sourceTransactionID, false, field + ".sourceTransactionID");
    checkString(d.endUserID, false, field + ".endUserID");
    checkString(d.cisUser, false, field + ".cisUser");
    checkString(d.pivUpn, false, field + ".pivUpn");
    checkString(d.picsID, false, field + ".picsID");
    checkString(d.email, false, field + ".email");
    checkString(d.nameFirst, false, field + ".nameFirst");
    checkString(d.nameLast, false, field + ".nameLast");
    checkString(d.nameDisplay, false, field + ".nameDisplay");
    checkString(d.cisRoles, false, field + ".cisRoles");
    checkString(d.cisRegion, false, field + ".cisRegion");
    checkString(d.cisSite, false, field + ".cisSite");
    checkString(d.cisDistrict, false, field + ".cisDistrict");
    checkString(d.organizationName, false, field + ".organizationName");
    return new LoginHistoryRequest1Proxy(d);
  }
  private constructor(d: any) {
    this.sourceSystemID = d.sourceSystemID;
    this.sourceTransactionID = d.sourceTransactionID;
    this.endUserID = d.endUserID;
    this.cisUser = d.cisUser;
    this.pivUpn = d.pivUpn;
    this.picsID = d.picsID;
    this.email = d.email;
    this.nameFirst = d.nameFirst;
    this.nameLast = d.nameLast;
    this.nameDisplay = d.nameDisplay;
    this.cisRoles = d.cisRoles;
    this.cisRegion = d.cisRegion;
    this.cisSite = d.cisSite;
    this.cisDistrict = d.cisDistrict;
    this.organizationName = d.organizationName;
  }
}

function throwNull2NonNull(field: string, d: any): never {
  return errorHelper(field, d, "non-nullable object", false);
}
function throwNotObject(field: string, d: any, nullable: boolean): never {
  return errorHelper(field, d, "object", nullable);
}
function throwIsArray(field: string, d: any, nullable: boolean): never {
  return errorHelper(field, d, "object", nullable);
}
function checkString(d: any, nullable: boolean, field: string): void {
  if (typeof(d) !== 'string' && (!nullable || (nullable && d !== null && d !== undefined))) {
    errorHelper(field, d, "string", nullable);
  }
}
function errorHelper(field: string, d: any, type: string, nullable: boolean): never {
  if (nullable) {
    type += ", null, or undefined";
  }
  throw new TypeError('Expected ' + type + " at " + field + " but found:\n" + JSON.stringify(d) + "\n\nFull object:\n" + JSON.stringify(obj));
}
