export interface Dol {
  GetDolDetailByEtaCaseNumberResponse: GetDolDetailByEtaCaseNumberResponse;
}
export interface GetDolDetailByEtaCaseNumberResponse {
  SourceSystemID: string;
  SourceTransactionID: string;
  ServiceRequestTimestamp: string;
  ServiceResponseTimestamp: string;
  AuditCorrelationID: string;
  ResponseStatusMessage: ResponseStatusMessage;
  DolEtaFormType: string;
  DolEtaFormVersion: string;
  DolJsonData: string;
}
export interface ResponseStatusMessage {
  StatusCode: string;
  Status: string;
}
export interface DolData {
  DOL_DATA: DOLDATA;
}
export interface DOLDATA {
  DOL_ETA_CLOB?: (DOLETACLOBEntity)[] | DOLETACLOB;
  DOL_ETA_EMPLOYERS?: (DOLETAEMPLOYERSEntity)[] | DOLETAEMPLOYERS;
  DOL_ETA_WORKSITES?: (DOLETAWORKSITESEntity)[] | DOLETAWORKSITES;
}
export interface DOLETACLOBEntity {
  VISA_CLASS: string;
  TEMPNEED_JOBTITLE: string;
  TEMPNEED_SOC: string;
  TEMPNEED_SOC_TITLE: string;
  TEMPNEED_FULLTIME: string;
  TEMPNEED_START: string;
  TEMPNEED_END: string;
  TEMPNEED_WKR_POS: string;
  NEW_EMP: string;
  CONT_PREV: string;
  CHANGE_PREV: string;
  NEW_CONCUR: string;
  CHANGE_EMP: string;
  AMEND_PET: string;
  TEMPNEED_NATURE: string;
  TEMPNEED_DESCRIPTION: string;
  CASE_NUMBER: string;
  CASE_STATUS: string;
  CASE_VALID_FROM: string;
  CASE_VALID_TO: string;
  EMP_BUSINESS_NAME: string;
  EMP_TRADE_NAME: string;
  EMP_ADDR1: string;
  EMP_ADDR2: string;
  EMP_CITY: string;
  EMP_STATE: string;
  EMP_POSTCODE: string;
  EMP_COUNTRY: string;
  EMP_PROVINCE: string;
  EMP_PHONE: string;
  EMP_PHONEEXT: string;
  EMP_FEIN: string;
  EMP_NAICS: string;
  EMP_NUMEMPLOYEES: string;
  EMP_GROSSRECEIPTS: string;
  EMP_YEAREST: string;
  EMP_TYPE: string;
  EMPPOC_LASTNAME: string;
  EMPPOC_FIRSTNAME: string;
  EMPPOC_MIDDLENAME: string;
  EMPPOC_JOBTITLE: string;
  EMPPOC_ADDR1: string;
  EMPPOC_ADDR2: string;
  EMPPOC_CITY: string;
  EMPPOC_STATE: string;
  EMPPOC_POSTCODE: string;
  EMPPOC_COUNTRY: string;
  EMPPOC_PROVINCE: string;
  EMPPOC_PHONE: string;
  EMPPOC_PHONEEXT: string;
  EMPPOC_EMAIL: string;
  ATTY_REPRESENT: string;
  ATTY_LASTNAME: string;
  ATTY_FIRSTNAME: string;
  ATTY_MIDDLENAME: string;
  ATTY_ADDR1: string;
  ATTY_ADDR2: string;
  ATTY_CITY: string;
  ATTY_STATE: string;
  ATTY_POSTCODE: string;
  ATTY_COUNTRY: string;
  ATTY_PROVINCE: string;
  ATTY_PHONE: string;
  ATTY_PHONEEXT: string;
  ATTY_EMAIL: string;
  ATTY_BIZNAME: string;
  ATTY_FEIN: string;
  ATTY_STATEBARNO: string;
  ATTY_STATEHIGHCT: string;
  ATTY_NAMEHIGHCT: string;
  JOB_TITLE: string;
  JOB_HOURSPERWK: string;
  JOB_HOURSTART: string;
  JOB_HOUREND: string;
  JOB_SUPERVISOR: string;
  JOB_NUMBER_SUP: string;
  JOB_DUTIES: string;
  JOB_MINEDU: string;
  JOB_MINOTHER: string;
  JOB_MINEDUMAJOR: string;
  JOB_MINSECDEGREE: string;
  JOB_MINSECDEGTYPE: string;
  JOB_MINTRAINING: string;
  JOB_MINTRAININGMONTHS: string;
  JOB_MINTRAINFIELD: string;
  JOB_MINEXP: string;
  JOB_MINEXPMONTHS: string;
  JOB_MINEXPOCCU: string;
  JOB_MINSPECIALREQ: string;
  JOB_ADDR1: string;
  JOB_ADDR2: string;
  JOB_CITY: string;
  JOB_COUNTY: string;
  JOB_STATE: string;
  JOB_POSTCODE: string;
  JOB_MULITPLESITES: string;
  WAGE_FROM: string;
  WAGE_TO: string;
  WAGE_OTFROM: string;
  WAGE_OT_TO: string;
  WAGE_PER: string;
  WAGE_PIECE: string;
  WAGE_ADDITIONAL: string;
  REC_SWANAME: string;
  REC_JOBORDER: string;
  REC_JOBORDSTART: string;
  REC_JOBORDEND: string;
  REC_SUNDAYPAPER: string;
  REC_PAPERNAMES: string;
  REC_POSTFROM: string;
  REC_POSTTO: string;
  REC_ADDITIONAL: string;
  DECLARE_AGREE_H2A: string;
  DECLARE_AGREE_H2B: string;
  PREP_LASTNAME: string;
  PREP_FIRSTNAME: string;
  PREP_MIDDLENAME: string;
  PREP_JOBTITLE: string;
  PREP_BIZNAME: string;
  PREP_EMAIL: string;
  CASE_DETERM: string;
  CASE_SUBMIT: string;
  CHANGED_DATE: string;
  LASTMOD_DATE: string;
  SUBMIT_IPADDRESS: string;
  RNUM: string;
  RECEIPT_NUMBER_SUMMARY:string;
}
export interface DOLETAWORKSITESEntity {
  CASE_NUMBER: string;
  LASTMOD_DATE: string;
  JOB_ADDR1: string;
  JOB_ADDR2: string;
  JOB_CITY: string;
  JOB_COUNTY: string;
  JOB_STATE: string;
  JOB_POSTCODE: string;
  JOB_MULITPLESITES: string;
  STATE_TERRITORY: string;
  AREA_BASED_ON: string;
  AREA: string;
  RNUM: string;
}
export interface DOLETAEMPLOYERSEntity {
  CASE_NUMBER: string;
  LASTMOD_DATE: string;
  EMP_BUSINESS_NAME: string;
  EMP_TRADE_NAME: string;
  EMP_ADDR1: string;
  EMP_ADDR2: string;
  EMP_CITY: string;
  EMP_STATE: string;
  EMP_POSTCODE: string;
  EMP_COUNTRY: string;
  EMP_PROVINCE: string;
  EMP_PHONE: string;
  EMP_PHONEEXT: string;
  EMP_FEIN: string;
  EMP_NAICS: string;
  NAICS_TEXT: string;
  EMP_NUMEMPLOYEES: string;
  EMP_GROSSRECEIPTS: string;
  EMP_YEAREST: string;
  EMP_TYPE: string;
  SUB_CERTIFIED: string;
  SUB_CERT_BEGIN_DATE: string;
  SUB_CERT_END_DATE: string;
  RNUM: string;
}

export interface DOLETACLOB {
  RESPONSECODE: string;
  RESPONSEMESSAGE: string;
  DOLCASENUMBER: string;
}

export interface DOLETAWORKSITES {
  RESPONSECODE: string;
  RESPONSEMESSAGE: string;
  DOLCASENUMBER: string;
}

export interface DOLETAEMPLOYERS {
  RESPONSECODE: string;
  RESPONSEMESSAGE: string;
  DOLCASENUMBER: string;
}
