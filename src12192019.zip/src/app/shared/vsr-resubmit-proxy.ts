// Stores the currently-being-typechecked object for error messages.
let obj: any = null;
export class VsrResubmitProxy {
  public readonly VsrResubmitResponse: VsrResubmitResponseProxy;
  public static Parse(d: string): VsrResubmitProxy {
    return VsrResubmitProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): VsrResubmitProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    d.VsrResubmitResponse = VsrResubmitResponseProxy.Create(d.VsrResubmitResponse, field + ".VsrResubmitResponse");
    return new VsrResubmitProxy(d);
  }
  private constructor(d: any) {
    this.VsrResubmitResponse = d.VsrResubmitResponse;
  }
}

export class VsrResubmitResponseProxy {
  public readonly SourceSystemID: string;
  public readonly SourceTransactionID: string;
  public readonly ServiceRequestTimestamp: string;
  public readonly ServiceResponseTimestamp: string;
  public readonly AuditCorrelationID: string;
  public readonly ResponseStatusMessage: ResponseStatusMessageProxy;
  public readonly VsrResultSet: VsrResultSetProxy;
  public static Parse(d: string): VsrResubmitResponseProxy {
    return VsrResubmitResponseProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): VsrResubmitResponseProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    checkString(d.SourceSystemID, false, field + ".SourceSystemID");
    checkString(d.SourceTransactionID, false, field + ".SourceTransactionID");
    checkString(d.ServiceRequestTimestamp, false, field + ".ServiceRequestTimestamp");
    checkString(d.ServiceResponseTimestamp, false, field + ".ServiceResponseTimestamp");
    checkString(d.AuditCorrelationID, false, field + ".AuditCorrelationID");
    d.ResponseStatusMessage = ResponseStatusMessageProxy.Create(d.ResponseStatusMessage, field + ".ResponseStatusMessage");
    d.VsrResultSet = VsrResultSetProxy.Create(d.VsrResultSet, field + ".VsrResultSet");
    return new VsrResubmitResponseProxy(d);
  }
  private constructor(d: any) {
    this.SourceSystemID = d.SourceSystemID;
    this.SourceTransactionID = d.SourceTransactionID;
    this.ServiceRequestTimestamp = d.ServiceRequestTimestamp;
    this.ServiceResponseTimestamp = d.ServiceResponseTimestamp;
    this.AuditCorrelationID = d.AuditCorrelationID;
    this.ResponseStatusMessage = d.ResponseStatusMessage;
    this.VsrResultSet = d.VsrResultSet;
  }
}

export class ResponseStatusMessageProxy {
  public readonly StatusCode: string;
  public readonly Status: string;
  public static Parse(d: string): ResponseStatusMessageProxy {
    return ResponseStatusMessageProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): ResponseStatusMessageProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    checkString(d.StatusCode, false, field + ".StatusCode");
    checkString(d.Status, false, field + ".Status");
    return new ResponseStatusMessageProxy(d);
  }
  private constructor(d: any) {
    this.StatusCode = d.StatusCode;
    this.Status = d.Status;
  }
}

export class VsrResultSetProxy {
  public readonly lastRecordIndex: number;
  public readonly recordCountInThisResultSet: number;
  public readonly totalRecordCount: number;
  public readonly VsrRecord: VsrRecordEntityProxy[] | null;
  public static Parse(d: string): VsrResultSetProxy {
    return VsrResultSetProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): VsrResultSetProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    checkNumber(d.lastRecordIndex, false, field + ".lastRecordIndex");
    checkNumber(d.recordCountInThisResultSet, false, field + ".recordCountInThisResultSet");
    checkNumber(d.totalRecordCount, false, field + ".totalRecordCount");
    checkArray(d.VsrRecord, field + ".VsrRecord");
    if (d.VsrRecord) {
      for (let i = 0; i < d.VsrRecord.length; i++) {
        d.VsrRecord[i] = VsrRecordEntityProxy.Create(d.VsrRecord[i], field + ".VsrRecord" + "[" + i + "]");
      }
    }
    if (d.VsrRecord === undefined) {
      d.VsrRecord = null;
    }
    return new VsrResultSetProxy(d);
  }
  private constructor(d: any) {
    this.lastRecordIndex = d.lastRecordIndex;
    this.recordCountInThisResultSet = d.recordCountInThisResultSet;
    this.totalRecordCount = d.totalRecordCount;
    this.VsrRecord = d.VsrRecord;
  }
}

export class VsrRecordEntityProxy {
  public readonly ScoreID: string;
  public readonly AdjudicativeStatus: string;
  public readonly ReceiptNumber: string;
  public readonly Fein: string;
  public readonly PetitionInformation: PetitionInformationProxy;
  public readonly VIBEScoreResult: VIBEScoreResultProxy;
  public readonly DNBMatchedBranchInformation: DNBMatchedBranchInformationProxy | null;
  public readonly DNBMatchedCompanyInformation: DNBMatchedCompanyInformationProxy;
  public readonly DNBDetailedCompanyInformation: DNBDetailedCompanyInformationProxy;
  public readonly DNBCompanyExecutiveBio: DNBCompanyExecutiveBioProxy;
  public readonly DNBCompanyFinancialInformation: DNBCompanyFinancialInformationProxy;
  public readonly DOLSummaryProxy: DOLSummaryProxy;
  public readonly ManualSearchInfo: ManualSearchInfoProxy | null;
  public static Parse(d: string): VsrRecordEntityProxy {
    return VsrRecordEntityProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): VsrRecordEntityProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    checkString(d.ScoreID, false, field + ".ScoreID");
    checkString(d.AdjudicativeStatus, false, field + ".AdjudicativeStatus");
    checkString(d.Fein, false, field + ".Fein");
    checkString(d.ReceiptNumber, false, field + ".ReceiptNumber");
    d.PetitionInformation = PetitionInformationProxy.Create(d.PetitionInformation, field + ".PetitionInformation");
    d.VIBEScoreResult = VIBEScoreResultProxy.Create(d.VIBEScoreResult, field + ".VIBEScoreResult");
    d.DNBMatchedBranchInformation = DNBMatchedBranchInformationProxy.Create(d.DNBMatchedBranchInformation, field + ".DNBMatchedBranchInformation");
    if (d.DNBMatchedBranchInformation === undefined) {
      d.DNBMatchedBranchInformation = null;
    }
    d.DNBMatchedCompanyInformation = DNBMatchedCompanyInformationProxy.Create(d.DNBMatchedCompanyInformation, field + ".DNBMatchedCompanyInformation");
    d.DNBDetailedCompanyInformation = DNBDetailedCompanyInformationProxy.Create(d.DNBDetailedCompanyInformation, field + ".DNBDetailedCompanyInformation");
    d.DNBCompanyExecutiveBio = DNBCompanyExecutiveBioProxy.Create(d.DNBCompanyExecutiveBio, field + ".DNBCompanyExecutiveBio");
    d.DNBCompanyFinancialInformation = DNBCompanyFinancialInformationProxy.Create(d.DNBCompanyFinancialInformation, field + ".DNBCompanyFinancialInformation");
    d.ManualSearchInfo = ManualSearchInfoProxy.Create(d.ManualSearchInfo, field + ".ManualSearchInfo");
    if (d.ManualSearchInfo === undefined) {
      d.ManualSearchInfo = null;
    }
    return new VsrRecordEntityProxy(d);
  }
  private constructor(d: any) {
    this.ScoreID = d.ScoreID;
    this.AdjudicativeStatus = d.AdjudicativeStatus;
    this.Fein = d.Fein;
    this.ReceiptNumber = d.ReceiptNumber;
    this.PetitionInformation = d.PetitionInformation;
    this.VIBEScoreResult = d.VIBEScoreResult;
    this.DNBMatchedBranchInformation = d.DNBMatchedBranchInformation;
    this.DNBMatchedCompanyInformation = d.DNBMatchedCompanyInformation;
    this.DNBDetailedCompanyInformation = d.DNBDetailedCompanyInformation;
    this.DNBCompanyExecutiveBio = d.DNBCompanyExecutiveBio;
    this.DNBCompanyFinancialInformation = d.DNBCompanyFinancialInformation;
    this.ManualSearchInfo = d.ManualSearchInfo;
  }
}

export class DOLSummaryProxy {
  public readonly PetitionID: string;
  public readonly EtaStatus: string;
  public readonly EtaCaseNumber: string;
  public readonly FilingDate: string;
  public readonly EtaVisaType: string;
  public readonly EmployerName: string;
  public readonly Fein: string;
  public readonly JobTitle: string;
  public readonly TotalWorkerPositions: string;
  public readonly ValidStartDate: string;
  public readonly ValidEndDate: string;
  public readonly PreviousEtaFilings: string;
  public readonly DolEtaClobId: string;


  public static Parse(d: string): DOLSummaryProxy {
   return DOLSummaryProxy.Create(JSON.parse(d));
 }
 public static Create(d: any, field: string = 'root'): DOLSummaryProxy {
   if (!field) {
     obj = d;
     field = "root";
   }
   if (d === null || d === undefined) {
     throwNull2NonNull(field, d);
   } else if (typeof (d) !== 'object') {
     throwNotObject(field, d, false);
   } else if (Array.isArray(d)) {
     throwIsArray(field, d, false);
   }
   checkString(d.PetitionID, false, field + ".PetitionID");
   checkNumber(d.EtaStatus, false, field + ".EtaStatus");
   checkString(d.EtaCaseNumber, false, field + ".EtaCaseNumber");
   checkNumber(d.FilingDate, false, field + ".FilingDate");
   checkString(d.EtaVisaType, false, field + ".EtaVisaType");
   checkNumber(d.EmployerName, false, field + ".EmployerName");
   checkString(d.Fein, false, field + ".Fein");
   checkNumber(d.JobTitle, false, field + ".JobTitle");
   checkNumber(d.TotalWorkerPositions, false, field + ".TotalWorkerPositions");
   checkNumber(d.ValidStartDate, false, field + ".ValidStartDate");
   checkNumber(d.ValidEndDate, false, field + ".ValidEndDate");
   checkNumber(d.PreviousEtaFilings, false, field + ".PreviousEtaFilings");
   checkNumber(d.DolEtaClobId, false, field + ".DolEtaClobId");
   return new DOLSummaryProxy(d);
 }
 private constructor(d: any) {
  this.PetitionID = d.PetitionID;
  this.EtaStatus = d.EtaStatus;
  this.EtaCaseNumber = d.EtaCaseNumber;
  this.FilingDate = d.FilingDate;
  this.EtaVisaType = d.EtaVisaType;
  this.EmployerName = d.EmployerName;
  this.Fein = d.Fein;
  this.JobTitle = d.JobTitle;
  this.TotalWorkerPositions = d.TotalWorkerPositions;
  this.ValidStartDate = d.ValidStartDate;
  this.ValidEndDate = d.ValidEndDate;
  this.PreviousEtaFilings = d.PreviousEtaFilings;
  this.DolEtaClobId = d.DolEtaClobId;
 }

}

export class PetitionInformationProxy {
  public readonly ReceiptNumber: string;
  public readonly PetitionVisaType: string;
  public readonly PetitionType: string;
  public readonly ReceiptDate: string;
  public readonly RecordTimeStamp: string;
  public readonly OrganizationDataSource: string;
  public readonly OrganizationName: string;
  public readonly Address: AddressProxy;
  public readonly DolEtaCaseNumber: string;
  public readonly Fein: string;
  public static Parse(d: string): PetitionInformationProxy {
    return PetitionInformationProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): PetitionInformationProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    checkString(d.ReceiptNumber, false, field + ".ReceiptNumber");
    checkString(d.PetitionVisaType, false, field + ".PetitionVisaType");
    checkString(d.PetitionType, false, field + ".PetitionType");
    checkString(d.ReceiptDate, false, field + ".ReceiptDate");
    checkString(d.RecordTimeStamp, false, field + ".RecordTimeStamp");
    checkString(d.OrganizationDataSource, false, field + ".OrganizationDataSource");
    checkString(d.OrganizationName, false, field + ".OrganizationName");
    d.Address = AddressProxy.Create(d.Address, field + ".Address");
    checkString(d.DolEtaCaseNumber, false, field + ".DolEtaCaseNumber");
    checkString(d.Fein, false, field + ".Fein");
    return new PetitionInformationProxy(d);
  }
  private constructor(d: any) {
    this.ReceiptNumber = d.ReceiptNumber;
    this.PetitionVisaType = d.PetitionVisaType;
    this.PetitionType = d.PetitionType;
    this.ReceiptDate = d.ReceiptDate;
    this.RecordTimeStamp = d.RecordTimeStamp;
    this.OrganizationDataSource = d.OrganizationDataSource;
    this.OrganizationName = d.OrganizationName;
    this.Address = d.Address;
    this.DolEtaCaseNumber = d.DolEtaCaseNumber;
    this.Fein = d.Fein;
  }
}

export class AddressProxy {
  public readonly AddressID: string;
  public readonly StreetFullText: string;
  public readonly StreetExtensionText: string;
  public readonly LocationCityName: string;
  public readonly LocationPostalCode: string;
  public readonly LocationStateName: string;
  public readonly LocationCountryName: LocationCountryNameOrStreetExtensionTextProxy;
  public static Parse(d: string): AddressProxy {
    return AddressProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): AddressProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    checkString(d.AddressID, false, field + ".AddressID");
    checkString(d.StreetFullText, false, field + ".StreetFullText");
    checkString(d.StreetExtensionText, false, field + ".StreetExtensionText");
    checkString(d.LocationCityName, false, field + ".LocationCityName");
    checkString(d.LocationPostalCode, false, field + ".LocationPostalCode");
    checkString(d.LocationStateName, false, field + ".LocationStateName");
    d.LocationCountryName = LocationCountryNameOrStreetExtensionTextProxy.Create(d.LocationCountryName, field + ".LocationCountryName");
    return new AddressProxy(d);
  }
  private constructor(d: any) {
    this.AddressID = d.AddressID;
    this.StreetFullText = d.StreetFullText;
    this.StreetExtensionText = d.StreetExtensionText;
    this.LocationCityName = d.LocationCityName;
    this.LocationPostalCode = d.LocationPostalCode;
    this.LocationStateName = d.LocationStateName;
    this.LocationCountryName = d.LocationCountryName;
  }
}

export class LocationCountryNameOrStreetExtensionTextProxy {
  public readonly nil: boolean;
  public static Parse(d: string): LocationCountryNameOrStreetExtensionTextProxy {
    return LocationCountryNameOrStreetExtensionTextProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): LocationCountryNameOrStreetExtensionTextProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    checkBoolean(d.nil, false, field + ".nil");
    return new LocationCountryNameOrStreetExtensionTextProxy(d);
  }
  private constructor(d: any) {
    this.nil = d.nil;
  }
}

export class VIBEScoreResultProxy {
  public readonly Score: string;
  public readonly ScoreRunTimeStamp: string;
  public readonly Matched: string;
  public readonly ConfidenceFactor: string;
  public readonly I129CountInLast12Month: number | null;
  public static Parse(d: string): VIBEScoreResultProxy {
    return VIBEScoreResultProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): VIBEScoreResultProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    checkString(d.Score, false, field + ".Score");
    checkString(d.ScoreRunTimeStamp, false, field + ".ScoreRunTimeStamp");
    checkString(d.Matched, false, field + ".Matched");
    checkString(d.ConfidenceFactor, false, field + ".ConfidenceFactor");
    checkNumber(d.I129CountInLast12Month, true, field + ".I129CountInLast12Month");
    if (d.I129CountInLast12Month === undefined) {
      d.I129CountInLast12Month = null;
    }
    return new VIBEScoreResultProxy(d);
  }
  private constructor(d: any) {
    this.Score = d.Score;
    this.ScoreRunTimeStamp = d.ScoreRunTimeStamp;
    this.Matched = d.Matched;
    this.ConfidenceFactor = d.ConfidenceFactor;
    this.I129CountInLast12Month = d.I129CountInLast12Month;
  }
}

export class DNBMatchedBranchInformationProxy {
  public readonly AgnID: string;
  public readonly Address: Address1Proxy;
  public readonly OrganizationDUNSNumber: string;
  public static Parse(d: string): DNBMatchedBranchInformationProxy | null {
    return DNBMatchedBranchInformationProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): DNBMatchedBranchInformationProxy | null {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      return null;
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, true);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, true);
    }
    checkString(d.AgnID, false, field + ".AgnID");
    d.Address = Address1Proxy.Create(d.Address, field + ".Address");
    checkString(d.OrganizationDUNSNumber, false, field + ".OrganizationDUNSNumber");
    return new DNBMatchedBranchInformationProxy(d);
  }
  private constructor(d: any) {
    this.AgnID = d.AgnID;
    this.Address = d.Address;
    this.OrganizationDUNSNumber = d.OrganizationDUNSNumber;
  }
}

export class Address1Proxy {
  public readonly AddressID: string;
  public readonly OrganizationName: string;
  public readonly TelephoneNumberFullID: string;
  public readonly StreetFullText: string;
  public readonly StreetExtensionText: LocationCountryNameOrStreetExtensionTextProxy;
  public readonly LocationCityName: string;
  public readonly LocationPostalCode: string;
  public readonly LocationStateName: string;
  public readonly LocationCountryName: string;
  public static Parse(d: string): Address1Proxy {
    return Address1Proxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): Address1Proxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    checkString(d.AddressID, false, field + ".AddressID");
    checkString(d.OrganizationName, false, field + ".OrganizationName");
    checkString(d.TelephoneNumberFullID, false, field + ".TelephoneNumberFullID");
    checkString(d.StreetFullText, false, field + ".StreetFullText");
    d.StreetExtensionText = LocationCountryNameOrStreetExtensionTextProxy.Create(d.StreetExtensionText, field + ".StreetExtensionText");
    checkString(d.LocationCityName, false, field + ".LocationCityName");
    checkString(d.LocationPostalCode, false, field + ".LocationPostalCode");
    checkString(d.LocationStateName, false, field + ".LocationStateName");
    checkString(d.LocationCountryName, false, field + ".LocationCountryName");
    return new Address1Proxy(d);
  }
  private constructor(d: any) {
    this.AddressID = d.AddressID;
    this.OrganizationName = d.OrganizationName;
    this.TelephoneNumberFullID = d.TelephoneNumberFullID;
    this.StreetFullText = d.StreetFullText;
    this.StreetExtensionText = d.StreetExtensionText;
    this.LocationCityName = d.LocationCityName;
    this.LocationPostalCode = d.LocationPostalCode;
    this.LocationStateName = d.LocationStateName;
    this.LocationCountryName = d.LocationCountryName;
  }
}

export class DNBMatchedCompanyInformationProxy {
  public readonly OrganizationName: string;
  public readonly Address: Address2Proxy;
  public readonly LocationType: string;
  public readonly OrganizationPhone: OrganizationPhoneProxy;
  public readonly OrganizationDUNSNumber: string;
  public readonly GlobalUltimateDUNSNumber: string;
  public readonly GlobalUltimateCompanyName: string;
  public readonly RelationshipToGlobal: string;
  public readonly ForeignRelationshipIndicator: string;
  public readonly OwnershipStatus: string;
  public static Parse(d: string): DNBMatchedCompanyInformationProxy {
    return DNBMatchedCompanyInformationProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): DNBMatchedCompanyInformationProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    checkString(d.OrganizationName, false, field + ".OrganizationName");
    d.Address = Address2Proxy.Create(d.Address, field + ".Address");
    checkString(d.LocationType, false, field + ".LocationType");
    d.OrganizationPhone = OrganizationPhoneProxy.Create(d.OrganizationPhone, field + ".OrganizationPhone");
    checkString(d.OrganizationDUNSNumber, false, field + ".OrganizationDUNSNumber");
    checkString(d.GlobalUltimateDUNSNumber, false, field + ".GlobalUltimateDUNSNumber");
    checkString(d.GlobalUltimateCompanyName, false, field + ".GlobalUltimateCompanyName");
    checkString(d.RelationshipToGlobal, false, field + ".RelationshipToGlobal");
    checkString(d.ForeignRelationshipIndicator, false, field + ".ForeignRelationshipIndicator");
    checkString(d.OwnershipStatus, false, field + ".OwnershipStatus");
    return new DNBMatchedCompanyInformationProxy(d);
  }
  private constructor(d: any) {
    this.OrganizationName = d.OrganizationName;
    this.Address = d.Address;
    this.LocationType = d.LocationType;
    this.OrganizationPhone = d.OrganizationPhone;
    this.OrganizationDUNSNumber = d.OrganizationDUNSNumber;
    this.GlobalUltimateDUNSNumber = d.GlobalUltimateDUNSNumber;
    this.GlobalUltimateCompanyName = d.GlobalUltimateCompanyName;
    this.RelationshipToGlobal = d.RelationshipToGlobal;
    this.ForeignRelationshipIndicator = d.ForeignRelationshipIndicator;
    this.OwnershipStatus = d.OwnershipStatus;
  }
}

export class Address2Proxy {
  public readonly AddressID: string;
  public readonly StreetFullText: string;
  public readonly StreetExtensionText: LocationCountryNameOrStreetExtensionTextProxy;
  public readonly LocationCityName: string;
  public readonly LocationPostalCode: string;
  public readonly LocationStateName: string;
  public readonly LocationCountryName: string;
  public static Parse(d: string): Address2Proxy {
    return Address2Proxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): Address2Proxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    checkString(d.AddressID, false, field + ".AddressID");
    checkString(d.StreetFullText, false, field + ".StreetFullText");
    d.StreetExtensionText = LocationCountryNameOrStreetExtensionTextProxy.Create(d.StreetExtensionText, field + ".StreetExtensionText");
    checkString(d.LocationCityName, false, field + ".LocationCityName");
    checkString(d.LocationPostalCode, false, field + ".LocationPostalCode");
    checkString(d.LocationStateName, false, field + ".LocationStateName");
    checkString(d.LocationCountryName, false, field + ".LocationCountryName");
    return new Address2Proxy(d);
  }
  private constructor(d: any) {
    this.AddressID = d.AddressID;
    this.StreetFullText = d.StreetFullText;
    this.StreetExtensionText = d.StreetExtensionText;
    this.LocationCityName = d.LocationCityName;
    this.LocationPostalCode = d.LocationPostalCode;
    this.LocationStateName = d.LocationStateName;
    this.LocationCountryName = d.LocationCountryName;
  }
}

export class OrganizationPhoneProxy {
  public readonly TelephoneNumberFullID: string;
  public static Parse(d: string): OrganizationPhoneProxy {
    return OrganizationPhoneProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): OrganizationPhoneProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    checkString(d.TelephoneNumberFullID, false, field + ".TelephoneNumberFullID");
    return new OrganizationPhoneProxy(d);
  }
  private constructor(d: any) {
    this.TelephoneNumberFullID = d.TelephoneNumberFullID;
  }
}

export class DNBDetailedCompanyInformationProxy {
  public readonly CEOName: string;
  public readonly LegalStatusCode: string;
  public readonly ImportExport: string;
  public readonly NumberOfRelatedEntities: number;
  public readonly NumberOfCorroboratingSources: number;
  public readonly TotalTradePayments: number;
  public readonly NumberOfEmployeesInUSA: string;
  public readonly NumberOfEmployeesWorldWide: string;
  public readonly YearEstablished: number;
  public readonly ManagementControlYear: number;
  public readonly SevereRisk: string;
  public readonly HistoryType: string;
  public readonly OutOfBusinessIndicator: boolean;
  public readonly NAICCodes: NAICCodesProxy;
  public readonly TradeStyleCodes: null;
  public readonly NonProfitIndicator: string | null;
  public static Parse(d: string): DNBDetailedCompanyInformationProxy {
    return DNBDetailedCompanyInformationProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): DNBDetailedCompanyInformationProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    checkString(d.CEOName, false, field + ".CEOName");
    checkString(d.LegalStatusCode, false, field + ".LegalStatusCode");
    checkString(d.ImportExport, false, field + ".ImportExport");
    checkNumber(d.NumberOfRelatedEntities, false, field + ".NumberOfRelatedEntities");
    checkNumber(d.NumberOfCorroboratingSources, false, field + ".NumberOfCorroboratingSources");
    checkNumber(d.TotalTradePayments, false, field + ".TotalTradePayments");
    checkString(d.NumberOfEmployeesInUSA, false, field + ".NumberOfEmployeesInUSA");
    checkString(d.NumberOfEmployeesWorldWide, false, field + ".NumberOfEmployeesWorldWide");
    checkNumber(d.YearEstablished, false, field + ".YearEstablished");
    checkNumber(d.ManagementControlYear, false, field + ".ManagementControlYear");
    checkString(d.SevereRisk, false, field + ".SevereRisk");
    checkString(d.HistoryType, false, field + ".HistoryType");
    checkBoolean(d.OutOfBusinessIndicator, false, field + ".OutOfBusinessIndicator");
    d.NAICCodes = NAICCodesProxy.Create(d.NAICCodes, field + ".NAICCodes");
    checkNull(d.TradeStyleCodes, field + ".TradeStyleCodes");
    if (d.TradeStyleCodes === undefined) {
      d.TradeStyleCodes = null;
    }
    checkString(d.NonProfitIndicator, true, field + ".NonProfitIndicator");
    if (d.NonProfitIndicator === undefined) {
      d.NonProfitIndicator = null;
    }
    return new DNBDetailedCompanyInformationProxy(d);
  }
  private constructor(d: any) {
    this.CEOName = d.CEOName;
    this.LegalStatusCode = d.LegalStatusCode;
    this.ImportExport = d.ImportExport;
    this.NumberOfRelatedEntities = d.NumberOfRelatedEntities;
    this.NumberOfCorroboratingSources = d.NumberOfCorroboratingSources;
    this.TotalTradePayments = d.TotalTradePayments;
    this.NumberOfEmployeesInUSA = d.NumberOfEmployeesInUSA;
    this.NumberOfEmployeesWorldWide = d.NumberOfEmployeesWorldWide;
    this.YearEstablished = d.YearEstablished;
    this.ManagementControlYear = d.ManagementControlYear;
    this.SevereRisk = d.SevereRisk;
    this.HistoryType = d.HistoryType;
    this.OutOfBusinessIndicator = d.OutOfBusinessIndicator;
    this.NAICCodes = d.NAICCodes;
    this.TradeStyleCodes = d.TradeStyleCodes;
    this.NonProfitIndicator = d.NonProfitIndicator;
  }
}

export class NAICCodesProxy {
  public readonly NAIC1: string;
  public readonly NAIC2: string | null;
  public readonly NAIC3: null;
  public readonly NAIC4: null;
  public readonly NAIC5: null;
  public readonly NAIC6: null;
  public static Parse(d: string): NAICCodesProxy {
    return NAICCodesProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): NAICCodesProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    checkString(d.NAIC1, false, field + ".NAIC1");
    checkString(d.NAIC2, true, field + ".NAIC2");
    if (d.NAIC2 === undefined) {
      d.NAIC2 = null;
    }
    checkNull(d.NAIC3, field + ".NAIC3");
    if (d.NAIC3 === undefined) {
      d.NAIC3 = null;
    }
    checkNull(d.NAIC4, field + ".NAIC4");
    if (d.NAIC4 === undefined) {
      d.NAIC4 = null;
    }
    checkNull(d.NAIC5, field + ".NAIC5");
    if (d.NAIC5 === undefined) {
      d.NAIC5 = null;
    }
    checkNull(d.NAIC6, field + ".NAIC6");
    if (d.NAIC6 === undefined) {
      d.NAIC6 = null;
    }
    return new NAICCodesProxy(d);
  }
  private constructor(d: any) {
    this.NAIC1 = d.NAIC1;
    this.NAIC2 = d.NAIC2;
    this.NAIC3 = d.NAIC3;
    this.NAIC4 = d.NAIC4;
    this.NAIC5 = d.NAIC5;
    this.NAIC6 = d.NAIC6;
  }
}

export class DNBCompanyExecutiveBioProxy {
  public readonly Executive1: string;
  public readonly Executive2: string | null;
  public readonly Executive3: string | null;
  public static Parse(d: string): DNBCompanyExecutiveBioProxy {
    return DNBCompanyExecutiveBioProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): DNBCompanyExecutiveBioProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    checkString(d.Executive1, false, field + ".Executive1");
    checkString(d.Executive2, true, field + ".Executive2");
    if (d.Executive2 === undefined) {
      d.Executive2 = null;
    }
    checkString(d.Executive3, true, field + ".Executive3");
    if (d.Executive3 === undefined) {
      d.Executive3 = null;
    }
    return new DNBCompanyExecutiveBioProxy(d);
  }
  private constructor(d: any) {
    this.Executive1 = d.Executive1;
    this.Executive2 = d.Executive2;
    this.Executive3 = d.Executive3;
  }
}

export class DNBCompanyFinancialInformationProxy {
  public readonly GrossAnualIncome: string;
  public readonly FinancialStressScore: number;
  public static Parse(d: string): DNBCompanyFinancialInformationProxy {
    return DNBCompanyFinancialInformationProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): DNBCompanyFinancialInformationProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    checkString(d.GrossAnualIncome, false, field + ".GrossAnualIncome");
    checkNumber(d.FinancialStressScore, false, field + ".FinancialStressScore");
    return new DNBCompanyFinancialInformationProxy(d);
  }
  private constructor(d: any) {
    this.GrossAnualIncome = d.GrossAnualIncome;
    this.FinancialStressScore = d.FinancialStressScore;
  }
}

export class ManualSearchInfoProxy {
  public readonly OrganizationName: string;
  public readonly Address: Address2Proxy;
  public readonly RelatedToPetitioner: boolean;
  public static Parse(d: string): ManualSearchInfoProxy | null {
    return ManualSearchInfoProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): ManualSearchInfoProxy | null {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      return null;
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, true);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, true);
    }
    checkString(d.OrganizationName, false, field + ".OrganizationName");
    d.Address = Address2Proxy.Create(d.Address, field + ".Address");
    checkBoolean(d.RelatedToPetitioner, false, field + ".RelatedToPetitioner");
    return new ManualSearchInfoProxy(d);
  }
  private constructor(d: any) {
    this.OrganizationName = d.OrganizationName;
    this.Address = d.Address;
    this.RelatedToPetitioner = d.RelatedToPetitioner;
  }
}

function throwNull2NonNull(field: string, d: any): never {
  return errorHelper(field, d, "non-nullable object", false);
}
function throwNotObject(field: string, d: any, nullable: boolean): never {
  return errorHelper(field, d, "object", nullable);
}
function throwIsArray(field: string, d: any, nullable: boolean): never {
  return errorHelper(field, d, "object", nullable);
}
function checkArray(d: any, field: string): void {
  if (!Array.isArray(d) && d !== null && d !== undefined) {
    errorHelper(field, d, "array", true);
  }
}
function checkNumber(d: any, nullable: boolean, field: string): void {
  if (typeof(d) !== 'number' && (!nullable || (nullable && d !== null && d !== undefined))) {
    errorHelper(field, d, "number", nullable);
  }
}
function checkBoolean(d: any, nullable: boolean, field: string): void {
  if (typeof(d) !== 'boolean' && (!nullable || (nullable && d !== null && d !== undefined))) {
    errorHelper(field, d, "boolean", nullable);
  }
}
function checkString(d: any, nullable: boolean, field: string): void {
  if (typeof(d) !== 'string' && (!nullable || (nullable && d !== null && d !== undefined))) {
    errorHelper(field, d, "string", nullable);
  }
}
function checkNull(d: any, field: string): void {
  if (d !== null && d !== undefined) {
    errorHelper(field, d, "null or undefined", false);
  }
}
function errorHelper(field: string, d: any, type: string, nullable: boolean): never {
  if (nullable) {
    type += ", null, or undefined";
  }
  throw new TypeError('Expected ' + type + " at " + field + " but found:\n" + JSON.stringify(d) + "\n\nFull object:\n" + JSON.stringify(obj));
}
