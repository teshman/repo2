// Stores the currently-being-typechecked object for error messages.
let obj: any = null;
// Stores the currently-being-typechecked object for error messages.

export class DolProxy {
  public readonly GetDolDetailByEtaCaseNumberResponse: GetDolDetailByEtaCaseNumberResponseProxy;
  public static Parse(d: string): DolProxy {
    return DolProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): DolProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof (d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    d.GetDolDetailByEtaCaseNumberResponse = GetDolDetailByEtaCaseNumberResponseProxy.Create(d.GetDolDetailByEtaCaseNumberResponse, field + ".GetDolDetailByEtaCaseNumberResponse");
    return new DolProxy(d);
  }
  private constructor(d: any) {
    this.GetDolDetailByEtaCaseNumberResponse = d.GetDolDetailByEtaCaseNumberResponse;
  }
}

export class GetDolDetailByEtaCaseNumberResponseProxy {
  public readonly SourceSystemID: string;
  public readonly SourceTransactionID: string;
  public readonly ServiceRequestTimestamp: string;
  public readonly ServiceResponseTimestamp: string;
  public readonly AuditCorrelationID: string;
  public readonly ResponseStatusMessage: ResponseStatusMessageProxy;
  public readonly DolEtaFormType: string;
  public readonly DolEtaFormVersion: string;
  public readonly DolJsonData: string;
  public static Parse(d: string): GetDolDetailByEtaCaseNumberResponseProxy {
    return GetDolDetailByEtaCaseNumberResponseProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): GetDolDetailByEtaCaseNumberResponseProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    checkString(d.SourceSystemID, false, field + ".SourceSystemID");
    checkString(d.SourceTransactionID, false, field + ".SourceTransactionID");
    checkString(d.ServiceRequestTimestamp, false, field + ".ServiceRequestTimestamp");
    checkString(d.ServiceResponseTimestamp, false, field + ".ServiceResponseTimestamp");
    checkString(d.AuditCorrelationID, false, field + ".AuditCorrelationID");
    d.ResponseStatusMessage = ResponseStatusMessageProxy.Create(d.ResponseStatusMessage, field + ".ResponseStatusMessage");
    checkString(d.DolEtaFormType, false, field + ".DolEtaFormType");
    checkString(d.DolEtaFormVersion, false, field + ".DolEtaFormVersion");
    checkString(d.DolJsonData, false, field + ".DolJsonData");
    return new GetDolDetailByEtaCaseNumberResponseProxy(d);
  }
  private constructor(d: any) {
    this.SourceSystemID = d.SourceSystemID;
    this.SourceTransactionID = d.SourceTransactionID;
    this.ServiceRequestTimestamp = d.ServiceRequestTimestamp;
    this.ServiceResponseTimestamp = d.ServiceResponseTimestamp;
    this.AuditCorrelationID = d.AuditCorrelationID;
    this.ResponseStatusMessage = d.ResponseStatusMessage;
    this.DolEtaFormType = d.DolEtaFormType;
    this.DolEtaFormVersion = d.DolEtaFormVersion;
    this.DolJsonData = d.DolJsonData;
  }
}

export class ResponseStatusMessageProxy {
  public readonly StatusCode: string;
  public readonly Status: string;
  public static Parse(d: string): ResponseStatusMessageProxy {
    return ResponseStatusMessageProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): ResponseStatusMessageProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    checkString(d.StatusCode, false, field + ".StatusCode");
    checkString(d.Status, false, field + ".Status");
    return new ResponseStatusMessageProxy(d);
  }
  private constructor(d: any) {
    this.StatusCode = d.StatusCode;
    this.Status = d.Status;
  }
}

export class DolDataProxy {
  public readonly DOL_DATA: DOLDATAProxy;
  public static Parse(d: string): DolDataProxy {
    return DolDataProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): DolDataProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof (d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    d.DOL_DATA = DOLDATAProxy.Create(d.DOL_DATA, field + ".DOL_DATA");
    return new DolDataProxy(d);
  }
  private constructor(d: any) {
    this.DOL_DATA = d.DOL_DATA;
  }
}

export class DOLDATAProxy {
  public readonly DOL_ETA_CLOB: DOLETACLOBEntityProxy[] | null;
  public readonly DOL_ETA_WORKSITES: DOLETAWORKSITESEntityProxy[] | null;
  public readonly DOL_ETA_EMPLOYERS: DOLETAEMPLOYERSEntityProxy[] | null;
  public static Parse(d: string): DOLDATAProxy {
    return DOLDATAProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): DOLDATAProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof (d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    checkArray(d.DOL_ETA_CLOB, field + ".DOL_ETA_CLOB");
    if (d.DOL_ETA_CLOB) {
      for (let i = 0; i < d.DOL_ETA_CLOB.length; i++) {
        d.DOL_ETA_CLOB[i] = DOLETACLOBEntityProxy.Create(d.DOL_ETA_CLOB[i], field + ".DOL_ETA_CLOB" + "[" + i + "]");
      }
    }
    if (d.DOL_ETA_CLOB === undefined) {
      d.DOL_ETA_CLOB = null;
    }
    checkArray(d.DOL_ETA_WORKSITES, field + ".DOL_ETA_WORKSITES");
    if (d.DOL_ETA_WORKSITES) {
      for (let i = 0; i < d.DOL_ETA_WORKSITES.length; i++) {
        d.DOL_ETA_WORKSITES[i] = DOLETAWORKSITESEntityProxy.Create(d.DOL_ETA_WORKSITES[i], field + ".DOL_ETA_WORKSITES" + "[" + i + "]");
      }
    }
    if (d.DOL_ETA_WORKSITES === undefined) {
      d.DOL_ETA_WORKSITES = null;
    }
    checkArray(d.DOL_ETA_EMPLOYERS, field + ".DOL_ETA_EMPLOYERS");
    if (d.DOL_ETA_EMPLOYERS) {
      for (let i = 0; i < d.DOL_ETA_EMPLOYERS.length; i++) {
        d.DOL_ETA_EMPLOYERS[i] = DOLETAEMPLOYERSEntityProxy.Create(d.DOL_ETA_EMPLOYERS[i], field + ".DOL_ETA_EMPLOYERS" + "[" + i + "]");
      }
    }
    if (d.DOL_ETA_EMPLOYERS === undefined) {
      d.DOL_ETA_EMPLOYERS = null;
    }
    return new DOLDATAProxy(d);
  }
  private constructor(d: any) {
    this.DOL_ETA_CLOB = d.DOL_ETA_CLOB;
    this.DOL_ETA_WORKSITES = d.DOL_ETA_WORKSITES;
    this.DOL_ETA_EMPLOYERS = d.DOL_ETA_EMPLOYERS;
  }
}

export class DOLETACLOBEntityProxy {
  public readonly VISA_CLASS: string;
  public readonly TEMPNEED_JOBTITLE: string;
  public readonly TEMPNEED_SOC: string;
  public readonly TEMPNEED_SOC_TITLE: string;
  public readonly TEMPNEED_FULLTIME: string;
  public readonly TEMPNEED_START: string;
  public readonly TEMPNEED_END: string;
  public readonly TEMPNEED_WKR_POS: string;
  public readonly NEW_EMP: string;
  public readonly CONT_PREV: string;
  public readonly CHANGE_PREV: string;
  public readonly NEW_CONCUR: string;
  public readonly CHANGE_EMP: string;
  public readonly AMEND_PET: string;
  public readonly TEMPNEED_NATURE: string;
  public readonly TEMPNEED_DESCRIPTION: string;
  public readonly CASE_NUMBER: string;
  public readonly CASE_STATUS: string;
  public readonly CASE_VALID_FROM: string;
  public readonly CASE_VALID_TO: string;
  public readonly EMP_BUSINESS_NAME: string;
  public readonly EMP_TRADE_NAME: string;
  public readonly EMP_ADDR1: string;
  public readonly EMP_ADDR2: string;
  public readonly EMP_CITY: string;
  public readonly EMP_STATE: string;
  public readonly EMP_POSTCODE: string;
  public readonly EMP_COUNTRY: string;
  public readonly EMP_PROVINCE: string;
  public readonly EMP_PHONE: string;
  public readonly EMP_PHONEEXT: string;
  public readonly EMP_FEIN: string;
  public readonly EMP_NAICS: string;
  public readonly EMP_NUMEMPLOYEES: string;
  public readonly EMP_GROSSRECEIPTS: string;
  public readonly EMP_YEAREST: string;
  public readonly EMP_TYPE: string;
  public readonly EMPPOC_LASTNAME: string;
  public readonly EMPPOC_FIRSTNAME: string;
  public readonly EMPPOC_MIDDLENAME: string;
  public readonly EMPPOC_JOBTITLE: string;
  public readonly EMPPOC_ADDR1: string;
  public readonly EMPPOC_ADDR2: string;
  public readonly EMPPOC_CITY: string;
  public readonly EMPPOC_STATE: string;
  public readonly EMPPOC_POSTCODE: string;
  public readonly EMPPOC_COUNTRY: string;
  public readonly EMPPOC_PROVINCE: string;
  public readonly EMPPOC_PHONE: string;
  public readonly EMPPOC_PHONEEXT: string;
  public readonly EMPPOC_EMAIL: string;
  public readonly ATTY_REPRESENT: string;
  public readonly ATTY_LASTNAME: string;
  public readonly ATTY_FIRSTNAME: string;
  public readonly ATTY_MIDDLENAME: string;
  public readonly ATTY_ADDR1: string;
  public readonly ATTY_ADDR2: string;
  public readonly ATTY_CITY: string;
  public readonly ATTY_STATE: string;
  public readonly ATTY_POSTCODE: string;
  public readonly ATTY_COUNTRY: string;
  public readonly ATTY_PROVINCE: string;
  public readonly ATTY_PHONE: string;
  public readonly ATTY_PHONEEXT: string;
  public readonly ATTY_EMAIL: string;
  public readonly ATTY_BIZNAME: string;
  public readonly ATTY_FEIN: string;
  public readonly ATTY_STATEBARNO: string;
  public readonly ATTY_STATEHIGHCT: string;
  public readonly ATTY_NAMEHIGHCT: string;
  public readonly JOB_TITLE: string;
  public readonly JOB_HOURSPERWK: string;
  public readonly JOB_HOURSTART: string;
  public readonly JOB_HOUREND: string;
  public readonly JOB_SUPERVISOR: string;
  public readonly JOB_NUMBER_SUP: string;
  public readonly JOB_DUTIES: string;
  public readonly JOB_MINEDU: string;
  public readonly JOB_MINOTHER: string;
  public readonly JOB_MINEDUMAJOR: string;
  public readonly JOB_MINSECDEGREE: string;
  public readonly JOB_MINSECDEGTYPE: string;
  public readonly JOB_MINTRAINING: string;
  public readonly JOB_MINTRAININGMONTHS: string;
  public readonly JOB_MINTRAINFIELD: string;
  public readonly JOB_MINEXP: string;
  public readonly JOB_MINEXPMONTHS: string;
  public readonly JOB_MINEXPOCCU: string;
  public readonly JOB_MINSPECIALREQ: string;
  public readonly JOB_ADDR1: string;
  public readonly JOB_ADDR2: string;
  public readonly JOB_CITY: string;
  public readonly JOB_COUNTY: string;
  public readonly JOB_STATE: string;
  public readonly JOB_POSTCODE: string;
  public readonly JOB_MULITPLESITES: string;
  public readonly WAGE_FROM: string;
  public readonly WAGE_TO: string;
  public readonly WAGE_OTFROM: string;
  public readonly WAGE_OT_TO: string;
  public readonly WAGE_PER: string;
  public readonly WAGE_PIECE: string;
  public readonly WAGE_ADDITIONAL: string;
  public readonly REC_SWANAME: string;
  public readonly REC_JOBORDER: string;
  public readonly REC_JOBORDSTART: string;
  public readonly REC_JOBORDEND: string;
  public readonly REC_SUNDAYPAPER: string;
  public readonly REC_PAPERNAMES: string;
  public readonly REC_POSTFROM: string;
  public readonly REC_POSTTO: string;
  public readonly REC_ADDITIONAL: string;
  public readonly DECLARE_AGREE_H2A: string;
  public readonly DECLARE_AGREE_H2B: string;
  public readonly PREP_LASTNAME: string;
  public readonly PREP_FIRSTNAME: string;
  public readonly PREP_MIDDLENAME: string;
  public readonly PREP_JOBTITLE: string;
  public readonly PREP_BIZNAME: string;
  public readonly PREP_EMAIL: string;
  public readonly CASE_DETERM: string;
  public readonly CASE_SUBMIT: string;
  public readonly CHANGED_DATE: string;
  public readonly LASTMOD_DATE: string;
  public readonly SUBMIT_IPADDRESS: string;
  public readonly RNUM: string;
  public static Parse(d: string): DOLETACLOBEntityProxy {
    return DOLETACLOBEntityProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): DOLETACLOBEntityProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof (d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    checkString(d.VISA_CLASS, false, field + ".VISA_CLASS");
    checkString(d.TEMPNEED_JOBTITLE, false, field + ".TEMPNEED_JOBTITLE");
    checkString(d.TEMPNEED_SOC, false, field + ".TEMPNEED_SOC");
    checkString(d.TEMPNEED_SOC_TITLE, false, field + ".TEMPNEED_SOC_TITLE");
    checkString(d.TEMPNEED_FULLTIME, false, field + ".TEMPNEED_FULLTIME");
    checkString(d.TEMPNEED_START, false, field + ".TEMPNEED_START");
    checkString(d.TEMPNEED_END, false, field + ".TEMPNEED_END");
    checkString(d.TEMPNEED_WKR_POS, false, field + ".TEMPNEED_WKR_POS");
    checkString(d.NEW_EMP, false, field + ".NEW_EMP");
    checkString(d.CONT_PREV, false, field + ".CONT_PREV");
    checkString(d.CHANGE_PREV, false, field + ".CHANGE_PREV");
    checkString(d.NEW_CONCUR, false, field + ".NEW_CONCUR");
    checkString(d.CHANGE_EMP, false, field + ".CHANGE_EMP");
    checkString(d.AMEND_PET, false, field + ".AMEND_PET");
    checkString(d.TEMPNEED_NATURE, false, field + ".TEMPNEED_NATURE");
    checkString(d.TEMPNEED_DESCRIPTION, false, field + ".TEMPNEED_DESCRIPTION");
    checkString(d.CASE_NUMBER, false, field + ".CASE_NUMBER");
    checkString(d.CASE_STATUS, false, field + ".CASE_STATUS");
    checkString(d.CASE_VALID_FROM, false, field + ".CASE_VALID_FROM");
    checkString(d.CASE_VALID_TO, false, field + ".CASE_VALID_TO");
    checkString(d.EMP_BUSINESS_NAME, false, field + ".EMP_BUSINESS_NAME");
    checkString(d.EMP_TRADE_NAME, false, field + ".EMP_TRADE_NAME");
    checkString(d.EMP_ADDR1, false, field + ".EMP_ADDR1");
    checkString(d.EMP_ADDR2, false, field + ".EMP_ADDR2");
    checkString(d.EMP_CITY, false, field + ".EMP_CITY");
    checkString(d.EMP_STATE, false, field + ".EMP_STATE");
    checkString(d.EMP_POSTCODE, false, field + ".EMP_POSTCODE");
    checkString(d.EMP_COUNTRY, false, field + ".EMP_COUNTRY");
    checkString(d.EMP_PROVINCE, false, field + ".EMP_PROVINCE");
    checkString(d.EMP_PHONE, false, field + ".EMP_PHONE");
    checkString(d.EMP_PHONEEXT, false, field + ".EMP_PHONEEXT");
    checkString(d.EMP_FEIN, false, field + ".EMP_FEIN");
    checkString(d.EMP_NAICS, false, field + ".EMP_NAICS");
    checkString(d.EMP_NUMEMPLOYEES, false, field + ".EMP_NUMEMPLOYEES");
    checkString(d.EMP_GROSSRECEIPTS, false, field + ".EMP_GROSSRECEIPTS");
    checkString(d.EMP_YEAREST, false, field + ".EMP_YEAREST");
    checkString(d.EMP_TYPE, false, field + ".EMP_TYPE");
    checkString(d.EMPPOC_LASTNAME, false, field + ".EMPPOC_LASTNAME");
    checkString(d.EMPPOC_FIRSTNAME, false, field + ".EMPPOC_FIRSTNAME");
    checkString(d.EMPPOC_MIDDLENAME, false, field + ".EMPPOC_MIDDLENAME");
    checkString(d.EMPPOC_JOBTITLE, false, field + ".EMPPOC_JOBTITLE");
    checkString(d.EMPPOC_ADDR1, false, field + ".EMPPOC_ADDR1");
    checkString(d.EMPPOC_ADDR2, false, field + ".EMPPOC_ADDR2");
    checkString(d.EMPPOC_CITY, false, field + ".EMPPOC_CITY");
    checkString(d.EMPPOC_STATE, false, field + ".EMPPOC_STATE");
    checkString(d.EMPPOC_POSTCODE, false, field + ".EMPPOC_POSTCODE");
    checkString(d.EMPPOC_COUNTRY, false, field + ".EMPPOC_COUNTRY");
    checkString(d.EMPPOC_PROVINCE, false, field + ".EMPPOC_PROVINCE");
    checkString(d.EMPPOC_PHONE, false, field + ".EMPPOC_PHONE");
    checkString(d.EMPPOC_PHONEEXT, false, field + ".EMPPOC_PHONEEXT");
    checkString(d.EMPPOC_EMAIL, false, field + ".EMPPOC_EMAIL");
    checkString(d.ATTY_REPRESENT, false, field + ".ATTY_REPRESENT");
    checkString(d.ATTY_LASTNAME, false, field + ".ATTY_LASTNAME");
    checkString(d.ATTY_FIRSTNAME, false, field + ".ATTY_FIRSTNAME");
    checkString(d.ATTY_MIDDLENAME, false, field + ".ATTY_MIDDLENAME");
    checkString(d.ATTY_ADDR1, false, field + ".ATTY_ADDR1");
    checkString(d.ATTY_ADDR2, false, field + ".ATTY_ADDR2");
    checkString(d.ATTY_CITY, false, field + ".ATTY_CITY");
    checkString(d.ATTY_STATE, false, field + ".ATTY_STATE");
    checkString(d.ATTY_POSTCODE, false, field + ".ATTY_POSTCODE");
    checkString(d.ATTY_COUNTRY, false, field + ".ATTY_COUNTRY");
    checkString(d.ATTY_PROVINCE, false, field + ".ATTY_PROVINCE");
    checkString(d.ATTY_PHONE, false, field + ".ATTY_PHONE");
    checkString(d.ATTY_PHONEEXT, false, field + ".ATTY_PHONEEXT");
    checkString(d.ATTY_EMAIL, false, field + ".ATTY_EMAIL");
    checkString(d.ATTY_BIZNAME, false, field + ".ATTY_BIZNAME");
    checkString(d.ATTY_FEIN, false, field + ".ATTY_FEIN");
    checkString(d.ATTY_STATEBARNO, false, field + ".ATTY_STATEBARNO");
    checkString(d.ATTY_STATEHIGHCT, false, field + ".ATTY_STATEHIGHCT");
    checkString(d.ATTY_NAMEHIGHCT, false, field + ".ATTY_NAMEHIGHCT");
    checkString(d.JOB_TITLE, false, field + ".JOB_TITLE");
    checkString(d.JOB_HOURSPERWK, false, field + ".JOB_HOURSPERWK");
    checkString(d.JOB_HOURSTART, false, field + ".JOB_HOURSTART");
    checkString(d.JOB_HOUREND, false, field + ".JOB_HOUREND");
    checkString(d.JOB_SUPERVISOR, false, field + ".JOB_SUPERVISOR");
    checkString(d.JOB_NUMBER_SUP, false, field + ".JOB_NUMBER_SUP");
    checkString(d.JOB_DUTIES, false, field + ".JOB_DUTIES");
    checkString(d.JOB_MINEDU, false, field + ".JOB_MINEDU");
    checkString(d.JOB_MINOTHER, false, field + ".JOB_MINOTHER");
    checkString(d.JOB_MINEDUMAJOR, false, field + ".JOB_MINEDUMAJOR");
    checkString(d.JOB_MINSECDEGREE, false, field + ".JOB_MINSECDEGREE");
    checkString(d.JOB_MINSECDEGTYPE, false, field + ".JOB_MINSECDEGTYPE");
    checkString(d.JOB_MINTRAINING, false, field + ".JOB_MINTRAINING");
    checkString(d.JOB_MINTRAININGMONTHS, false, field + ".JOB_MINTRAININGMONTHS");
    checkString(d.JOB_MINTRAINFIELD, false, field + ".JOB_MINTRAINFIELD");
    checkString(d.JOB_MINEXP, false, field + ".JOB_MINEXP");
    checkString(d.JOB_MINEXPMONTHS, false, field + ".JOB_MINEXPMONTHS");
    checkString(d.JOB_MINEXPOCCU, false, field + ".JOB_MINEXPOCCU");
    checkString(d.JOB_MINSPECIALREQ, false, field + ".JOB_MINSPECIALREQ");
    checkString(d.JOB_ADDR1, false, field + ".JOB_ADDR1");
    checkString(d.JOB_ADDR2, false, field + ".JOB_ADDR2");
    checkString(d.JOB_CITY, false, field + ".JOB_CITY");
    checkString(d.JOB_COUNTY, false, field + ".JOB_COUNTY");
    checkString(d.JOB_STATE, false, field + ".JOB_STATE");
    checkString(d.JOB_POSTCODE, false, field + ".JOB_POSTCODE");
    checkString(d.JOB_MULITPLESITES, false, field + ".JOB_MULITPLESITES");
    checkString(d.WAGE_FROM, false, field + ".WAGE_FROM");
    checkString(d.WAGE_TO, false, field + ".WAGE_TO");
    checkString(d.WAGE_OTFROM, false, field + ".WAGE_OTFROM");
    checkString(d.WAGE_OT_TO, false, field + ".WAGE_OT_TO");
    checkString(d.WAGE_PER, false, field + ".WAGE_PER");
    checkString(d.WAGE_PIECE, false, field + ".WAGE_PIECE");
    checkString(d.WAGE_ADDITIONAL, false, field + ".WAGE_ADDITIONAL");
    checkString(d.REC_SWANAME, false, field + ".REC_SWANAME");
    checkString(d.REC_JOBORDER, false, field + ".REC_JOBORDER");
    checkString(d.REC_JOBORDSTART, false, field + ".REC_JOBORDSTART");
    checkString(d.REC_JOBORDEND, false, field + ".REC_JOBORDEND");
    checkString(d.REC_SUNDAYPAPER, false, field + ".REC_SUNDAYPAPER");
    checkString(d.REC_PAPERNAMES, false, field + ".REC_PAPERNAMES");
    checkString(d.REC_POSTFROM, false, field + ".REC_POSTFROM");
    checkString(d.REC_POSTTO, false, field + ".REC_POSTTO");
    checkString(d.REC_ADDITIONAL, false, field + ".REC_ADDITIONAL");
    checkString(d.DECLARE_AGREE_H2A, false, field + ".DECLARE_AGREE_H2A");
    checkString(d.DECLARE_AGREE_H2B, false, field + ".DECLARE_AGREE_H2B");
    checkString(d.PREP_LASTNAME, false, field + ".PREP_LASTNAME");
    checkString(d.PREP_FIRSTNAME, false, field + ".PREP_FIRSTNAME");
    checkString(d.PREP_MIDDLENAME, false, field + ".PREP_MIDDLENAME");
    checkString(d.PREP_JOBTITLE, false, field + ".PREP_JOBTITLE");
    checkString(d.PREP_BIZNAME, false, field + ".PREP_BIZNAME");
    checkString(d.PREP_EMAIL, false, field + ".PREP_EMAIL");
    checkString(d.CASE_DETERM, false, field + ".CASE_DETERM");
    checkString(d.CASE_SUBMIT, false, field + ".CASE_SUBMIT");
    checkString(d.CHANGED_DATE, false, field + ".CHANGED_DATE");
    checkString(d.LASTMOD_DATE, false, field + ".LASTMOD_DATE");
    checkString(d.SUBMIT_IPADDRESS, false, field + ".SUBMIT_IPADDRESS");
    checkString(d.RNUM, false, field + ".RNUM");
    return new DOLETACLOBEntityProxy(d);
  }
  private constructor(d: any) {
    this.VISA_CLASS = d.VISA_CLASS;
    this.TEMPNEED_JOBTITLE = d.TEMPNEED_JOBTITLE;
    this.TEMPNEED_SOC = d.TEMPNEED_SOC;
    this.TEMPNEED_SOC_TITLE = d.TEMPNEED_SOC_TITLE;
    this.TEMPNEED_FULLTIME = d.TEMPNEED_FULLTIME;
    this.TEMPNEED_START = d.TEMPNEED_START;
    this.TEMPNEED_END = d.TEMPNEED_END;
    this.TEMPNEED_WKR_POS = d.TEMPNEED_WKR_POS;
    this.NEW_EMP = d.NEW_EMP;
    this.CONT_PREV = d.CONT_PREV;
    this.CHANGE_PREV = d.CHANGE_PREV;
    this.NEW_CONCUR = d.NEW_CONCUR;
    this.CHANGE_EMP = d.CHANGE_EMP;
    this.AMEND_PET = d.AMEND_PET;
    this.TEMPNEED_NATURE = d.TEMPNEED_NATURE;
    this.TEMPNEED_DESCRIPTION = d.TEMPNEED_DESCRIPTION;
    this.CASE_NUMBER = d.CASE_NUMBER;
    this.CASE_STATUS = d.CASE_STATUS;
    this.CASE_VALID_FROM = d.CASE_VALID_FROM;
    this.CASE_VALID_TO = d.CASE_VALID_TO;
    this.EMP_BUSINESS_NAME = d.EMP_BUSINESS_NAME;
    this.EMP_TRADE_NAME = d.EMP_TRADE_NAME;
    this.EMP_ADDR1 = d.EMP_ADDR1;
    this.EMP_ADDR2 = d.EMP_ADDR2;
    this.EMP_CITY = d.EMP_CITY;
    this.EMP_STATE = d.EMP_STATE;
    this.EMP_POSTCODE = d.EMP_POSTCODE;
    this.EMP_COUNTRY = d.EMP_COUNTRY;
    this.EMP_PROVINCE = d.EMP_PROVINCE;
    this.EMP_PHONE = d.EMP_PHONE;
    this.EMP_PHONEEXT = d.EMP_PHONEEXT;
    this.EMP_FEIN = d.EMP_FEIN;
    this.EMP_NAICS = d.EMP_NAICS;
    this.EMP_NUMEMPLOYEES = d.EMP_NUMEMPLOYEES;
    this.EMP_GROSSRECEIPTS = d.EMP_GROSSRECEIPTS;
    this.EMP_YEAREST = d.EMP_YEAREST;
    this.EMP_TYPE = d.EMP_TYPE;
    this.EMPPOC_LASTNAME = d.EMPPOC_LASTNAME;
    this.EMPPOC_FIRSTNAME = d.EMPPOC_FIRSTNAME;
    this.EMPPOC_MIDDLENAME = d.EMPPOC_MIDDLENAME;
    this.EMPPOC_JOBTITLE = d.EMPPOC_JOBTITLE;
    this.EMPPOC_ADDR1 = d.EMPPOC_ADDR1;
    this.EMPPOC_ADDR2 = d.EMPPOC_ADDR2;
    this.EMPPOC_CITY = d.EMPPOC_CITY;
    this.EMPPOC_STATE = d.EMPPOC_STATE;
    this.EMPPOC_POSTCODE = d.EMPPOC_POSTCODE;
    this.EMPPOC_COUNTRY = d.EMPPOC_COUNTRY;
    this.EMPPOC_PROVINCE = d.EMPPOC_PROVINCE;
    this.EMPPOC_PHONE = d.EMPPOC_PHONE;
    this.EMPPOC_PHONEEXT = d.EMPPOC_PHONEEXT;
    this.EMPPOC_EMAIL = d.EMPPOC_EMAIL;
    this.ATTY_REPRESENT = d.ATTY_REPRESENT;
    this.ATTY_LASTNAME = d.ATTY_LASTNAME;
    this.ATTY_FIRSTNAME = d.ATTY_FIRSTNAME;
    this.ATTY_MIDDLENAME = d.ATTY_MIDDLENAME;
    this.ATTY_ADDR1 = d.ATTY_ADDR1;
    this.ATTY_ADDR2 = d.ATTY_ADDR2;
    this.ATTY_CITY = d.ATTY_CITY;
    this.ATTY_STATE = d.ATTY_STATE;
    this.ATTY_POSTCODE = d.ATTY_POSTCODE;
    this.ATTY_COUNTRY = d.ATTY_COUNTRY;
    this.ATTY_PROVINCE = d.ATTY_PROVINCE;
    this.ATTY_PHONE = d.ATTY_PHONE;
    this.ATTY_PHONEEXT = d.ATTY_PHONEEXT;
    this.ATTY_EMAIL = d.ATTY_EMAIL;
    this.ATTY_BIZNAME = d.ATTY_BIZNAME;
    this.ATTY_FEIN = d.ATTY_FEIN;
    this.ATTY_STATEBARNO = d.ATTY_STATEBARNO;
    this.ATTY_STATEHIGHCT = d.ATTY_STATEHIGHCT;
    this.ATTY_NAMEHIGHCT = d.ATTY_NAMEHIGHCT;
    this.JOB_TITLE = d.JOB_TITLE;
    this.JOB_HOURSPERWK = d.JOB_HOURSPERWK;
    this.JOB_HOURSTART = d.JOB_HOURSTART;
    this.JOB_HOUREND = d.JOB_HOUREND;
    this.JOB_SUPERVISOR = d.JOB_SUPERVISOR;
    this.JOB_NUMBER_SUP = d.JOB_NUMBER_SUP;
    this.JOB_DUTIES = d.JOB_DUTIES;
    this.JOB_MINEDU = d.JOB_MINEDU;
    this.JOB_MINOTHER = d.JOB_MINOTHER;
    this.JOB_MINEDUMAJOR = d.JOB_MINEDUMAJOR;
    this.JOB_MINSECDEGREE = d.JOB_MINSECDEGREE;
    this.JOB_MINSECDEGTYPE = d.JOB_MINSECDEGTYPE;
    this.JOB_MINTRAINING = d.JOB_MINTRAINING;
    this.JOB_MINTRAININGMONTHS = d.JOB_MINTRAININGMONTHS;
    this.JOB_MINTRAINFIELD = d.JOB_MINTRAINFIELD;
    this.JOB_MINEXP = d.JOB_MINEXP;
    this.JOB_MINEXPMONTHS = d.JOB_MINEXPMONTHS;
    this.JOB_MINEXPOCCU = d.JOB_MINEXPOCCU;
    this.JOB_MINSPECIALREQ = d.JOB_MINSPECIALREQ;
    this.JOB_ADDR1 = d.JOB_ADDR1;
    this.JOB_ADDR2 = d.JOB_ADDR2;
    this.JOB_CITY = d.JOB_CITY;
    this.JOB_COUNTY = d.JOB_COUNTY;
    this.JOB_STATE = d.JOB_STATE;
    this.JOB_POSTCODE = d.JOB_POSTCODE;
    this.JOB_MULITPLESITES = d.JOB_MULITPLESITES;
    this.WAGE_FROM = d.WAGE_FROM;
    this.WAGE_TO = d.WAGE_TO;
    this.WAGE_OTFROM = d.WAGE_OTFROM;
    this.WAGE_OT_TO = d.WAGE_OT_TO;
    this.WAGE_PER = d.WAGE_PER;
    this.WAGE_PIECE = d.WAGE_PIECE;
    this.WAGE_ADDITIONAL = d.WAGE_ADDITIONAL;
    this.REC_SWANAME = d.REC_SWANAME;
    this.REC_JOBORDER = d.REC_JOBORDER;
    this.REC_JOBORDSTART = d.REC_JOBORDSTART;
    this.REC_JOBORDEND = d.REC_JOBORDEND;
    this.REC_SUNDAYPAPER = d.REC_SUNDAYPAPER;
    this.REC_PAPERNAMES = d.REC_PAPERNAMES;
    this.REC_POSTFROM = d.REC_POSTFROM;
    this.REC_POSTTO = d.REC_POSTTO;
    this.REC_ADDITIONAL = d.REC_ADDITIONAL;
    this.DECLARE_AGREE_H2A = d.DECLARE_AGREE_H2A;
    this.DECLARE_AGREE_H2B = d.DECLARE_AGREE_H2B;
    this.PREP_LASTNAME = d.PREP_LASTNAME;
    this.PREP_FIRSTNAME = d.PREP_FIRSTNAME;
    this.PREP_MIDDLENAME = d.PREP_MIDDLENAME;
    this.PREP_JOBTITLE = d.PREP_JOBTITLE;
    this.PREP_BIZNAME = d.PREP_BIZNAME;
    this.PREP_EMAIL = d.PREP_EMAIL;
    this.CASE_DETERM = d.CASE_DETERM;
    this.CASE_SUBMIT = d.CASE_SUBMIT;
    this.CHANGED_DATE = d.CHANGED_DATE;
    this.LASTMOD_DATE = d.LASTMOD_DATE;
    this.SUBMIT_IPADDRESS = d.SUBMIT_IPADDRESS;
    this.RNUM = d.RNUM;
  }
}

export class DOLETAWORKSITESEntityProxy {
  public readonly CASE_NUMBER: string;
  public readonly LASTMOD_DATE: string;
  public readonly JOB_ADDR1: string;
  public readonly JOB_ADDR2: string;
  public readonly JOB_CITY: string;
  public readonly JOB_COUNTY: string;
  public readonly JOB_STATE: string;
  public readonly JOB_POSTCODE: string;
  public readonly JOB_MULITPLESITES: string;
  public readonly STATE_TERRITORY: string;
  public readonly AREA_BASED_ON: string;
  public readonly AREA: string;
  public readonly RNUM: string;
  public static Parse(d: string): DOLETAWORKSITESEntityProxy {
    return DOLETAWORKSITESEntityProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): DOLETAWORKSITESEntityProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof (d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    checkString(d.CASE_NUMBER, false, field + ".CASE_NUMBER");
    checkString(d.LASTMOD_DATE, false, field + ".LASTMOD_DATE");
    checkString(d.JOB_ADDR1, false, field + ".JOB_ADDR1");
    checkString(d.JOB_ADDR2, false, field + ".JOB_ADDR2");
    checkString(d.JOB_CITY, false, field + ".JOB_CITY");
    checkString(d.JOB_COUNTY, false, field + ".JOB_COUNTY");
    checkString(d.JOB_STATE, false, field + ".JOB_STATE");
    checkString(d.JOB_POSTCODE, false, field + ".JOB_POSTCODE");
    checkString(d.JOB_MULITPLESITES, false, field + ".JOB_MULITPLESITES");
    checkString(d.STATE_TERRITORY, false, field + ".STATE_TERRITORY");
    checkString(d.AREA_BASED_ON, false, field + ".AREA_BASED_ON");
    checkString(d.AREA, false, field + ".AREA");
    checkString(d.RNUM, false, field + ".RNUM");
    return new DOLETAWORKSITESEntityProxy(d);
  }
  private constructor(d: any) {
    this.CASE_NUMBER = d.CASE_NUMBER;
    this.LASTMOD_DATE = d.LASTMOD_DATE;
    this.JOB_ADDR1 = d.JOB_ADDR1;
    this.JOB_ADDR2 = d.JOB_ADDR2;
    this.JOB_CITY = d.JOB_CITY;
    this.JOB_COUNTY = d.JOB_COUNTY;
    this.JOB_STATE = d.JOB_STATE;
    this.JOB_POSTCODE = d.JOB_POSTCODE;
    this.JOB_MULITPLESITES = d.JOB_MULITPLESITES;
    this.STATE_TERRITORY = d.STATE_TERRITORY;
    this.AREA_BASED_ON = d.AREA_BASED_ON;
    this.AREA = d.AREA;
    this.RNUM = d.RNUM;
  }
}

export class DOLETAEMPLOYERSEntityProxy {
  public readonly CASE_NUMBER: string;
  public readonly LASTMOD_DATE: string;
  public readonly EMP_BUSINESS_NAME: string;
  public readonly EMP_TRADE_NAME: string;
  public readonly EMP_ADDR1: string;
  public readonly EMP_ADDR2: string;
  public readonly EMP_CITY: string;
  public readonly EMP_STATE: string;
  public readonly EMP_POSTCODE: string;
  public readonly EMP_COUNTRY: string;
  public readonly EMP_PROVINCE: string;
  public readonly EMP_PHONE: string;
  public readonly EMP_PHONEEXT: string;
  public readonly EMP_FEIN: string;
  public readonly EMP_NAICS: string;
  public readonly NAICS_TEXT: string;
  public readonly EMP_NUMEMPLOYEES: string;
  public readonly EMP_GROSSRECEIPTS: string;
  public readonly EMP_YEAREST: string;
  public readonly EMP_TYPE: string;
  public readonly SUB_CERTIFIED: string;
  public readonly SUB_CERT_BEGIN_DATE: string;
  public readonly SUB_CERT_END_DATE: string;
  public readonly RNUM: string;
  public static Parse(d: string): DOLETAEMPLOYERSEntityProxy {
    return DOLETAEMPLOYERSEntityProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): DOLETAEMPLOYERSEntityProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof (d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    checkString(d.CASE_NUMBER, false, field + ".CASE_NUMBER");
    checkString(d.LASTMOD_DATE, false, field + ".LASTMOD_DATE");
    checkString(d.EMP_BUSINESS_NAME, false, field + ".EMP_BUSINESS_NAME");
    checkString(d.EMP_TRADE_NAME, false, field + ".EMP_TRADE_NAME");
    checkString(d.EMP_ADDR1, false, field + ".EMP_ADDR1");
    checkString(d.EMP_ADDR2, false, field + ".EMP_ADDR2");
    checkString(d.EMP_CITY, false, field + ".EMP_CITY");
    checkString(d.EMP_STATE, false, field + ".EMP_STATE");
    checkString(d.EMP_POSTCODE, false, field + ".EMP_POSTCODE");
    checkString(d.EMP_COUNTRY, false, field + ".EMP_COUNTRY");
    checkString(d.EMP_PROVINCE, false, field + ".EMP_PROVINCE");
    checkString(d.EMP_PHONE, false, field + ".EMP_PHONE");
    checkString(d.EMP_PHONEEXT, false, field + ".EMP_PHONEEXT");
    checkString(d.EMP_FEIN, false, field + ".EMP_FEIN");
    checkString(d.EMP_NAICS, false, field + ".EMP_NAICS");
    checkString(d.NAICS_TEXT, false, field + ".NAICS_TEXT");
    checkString(d.EMP_NUMEMPLOYEES, false, field + ".EMP_NUMEMPLOYEES");
    checkString(d.EMP_GROSSRECEIPTS, false, field + ".EMP_GROSSRECEIPTS");
    checkString(d.EMP_YEAREST, false, field + ".EMP_YEAREST");
    checkString(d.EMP_TYPE, false, field + ".EMP_TYPE");
    checkString(d.SUB_CERTIFIED, false, field + ".SUB_CERTIFIED");
    checkString(d.SUB_CERT_BEGIN_DATE, false, field + ".SUB_CERT_BEGIN_DATE");
    checkString(d.SUB_CERT_END_DATE, false, field + ".SUB_CERT_END_DATE");
    checkString(d.RNUM, false, field + ".RNUM");
    return new DOLETAEMPLOYERSEntityProxy(d);
  }
  private constructor(d: any) {
    this.CASE_NUMBER = d.CASE_NUMBER;
    this.LASTMOD_DATE = d.LASTMOD_DATE;
    this.EMP_BUSINESS_NAME = d.EMP_BUSINESS_NAME;
    this.EMP_TRADE_NAME = d.EMP_TRADE_NAME;
    this.EMP_ADDR1 = d.EMP_ADDR1;
    this.EMP_ADDR2 = d.EMP_ADDR2;
    this.EMP_CITY = d.EMP_CITY;
    this.EMP_STATE = d.EMP_STATE;
    this.EMP_POSTCODE = d.EMP_POSTCODE;
    this.EMP_COUNTRY = d.EMP_COUNTRY;
    this.EMP_PROVINCE = d.EMP_PROVINCE;
    this.EMP_PHONE = d.EMP_PHONE;
    this.EMP_PHONEEXT = d.EMP_PHONEEXT;
    this.EMP_FEIN = d.EMP_FEIN;
    this.EMP_NAICS = d.EMP_NAICS;
    this.NAICS_TEXT = d.NAICS_TEXT;
    this.EMP_NUMEMPLOYEES = d.EMP_NUMEMPLOYEES;
    this.EMP_GROSSRECEIPTS = d.EMP_GROSSRECEIPTS;
    this.EMP_YEAREST = d.EMP_YEAREST;
    this.EMP_TYPE = d.EMP_TYPE;
    this.SUB_CERTIFIED = d.SUB_CERTIFIED;
    this.SUB_CERT_BEGIN_DATE = d.SUB_CERT_BEGIN_DATE;
    this.SUB_CERT_END_DATE = d.SUB_CERT_END_DATE;
    this.RNUM = d.RNUM;
  }
}

function throwNull2NonNull(field: string, d: any): never {
  return errorHelper(field, d, "non-nullable object", false);
}
function throwNotObject(field: string, d: any, nullable: boolean): never {
  return errorHelper(field, d, "object", nullable);
}
function throwIsArray(field: string, d: any, nullable: boolean): never {
  return errorHelper(field, d, "object", nullable);
}
function checkArray(d: any, field: string): void {
  if (!Array.isArray(d) && d !== null && d !== undefined) {
    errorHelper(field, d, "array", true);
  }
}
function checkString(d: any, nullable: boolean, field: string): void {
  if (typeof (d) !== 'string' && (!nullable || (nullable && d !== null && d !== undefined))) {
    errorHelper(field, d, "string", nullable);
  }
}
function errorHelper(field: string, d: any, type: string, nullable: boolean): never {
  if (nullable) {
    type += ", null, or undefined";
  }
  throw new TypeError('Expected ' + type + " at " + field + " but found:\n" + JSON.stringify(d) + "\n\nFull object:\n" + JSON.stringify(obj));
}
