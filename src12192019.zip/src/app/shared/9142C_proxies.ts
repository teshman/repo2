// Stores the currently-being-typechecked object for error messages.
let obj: any = null;
export class dol9142CProxy {
  public readonly GetDolDetailByEtaCaseNumberResponse: GetDolDetailByEtaCaseNumberResponseProxy;
  public static Parse(d: string): dol9142CProxy {
    return dol9142CProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): dol9142CProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    d.GetDolDetailByEtaCaseNumberResponse = GetDolDetailByEtaCaseNumberResponseProxy.Create(d.GetDolDetailByEtaCaseNumberResponse, field + ".GetDolDetailByEtaCaseNumberResponse");
    return new dol9142CProxy(d);
  }
  private constructor(d: any) {
    this.GetDolDetailByEtaCaseNumberResponse = d.GetDolDetailByEtaCaseNumberResponse;
  }
}

export class GetDolDetailByEtaCaseNumberResponseProxy {
  public readonly SourceSystemID: string;
  public readonly SourceTransactionID: string;
  public readonly ServiceRequestTimestamp: string;
  public readonly ServiceResponseTimestamp: string;
  public readonly AuditCorrelationID: string;
  public readonly ResponseStatusMessage: ResponseStatusMessageProxy;
  public readonly DolEtaFormType: string;
  public readonly DolEtaFormVersion: string;
  public readonly DolJsonData: string;
  public static Parse(d: string): GetDolDetailByEtaCaseNumberResponseProxy {
    return GetDolDetailByEtaCaseNumberResponseProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): GetDolDetailByEtaCaseNumberResponseProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    checkString(d.SourceSystemID, false, field + ".SourceSystemID");
    checkString(d.SourceTransactionID, false, field + ".SourceTransactionID");
    checkString(d.ServiceRequestTimestamp, false, field + ".ServiceRequestTimestamp");
    checkString(d.ServiceResponseTimestamp, false, field + ".ServiceResponseTimestamp");
    checkString(d.AuditCorrelationID, false, field + ".AuditCorrelationID");
    d.ResponseStatusMessage = ResponseStatusMessageProxy.Create(d.ResponseStatusMessage, field + ".ResponseStatusMessage");
    checkString(d.DolEtaFormType, false, field + ".DolEtaFormType");
    checkString(d.DolEtaFormVersion, false, field + ".DolEtaFormVersion");
    checkString(d.DolJsonData, false, field + ".DolJsonData");
    return new GetDolDetailByEtaCaseNumberResponseProxy(d);
  }
  private constructor(d: any) {
    this.SourceSystemID = d.SourceSystemID;
    this.SourceTransactionID = d.SourceTransactionID;
    this.ServiceRequestTimestamp = d.ServiceRequestTimestamp;
    this.ServiceResponseTimestamp = d.ServiceResponseTimestamp;
    this.AuditCorrelationID = d.AuditCorrelationID;
    this.ResponseStatusMessage = d.ResponseStatusMessage;
    this.DolEtaFormType = d.DolEtaFormType;
    this.DolEtaFormVersion = d.DolEtaFormVersion;
    this.DolJsonData = d.DolJsonData;
  }
}

export class ResponseStatusMessageProxy {
  public readonly StatusCode: string;
  public readonly Status: string;
  public static Parse(d: string): ResponseStatusMessageProxy {
    return ResponseStatusMessageProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): ResponseStatusMessageProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    checkString(d.StatusCode, false, field + ".StatusCode");
    checkString(d.Status, false, field + ".Status");
    return new ResponseStatusMessageProxy(d);
  }
  private constructor(d: any) {
    this.StatusCode = d.StatusCode;
    this.Status = d.Status;
  }
}

function throwNull2NonNull(field: string, d: any): never {
  return errorHelper(field, d, "non-nullable object", false);
}
function throwNotObject(field: string, d: any, nullable: boolean): never {
  return errorHelper(field, d, "object", nullable);
}
function throwIsArray(field: string, d: any, nullable: boolean): never {
  return errorHelper(field, d, "object", nullable);
}
function checkString(d: any, nullable: boolean, field: string): void {
  if (typeof(d) !== 'string' && (!nullable || (nullable && d !== null && d !== undefined))) {
    errorHelper(field, d, "string", nullable);
  }
}
function errorHelper(field: string, d: any, type: string, nullable: boolean): never {
  if (nullable) {
    type += ", null, or undefined";
  }
  throw new TypeError('Expected ' + type + " at " + field + " but found:\n" + JSON.stringify(d) + "\n\nFull object:\n" + JSON.stringify(obj));
}
