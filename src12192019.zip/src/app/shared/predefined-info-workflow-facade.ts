import { PredfinedInfoRequestAddress, PredefinedInformationWorkflowRequest } from "./predefined-Info-request";
import { PredefinedInformationGetDetailResponse } from "./predefined-info-response";


export class PredefinedInfoWorkflowFacade {

  constructor(data: Partial<PredefinedInfoWorkflowFacade>) {
    Object.assign(this, data);
  }
  source: string;
  formTypes = ["I129", "I140", "I360", "I485J"];
  commentTypes = ["LE13", "H2A", "Q", "SIEVE", "Viability", "Public Law"];
  nominationSources = ["CSC", "VSC", "TSC", "NSC", "PSC", "AAO", "CBP", "ICE",
    "DOL", "DSS", "KCC", "Field FDNS", "NBC", "SIEVE", "SCOPSHQ"];
  selectedNS: { [nominationSource: string]: boolean } = {};
  selectedFormType: { [formType: string]: boolean } = {};
  selectedCommentType: { [commentType: string]: boolean } = {};

  FDNS_DS_CMEType: string = "";
  FDNS_DSNumber: string = "";
  exceptionID: string = "";
  confidenceCode: string = "";
  formTypeManualEdit: boolean = false;
  workFlowStatus: string = "";
  forceEdit: boolean = false;
  expirePredefinedInfo: boolean = false;
  searchByAddress: boolean = false;
  predefinedInformationRequest: PredefinedInformationWorkflowRequest;
  PredefinedInformationGetDetailResponse: PredefinedInformationGetDetailResponse;
  businessSearchAddress: PredfinedInfoRequestAddress;
  businessSearchEditDetailAddress: PredfinedInfoRequestAddress;
  PetitionAddress: PredfinedInfoRequestAddress;
  ManualSearchAddress: PredfinedInfoRequestAddress;
  IIPMatchedAddress: PredfinedInfoRequestAddress;
  iipNextDisabled: boolean = true;
  addCommentFormValid: boolean = false;

  addCommentFormSaved: boolean = false;
  approvalFormInputValid: boolean = false;
  approvalFormAccepted: boolean = false;

  setNominationSource(ns: string) {
    console.log("seeting NS: " + ns);
    for (let sds of this.nominationSources) {
      if (ns !== undefined && ns !== null && ns.includes(sds))
        this.selectedNS[sds] = true;

    }

    // if (!this.formTypeManualEdit) {
    //   console.log("seeting NS: " + ns);
    //   for (let sds of this.nominationSources) {
    //     if(ns !==undefined && ns !==null && ns.includes(sds))
    //     this.selectedNS[sds] = true;

    //   }
    // }
  }
  setFDNSType() {
    if (this.predefinedInformationRequest.fdnsdsNumber &&
      this.predefinedInformationRequest.fdnsdsNumber !== "") {
      let fdns_pre: string = "";
      let fdns_post: string = "";
      fdns_pre = this.predefinedInformationRequest.fdnsdsNumber;
      fdns_post = fdns_pre.substring(fdns_pre.indexOf(" "));
      fdns_pre = fdns_pre.substring(0, fdns_pre.indexOf(" "));
      if (fdns_pre !== "") {
        this.FDNS_DS_CMEType = fdns_pre.toUpperCase();
        this.FDNS_DSNumber = fdns_post;
        this.formTypeManualEdit = true;
      }
    }
  }
  setFDNS() {
    console.log("this.FDNS_DS_CMEType and this.FDNS_DSNumber are: " + this.FDNS_DS_CMEType + ", " + this.FDNS_DSNumber);
    if (this.FDNS_DS_CMEType !== undefined && this.FDNS_DS_CMEType !== null && (this.FDNS_DS_CMEType == 'N/A'))
      this.predefinedInformationRequest.fdnsdsNumber = "";
    else if (this.FDNS_DS_CMEType !== undefined && this.FDNS_DS_CMEType !== null && this.FDNS_DS_CMEType !== 'N/A' && this.FDNS_DS_CMEType !== 'N/A'
      && (this.FDNS_DSNumber == undefined || this.FDNS_DSNumber == null || this.FDNS_DSNumber == "") &&
      this.predefinedInformationRequest.fdnsdsNumber !== undefined &&
      this.predefinedInformationRequest.fdnsdsNumber !== null &&
      this.predefinedInformationRequest.fdnsdsNumber !== "") {
      if (this.predefinedInformationRequest.fdnsdsNumber.includes("CASE"))
        this.predefinedInformationRequest.fdnsdsNumber = this.predefinedInformationRequest.fdnsdsNumber.replace("CASE", this.FDNS_DS_CMEType);
      if (this.predefinedInformationRequest.fdnsdsNumber.includes("LEAD"))
        this.predefinedInformationRequest.fdnsdsNumber = this.predefinedInformationRequest.fdnsdsNumber.replace("LEAD", this.FDNS_DS_CMEType);
      if (this.predefinedInformationRequest.fdnsdsNumber.includes("RFA"))
        this.predefinedInformationRequest.fdnsdsNumber = this.predefinedInformationRequest.fdnsdsNumber.replace("RFA", this.FDNS_DS_CMEType);
      if (this.predefinedInformationRequest.fdnsdsNumber.includes("SVP"))
        this.predefinedInformationRequest.fdnsdsNumber = this.predefinedInformationRequest.fdnsdsNumber.replace("SVP", this.FDNS_DS_CMEType);

      console.log("this.predefinedInformationRequest.fdnsdsNumber after the change: " + this.predefinedInformationRequest.fdnsdsNumber);
    }
    else {
      if (this.FDNS_DS_CMEType !== undefined && this.FDNS_DS_CMEType !== null && this.FDNS_DS_CMEType !== ""
        && this.FDNS_DSNumber !== undefined && this.FDNS_DSNumber !== null && this.FDNS_DSNumber !== "") {

        this.predefinedInformationRequest.fdnsdsNumber = this.FDNS_DS_CMEType +
          " " + this.FDNS_DSNumber;

        this.formTypeManualEdit = true;
      } else {
        // this.predefinedInformationRequest.fdnsdsNumber = "";
        this.formTypeManualEdit = true;
      }
    }
  }

  setFormType() {
    let formType = this.predefinedInformationRequest.preDefFormCommentType;

    // console.log("inside predf list, setFormtype formTypeManualEdit == true && this.forceEdit == true).formtype is: " + formType);
    if (this.formTypeManualEdit == true || this.forceEdit == true) {
      for (let ft of this.formTypes) {
        if (formType !== undefined && formType !== null && formType.includes(ft))
          this.selectedFormType[ft] = true;
        else
          this.selectedFormType[ft] = false;
      }
    }
    this.forceEdit == false;

    // console.log("form type is being setup...") ;
  }

  updateFormTypeInputValues(ctrl) {
    let formTypeStr = "";
    let ctrlState: boolean = false;
    let ctrlState1: boolean = true;
    this.formTypeManualEdit = true;
    ctrlState1 = this.selectedFormType[ctrl];
    console.log("form type is being modified...");
    for (let ft of this.formTypes) {
      if (ft !== ctrl) {
        ctrlState = this.selectedFormType[ft];
        if (ctrlState) formTypeStr = formTypeStr + ft;
      }
      else if (!ctrlState1) {
        formTypeStr = formTypeStr + ft;
      }
    }

    this.predefinedInformationRequest.preDefFormCommentType = formTypeStr;
  }
  updateCommentTypeInputValues(ctrl) {

    let commentTypeStr = "";
    let ctrlState: boolean = false;
    let ctrlState1: boolean = true;
    this.formTypeManualEdit = true;
    ctrlState1 = this.selectedCommentType[ctrl];

    for (let commentT of this.commentTypes) {
      if (commentT !== ctrl) {
        ctrlState = this.selectedCommentType[commentT];
        if (ctrlState) commentTypeStr = commentTypeStr + commentT.substr(0, 1);
      }
      else if (!ctrlState1) {
        commentTypeStr = commentTypeStr + commentT.substr(0, 1);
      }
    }
    this.predefinedInformationRequest.preDefCommentType =
      commentTypeStr;

  }
  setNominationSourceInputValues(ctrl) {
    let nsStr = "";
    let ctrlState: boolean = false;
    let ctrlState1: boolean = true;
    this.formTypeManualEdit = true;
    ctrlState1 = this.selectedNS[ctrl];

    for (let ns of this.nominationSources) {
      if (ns !== ctrl) {
        ctrlState = this.selectedNS[ns];
        if (ctrlState) {
          if (nsStr == "")
            nsStr = nsStr + ns
          else
            nsStr = nsStr + "," + ns
        }
      }
      else if (!ctrlState1) {
        if (nsStr == "")
          nsStr = nsStr + ns
        else
          nsStr = nsStr + "," + ns
      }
    }
    this.predefinedInformationRequest.nominationSource =
      nsStr;
  }



}
