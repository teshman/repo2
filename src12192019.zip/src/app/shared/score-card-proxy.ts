// Stores the currently-being-typechecked object for error messages.
let obj: any = null;
export class ScoreCardProxy {
  public readonly ScoreCardGetResponse: ScoreCardGetResponseProxy;
  public static Parse(d: string): ScoreCardProxy {
    return ScoreCardProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): ScoreCardProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    d.ScoreCardGetResponse = ScoreCardGetResponseProxy.Create(d.ScoreCardGetResponse, field + ".ScoreCardGetResponse");
    return new ScoreCardProxy(d);
  }
  private constructor(d: any) {
    this.ScoreCardGetResponse = d.ScoreCardGetResponse;
  }
}

export class ScoreCardGetResponseProxy {
  public readonly SourceSystemID: string;
  public readonly SourceTransactionID: string;
  public readonly ServiceRequestTimestamp: string;
  public readonly ServiceResponseTimestamp: string;
  public readonly AuditCorrelationID: string;
  public readonly ScoreCardResultSet: ScoreCardResultSetProxy;
  public static Parse(d: string): ScoreCardGetResponseProxy {
    return ScoreCardGetResponseProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): ScoreCardGetResponseProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    checkString(d.SourceSystemID, false, field + ".SourceSystemID");
    checkString(d.SourceTransactionID, false, field + ".SourceTransactionID");
    checkString(d.ServiceRequestTimestamp, false, field + ".ServiceRequestTimestamp");
    checkString(d.ServiceResponseTimestamp, false, field + ".ServiceResponseTimestamp");
    checkString(d.AuditCorrelationID, false, field + ".AuditCorrelationID");
    d.ScoreCardResultSet = ScoreCardResultSetProxy.Create(d.ScoreCardResultSet, field + ".ScoreCardResultSet");
    return new ScoreCardGetResponseProxy(d);
  }
  private constructor(d: any) {
    this.SourceSystemID = d.SourceSystemID;
    this.SourceTransactionID = d.SourceTransactionID;
    this.ServiceRequestTimestamp = d.ServiceRequestTimestamp;
    this.ServiceResponseTimestamp = d.ServiceResponseTimestamp;
    this.AuditCorrelationID = d.AuditCorrelationID;
    this.ScoreCardResultSet = d.ScoreCardResultSet;
  }
}

export class ScoreCardResultSetProxy {
  public readonly ScoreCardRecord: ScoreCardRecordEntityProxy[] | null;
  public static Parse(d: string): ScoreCardResultSetProxy {
    return ScoreCardResultSetProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): ScoreCardResultSetProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    checkArray(d.ScoreCardRecord, field + ".ScoreCardRecord");
    if (d.ScoreCardRecord) {
      for (let i = 0; i < d.ScoreCardRecord.length; i++) {
        d.ScoreCardRecord[i] = ScoreCardRecordEntityProxy.Create(d.ScoreCardRecord[i], field + ".ScoreCardRecord" + "[" + i + "]");
      }
    }
    if (d.ScoreCardRecord === undefined) {
      d.ScoreCardRecord = null;
    }
    return new ScoreCardResultSetProxy(d);
  }
  private constructor(d: any) {
    this.ScoreCardRecord = d.ScoreCardRecord;
  }
}

export class ScoreCardRecordEntityProxy {
  public readonly BusinessRuleName: string;
  public readonly Score: string;
  public static Parse(d: string): ScoreCardRecordEntityProxy {
    return ScoreCardRecordEntityProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): ScoreCardRecordEntityProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    checkString(d.BusinessRuleName, false, field + ".BusinessRuleName");
    checkString(d.Score, false, field + ".Score");
    return new ScoreCardRecordEntityProxy(d);
  }
  private constructor(d: any) {
    this.BusinessRuleName = d.BusinessRuleName;
    this.Score = d.Score;
  }
}

function throwNull2NonNull(field: string, d: any): never {
  return errorHelper(field, d, "non-nullable object", false);
}
function throwNotObject(field: string, d: any, nullable: boolean): never {
  return errorHelper(field, d, "object", nullable);
}
function throwIsArray(field: string, d: any, nullable: boolean): never {
  return errorHelper(field, d, "object", nullable);
}
function checkArray(d: any, field: string): void {
  if (!Array.isArray(d) && d !== null && d !== undefined) {
    errorHelper(field, d, "array", true);
  }
}
function checkString(d: any, nullable: boolean, field: string): void {
  if (typeof(d) !== 'string' && (!nullable || (nullable && d !== null && d !== undefined))) {
    errorHelper(field, d, "string", nullable);
  }
}
function errorHelper(field: string, d: any, type: string, nullable: boolean): never {
  if (nullable) {
    type += ", null, or undefined";
  }
  throw new TypeError('Expected ' + type + " at " + field + " but found:\n" + JSON.stringify(d) + "\n\nFull object:\n" + JSON.stringify(obj));
}
