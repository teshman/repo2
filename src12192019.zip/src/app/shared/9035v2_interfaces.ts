export interface dol9035vTwo {
  GetDolDetailByPetitionIDResponse: GetDolDetailByPetitionIDResponse;
}
export interface GetDolDetailByPetitionIDResponse {
  SourceSystemID: string;
  SourceTransactionID: string;
  ServiceRequestTimestamp: string;
  ServiceResponseTimestamp: string;
  AuditCorrelationID: string;
  DolEtaFormType: string;
  DolEtaFormVersion: string;
  DolJsonData: string;
}

export interface DolData {
  DOL_DATA: DOLDATA;
}

export interface DOLDATA {
  DOL_ETA_CLOB: DOLETACLOB[] | DOLETACLOB;
  DOL_ETA_WORKSITES: DOLETAWORKSITE[] | DOLETAWORKSITE;
  DOL_ETA_EMPLOYERS: DOLETAEMPLOYERS;
  DOL_ETA_EDUCATION: DOLETAEDUCATION[]|DOLETAEDUCATION;
}


export interface DOLETACLOB {
  CASE_NUMBER: string;
  CASE_STATUS: string;
  CASE_CERTFROM: string;
  CASE_CERTTO: string;
  A1_VISA_CLASS: string;
  B1_TEMPNEED_JOBTITLE: string;
  B2_TEMPNEED_SOCCODE: string;
  B3_TEMPNEED_OCCTITLE: string;
  B4_TEMPNEED_FULLTIME: string;
  B5_TEMPNEED_START: string;
  B6_TEMPNEED_END: string;
  B7_TEMPNEED_POSITIONS: string;
  B7A_TEMPNEED_NEWEMP: string;
  B7B_TEMPNEED_CONTEMP: string;
  B7C_TEMPNEED_CHGAPPEMP: string;
  B7D_TEMPNEED_CONCUREMP: string;
  B7E_TEMPNEED_CHGINEMPLOYER: string;
  B7F_TEMPNEED_AMENDEDPETITION: string;
  C1_EMP_BUSINESS_NAME: string;
  C3_EMP_ADDR1: string;
  C5_EMP_CITY: string;
  C6_EMP_STATE: string;
  C7_EMP_POSTCODE: string;
  C8_EMP_COUNTRY: string;
  C10_EMP_PHONE: string;
  C12_EMP_FEIN: string;
  C13_EMP_NAICS: string;
  NAICS_TEXT: string;
  D1_EMPPOC_LASTNAME: string;
  D2_EMPPOC_FIRSTNAME: string;
  D3_EMPPOC_MIDDLENAME: string;
  D4_EMPPOC_JOBTITLE: string;
  D5_EMPPOC_ADDR1: string;
  D7_EMPPOC_CITY: string;
  D8_EMPPOC_STATE: string;
  D9_EMPPOC_POSTCODE: string;
  D10_EMPPOC_COUNTRY: string;
  D12_EMPPOC_PHONE: string;
  D14_EMPPOC_EMAIL: string;
  E1_ATTY_REPRESENT: string;
  E2_ATTY_LASTNAME: string;
  E3_ATTY_FIRSTNAME: string;
  E4_ATTY_MIDDLENAME: string;
  E5_ATTY_ADDR1: string;
  E7_ATTY_CITY: string;
  E8_ATTY_STATE: string;
  E9_ATTY_POSTCODE: string;
  E10_ATTY_COUNTRY: string;
  E12_ATTY_PHONE: string;
  E14_ATTY_EMAIL: string;
  E15_ATTY_BIZNAME: string;
  E16_ATTY_FEIN: string;
  E17_ATTY_STATEBARNO: string;
  E18_ATTY_STATEHIGHCT: string;
  E19_ATTY_NAMEHIGHCT: string;
  G1_ATTEST_ACTIONS: string;
  H1_ATTEST_H1BDEPENDENT: string;
  H2_ATTEST_WILLFULVIOLATOR: string;
  H3_ATTEST_LIMITATION: string;
  H4_ATTEST_IDEXEMPTION: string;
  I1_ATTEST_PUBDISCLOSURE: string;
  J1_DECLARE_LASTNAME: string;
  J2_DECLARE_FIRSTNAME: string;
  J3_DECLARE_MIDNAME: string;
  J4_DECLARE_TITLE: string;
  L_CASE_DETERM_DATE: string;
  CASE_SUBMIT: string;
  LASTMOD_DATE: string;
  SUBMIT_IPADDRESS: string;
  RECEIPT_NUMBER: string;
  SCORE_RUN_DATE: string;
}

export interface DOLETAWORKSITE {
  CASE_NUMBER: string;
  LASTMOD_DATE: string;
  SEQ: string;
  FA1_WRKRPOS: string;
  FA2_SECONDARY: string;
  FA3_SECBUSINESS: string;
  FA4_ADDR1: string;
  FA5_ADDR2: string;
  FA6_CITY: string;
  FA7_COUNTY: string;
  FA8_STATE: string;
  FA9_POSTALCODE: string;
  FA10_WAGE_FROM: string;
  FA10_WAGE_TO: string;
  FA10A_WAGE_PER: string;
  FA11_PREVWAGE: string;
  FA11A_PREVWAGE_PER: string;
  FA12A_DOLPWD: string;
  FA12A_PWNUMBER: string;
  FA13_OESPW: string;
  FA13A_OESWAGELEVEL: string;
  FA13B_OESWAGEYEAR: string;
  F14_OTHERPW: string;
  FA14A_OTHERWAGESOURCE: string;
  FA14B_OTHERWAGEYEAR: string;
  FA14C_OTHERSURVEYPUB: string;
  FA14D_OTHERSURVEYTITLE: string;
  PWSOURCE_WRK: string;
  PWDETAIL_WRK: string;
}

export interface DOLETAEMPLOYERS {
  RESPONSECODE: string;
  RESPONSEMESSAGE: string;
  DOLCASENUMBER: string;
  PETITIONID: string;
}
export interface DOLETAEDUCATION {
  CASE_NUMBER: string;
  LASTMOD_DATE: string;
  SEQ: string;
  HA1_NUMWORKERS: string;
  HA2_INSTITUTION: string;
  HA3_STUDYFIELD: string;
  HA4_DEGREEDATE: string;
}
export interface DOLETAEDUCATION {
  RESPONSECODE: string;
  RESPONSEMESSAGE: string;
  DOLCASENUMBER: string;
  PETITIONID: string;
}

