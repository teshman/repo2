// Stores the currently-being-typechecked object for error messages.
let obj: any = null;
export class IndependentManualQueryResponseProxy {
  public readonly IndependentManualQueryResponse: IndependentManualQueryResponse1Proxy;
  public static Parse(d: string): IndependentManualQueryResponseProxy {
    return IndependentManualQueryResponseProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): IndependentManualQueryResponseProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    d.IndependentManualQueryResponse = IndependentManualQueryResponse1Proxy.Create(d.IndependentManualQueryResponse, field + ".IndependentManualQueryResponse");
    return new IndependentManualQueryResponseProxy(d);
  }
  private constructor(d: any) {
    this.IndependentManualQueryResponse = d.IndependentManualQueryResponse;
  }
}

export class IndependentManualQueryResponse1Proxy {
  public readonly SourceSystemID: string;
  public readonly SourceTransactionID: string;
  public readonly ServiceRequestTimestamp: string;
  public readonly ServiceResponseTimestamp: string;
  public readonly AuditCorrelationID: string;
  public readonly ResponseStatusMessage: ResponseStatusMessageProxy;
  public readonly AgnID: string;
  public readonly Fein: string;
  public readonly DunsNumber: string;
  public readonly OrganizationName: string;
  public readonly Address: AddressProxy;
  public readonly ConfidenceFactor: string;
  public readonly Matched: string;
  public readonly I129CountInLast36Month: number;
  public readonly I360CountInLast36Month: number;
  public readonly I140CountInLast36Month: number;
  public readonly I485JCountInLast36Month: number;
  public static Parse(d: string): IndependentManualQueryResponse1Proxy {
    return IndependentManualQueryResponse1Proxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): IndependentManualQueryResponse1Proxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    checkString(d.SourceSystemID, false, field + ".SourceSystemID");
    checkString(d.SourceTransactionID, false, field + ".SourceTransactionID");
    checkString(d.ServiceRequestTimestamp, false, field + ".ServiceRequestTimestamp");
    checkString(d.ServiceResponseTimestamp, false, field + ".ServiceResponseTimestamp");
    checkString(d.AuditCorrelationID, false, field + ".AuditCorrelationID");
    d.ResponseStatusMessage = ResponseStatusMessageProxy.Create(d.ResponseStatusMessage, field + ".ResponseStatusMessage");
    checkString(d.AgnID, false, field + ".AgnID");
    checkString(d.Fein, false, field + ".Fein");
    checkString(d.DunsNumber, false, field + ".DunsNumber");
    checkString(d.OrganizationName, false, field + ".OrganizationName");
    d.Address = AddressProxy.Create(d.Address, field + ".Address");
    checkString(d.ConfidenceFactor, false, field + ".ConfidenceFactor");
    checkString(d.Matched, false, field + ".Matched");
    checkNumber(d.I129CountInLast36Month, false, field + ".I129CountInLast36Month");
    checkNumber(d.I360CountInLast36Month, false, field + ".I360CountInLast36Month");
    checkNumber(d.I140CountInLast36Month, false, field + ".I140CountInLast36Month");
    checkNumber(d.I485JCountInLast36Month, false, field + ".I485JCountInLast36Month");
    return new IndependentManualQueryResponse1Proxy(d);
  }
  private constructor(d: any) {
    this.SourceSystemID = d.SourceSystemID;
    this.SourceTransactionID = d.SourceTransactionID;
    this.ServiceRequestTimestamp = d.ServiceRequestTimestamp;
    this.ServiceResponseTimestamp = d.ServiceResponseTimestamp;
    this.AuditCorrelationID = d.AuditCorrelationID;
    this.ResponseStatusMessage = d.ResponseStatusMessage;
    this.AgnID = d.AgnID;
    this.Fein = d.Fein;
    this.DunsNumber = d.DunsNumber;
    this.OrganizationName = d.OrganizationName;
    this.Address = d.Address;
    this.ConfidenceFactor = d.ConfidenceFactor;
    this.Matched = d.Matched;
    this.I129CountInLast36Month = d.I129CountInLast36Month;
    this.I360CountInLast36Month = d.I360CountInLast36Month;
    this.I140CountInLast36Month = d.I140CountInLast36Month;
    this.I485JCountInLast36Month = d.I485JCountInLast36Month;
  }
}

export class ResponseStatusMessageProxy {
  public readonly StatusCode: string;
  public readonly Status: string;
  public static Parse(d: string): ResponseStatusMessageProxy {
    return ResponseStatusMessageProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): ResponseStatusMessageProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    checkString(d.StatusCode, false, field + ".StatusCode");
    checkString(d.Status, false, field + ".Status");
    return new ResponseStatusMessageProxy(d);
  }
  private constructor(d: any) {
    this.StatusCode = d.StatusCode;
    this.Status = d.Status;
  }
}

export class AddressProxy {
  public readonly AddressID: string;
  public readonly OrganizationName: string;
  public readonly StreetFullText: string;
  public readonly StreetExtensionText: string;
  public readonly LocationCityName: string;
  public readonly LocationPostalCode: string;
  public readonly LocationStateName: string;
  public readonly LocationCountryName: string;
  public readonly Comment: string;
  public readonly DateAdded: string;
  public readonly ValidUntilDate: string;
  public readonly AddedBy: string;
  public static Parse(d: string): AddressProxy {
    return AddressProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): AddressProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    checkString(d.AddressID, false, field + ".AddressID");
    checkString(d.OrganizationName, false, field + ".OrganizationName");
    checkString(d.StreetFullText, false, field + ".StreetFullText");
    checkString(d.StreetExtensionText, false, field + ".StreetExtensionText");
    checkString(d.LocationCityName, false, field + ".LocationCityName");
    checkString(d.LocationPostalCode, false, field + ".LocationPostalCode");
    checkString(d.LocationStateName, false, field + ".LocationStateName");
    checkString(d.LocationCountryName, false, field + ".LocationCountryName");
    checkString(d.Comment, false, field + ".Comment");
    checkString(d.DateAdded, false, field + ".DateAdded");
    checkString(d.ValidUntilDate, false, field + ".ValidUntilDate");
    checkString(d.AddedBy, false, field + ".AddedBy");
    return new AddressProxy(d);
  }
  private constructor(d: any) {
    this.AddressID = d.AddressID;
    this.OrganizationName = d.OrganizationName;
    this.StreetFullText = d.StreetFullText;
    this.StreetExtensionText = d.StreetExtensionText;
    this.LocationCityName = d.LocationCityName;
    this.LocationPostalCode = d.LocationPostalCode;
    this.LocationStateName = d.LocationStateName;
    this.LocationCountryName = d.LocationCountryName;
    this.Comment = d.Comment;
    this.DateAdded = d.DateAdded;
    this.ValidUntilDate = d.ValidUntilDate;
    this.AddedBy = d.AddedBy;
  }
}

function throwNull2NonNull(field: string, d: any): never {
  return errorHelper(field, d, "non-nullable object", false);
}
function throwNotObject(field: string, d: any, nullable: boolean): never {
  return errorHelper(field, d, "object", nullable);
}
function throwIsArray(field: string, d: any, nullable: boolean): never {
  return errorHelper(field, d, "object", nullable);
}
function checkNumber(d: any, nullable: boolean, field: string): void {
  if (typeof(d) !== 'number' && (!nullable || (nullable && d !== null && d !== undefined))) {
    errorHelper(field, d, "number", nullable);
  }
}
function checkString(d: any, nullable: boolean, field: string): void {
  if (typeof(d) !== 'string' && (!nullable || (nullable && d !== null && d !== undefined))) {
    errorHelper(field, d, "string", nullable);
  }
}
function errorHelper(field: string, d: any, type: string, nullable: boolean): never {
  if (nullable) {
    type += ", null, or undefined";
  }
  throw new TypeError('Expected ' + type + " at " + field + " but found:\n" + JSON.stringify(d) + "\n\nFull object:\n" + JSON.stringify(obj));
}
