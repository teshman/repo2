export interface RedReportGetDateResponse {
  RedReportGetAdvancedResponse: RedReportGetAdvancedResponse;
}
export interface RedReportGetAdvancedResponse {
  SourceSystemID: string;
  SourceTransactionID: string;
  ServiceRequestTimestamp: string;
  ServiceResponseTimestamp: string;
  AuditCorrelationID: string;
  RedReportResultSet: RedReportResultSet;
}
export interface RedReportResultSet {
  totalRecordCount: number;
  lastRecordIndex: number;
  recordCountInThisResultSet: number;
  RedReportRecord?: (RedReportRecordEntity)[] | null;
}
export interface RedReportRecordEntity {
  OrganizationName: string;
  Score: string;
  ReceiptNumber: string;
  ReceiptDate: string;
  DeliverToCFDO: boolean;
  PetitionID: number;
  PetitionType: string;
  Fein: string;
  DunsNumber: string;
  FDNSDSNumber: string;
  AddressID: string;
  VisaType: string;
  ConfidenceFactor: string;
  RedAttorneyID: string;
  AttorneyFraud: string;
  AttorneyDoj: string;
  RedPetitionAddressID: string;
  Entity: string;
  Identifier: string;
}

export interface RedReportDateRequest {
  sourceSystemID: string;
  sourceTransactionID: string;
  endUserID: string;
  startDate: string;
  endDate: string;
  serviceCenter?: any;
}

export interface UpdateRedListPetition {
  receiptNumber: string;
  deliverToCFDO: boolean;
  petitionID: string;
}

export interface UpdateRedListPetitionSet {
  updateRedListPetition: UpdateRedListPetition[];
}

export interface RedReportMarkRequest {
  sourceSystemID: string;
  sourceTransactionID: string;
  endUserID: string;
  updateRedListPetitionSet: UpdateRedListPetitionSet;
}

export interface RedReportMarkSendResponse {
  RedReportMarkSendToCFDOResponse: RedReportMarkSendToCFDOResponse;
}
export interface RedReportMarkSendToCFDOResponse {
  SourceSystemID: string;
  SourceTransactionID: string;
  ServiceRequestTimestamp: string;
  ServiceResponseTimestamp: string;
  AuditCorrelationID: string;
  UpdateMessage: string;
}

export interface RedReportExportSchema {
  ReceivedIn: string;
  Entity: string;
  Identifier: string;
  Score: string;
  ReceiptNumber: string;
  FormType: string;
  VisaType: string;
  DateAdded: string;
}