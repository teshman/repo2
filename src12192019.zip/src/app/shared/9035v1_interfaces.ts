export interface dol9035vOne {
  GetDolDetailByPetitionIDResponse: GetDolDetailByPetitionIDResponse;
}
export interface GetDolDetailByPetitionIDResponse {
  SourceSystemID: string;
  SourceTransactionID: string;
  ServiceRequestTimestamp: string;
  ServiceResponseTimestamp: string;
  AuditCorrelationID: string;
  DolEtaFormType: string;
  DolEtaFormVersion: string;
  DolJsonData: string;
  
}
export interface DolData {
  DOL_DATA: DOLDATA;
}
export interface DOLDATA {
  DOL_ETA_CLOB: (DOLETACLOB)[] | DOLETACLOB;
  DOL_ETA_WORKSITES: DOLETAWORKSITES;
  DOL_ETA_EMPLOYERS: DOLETAEMPLOYERS;
  DOL_ETA_EDUCATION: DOLETAEDUCATION;
}


export interface DOLETACLOB {
  CASE_NUMBER: string;
  CASE_STATUS: string;
  CASE_CERTFROM: string;
  CASE_CERTTO: string;
  VISA_CLASS: string;
  TEMPNEED_JOBTITLE: string;
  TEMPNEED_SOCCODE: string;
  TEMPNEED_OCCTITLE: string;
  TEMPNEED_FULLTIME: string;
  TEMPNEED_START: string;
  TEMPNEED_END: string;
  TEMPNEED_POSITIONS: string;
  EMP_BUSINESS_NAME: string;
  EMP_TRADE_NAME: string;
  EMP_ADDR1: string;
  EMP_ADDR2: string;
  EMP_CITY: string;
  EMP_STATE: string;
  EMP_POSTCODE: string;
  EMP_COUNTRY: string;
  EMP_PHONE: string;
  EMP_FEIN: string;
  EMP_NAICS: string;
  NAICS_TEXT: string;
  EMPPOC_LASTNAME: string;
  EMPPOC_FIRSTNAME: string;
  EMPPOC_MIDDLENAME: string;
  EMPPOC_JOBTITLE: string;
  EMPPOC_ADDR1: string;
  EMPPOC_ADDR2: string;
  EMPPOC_CITY: string;
  EMPPOC_STATE: string;
  EMPPOC_POSTCODE: string;
  EMPPOC_COUNTRY: string;
  EMPPOC_PHONE: string;
  EMPPOC_EMAIL: string;
  ATTY_REPRESENT: string;
  WAGE_FROM: string;
  WAGE_PER: string;
  WRK1_ADDR1: string;
  WRK1_ADDR2: string;
  WRK1_CITY: string;
  WRK1_COUNTY: string;
  WRK1_STATE: string;
  WRK1_POSTALCODE: string;
  WRK1_STWORKAGENCY: string;
  WRK1_PWNUMBER: string;
  WRK1_WAGELEVEL: string;
  WRK1_WAGE: string;
  WRK1_WAGE_PER: string;
  WRK1_WAGE_SOURCE: string;
  WRK1_WAGE_YEAR: string;
  WRK1_SOURCE_OTHER: string;
  WRK2_ADDR1: string;
  WRK2_ADDR2: string;
  WRK2_CITY: string;
  WRK2_COUNTY: string;
  WRK2_STATE: string;
  WRK2_POSTALCODE: string;
  WRK2_STWORKAGENCY: string;
  WRK2_PWNUMBER: string;
  WRK2_WAGELEVEL: string;
  WRK2_WAGE: string;
  WRK2_WAGE_PER: string;
  WRK2_WAGE_SOURCE: string;
  WRK2_WAGE_YEAR: string;
  WRK2_SOURCE_OTHER: string;
  WRK3_ADDR1: string;
  WRK3_ADDR2: string;
  WRK3_CITY: string;
  WRK3_COUNTY: string;
  WRK3_STATE: string;
  WRK3_POSTALCODE: string;
  WRK3_STWORKAGENCY: string;
  WRK3_PWNUMBER: string;
  WRK3_WAGELEVEL: string;
  WRK3_WAGE: string;
  WRK3_WAGE_PER: string;
  WRK3_WAGE_SOURCE: string;
  WRK3_WAGE_YEAR: string;
  WRK3_SOURCE_OTHER: string;
  ATTEST_H1BDEPENDENT: string;
  ATTEST_WILLFULVIOLATOR: string;
  ATTEST_LIMITATION: string;
  ATTEST_PUBDISCLOSURE: string;
  DECLARE_LASTNAME: string;
  DECLARE_FIRSTNAME: string;
  PREP_LASTNAME: string;
  PREP_FIRSTNAME: string;
  PREP_MIDINITIAL: string;
  PREP_BIZNAME: string;
  PREP_EMAIL: string;
  CASE_DETERM_DATE: string;
  CASE_SUBMIT: string;
  LASTMOD_DATE: string;
  PRE_EMPAGREE: string;
  PRE_ATTESTTRUE: string;
  PRE_ELECTRONIC: string;
  SUBMIT_IPADDRESS: string;
  RECEIPT_NUMBER: string;
  SCORE_RUN_DATE: string;
}

export interface DOLETAWORKSITES {
  RESPONSECODE: string;
  RESPONSEMESSAGE: string;
  DOLCASENUMBER: string;
  PETITIONID: string;
}

export interface DOLETAEMPLOYERS {
  RESPONSECODE: string;
  RESPONSEMESSAGE: string;
  DOLCASENUMBER: string;
  PETITIONID: string;
}

export interface DOLETAEDUCATION {
  RESPONSECODE: string;
  RESPONSEMESSAGE: string;
  DOLCASENUMBER: string;
  PETITIONID: string;
}

