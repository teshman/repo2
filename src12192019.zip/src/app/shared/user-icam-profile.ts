export interface UserIcamProfile {
    X_REMOTE_CIS_DISTRICT: string;
    X_REMOTE_LAST_NAME: string;
    X_REMOTE_CIS_REGION: string;
    nameidFormat: string;
    X_REMOTE_CIS_SITE: string;
    X_REMOTE_USER: string;
    AttributeMap: string;
    X_REMOTE_HTTP_USER: string;
    X_REMOTE_DISPLAY_NAME: string;
    X_REMOTE_PIV_UPN: string;
    nameid: string;
    X_REMOTE_EMAIL: string;
    X_REMOTE_VIBE_ROLE: string;
    X_REMOTE_FIRST_NAME: string;
  }
  