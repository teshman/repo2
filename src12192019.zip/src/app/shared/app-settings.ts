export class AppSettings {
    //Predefinition Information Request Status Messages
    public static PREDEF_REQUEST_SAVE_MESSAGE = "Predefined Information for <Company Name > saved successfully. ";
    public static PREDEF_REQUEST_SUBMIT_MESSAGE = "Predefined Information for <Company Name > is submitted.";
    public static PREDEF_REQUEST_ACCEPT_MESSAGE = "Predefined Information for <Company Name > is accepted and it will become active from <start date> to <end date>.";
    public static PREDEF_REQUEST_REJECT_MESSAGE = "Predefined Information for <Company Name > is rejected.  ";
    public static PREDEF_REQUEST_EXPIRE_MESSAGE = "Predefined Information for <Company Name > is expired.  ";
    
    public static PREDEF_REQUEST_SAVE_FAILURE_MESSAGE = "System Exception: Unable to SAVE Predefined Information; please contact system administrator. ";
    public static PREDEF_REQUEST_SUBMIT_FAILURE_MESSAGE = "System Exception: Unable to SUBMIT Predefined Information; please contact system administrator.";
    public static PREDEF_REQUEST_ACCEPT_FAILURE_MESSAGE = "System Exception: Unable to ACCEPT Predefined Information; please contact system administrator.";
    public static PREDEF_REQUEST_REJECT_FAILURE_MESSAGE = "System Exception: Unable to REJECT Predefined Information; please contact system administrator.";
    public static PREDEF_REQUEST_EXPIRE_FAILURE_MESSAGE = "System Exception: Unable to REJECT Predefined Information; please contact system administrator.";
    public static USER_IDLE_TIME = 3600;    //60 min 
    public static USER_TIMEOUT = 300;       //5 min 
    public static USER_PING_INTERVAL = 600; //10 min 

    public static SERVICE_TIMEOUT = 60; //60 seconds 

    public static VSR_RESPNSE_JSON = './assets/receipt-search-response.json';
    public static RESUBMIT_RESPONSE_JSON = './assets/resubmitResponse.json';
    public static US_STATES_JSON = './assets/us-states.json';
    public static PROVINCES_JSON = './assets/provinces.json';
    public static COUNTRIES_JSON = './assets/countries.json';
    public static DOL_INFORMATION_JSON = './assets/receipt-search-response.json';
    public static HISTORY_SEARCH_RESPONSE_JSON = './assets/history-search-response.json';
    public static DOL_9035V2_JSON = './assets/9035v2tab1.json';
    public static DOL_9035V2_JSON2 = './assets/9035v2tab2.json';
    //public static DOL_DATA_JSON = './assets/H30017178227081-dol-data.json';
   public static SCORE_CARD_JSON = './assets/scoreCard.json';
    //public static DOL_DATA_JSON = './assets/H30014321198839.json';
   // public static DOL_DATA_JSON = './assets/9142C.json';
    public static DOL_DATA_JSON = './assets/9142BPetition.json';
    public static DOL_DISPLAY_RECEIPT_FROM_DATE = "2017-10-01";
    public static PREVIOUS_FILING_RESPONSE = './assets/previousfilingsResponseDuns.json'
    //Page Titles
    public static VSR_TITLE = 'VIBE PLUS - Status Report';
    public static RED_REPORT_TITLE = 'VIBE PLUS - Red Report';
    public static ETA_TITLE = 'VIBE PLUS - DOL ETA Case Detail';
    public static INDEPENDENT_MANUAL_TITLE = 'VIBE PLUS - Independent Manual Query';    
    public static TSVVP_REPORT_TITLE = 'VIBE PLUS - TSVVP Report';
    public static PREDEFINED_INFO_TITLE = 'VIBE PLUS - Predefined Information'; 
    public static DATA_INQUIRY_TITLE = 'VIBE PLUS - Data Inquiry ';
    public static REPORTS_TITLE = 'VIBE PLUS - Reports ';
    public static CIS_USERS_JSON = './assets/frequent-users.json';
    public static CIS_FREQUENT_USERS_URL = '/vibe-plus/rest/frequent-updaters/PRE_DEF_USERS';
    public static DI_FREQUENT_USERS_URL = '/vibe-plus/rest/frequent-updaters/DATA_INQUIRY_USERS';
    public static DATA_INQUIRY_MAX_ROWS = 1000;
    public static PREDEF_INFO_LIST_JSON = './assets/predefined-information.json';
    public static PREDEF_INFO_DETAIL_BY_EXCEPTION_ID_JSON = './assets/predef-detail-by-exception-id.json';
    public static PREDEF_INFO_ORGANIZATION_LOOKUP_JSON = './assets/OrganizationLookupResponse.json';
    
    //Service URLS
    public static VIBE_PLUS_URL = '/vibe-plus';
    public static VSR_URL = '/vibe-plus/rest/vsr/receipt';
    public static VSR_DOL_MANUAL_URL = '/vibe-plus/rest/vsr/dol';
    public static PREDEF_URL = '/vibe-plus/rest/predef-info/get-list/ALL/after/';
    public static PREDEF_DETAIL_URL = '/vibe-plus/rest/predef-info/get-detail/';
    public static SCORE_CARD_URL = '/vibe-plus/rest/score/scorecard';
    public static USER_PROFILE_URL = '/vibe-plus/rest/session/user/vibe-detail';
    public static USER_LOGOUT_URL = '/vibe-plus/rest/session/user/logout';

    public static SOURCE_SYSTEM_ID = "vsr-resubmit";
    public static SOURCE_TRANSACTION_ID = "resubmit-12345678";
    public static END_USER_ID = "vsr user";
    public static RED_REPORTS_DATE_URL = "/vibe-plus/rest/redlist/date-range";
    public static RED_REPORTS_MARK_URL = "/vibe-plus/rest/redlist/mark-sent"


    //VIBE Status/Error codes
    public static VSR_STATUS_CODE_001 = "ESB-VIBE.STATUS.001";
    public static VSR_STATUS_CODE_002 = "ESB-VIBE.STATUS.002";
    public static VSR_STATUS_CODE_003 = "ESB-VIBE.STATUS.003";
    public static VSR_STATUS_CODE_004 = "ESB-VIBE.STATUS.004";
    
    public static VSR_EXCEPTION_CODE_0500 = "ESB-VIBE-VIBE-0500";
    public static VSR_EXCEPTION_CODE_0108 = "ESB-VIBE-VIBE-0108";
    public static VSR_EXCEPTION_CODE_0107 = "ESB-VIBE-VIBE-0107"; 

    //Status/ERROR Descriptions
    
    public static VSR_STATUS_CODE_001_DESC = "No search results could be found for this query.";
    public static VSR_STATUS_CODE_002_DESC = "Operation Successful";
    public static VSR_STATUS_CODE_003_DESC = "Operation Not Successful.";
    public static VSR_STATUS_CODE_004_DESC = "VIBE returned a blank VSR for receipt's petition address.";
    public static HTTP_STATUS_400 = "400 - Bad Request.";
    public static HTTP_STATUS_401 = "401 - System Timeout Error.";
    public static HTTP_STATUS_404 = "404 - Not found.";
    public static HTTP_STATUS_500 = "500 - Internal Server Error.";
    public static HTTP_STATUS_503 = "503 - Service unavailable.";
    public static HTTP_STATUS_502 = "502 - Proxy Error.";
    public static HTTP_STATUS_599 = "599 - Network connect timeout error.";
    public static HTTP_STATUS_408 = "408 - Request timedout.";
    public static HTTP_STATUS_UNKNOWN = "UNKNOWN ERROR";
    public static VSR_EXCEPTION_CODE_0107_DESC = "Receipt Not Processed.";
    public static VSR_EXCEPTION_CODE_0108_DESC = "Receipt number not found.";
    public static VSR_EXCEPTION_CODE_0500_DESC = "Receipt could not be processed. Please contact the VIBE-SCOPS mailbox";
    public static SYSTEM_EXCEPTION = "A system exception was encountered while executing your request. Please contact your system administrator.";
    public static GOOGLEMAPS_NO_STREETVIEW = "Google street view is not available for this address,  a satellite view is provided for accessibility."
    public static GOOGLEMAPS_NO_MAP = "Google street view and satellite view are not available for this address."
    public static PO_BOX_STREET_VIEW_NOT_AVAILABLE = 'Google street view is not available for P.O. Box addresses.  Please conduct a manual search using the petitioner’s physical address for Google street view.';
    public static INVALID_ADDRESS_GOOGLE_MAP_NOT_AVAILABLE = 'Google street view is not available for incomplete addresses. Please conduct a manual search using the petitioner’s full physical address to enable Google street view.';
   
    public static MAX_RECORDS_TO_COMPARE_WARNING = 'A maximum of two records may be selected and viewed at the same time.'
    public static MAX_RECORDS_TO_COMPARE_PROMPT = 'Select one record to view that VSR. Select up to two records for a side by side comparison.';

    public static PREV_FILINGS_HUB_NOT_FOUND="No Previous Filings for VIBE eligible forms and classifications were found for the Company or Organization for the last 36 months."
    public static INVALID_ADDRESS="Valid Company Name and Address are required."
    public static MARK_SENT_UPDATE_ERROR="Records could not be updated.  Please contact your system administrator."


    //Common Erors 
    //====================================
    public static INVALID_DUNS="A valid DUNS number format is 9 digits."; 
    public static INVALID_RECEIPT_NUMBER="Receipt Number format is 3 letters followed by 10 numerals (no more than 13 characters).";
    public static INVALID_FEIN_NUMBER="A valid FEIN format is 9 digits.";


    //Previous Filings Errors
    //===============================
    public static NO_PREVIOUS_FILINGS_FOUND="No Previous Filings for VIBE eligible forms and classifications were found for the Company or Organization for the last 36 months."

    //=====================================
    //SETTINGS
    public static PAGINATION_COUNT = "20";
    public static API_KEY = "AIzaSyCW1C3cbnW9G1kKeOVUUaWKrOGTlBTquTQ";
    //PRE PROD: AIzaSyCW1C3cbnW9G1kKeOVUUaWKrOGTlBTquTQ
    //PROD: AIzaSyDGWPOh5AgnDBrY6akzP-LT1yqz62UtbYA

    //VISA type to Form Type 
    public static i129 = ["1B1", "1B2", "1B3", "HSC", "L1A", "L1B", "R1", "TN1", "TN2", "E1", "E2", "E3", "H2A", "H2B", "H3", "LZ", "Q1", "CW1"];
    public static i140 = ["E12", "E13", "E21", "E31", "E32", "EW3" ];
    public static i360 = ["SD1/SD6", "SR1/SR6", "SD1/SR1"];
    public static i485J = ["N/A"];

    // ssb string constants 
    public static SSB_vsr_DISPLAY = "VSR"; 
    public static SSB_previousFilings_DISPLAY="Previous Filings Hub";
    public static SSB_prevEtaFilings_DISPLAY= "ETA Associated Filings";
    public static SSB_dolEtaLookup_DISPLAY= "DOL ETA Lookup";

    public static SSB_pfEta_DISPLAY= "DOL ETA Case Number";
    public static SSB_dolEta_DISPLAY= "DOL ETA Case Number";
    
    public static SSB_receiptNumber_DISPLAY="Receipt Number"
    public static SSB_dolAddr_DISPLAY="Business Name and Address"
    
    public static SSB_pfFein_DISPLAY="FEIN"
    public static SSB_pfBA_DISPLAY="Business Name and Address"
    public static SSB_pfDuns_DISPLAY="DUNS Number"

    public static SSB_receiptNumber_DESCRIPTION="VIBE Status Report Search" ;
    public static SSB_dolAddr_DESCRIPTION="VIBE Status Report search based on business name and address" ;

    public static SSB_pfFein_DESCRIPTION="3-year USCIS previous filing search based on FEIN" ;
    public static SSB_pfBA_DESCRIPTION= "3-year USCIS previous filing search based on Business Name and Address matching at confidence code > 6" 
    public static SSB_pfDuns_DESCRIPTION="3-year USCIS previous filing search based on DUNS Number matching at confidence code > 6";
    public static SSB_pfEta_DESCRIPTION="USCIS previous filing search based on DOL ETA Case Number (For ETA 9035 and ETA 9142 only)."
    public static SSB_dolEta_DESCRIPTION="DOL ETA Search (For ETA 9035 and ETA 9142 only)"

    //component status
    public static CS_SSB="SSB"
    public static CS_VSR="VSR"
    public static CS_APP="APP"
    public static CS_VSR_DOL_MANUAL="VSR_DOL_MANUAL"
    
    public static CS_PREVIOUS_FILINGS_HUB="PFH"
    public static CS_DOL_ETA_LOOKUP="DEL"
    public static CS_DOL_ETA_9035V1="ETA_9035V1"
    public static CS_DOL_ETA_9035V2="ETA_9035V2"
    public static CS_DOL_ETA_9142C="ETA_9142C"
    public static CS_DOL_ETA_9142A="ETA_9142A"
    public static CS_DOL_ETA_9142BV2="ETA_9142BV2"
    public static CS_PREDEF_INFO="PREDEF_INFO"

}


