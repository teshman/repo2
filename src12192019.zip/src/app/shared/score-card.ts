export interface ScoreCard {
    ScoreCardGetResponse: ScoreCardGetResponse;
  }
  export interface ScoreCardGetResponse {
    SourceSystemID: string;
    SourceTransactionID: string;
    ServiceRequestTimestamp: string;
    ServiceResponseTimestamp: string;
    AuditCorrelationID: string;
    ScoreCardResultSet: ScoreCardResultSet;
  }
  export interface ScoreCardResultSet {
    ScoreCardRecord?: (ScoreCardRecordEntity)[] | null;
  }
  export interface ScoreCardRecordEntity {
    BusinessRuleName: string;
    Score: string;
  }
  