export interface FrequentUser {
    FrequentUpdaterListGetResponse: FrequentUpdaterListGetResponse;
  }
  export interface FrequentUpdaterListGetResponse {
    SourceSystemID: string;
    SourceTransactionID: string;
    ServiceRequestTimestamp: string;
    ServiceResponseTimestamp: string;
    AuditCorrelationID: string;
    FrequentUserResultSet: FrequentUserResultSet;
  }
  export interface FrequentUserResultSet {
    lastRecordIndex: number;
    recordCountInThisResultSet: number;
    totalRecordCount: number;
    FrequentUserRecord?: (FrequentUserRecordEntity)[] | null;
  }
  export interface FrequentUserRecordEntity {   
     CisUser: string;
     PivUpn: string;
  }
  