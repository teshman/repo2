
export class PredefinedInformationWorkflowRequest {
    
    sourceSystemID: string;
    sourceTransactionID: string;
    endUserID: string;
    exceptionID: string;
    receiptNumber: string;
    fein: string;
    duns: string;
    agn: string;
    // iipConfidenceCode:string;
    validUntilDateRange:ValidUntilDateRange;
    overrideScore: string;
    office: string;
    fdnsdsNumber: string;
    predefinedInformationComment: string;
    justificationComment: string;
    siteVisitProgram: string;
    nominationSource: string;
    operationCode: string;
    addressId: string;
    organizationName: string;
    address: PredfinedInfoRequestAddress;
    preDefCommentType: string;
    preDefFormCommentType: string;

    public constructor(
        fields?: {
            sourceSystemID: string;
            sourceTransactionID: string;
            endUserID: string;
            exceptionID: string;
            receiptNumber: string;
            fein: string;
            duns: string;
            agn: string;
            // iipConfidenceCode:string;
            validUntilDateRange:ValidUntilDateRange;
            overrideScore: string;
            office: string;
            fdnsdsNumber: string;
            predefinedInformationComment: string;
            justificationComment: string;
            siteVisitProgram: string;
            nominationSource: string;
            operationCode: string;
            addressId: string;
            organizationName: string;
            address: PredfinedInfoRequestAddress;
            preDefCommentType: string;
            preDefFormCommentType: string;
        }) {
        if (fields) Object.assign(this, fields);
    }
    public setValidUntilDateRange(startDate:string, endDate:string){
        this.validUntilDateRange = new ValidUntilDateRange();
        this.validUntilDateRange.startDate = startDate;
        this.validUntilDateRange.endDate = endDate;
    }
}

 
  export class ValidUntilDateRange {
    startDate: string;
    endDate: string;

    public constructor(
        fields?: {
            city: string;
            country: string;
        }) {
        if (fields) Object.assign(this, fields);
    }

}

export class PredfinedInfoRequestAddress {
    addressId: string;
    city: string;
    country: string;
    organizationName: string;
    postalCode: string;
    state: string;
    streetExtension: string;
    streetFull: string;
    telephoneNumber: string;
    singleLineFullAddress: string;

    public constructor(
        fields?: {
            addressId: string;
            city: string;
            country: string;
            organizationName: string;
            postalCode: string;
            state: string;
            streetExtension: string;
            streetFull: string;
            telephoneNumber: string;
            singleLineFullAddress: string;
        }) {
        if (fields) Object.assign(this, fields);
    }

}




    export interface ResponseStatusMessage {
        statusCode: string;
        Status: string;
    }

    export interface PredefinedInformationResponse {
        SourceSystemID: string;
        SourceTransactionID: string;
        ServiceRequestTimestamp: Date;
        ServiceResponseTimestamp: Date;
        AuditCorrelationID: string;
        responseStatusMessage: ResponseStatusMessage;
        ExceptionID: string;
    }

    export interface WorkflowResponse {
        PredefinedInformationResponse: PredefinedInformationResponse;
    }



