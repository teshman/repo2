export interface Previousfiling {
  PreviousFilingsGetByDolCaseNumberResponse: PreviousFilingsGetByDolCaseNumberResponse;
}
export interface PreviousFilingsGetByDolCaseNumberResponse {
  SourceSystemID: string;
  SourceTransactionID: string;
  ServiceRequestTimestamp: string;
  ServiceResponseTimestamp: string;
  AuditCorrelationID: string;
  PreviousFilingsDolResultSet: PreviousFilingsDolResultSet;
}
export interface PreviousFilingsDolResultSet {
  lastRecordIndex: number;
  recordCountInThisResultSet: number;
  totalRecordCount: number;
  PreviousFilingDolRecord?: (PreviousFilingDolRecordEntity)[] | null;
}
export interface PreviousFilingDolRecordEntity {
  ReceiptNumber: string;
  DolEtaCaseNumber: string;
  NumberOfBen: string;
  NumberOfApprBen: string;
  ReceiptDate: string;
  OrganizationName: string;
  FormType: string;
  EtaStatus: string;
}

export interface pfDunsRequest {
  sourceSystemID: string;
  sourceTransactionID: string;
  endUserID: string;
  startRecordNumber: string;
  endRecordNumber: string;
  sortByColumnNamePrevFilings: string;
  sortOrder: string;
  organizationName: string;
  dunsNumber: string;
  petitionType: string;
  timePeriod: string;
  c3StatusCode: string[];
  visaType: string[];
}
