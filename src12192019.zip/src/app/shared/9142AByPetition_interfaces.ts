  export interface DOLETACLOB {
      CASE_NUMBER: string;
      CASE_STATUS: string;
      CASE_DETERMIN_DATE: string;
      CASE_VALID_FROM: string;
      CASE_VALID_TO: string;
      CASE_TYPE: string;
      VISA_TYPE: string;
      NAT_EMP_TYPE: string;
      NAT_IS_H2A_LBRCONTRACTOR: string;
      NAT_TEMP_NEED: string;
      NAT_IS_NEED_STATEMENT_ATTACHED: string;
      NAT_IS_EMERGENCY_SITUATION: string;
      NAT_EMERGENCY_SIT_ATTACHED: string;
      EMP_BUSINESS_NAME: string;
      EMP_TRADE_NAME: string;
      EMP_ADDR1: string;
      EMP_ADDR2: string;
      EMP_CITY: string;
      EMP_STATE: string;
      EMP_POSTCODE: string;
      EMP_COUNTRY: string;
      EMP_PROVINCE: string;
      EMP_PHONE: string;
      EMP_PHONEEXT: string;
      EMP_FEIN: string;
      EMP_NAICS: string;
      EMPPOC_LASTNAME: string;
      EMPPOC_FIRSTNAME: string;
      EMPPOC_MIDDLENAME: string;
      EMPPOC_JOBTITLE: string;
      EMPPOC_ADDR1: string;
      EMPPOC_ADDR2: string;
      EMPPOC_CITY: string;
      EMPPOC_STATE: string;
      EMPPOC_POSTCODE: string;
      EMPPOC_COUNTRY: string;
      EMPPOC_PROVINCE: string;
      EMPPOC_PHONE: string;
      EMPPOC_PHONEEXT: string;
      EMPPOC_EMAIL: string;
      ATTY_REPRESENT_TYPE: string;
      ATTY_LASTNAME: string;
      ATTY_FIRSTNAME: string;
      ATTY_MIDDLENAME: string;
      ATTY_ADDR1: string;
      ATTY_ADDR2: string;
      ATTY_CITY: string;
      ATTY_STATE: string;
      ATTY_POSTCODE: string;
      ATTY_COUNTRY: string;
      ATTY_PROVINCE: string;
      ATTY_PHONE: string;
      ATTY_PHONEEXT: string;
      ATTY_EMAIL: string;
      ATTY_BIZNAME: string;
      ATTY_FEIN: string;
      ATTY_STATEBARNO: string;
      ATTY_STATEHIGHCT: string;
      ATTY_NAMEHIGHCT: string;
      ATTY_IS_AGREEMENT_ATTACHED: string;
      AGNT_IS_MSPA_ATTACHED: string;
      JOB_SOC: string;
      JOB_SOC_TITLE: string;
      JOB_ORDER_ATTACHED: string;
      JOB_ORDER_NUMBER: string;
      JOB_JOINT_EMP_DETAILS: string;
      JOB_FIXED_SITE_DETAILS: string;
      JOB_WORK_CONTRACT_ATTACHED: string;
      JOB_MSPA_ATTACHED: string;
      JOB_SURETY_BOND_ATTACHED: string;
      JOB_HOUSING_TRANSPORT: string;
      DECLARE_IS_CONFM_APDX_A: string;
      DECLARE_CONFM_EMP: string;
      PREP_LASTNAME: string;
      PREP_FIRSTNAME: string;
      PREP_MIDDLENAME: string;
      PREP_FEIN: string;
      PREP_BIZNAME: string;
      PREP_EMAIL: string;
      DATE_SUBMITTED: string;
      DATE_LAST_MODIFIED: string;
      FINAL_DETERM_LTR_ISSUED: string;
      RECEIPT_NUMBER: string;
      SCORE_RUN_DATE: string;
  }

  export interface DOLETAWORKSITE {
      JOB_ORDER_NUMBER: string;
      ROW_NUM: string;
      ADDMB_EMP_BUZNAME: string;
      ADDMB_EMP_ADDR1: string;
      ADDMB_EMP_ADDR2: string;
      ADDMB_EMP_CITY: string;
      ADDMB_EMP_POSTCODE: string;
      ADDMB_EMP_STATE: string;
      ADDMB_EMP_COUNTY: string;
      ADDMB_EMP_ADDITIONAL_INFO: string;
      ADDMB_EMP_BEGIN_DATE: string;
      ADDMB_EMP_END_DATE: string;
      ADDMB_EMP_TOTAL_WRKS: string;
      DATE_LAST_MODIFIED: string;
  }

  export interface DOLETAEMPLOYERS {
      RESPONSECODE: string;
      RESPONSEMESSAGE: string;
      DOLCASENUMBER: string;
      PETITIONID: string;
  }

  export interface DOLETAEDUCATION {
      RESPONSECODE: string;
      RESPONSEMESSAGE: string;
      DOLCASENUMBER: string;
      PETITIONID: string;
  }

  export interface DOLETAFRNREC {
      RESPONSECODE: string;
      RESPONSEMESSAGE: string;
      DOLCASENUMBER: string;
      PETITIONID: string;
  }

  export interface DOLETAFDCERT {
      CASE_NUMBER: string;
      CASE_STATUS: string;
      CASE_DETERMIN_DATE: string;
      EMP_LEGAL_NAME: string;
      EMP_FEIN: string;
      JOB_TITLE: string;
      JOB_SOC: string;
      JOB_SOC_TITLE: string;
      CERTIFIED_WORKERS: string;
      START_DATE: string;
      END_DATE: string;
  }

  export interface DOLETAAGCLEARANCE {
      JOB_ORDER_NUMBER: string;
      JOB_TITLE: string;
      JOB_WRKS_NEEDED: string;
      JOB_WRKS_NEEDED_H2A: string;
      JOB_BEGIN_DATE: string;
      JOB_END_DATE: string;
      JOB_IS_ONCALL: string;
      JOB_HOURS_TOTAL: string;
      JOB_HOURS_SUN: string;
      JOB_HOURS_MON: string;
      JOB_HOURS_TUE: string;
      JOB_HOURS_WED: string;
      JOB_HOURS_THU: string;
      JOB_HOURS_FRI: string;
      JOB_HOURS_SAT: string;
      JOB_HOURS_START: string;
      JOB_STARTPERIOD: string;
      JOB_HOURS_END: string;
      JOB_ENDPERIOD: string;
      JOB_DUTIES: string;
      JOB_WAGE_OFFER: string;
      JOB_WAGE_PER: string;
      JOB_PIECE_RATE: string;
      JOB_SPECIAL_PAY_INFO: string;
      IS_ADDM_A_ATTACHED: string;
      JOB_PAY_FREQUENCY: string;
      JOB_PAY_FREQUENCY_OTHER: string;
      JOB_PAY_DEDUCTION: string;
      JOB_MINEDU: string;
      JOB_MINEXPMONTHS: string;
      JOB_MINTRAININGMONTHS: string;
      JOB_IS_CERT: string;
      JOB_IS_DRIVER: string;
      JOB_IS_BACKGROUND: string;
      JOB_IS_DRUG_SCREEN: string;
      JOB_IS_LIFTING: string;
      JOB_LIFTING_WEIGHT: string;
      JOB_IS_TEMPERATURE: string;
      JOB_IS_PUSHING: string;
      JOB_IS_SITTING: string;
      JOB_IS_BENDING: string;
      JOB_IS_REPETITIVE: string;
      JOB_IS_SUPERVISING: string;
      JOB_NUMBER_SUP: string;
      JOB_ADD_REQINFO: string;
      JOB_ADDR1: string;
      JOB_CITY: string;
      JOB_STATE: string;
      JOB_POSTCODE: string;
      JOB_COUNTY: string;
      JOB_ADD_LOCINFO: string;
      IS_ADDM_B_ATTACHED: string;
      HOUSING_ADDR1: string;
      HOUSING_ADDR2: string;
      HOUSING_CITY: string;
      HOUSING_STATE: string;
      HOUSING_POSTCODE: string;
      HOUSING_COUNTY: string;
      HOUSING_TYPE: string;
      HOUSING_TOTAL_UNITS: string;
      HOUSING_TOTAL_OCCUPY: string;
      HOUSING_COMP_LOCAL: string;
      HOUSING_COMP_STATE: string;
      HOUSING_COMP_FEDERAL: string;
      HOUSING_ADD_INFO: string;
      HOUSING_ADDM_B_ATTACHED: string;
      MEAL_DESCRIPTION: string;
      MEAL_IS_CHARGED: string;
      MEAL_CHARGE: string;
      TRANSPORT_DESC_DAILY: string;
      TRANSPORT_DESC_EMP: string;
      TRANSPORT_MINREIMBURSE: string;
      TRANSPORT_MAXREIMBURSE: string;
      REC_DETAILS: string;
      REC_APPLY_PHONE: string;
      REC_APPLY_EMAIL: string;
      REC_APPLY_URL: string;
      IS_ADDM_C_ATTACHED: string;
      DATE_SUBMITTED: string;
      DATE_LAST_MODIFIED: string;
  }

  export interface DOLETACROPWAGE {
      JOB_ORDER_NUMBER: string;
      ROW_NUM: string;
      ADDMA_CROP_ID: string;
      ADDMA_CROP_ACTIVITY: string;
      ADDMA_WAGE_OFFER: string;
      ADDMA_PAY_PER: string;
      ADDMA_ADDITIOAL_INFO: string;
      DATE_LAST_MODIFIED: string;
  }

  export interface DOLETAHOUSING {
      JOB_ORDER_NUMBER: string;
      ROW_NUM: string;
      ADDMB_HOUSING_TYPE: string;
      ADDMB_HOUSING_ADDR1: string;
      ADDMB_HOUSING_ADDR2: string;
      ADDMB_HOUSING_CITY: string;
      ADDMB_HOUSING_POSTCODE: string;
      ADDMB_HOUSING_STATE: string;
      ADDMB_HOUSING_COUNTY: string;
      ADDMB_HOUSING_ADDITIONAL_INFO: string;
      ADDMB_HOUSING_TOTAL_UNITS: string;
      ADDMB_HOUSING_TOTAL_OCCUPY: string;
      ADDMB_HOUSING_COMPLY_LOCAL: string;
      ADDMB_HOUSING_COMPLY_STATE: string;
      ADDMB_HOUSING_COMPLY_FEDERAL: string;
      DATE_LAST_MODIFIED: string;
  }

  export interface DOLETAADDLINFO {
      JOB_ORDER_NUMBER: string;
      ROW_NUM: string;
      ADDMC_SECTION_NAME: string;
      ADDMC_SECTION_NUMBER: string;
      ADDMC_SECTION_DETAILS: string;
      DATE_LAST_MODIFIED: string;
  }

  export interface DOLDATA {
      DOL_ETA_CLOB: DOLETACLOB;
      DOL_ETA_WORKSITES: DOLETAWORKSITE | DOLETAWORKSITE[]
      DOL_ETA_EMPLOYERS: DOLETAEMPLOYERS;
      DOL_ETA_EDUCATION: DOLETAEDUCATION;
      DOL_ETA_FRN_REC: DOLETAFRNREC;
      DOL_ETA_FD_CERT: DOLETAFDCERT | DOLETAFDCERT[];
      DOL_ETA_AG_CLEARANCE: DOLETAAGCLEARANCE;
      DOL_ETA_CROP_WAGE: DOLETACROPWAGE | DOLETACROPWAGE[];
      DOL_ETA_HOUSING: DOLETAHOUSING | DOLETAHOUSING[];
      DOL_ETA_ADDL_INFO: DOLETAADDLINFO[];
  }

  export interface DolJsonData {
      DOL_DATA: DOLDATA;
  }

  export interface GetDolDetailByPetitionIDResponse {
    SourceSystemID: string;
    SourceTransactionID: string;
    ServiceRequestTimestamp: string;
    ServiceResponseTimestamp: string;
    AuditCorrelationID: string;
    DolEtaFormType: string;
    DolEtaFormVersion: string;
    DolJsonData: DolJsonData;
  }

  export interface dolPetitionResponse9142A {
    GetDolDetailByPetitionIDResponse1: GetDolDetailByPetitionIDResponse;
  }

