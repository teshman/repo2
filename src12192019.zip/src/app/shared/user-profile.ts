export interface UserProfile {
    firstName: string;
    lastName: string;
    displayName: string;
    cisDistrict: string;
    cisSite: string;
    cisRegion: string;
    role: string;
    email: string;
    pivUpn: string;
    username: string;
    httpUsername: string;
    vibeData: string;
    hasVibeRole: boolean;
    topLevelNavigationBasedOnUserRole?: (TopLevelNavigationBasedOnUserRoleEntity)[] | null;
    dashboardReviewer: boolean;
    cfdoOrRiskAnalyst: boolean;
    businessAdministrator: boolean;
    nonUscisUser: boolean;
    dolUser: boolean;
    standardUser: boolean;
    dosUser: boolean;
    vibeTeam: boolean;
    authenticated: boolean;
  }
  export interface TopLevelNavigationBasedOnUserRoleEntity {
    id: string;
    display: string;
    url: string;
  }
  