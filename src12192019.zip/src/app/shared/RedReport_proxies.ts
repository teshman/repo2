// Proxies for Date Request-Response
let obj: any = null;
export class RedReportGetDateResponseProxy {
  public readonly RedReportGetAdvancedResponse: RedReportGetAdvancedResponseProxy;
  public static Parse(d: string): RedReportGetDateResponseProxy {
    return RedReportGetDateResponseProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): RedReportGetDateResponseProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    d.RedReportGetAdvancedResponse = RedReportGetAdvancedResponseProxy.Create(d.RedReportGetAdvancedResponse, field + ".RedReportGetAdvancedResponse");
    return new RedReportGetDateResponseProxy(d);
  }
  private constructor(d: any) {
    this.RedReportGetAdvancedResponse = d.RedReportGetAdvancedResponse;
  }
}

export class RedReportGetAdvancedResponseProxy {
  public readonly SourceSystemID: string;
  public readonly SourceTransactionID: string;
  public readonly ServiceRequestTimestamp: string;
  public readonly ServiceResponseTimestamp: string;
  public readonly AuditCorrelationID: string;
  public readonly RedReportResultSet: RedReportResultSetProxy;
  public static Parse(d: string): RedReportGetAdvancedResponseProxy {
    return RedReportGetAdvancedResponseProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): RedReportGetAdvancedResponseProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    checkString(d.SourceSystemID, false, field + ".SourceSystemID");
    checkString(d.SourceTransactionID, false, field + ".SourceTransactionID");
    checkString(d.ServiceRequestTimestamp, false, field + ".ServiceRequestTimestamp");
    checkString(d.ServiceResponseTimestamp, false, field + ".ServiceResponseTimestamp");
    checkString(d.AuditCorrelationID, false, field + ".AuditCorrelationID");
    d.RedReportResultSet = RedReportResultSetProxy.Create(d.RedReportResultSet, field + ".RedReportResultSet");
    return new RedReportGetAdvancedResponseProxy(d);
  }
  private constructor(d: any) {
    this.SourceSystemID = d.SourceSystemID;
    this.SourceTransactionID = d.SourceTransactionID;
    this.ServiceRequestTimestamp = d.ServiceRequestTimestamp;
    this.ServiceResponseTimestamp = d.ServiceResponseTimestamp;
    this.AuditCorrelationID = d.AuditCorrelationID;
    this.RedReportResultSet = d.RedReportResultSet;
  }
}

export class RedReportResultSetProxy {
  public readonly totalRecordCount: number;
  public readonly lastRecordIndex: number;
  public readonly recordCountInThisResultSet: number;
  public readonly RedReportRecord: RedReportRecordEntityProxy[] | null;
  public static Parse(d: string): RedReportResultSetProxy {
    return RedReportResultSetProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): RedReportResultSetProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    checkNumber(d.totalRecordCount, false, field + ".totalRecordCount");
    checkNumber(d.lastRecordIndex, false, field + ".lastRecordIndex");
    checkNumber(d.recordCountInThisResultSet, false, field + ".recordCountInThisResultSet");
    checkArray(d.RedReportRecord, field + ".RedReportRecord");
    if (d.RedReportRecord) {
      for (let i = 0; i < d.RedReportRecord.length; i++) {
        d.RedReportRecord[i] = RedReportRecordEntityProxy.Create(d.RedReportRecord[i], field + ".RedReportRecord" + "[" + i + "]");
      }
    }
    if (d.RedReportRecord === undefined) {
      d.RedReportRecord = null;
    }
    return new RedReportResultSetProxy(d);
  }
  private constructor(d: any) {
    this.totalRecordCount = d.totalRecordCount;
    this.lastRecordIndex = d.lastRecordIndex;
    this.recordCountInThisResultSet = d.recordCountInThisResultSet;
    this.RedReportRecord = d.RedReportRecord;
  }
}

export class RedReportRecordEntityProxy {
  public readonly OrganizationName: string;
  public readonly Score: string;
  public readonly ReceiptNumber: string;
  public readonly ReceiptDate: string;
  public readonly DeliverToCFDO: boolean;
  public readonly PetitionID: number;
  public readonly PetitionType: string;
  public readonly Fein: null;
  public readonly DunsNumber: string;
  public readonly FDNSDSNumber: string;
  public readonly AddressID: string;
  public readonly VisaType: string;
  public readonly ConfidenceFactor: string;
  public readonly RedAttorneyID: string;
  public readonly AttorneyFraud: string;
  public readonly AttorneyDoj: string;
  public readonly RedPetitionAddressID: string;
  public readonly Entity: string;
  public readonly Identifier: string;
  public static Parse(d: string): RedReportRecordEntityProxy {
    return RedReportRecordEntityProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): RedReportRecordEntityProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    checkString(d.OrganizationName, false, field + ".OrganizationName");
    checkString(d.Score, false, field + ".Score");
    checkString(d.ReceiptNumber, false, field + ".ReceiptNumber");
    checkString(d.ReceiptDate, false, field + ".ReceiptDate");
    checkBoolean(d.DeliverToCFDO, false, field + ".DeliverToCFDO");
    checkNumber(d.PetitionID, false, field + ".PetitionID");
    checkString(d.PetitionType, false, field + ".PetitionType");
    checkString(d.Fein, false, field + ".Fein");
    checkString(d.DunsNumber, false, field + ".DunsNumber");
    checkString(d.FDNSDSNumber, false, field + ".FDNSDSNumber");
    checkString(d.AddressID, false, field + ".AddressID");
    checkString(d.VisaType, false, field + ".VisaType");
    checkString(d.ConfidenceFactor, false, field + ".ConfidenceFactor");
    checkString(d.RedAttorneyID, false, field + ".RedAttorneyID");
    checkString(d.AttorneyFraud, false, field + ".AttorneyFraud");
    checkString(d.AttorneyDoj, false, field + ".AttorneyDoj");
    checkString(d.RedPetitionAddressID, false, field + ".RedPetitionAddressID");
    checkString(d.Entity, false, field + ".Entity");
    checkString(d.Identifier, false, field + ".Identifier");
    return new RedReportRecordEntityProxy(d);
  }
  private constructor(d: any) {
    this.OrganizationName = d.OrganizationName;
    this.Score = d.Score;
    this.ReceiptNumber = d.ReceiptNumber;
    this.ReceiptDate = d.ReceiptDate;
    this.DeliverToCFDO = d.DeliverToCFDO;
    this.PetitionID = d.PetitionID;
    this.PetitionType = d.PetitionType;
    this.Fein = d.Fein;
    this.DunsNumber = d.DunsNumber;
    this.FDNSDSNumber = d.FDNSDSNumber;
    this.AddressID = d.AddressID;
    this.VisaType = d.VisaType;
    this.ConfidenceFactor = d.ConfidenceFactor;
    this.RedAttorneyID = d.RedAttorneyID;
    this.AttorneyFraud = d.AttorneyFraud;
    this.AttorneyDoj = d.AttorneyDoj;
    this.RedPetitionAddressID = d.RedPetitionAddressID;
    this.Entity = d.Entity;
    this.Identifier = d.Identifier;
  }
}
//Proxies for Mark send Response
export class RedReportMarkSendResponseProxy {
  public readonly RedReportMarkSendToCFDOResponse: RedReportMarkSendToCFDOResponseProxy;
  public static Parse(d: string): RedReportMarkSendResponseProxy {
    return RedReportMarkSendResponseProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): RedReportMarkSendResponseProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    d.RedReportMarkSendToCFDOResponse = RedReportMarkSendToCFDOResponseProxy.Create(d.RedReportMarkSendToCFDOResponse, field + ".RedReportMarkSendToCFDOResponse");
    return new RedReportMarkSendResponseProxy(d);
  }
  private constructor(d: any) {
    this.RedReportMarkSendToCFDOResponse = d.RedReportMarkSendToCFDOResponse;
  }
}

export class RedReportMarkSendToCFDOResponseProxy {
  public readonly SourceSystemID: string;
  public readonly SourceTransactionID: string;
  public readonly ServiceRequestTimestamp: string;
  public readonly ServiceResponseTimestamp: string;
  public readonly AuditCorrelationID: string;
  public readonly UpdateMessage: string;
  public static Parse(d: string): RedReportMarkSendToCFDOResponseProxy {
    return RedReportMarkSendToCFDOResponseProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): RedReportMarkSendToCFDOResponseProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    checkString(d.SourceSystemID, false, field + ".SourceSystemID");
    checkString(d.SourceTransactionID, false, field + ".SourceTransactionID");
    checkString(d.ServiceRequestTimestamp, false, field + ".ServiceRequestTimestamp");
    checkString(d.ServiceResponseTimestamp, false, field + ".ServiceResponseTimestamp");
    checkString(d.AuditCorrelationID, false, field + ".AuditCorrelationID");
    checkString(d.UpdateMessage, false, field + ".UpdateMessage");
    return new RedReportMarkSendToCFDOResponseProxy(d);
  }
  private constructor(d: any) {
    this.SourceSystemID = d.SourceSystemID;
    this.SourceTransactionID = d.SourceTransactionID;
    this.ServiceRequestTimestamp = d.ServiceRequestTimestamp;
    this.ServiceResponseTimestamp = d.ServiceResponseTimestamp;
    this.AuditCorrelationID = d.AuditCorrelationID;
    this.UpdateMessage = d.UpdateMessage;
  }
}
function throwNull2NonNull(field: string, d: any): never {
  return errorHelper(field, d, "non-nullable object", false);
}
function throwNotObject(field: string, d: any, nullable: boolean): never {
  return errorHelper(field, d, "object", nullable);
}
function throwIsArray(field: string, d: any, nullable: boolean): never {
  return errorHelper(field, d, "object", nullable);
}
function checkArray(d: any, field: string): void {
  if (!Array.isArray(d) && d !== null && d !== undefined) {
    errorHelper(field, d, "array", true);
  }
}
function checkNumber(d: any, nullable: boolean, field: string): void {
  if (typeof(d) !== 'number' && (!nullable || (nullable && d !== null && d !== undefined))) {
    errorHelper(field, d, "number", nullable);
  }
}
function checkBoolean(d: any, nullable: boolean, field: string): void {
  if (typeof(d) !== 'boolean' && (!nullable || (nullable && d !== null && d !== undefined))) {
    errorHelper(field, d, "boolean", nullable);
  }
}
function checkString(d: any, nullable: boolean, field: string): void {
  if (typeof(d) !== 'string' && (!nullable || (nullable && d !== null && d !== undefined))) {
    errorHelper(field, d, "string", nullable);
  }
}
function checkNull(d: any, field: string): void {
  if (d !== null && d !== undefined) {
    errorHelper(field, d, "null or undefined", false);
  }
}
function errorHelper(field: string, d: any, type: string, nullable: boolean): never {
  if (nullable) {
    type += ", null, or undefined";
  }
  throw new TypeError('Expected ' + type + " at " + field + " but found:\n" + JSON.stringify(d) + "\n\nFull object:\n" + JSON.stringify(obj));
}
