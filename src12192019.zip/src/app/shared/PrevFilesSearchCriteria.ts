export class PrevFilesSearchCriteria {
  sortColumn: string;
  sortDirection: string;
}
