import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/toPromise';
import { Vsr } from '../vsr';
import { VSRResubmitRequest, VsrResubmitResponse, VsrResubmit } from '../vsr-resubmit';
import { HttpClient } from '@angular/common/http';
import { AppSettings } from '../app-settings';
import { tap } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})

export class DolManualSearchService {

  url = AppSettings.VSR_DOL_MANUAL_URL;
  vsr: Vsr;
  constructor(private http: Http, private httpc: HttpClient) { }

  dolManualRequestInJson(address: VSRResubmitRequest): Observable<VsrResubmit> {
    console.log("the request is: " + JSON.stringify(address));
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers });
    return this.http.post(this.url, address, options)
      .map(this.extractData)
      .catch(this.handleErrorObservable);
  }

  dolManualRequest(resubmitRequest: VSRResubmitRequest): Observable<Vsr> {
    let headers = new Headers({ 'Content-Type': 'application/x-www-form-urlencoded' });
    let options = new RequestOptions({ headers: headers });
    return this.http.post(this.url, resubmitRequest, options)
      .map(this.extractData)
      .catch(this.handleErrorObservable);
  }

  dolManualRequestPromise(resubmitRequest: VSRResubmitRequest): Promise<VsrResubmitResponse> {
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers });
    return this.http.post(this.url, resubmitRequest, options).toPromise()
      .then(this.extractData)
      .catch(this.handleErrorPromise);
  }

  private extractData2(res: Response) {
    let body = JSON.parse(res.toString());
    return body || {};

  }


  getResubmitFromFile(url): Observable<VsrResubmit> {
    return this.httpc.get<VsrResubmit>(url).pipe(
      tap(data =>
        this.log("The fetched VsrResubmitResponse SourceTransactionID is: " + data.VsrResubmitResponse.SourceTransactionID)
      ));
  }

  private log(message: string) {
    console.log(message)
  }
  private extractData(res: Response) {
    //console.log("the data is: " + JSON.stringify(res.json()));       
    let body = res.json();
    return body || {};
  }
  private handleErrorObservable(error: Response | any) {
    console.error(error.message || error);
    return Observable.throw(error.message || error);
  }

  private handleErrorPromise(error: Response | any) {
    console.error(error.message || error);
    return Promise.reject(error.message || error);
  }

}
