import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { ComponentStatus } from './component-status';

@Injectable({
  providedIn: 'root'
})
export class ComponentStatusService {

  private messageSource = new BehaviorSubject<ComponentStatus>(new ComponentStatus());
  public currentMessage = this.messageSource.asObservable(); 

  constructor() { }

  changeMessage(message: ComponentStatus){
    // console.log(" ComponentStatus >>" + JSON.stringify(message));
    this.messageSource.next(message);
  }
  
}
