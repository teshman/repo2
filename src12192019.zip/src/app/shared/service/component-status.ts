export class ComponentStatus {
    private _srcComponentName: string;
    private _destComponentName: string;
    private _error: string;
    private _status: string;
    private _data: any;
    private _clear: boolean;


	constructor() {
	}

    /**
     * Getter srcComponentName
     * @return {string}
     */
	public get srcComponentName(): string {
		return this._srcComponentName;
	}

    /**
     * Getter destComponentName
     * @return {string}
     */
	public get destComponentName(): string {
		return this._destComponentName;
	}

    /**
     * Getter error
     * @return {string}
     */
	public get error(): string {
		return this._error;
	}

    /**
     * Getter status
     * @return {string}
     */
	public get status(): string {
		return this._status;
	}

    /**
     * Getter data
     * @return {any}
     */
	public get data(): any {
		return this._data;
	}

    /**
     * Getter clear
     * @return {boolean}
     */
	public get clear(): boolean {
		return this._clear;
	}

    /**
     * Setter srcComponentName
     * @param {string} value
     */
	public set srcComponentName(value: string) {
		this._srcComponentName = value;
	}

    /**
     * Setter destComponentName
     * @param {string} value
     */
	public set destComponentName(value: string) {
		this._destComponentName = value;
	}

    /**
     * Setter error
     * @param {string} value
     */
	public set error(value: string) {
		this._error = value;
	}

    /**
     * Setter status
     * @param {string} value
     */
	public set status(value: string) {
		this._status = value;
	}

    /**
     * Setter data
     * @param {any} value
     */
	public set data(value: any) {
		this._data = value;
	}

    /**
     * Setter clear
     * @param {boolean} value
     */
	public set clear(value: boolean) {
		this._clear = value;
	}
}
