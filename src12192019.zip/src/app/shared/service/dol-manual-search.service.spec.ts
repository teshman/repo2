import { TestBed } from '@angular/core/testing';

import { DolManualSearchService } from './dol-manual-search.service';

describe('DolManualSearchService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: DolManualSearchService = TestBed.get(DolManualSearchService);
    expect(service).toBeTruthy();
  });
});
