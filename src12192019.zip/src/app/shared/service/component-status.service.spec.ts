import { TestBed } from '@angular/core/testing';

import { ComponentStatusService } from './component-status.service';

describe('ComponentStatusService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ComponentStatusService = TestBed.get(ComponentStatusService);
    expect(service).toBeTruthy();
  });
});
