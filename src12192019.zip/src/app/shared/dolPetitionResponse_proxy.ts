// Stores the currently-being-typechecked object for error messages.
let obj: any = null;
export class GetDolDetailByPetitionIDResponseProxy {
  public readonly GetDolDetailByPetitionIDResponse: GetDolDetailByPetitionIDResponse1Proxy;
  public static Parse(d: string): GetDolDetailByPetitionIDResponseProxy {
    return GetDolDetailByPetitionIDResponseProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): GetDolDetailByPetitionIDResponseProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    d.GetDolDetailByPetitionIDResponse = GetDolDetailByPetitionIDResponse1Proxy.Create(d.GetDolDetailByPetitionIDResponse, field + ".GetDolDetailByPetitionIDResponse");
    return new GetDolDetailByPetitionIDResponseProxy(d);
  }
  private constructor(d: any) {
    this.GetDolDetailByPetitionIDResponse = d.GetDolDetailByPetitionIDResponse;
  }
}

export class GetDolDetailByPetitionIDResponse1Proxy {
  public readonly SourceSystemID: string;
  public readonly SourceTransactionID: string;
  public readonly ServiceRequestTimestamp: string;
  public readonly ServiceResponseTimestamp: string;
  public readonly AuditCorrelationID: string;
  public readonly DolEtaFormType: string;
  public readonly DolEtaFormVersion: string;
  public readonly DolJsonData: DolJsonDataProxy;
  public static Parse(d: string): GetDolDetailByPetitionIDResponse1Proxy {
    return GetDolDetailByPetitionIDResponse1Proxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): GetDolDetailByPetitionIDResponse1Proxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    checkString(d.SourceSystemID, false, field + ".SourceSystemID");
    checkString(d.SourceTransactionID, false, field + ".SourceTransactionID");
    checkString(d.ServiceRequestTimestamp, false, field + ".ServiceRequestTimestamp");
    checkString(d.ServiceResponseTimestamp, false, field + ".ServiceResponseTimestamp");
    checkString(d.AuditCorrelationID, false, field + ".AuditCorrelationID");
    checkString(d.DolEtaFormType, false, field + ".DolEtaFormType");
    checkString(d.DolEtaFormVersion, false, field + ".DolEtaFormVersion");
    d.DolJsonData = DolJsonDataProxy.Create(d.DolJsonData, field + ".DolJsonData");
    return new GetDolDetailByPetitionIDResponse1Proxy(d);
  }
  private constructor(d: any) {
    this.SourceSystemID = d.SourceSystemID;
    this.SourceTransactionID = d.SourceTransactionID;
    this.ServiceRequestTimestamp = d.ServiceRequestTimestamp;
    this.ServiceResponseTimestamp = d.ServiceResponseTimestamp;
    this.AuditCorrelationID = d.AuditCorrelationID;
    this.DolJsonData = d.DolJsonData;
  }
}

export class DolJsonDataProxy {
  public readonly DOL_DATA: DOLDATAProxy;
  public static Parse(d: string): DolJsonDataProxy {
    return DolJsonDataProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): DolJsonDataProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    d.DOL_DATA = DOLDATAProxy.Create(d.DOL_DATA, field + ".DOL_DATA");
    return new DolJsonDataProxy(d);
  }
  private constructor(d: any) {
    this.DOL_DATA = d.DOL_DATA;
  }
}

export class DOLDATAProxy {
  public readonly DOL_ETA_CLOB: DOLETACLOBProxy;
  public readonly DOL_ETA_WORKSITES: DOLETAWORKSITESOrDOLETAEMPLOYERSProxy;
  public readonly DOL_ETA_EMPLOYERS: DOLETAWORKSITESOrDOLETAEMPLOYERSProxy;
  public static Parse(d: string): DOLDATAProxy {
    return DOLDATAProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): DOLDATAProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    d.DOL_ETA_CLOB = DOLETACLOBProxy.Create(d.DOL_ETA_CLOB, field + ".DOL_ETA_CLOB");
    d.DOL_ETA_WORKSITES = DOLETAWORKSITESOrDOLETAEMPLOYERSProxy.Create(d.DOL_ETA_WORKSITES, field + ".DOL_ETA_WORKSITES");
    d.DOL_ETA_EMPLOYERS = DOLETAWORKSITESOrDOLETAEMPLOYERSProxy.Create(d.DOL_ETA_EMPLOYERS, field + ".DOL_ETA_EMPLOYERS");
    return new DOLDATAProxy(d);
  }
  private constructor(d: any) {
    this.DOL_ETA_CLOB = d.DOL_ETA_CLOB;
    this.DOL_ETA_WORKSITES = d.DOL_ETA_WORKSITES;
    this.DOL_ETA_EMPLOYERS = d.DOL_ETA_EMPLOYERS;
  }
}

export class DOLETACLOBProxy {
  public readonly VISA_CLASS: string;
  public readonly TEMPNEED_JOBTITLE: string;
  public readonly TEMPNEED_SOC: string;
  public readonly TEMPNEED_SOC_TITLE: string;
  public readonly TEMPNEED_FULLTIME: string;
  public readonly TEMPNEED_START: string;
  public readonly TEMPNEED_END: string;
  public readonly TEMPNEED_WKR_POS: string;
  public readonly TEMPNEED_NATURE: string;
  public readonly TEMPNEED_DESCRIPTION: string;
  public readonly CASE_NUMBER: string;
  public readonly CASE_STATUS: string;
  public readonly CASE_VALID_FROM: string;
  public readonly CASE_VALID_TO: string;
  public readonly EMP_BUSINESS_NAME: string;
  public readonly EMP_ADDR1: string;
  public readonly EMP_CITY: string;
  public readonly EMP_STATE: string;
  public readonly EMP_POSTCODE: string;
  public readonly EMP_COUNTRY: string;
  public readonly EMP_PHONE: string;
  public readonly EMP_FEIN: string;
  public readonly EMP_NAICS: string;
  public readonly EMP_YEAREST: string;
  public readonly EMP_TYPE: string;
  public readonly EMPPOC_LASTNAME: string;
  public readonly EMPPOC_FIRSTNAME: string;
  public readonly EMPPOC_JOBTITLE: string;
  public readonly EMPPOC_ADDR1: string;
  public readonly EMPPOC_CITY: string;
  public readonly EMPPOC_STATE: string;
  public readonly EMPPOC_POSTCODE: string;
  public readonly EMPPOC_COUNTRY: string;
  public readonly EMPPOC_PHONE: string;
  public readonly EMPPOC_EMAIL: string;
  public readonly ATTY_REPRESENT: string;
  public readonly ATTY_LASTNAME: string;
  public readonly ATTY_FIRSTNAME: string;
  public readonly ATTY_MIDDLENAME: string;
  public readonly ATTY_ADDR1: string;
  public readonly ATTY_CITY: string;
  public readonly ATTY_STATE: string;
  public readonly ATTY_POSTCODE: string;
  public readonly ATTY_COUNTRY: string;
  public readonly ATTY_PHONE: string;
  public readonly ATTY_EMAIL: string;
  public readonly ATTY_BIZNAME: string;
  public readonly ATTY_FEIN: string;
  public readonly ATTY_NAMEHIGHCT: string;
  public readonly JOB_TITLE: string;
  public readonly JOB_HOURSPERWK: string;
  public readonly JOB_HOURSTART: string;
  public readonly JOB_HOUREND: string;
  public readonly JOB_SUPERVISOR: string;
  public readonly JOB_DUTIES: string;
  public readonly JOB_MINEDU: string;
  public readonly JOB_MINSECDEGREE: string;
  public readonly JOB_MINTRAINING: string;
  public readonly JOB_MINEXP: string;
  public readonly JOB_MINEXPMONTHS: string;
  public readonly JOB_MINEXPOCCU: string;
  public readonly JOB_MINSPECIALREQ: string;
  public readonly JOB_ADDR1: string;
  public readonly JOB_CITY: string;
  public readonly JOB_COUNTY: string;
  public readonly JOB_STATE: string;
  public readonly JOB_POSTCODE: string;
  public readonly JOB_MULITPLESITES: string;
  public readonly WAGE_FROM: string;
  public readonly WAGE_PER: string;
  public readonly WAGE_ADDITIONAL: string;
  public readonly REC_SWANAME: string;
  public readonly REC_JOBORDER: string;
  public readonly REC_JOBORDSTART: string;
  public readonly REC_JOBORDEND: string;
  public readonly REC_SUNDAYPAPER: string;
  public readonly REC_PAPERNAMES: string;
  public readonly REC_ADDITIONAL: string;
  public readonly DECLARE_AGREE_H2A: string;
  public readonly CASE_DETERM: string;
  public readonly CASE_SUBMIT: string;
  public readonly CHANGED_DATE: string;
  public readonly LASTMOD_DATE: string;
  public readonly SUBMIT_IPADDRESS: string;
  public readonly RNUM: string;
  public readonly RECEIPT_NUMBER: string;
  public readonly SCORE_RUN_DATE: string;
  public static Parse(d: string): DOLETACLOBProxy {
    return DOLETACLOBProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): DOLETACLOBProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    checkString(d.VISA_CLASS, false, field + ".VISA_CLASS");
    checkString(d.TEMPNEED_JOBTITLE, false, field + ".TEMPNEED_JOBTITLE");
    checkString(d.TEMPNEED_SOC, false, field + ".TEMPNEED_SOC");
    checkString(d.TEMPNEED_SOC_TITLE, false, field + ".TEMPNEED_SOC_TITLE");
    checkString(d.TEMPNEED_FULLTIME, false, field + ".TEMPNEED_FULLTIME");
    checkString(d.TEMPNEED_START, false, field + ".TEMPNEED_START");
    checkString(d.TEMPNEED_END, false, field + ".TEMPNEED_END");
    checkString(d.TEMPNEED_WKR_POS, false, field + ".TEMPNEED_WKR_POS");
    checkString(d.TEMPNEED_NATURE, false, field + ".TEMPNEED_NATURE");
    checkString(d.TEMPNEED_DESCRIPTION, false, field + ".TEMPNEED_DESCRIPTION");
    checkString(d.CASE_NUMBER, false, field + ".CASE_NUMBER");
    checkString(d.CASE_STATUS, false, field + ".CASE_STATUS");
    checkString(d.CASE_VALID_FROM, false, field + ".CASE_VALID_FROM");
    checkString(d.CASE_VALID_TO, false, field + ".CASE_VALID_TO");
    checkString(d.EMP_BUSINESS_NAME, false, field + ".EMP_BUSINESS_NAME");
    checkString(d.EMP_ADDR1, false, field + ".EMP_ADDR1");
    checkString(d.EMP_CITY, false, field + ".EMP_CITY");
    checkString(d.EMP_STATE, false, field + ".EMP_STATE");
    checkString(d.EMP_POSTCODE, false, field + ".EMP_POSTCODE");
    checkString(d.EMP_COUNTRY, false, field + ".EMP_COUNTRY");
    checkString(d.EMP_PHONE, false, field + ".EMP_PHONE");
    checkString(d.EMP_FEIN, false, field + ".EMP_FEIN");
    checkString(d.EMP_NAICS, false, field + ".EMP_NAICS");
    checkString(d.EMP_YEAREST, false, field + ".EMP_YEAREST");
    checkString(d.EMP_TYPE, false, field + ".EMP_TYPE");
    checkString(d.EMPPOC_LASTNAME, false, field + ".EMPPOC_LASTNAME");
    checkString(d.EMPPOC_FIRSTNAME, false, field + ".EMPPOC_FIRSTNAME");
    checkString(d.EMPPOC_JOBTITLE, false, field + ".EMPPOC_JOBTITLE");
    checkString(d.EMPPOC_ADDR1, false, field + ".EMPPOC_ADDR1");
    checkString(d.EMPPOC_CITY, false, field + ".EMPPOC_CITY");
    checkString(d.EMPPOC_STATE, false, field + ".EMPPOC_STATE");
    checkString(d.EMPPOC_POSTCODE, false, field + ".EMPPOC_POSTCODE");
    checkString(d.EMPPOC_COUNTRY, false, field + ".EMPPOC_COUNTRY");
    checkString(d.EMPPOC_PHONE, false, field + ".EMPPOC_PHONE");
    checkString(d.EMPPOC_EMAIL, false, field + ".EMPPOC_EMAIL");
    checkString(d.ATTY_REPRESENT, false, field + ".ATTY_REPRESENT");
    checkString(d.ATTY_LASTNAME, false, field + ".ATTY_LASTNAME");
    checkString(d.ATTY_FIRSTNAME, false, field + ".ATTY_FIRSTNAME");
    checkString(d.ATTY_MIDDLENAME, false, field + ".ATTY_MIDDLENAME");
    checkString(d.ATTY_ADDR1, false, field + ".ATTY_ADDR1");
    checkString(d.ATTY_CITY, false, field + ".ATTY_CITY");
    checkString(d.ATTY_STATE, false, field + ".ATTY_STATE");
    checkString(d.ATTY_POSTCODE, false, field + ".ATTY_POSTCODE");
    checkString(d.ATTY_COUNTRY, false, field + ".ATTY_COUNTRY");
    checkString(d.ATTY_PHONE, false, field + ".ATTY_PHONE");
    checkString(d.ATTY_EMAIL, false, field + ".ATTY_EMAIL");
    checkString(d.ATTY_BIZNAME, false, field + ".ATTY_BIZNAME");
    checkString(d.ATTY_FEIN, false, field + ".ATTY_FEIN");
    checkString(d.ATTY_NAMEHIGHCT, false, field + ".ATTY_NAMEHIGHCT");
    checkString(d.JOB_TITLE, false, field + ".JOB_TITLE");
    checkString(d.JOB_HOURSPERWK, false, field + ".JOB_HOURSPERWK");
    checkString(d.JOB_HOURSTART, false, field + ".JOB_HOURSTART");
    checkString(d.JOB_HOUREND, false, field + ".JOB_HOUREND");
    checkString(d.JOB_SUPERVISOR, false, field + ".JOB_SUPERVISOR");
    checkString(d.JOB_DUTIES, false, field + ".JOB_DUTIES");
    checkString(d.JOB_MINEDU, false, field + ".JOB_MINEDU");
    checkString(d.JOB_MINSECDEGREE, false, field + ".JOB_MINSECDEGREE");
    checkString(d.JOB_MINTRAINING, false, field + ".JOB_MINTRAINING");
    checkString(d.JOB_MINEXP, false, field + ".JOB_MINEXP");
    checkString(d.JOB_MINEXPMONTHS, false, field + ".JOB_MINEXPMONTHS");
    checkString(d.JOB_MINEXPOCCU, false, field + ".JOB_MINEXPOCCU");
    checkString(d.JOB_MINSPECIALREQ, false, field + ".JOB_MINSPECIALREQ");
    checkString(d.JOB_ADDR1, false, field + ".JOB_ADDR1");
    checkString(d.JOB_CITY, false, field + ".JOB_CITY");
    checkString(d.JOB_COUNTY, false, field + ".JOB_COUNTY");
    checkString(d.JOB_STATE, false, field + ".JOB_STATE");
    checkString(d.JOB_POSTCODE, false, field + ".JOB_POSTCODE");
    checkString(d.JOB_MULITPLESITES, false, field + ".JOB_MULITPLESITES");
    checkString(d.WAGE_FROM, false, field + ".WAGE_FROM");
    checkString(d.WAGE_PER, false, field + ".WAGE_PER");
    checkString(d.WAGE_ADDITIONAL, false, field + ".WAGE_ADDITIONAL");
    checkString(d.REC_SWANAME, false, field + ".REC_SWANAME");
    checkString(d.REC_JOBORDER, false, field + ".REC_JOBORDER");
    checkString(d.REC_JOBORDSTART, false, field + ".REC_JOBORDSTART");
    checkString(d.REC_JOBORDEND, false, field + ".REC_JOBORDEND");
    checkString(d.REC_SUNDAYPAPER, false, field + ".REC_SUNDAYPAPER");
    checkString(d.REC_PAPERNAMES, false, field + ".REC_PAPERNAMES");
    checkString(d.REC_ADDITIONAL, false, field + ".REC_ADDITIONAL");
    checkString(d.DECLARE_AGREE_H2A, false, field + ".DECLARE_AGREE_H2A");
    checkString(d.CASE_DETERM, false, field + ".CASE_DETERM");
    checkString(d.CASE_SUBMIT, false, field + ".CASE_SUBMIT");
    checkString(d.CHANGED_DATE, false, field + ".CHANGED_DATE");
    checkString(d.LASTMOD_DATE, false, field + ".LASTMOD_DATE");
    checkString(d.SUBMIT_IPADDRESS, false, field + ".SUBMIT_IPADDRESS");
    checkString(d.RNUM, false, field + ".RNUM");
    checkString(d.RECEIPT_NUMBER, false, field + ".RECEIPT_NUMBER");
    checkString(d.SCORE_RUN_DATE, false, field + ".SCORE_RUN_DATE");
    return new DOLETACLOBProxy(d);
  }
  private constructor(d: any) {
    this.VISA_CLASS = d.VISA_CLASS;
    this.TEMPNEED_JOBTITLE = d.TEMPNEED_JOBTITLE;
    this.TEMPNEED_SOC = d.TEMPNEED_SOC;
    this.TEMPNEED_SOC_TITLE = d.TEMPNEED_SOC_TITLE;
    this.TEMPNEED_FULLTIME = d.TEMPNEED_FULLTIME;
    this.TEMPNEED_START = d.TEMPNEED_START;
    this.TEMPNEED_END = d.TEMPNEED_END;
    this.TEMPNEED_WKR_POS = d.TEMPNEED_WKR_POS;
    this.TEMPNEED_NATURE = d.TEMPNEED_NATURE;
    this.TEMPNEED_DESCRIPTION = d.TEMPNEED_DESCRIPTION;
    this.CASE_NUMBER = d.CASE_NUMBER;
    this.CASE_STATUS = d.CASE_STATUS;
    this.CASE_VALID_FROM = d.CASE_VALID_FROM;
    this.CASE_VALID_TO = d.CASE_VALID_TO;
    this.EMP_BUSINESS_NAME = d.EMP_BUSINESS_NAME;
    this.EMP_ADDR1 = d.EMP_ADDR1;
    this.EMP_CITY = d.EMP_CITY;
    this.EMP_STATE = d.EMP_STATE;
    this.EMP_POSTCODE = d.EMP_POSTCODE;
    this.EMP_COUNTRY = d.EMP_COUNTRY;
    this.EMP_PHONE = d.EMP_PHONE;
    this.EMP_FEIN = d.EMP_FEIN;
    this.EMP_NAICS = d.EMP_NAICS;
    this.EMP_YEAREST = d.EMP_YEAREST;
    this.EMP_TYPE = d.EMP_TYPE;
    this.EMPPOC_LASTNAME = d.EMPPOC_LASTNAME;
    this.EMPPOC_FIRSTNAME = d.EMPPOC_FIRSTNAME;
    this.EMPPOC_JOBTITLE = d.EMPPOC_JOBTITLE;
    this.EMPPOC_ADDR1 = d.EMPPOC_ADDR1;
    this.EMPPOC_CITY = d.EMPPOC_CITY;
    this.EMPPOC_STATE = d.EMPPOC_STATE;
    this.EMPPOC_POSTCODE = d.EMPPOC_POSTCODE;
    this.EMPPOC_COUNTRY = d.EMPPOC_COUNTRY;
    this.EMPPOC_PHONE = d.EMPPOC_PHONE;
    this.EMPPOC_EMAIL = d.EMPPOC_EMAIL;
    this.ATTY_REPRESENT = d.ATTY_REPRESENT;
    this.ATTY_LASTNAME = d.ATTY_LASTNAME;
    this.ATTY_FIRSTNAME = d.ATTY_FIRSTNAME;
    this.ATTY_MIDDLENAME = d.ATTY_MIDDLENAME;
    this.ATTY_ADDR1 = d.ATTY_ADDR1;
    this.ATTY_CITY = d.ATTY_CITY;
    this.ATTY_STATE = d.ATTY_STATE;
    this.ATTY_POSTCODE = d.ATTY_POSTCODE;
    this.ATTY_COUNTRY = d.ATTY_COUNTRY;
    this.ATTY_PHONE = d.ATTY_PHONE;
    this.ATTY_EMAIL = d.ATTY_EMAIL;
    this.ATTY_BIZNAME = d.ATTY_BIZNAME;
    this.ATTY_FEIN = d.ATTY_FEIN;
    this.ATTY_NAMEHIGHCT = d.ATTY_NAMEHIGHCT;
    this.JOB_TITLE = d.JOB_TITLE;
    this.JOB_HOURSPERWK = d.JOB_HOURSPERWK;
    this.JOB_HOURSTART = d.JOB_HOURSTART;
    this.JOB_HOUREND = d.JOB_HOUREND;
    this.JOB_SUPERVISOR = d.JOB_SUPERVISOR;
    this.JOB_DUTIES = d.JOB_DUTIES;
    this.JOB_MINEDU = d.JOB_MINEDU;
    this.JOB_MINSECDEGREE = d.JOB_MINSECDEGREE;
    this.JOB_MINTRAINING = d.JOB_MINTRAINING;
    this.JOB_MINEXP = d.JOB_MINEXP;
    this.JOB_MINEXPMONTHS = d.JOB_MINEXPMONTHS;
    this.JOB_MINEXPOCCU = d.JOB_MINEXPOCCU;
    this.JOB_MINSPECIALREQ = d.JOB_MINSPECIALREQ;
    this.JOB_ADDR1 = d.JOB_ADDR1;
    this.JOB_CITY = d.JOB_CITY;
    this.JOB_COUNTY = d.JOB_COUNTY;
    this.JOB_STATE = d.JOB_STATE;
    this.JOB_POSTCODE = d.JOB_POSTCODE;
    this.JOB_MULITPLESITES = d.JOB_MULITPLESITES;
    this.WAGE_FROM = d.WAGE_FROM;
    this.WAGE_PER = d.WAGE_PER;
    this.WAGE_ADDITIONAL = d.WAGE_ADDITIONAL;
    this.REC_SWANAME = d.REC_SWANAME;
    this.REC_JOBORDER = d.REC_JOBORDER;
    this.REC_JOBORDSTART = d.REC_JOBORDSTART;
    this.REC_JOBORDEND = d.REC_JOBORDEND;
    this.REC_SUNDAYPAPER = d.REC_SUNDAYPAPER;
    this.REC_PAPERNAMES = d.REC_PAPERNAMES;
    this.REC_ADDITIONAL = d.REC_ADDITIONAL;
    this.DECLARE_AGREE_H2A = d.DECLARE_AGREE_H2A;
    this.CASE_DETERM = d.CASE_DETERM;
    this.CASE_SUBMIT = d.CASE_SUBMIT;
    this.CHANGED_DATE = d.CHANGED_DATE;
    this.LASTMOD_DATE = d.LASTMOD_DATE;
    this.SUBMIT_IPADDRESS = d.SUBMIT_IPADDRESS;
    this.RNUM = d.RNUM;
    this.RECEIPT_NUMBER = d.RECEIPT_NUMBER;
    this.SCORE_RUN_DATE = d.SCORE_RUN_DATE;
  }
}

export class DOLETAWORKSITESOrDOLETAEMPLOYERSProxy {
  public readonly RESPONSECODE: string;
  public readonly RESPONSEMESSAGE: string;
  public readonly DOLCASENUMBER: string;
  public readonly PETITIONID: string;
  public static Parse(d: string): DOLETAWORKSITESOrDOLETAEMPLOYERSProxy {
    return DOLETAWORKSITESOrDOLETAEMPLOYERSProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): DOLETAWORKSITESOrDOLETAEMPLOYERSProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    checkString(d.RESPONSECODE, false, field + ".RESPONSECODE");
    checkString(d.RESPONSEMESSAGE, false, field + ".RESPONSEMESSAGE");
    checkString(d.DOLCASENUMBER, false, field + ".DOLCASENUMBER");
    checkString(d.PETITIONID, false, field + ".PETITIONID");
    return new DOLETAWORKSITESOrDOLETAEMPLOYERSProxy(d);
  }
  private constructor(d: any) {
    this.RESPONSECODE = d.RESPONSECODE;
    this.RESPONSEMESSAGE = d.RESPONSEMESSAGE;
    this.DOLCASENUMBER = d.DOLCASENUMBER;
    this.PETITIONID = d.PETITIONID;
  }
}

function throwNull2NonNull(field: string, d: any): never {
  return errorHelper(field, d, "non-nullable object", false);
}
function throwNotObject(field: string, d: any, nullable: boolean): never {
  return errorHelper(field, d, "object", nullable);
}
function throwIsArray(field: string, d: any, nullable: boolean): never {
  return errorHelper(field, d, "object", nullable);
}
function checkString(d: any, nullable: boolean, field: string): void {
  if (typeof(d) !== 'string' && (!nullable || (nullable && d !== null && d !== undefined))) {
    errorHelper(field, d, "string", nullable);
  }
}
function errorHelper(field: string, d: any, type: string, nullable: boolean): never {
  if (nullable) {
    type += ", null, or undefined";
  }
  throw new TypeError('Expected ' + type + " at " + field + " but found:\n" + JSON.stringify(d) + "\n\nFull object:\n" + JSON.stringify(obj));
}
