import { Pipe, PipeTransform } from '@angular/core';
import { PreviousFilingRecordEntity } from '../../shared/dunsResponse_interfaces'; 

@Pipe({ name: 'searchByPrevFilesColumnName' })
export class PrevFillingsColumnPipe implements PipeTransform {

  transform(resultset:  PreviousFilingRecordEntity[], searchText: string) {

    let multipleFilters: string[] = [];
    if (searchText) {      
      console.log("THE SEARCH TEXT IS: " + searchText.toUpperCase());
      multipleFilters = searchText.split(',');
      if (multipleFilters[0] !== undefined && multipleFilters[0].trim() !== 'undefined' && multipleFilters[0].trim() !== '') {
        console.log("THE multipleFilters0 TEXT IS: " + multipleFilters[0]);
        resultset = resultset.filter(pf => pf.ReceiptNumber.indexOf(multipleFilters[0].trim()) !== -1);
      }
      if (multipleFilters[1] !== undefined && multipleFilters[1].trim() !== 'undefined'  && multipleFilters[1].trim() !== '') {
        console.log("THE multipleFilters1 TEXT IS: " + multipleFilters[1]);
        resultset = resultset.filter(pf => pf.OrganizationName.indexOf(multipleFilters[1].trim().toUpperCase()) !== -1);
      }

      if (multipleFilters[2] !== undefined && multipleFilters[2].trim() !== 'undefined' && multipleFilters[2].trim() !== '') {
        console.log("THE multipleFilters0 TEXT IS: " + multipleFilters[2]);
        resultset = resultset.filter(pf => pf.VisaType.indexOf(multipleFilters[2].trim()) !== -1);
      }
      if (multipleFilters[3] !== undefined && multipleFilters[3].trim() !== 'undefined'  && multipleFilters[3].trim() !== '') {
        console.log("THE multipleFilters1 TEXT IS: " + multipleFilters[3]);
        resultset = resultset.filter(pf => pf.AdjudicativeStatus.indexOf(multipleFilters[3].trim().toUpperCase()) !== -1);
      }

      
      if (multipleFilters[4] !== undefined && multipleFilters[4].trim() !== 'undefined' && multipleFilters[4].trim() !== '') {
        console.log("THE multipleFilters0 TEXT IS: " + multipleFilters[4]);
        resultset = resultset.filter(pf => pf.ConfidenceFactor.indexOf(multipleFilters[4].trim()) !== -1);
      }
      if (multipleFilters[5] !== undefined && multipleFilters[5].trim() !== 'undefined'  && multipleFilters[5].trim() !== '') {
        console.log("THE multipleFilters1 TEXT IS: " + multipleFilters[5]);
        resultset = resultset.filter(pf => pf.DateAdded.indexOf(multipleFilters[5].trim().toUpperCase()) !== -1);
      }
    }
    
    return resultset;
  }
}
