import { SpecialCharactersPipe } from './special-characters.pipe';

describe('SpecialCharactersPipe', () => {
  it('create an instance', () => {
    const pipe = new SpecialCharactersPipe();
    expect(pipe).toBeTruthy();
  });
});
