export interface pfFeinResponse {
  PreviousFilingsGetByFeinNumberResponse: PreviousFilingsGetByFeinNumberResponseType;
}
export interface PreviousFilingsGetByFeinNumberResponseType {
  SourceSystemID: string;
  SourceTransactionID: string;
  ServiceRequestTimestamp: string;
  ServiceResponseTimestamp: string;
  AuditCorrelationID: string;
  PreviousFilingsResultSet: PreviousFilingsResultSet;
}
export interface PreviousFilingsResultSet {
  totalRecordCount: number;
  lastRecordIndex: number;
  recordCountInThisResultSet: number;
  PreviousFilingRecord?: (PreviousFilingRecordEntity)[] | null;
}
export interface PreviousFilingRecordEntity {
  PetitionID: number;
  ReceiptNumber: string;
  AdjudicativeStatus: string;
  DateAdded: string;
  ReceiptDate: string;
  VisaType: string;
  PetitionType: string;
  ConfidenceFactor: string;
  OrganizationName: string;
}
