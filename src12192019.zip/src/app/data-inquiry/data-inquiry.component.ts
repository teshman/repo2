import { Component, OnInit, ViewChild } from '@angular/core';
import { DataInquiryRequest, DateRange } from './data-inquiry';
import { UserInRoleService } from '../user-profile/user-in-role.service';
import { DataInquiryListService } from '../data-inquiry-list.service';
import { MatInput } from '@angular/material';
import { DataInquiryList, DataInquiryListRecord } from './data-inquiry-list';
import { CISUserService } from '../predefined-info/cis-user.service';
import { FrequentUser, FrequentUserRecordEntity } from '../shared/frequent-user';
import { AppSettings } from '../shared/app-settings';
import { ClrDatagridPagination } from '@clr/angular';
import { ExcelService } from '../excel.service';
import { formatDate } from '@angular/common';
import { DateFormatPipe } from '../shared/dateFormat-pipe';

@Component({
  selector: 'app-data-inquiry',
  templateUrl: './data-inquiry.component.html',
  styleUrls: ['./data-inquiry.component.css']
})
export class DataInquiryComponent implements OnInit {

  loading: boolean = false;
  appsAlert: string = "";
  diRequest: DataInquiryRequest;
  diMaxRowsReturned: number = AppSettings.DATA_INQUIRY_MAX_ROWS;
  diLastRecordNumber: number = 0;
  dataInquiryListRecord: DataInquiryListRecord[] = [];
  receiptNumber: string = "";
  validReceiptNumber:boolean = true;
  dataInquiryList: DataInquiryList;
  frequentUser: FrequentUser;
  frequentUserRecord: FrequentUserRecordEntity[] = [];
  filteredFrequentUsers: FrequentUserRecordEntity[] = [];
  totalNumberOfRecords: number = 0;
  exportOptions: string = "";
  isDunsValid:boolean = true;
  showRequestedDateAlert: boolean = false;
  requestedateAlertMessage: string = "";
  showSubmittedDateAlert: boolean = false;
  submittedateAlertMessage: string = "";
  showCompletedDateAlert: boolean = false;
  CompletedateAlertMessage: string = "";
  fillOutBothDatesMessage: string = "Please fill out both dates.";
  

  dateRangeAlertMessage: string = "";
  filloutBothRequestedDatesFlag: boolean = false;
  filloutBothCompletedDatesFlag: boolean = false;
  filloutBothSubmittedDatesFlag: boolean = false;
  filloutBothDatesFlag: boolean = false;


  p: number = 1;
  recordsPerPage: number = 10;
  PAGINATION_COUNT: number = 10;
  constructor(
    private excelService: ExcelService,
    private userInRoleService: UserInRoleService, private diRequestService: DataInquiryListService,  public datepipe: DateFormatPipe,
    private cisUserSearchService: CISUserService) {
    this.diRequest = new DataInquiryRequest();
    this.diRequest.requestedDateRange = new DateRange();
    this.diRequest.completedDateRange = new DateRange();
    this.diRequest.submittedDateRange = new DateRange();
    this.refresh();
  }


  @ViewChild('requestedFromDateInput', {
    read: MatInput,
    static: false
  }) requestedFromDateInput: MatInput;

  @ViewChild('requestedToDateInput', {
    read: MatInput,
    static: false
  }) requestedToDateInput: MatInput;

  @ViewChild('submittedFromDateInput', {
    read: MatInput,
    static: false
  }) submittedFromDateInput

  @ViewChild('submittedToDateInput', {
    read: MatInput,
    static: false
  }) submittedToDateInput

  @ViewChild('completedFromDateInput', {
    read: MatInput,
    static: false
  }) completedFromDateInput: MatInput;

  @ViewChild('completedToDateInput', {
    read: MatInput,
    static: false
  }) completedToDateInput: MatInput;

  @ViewChild("pagination", {
    static: true
  }) pagination: ClrDatagridPagination;

  _addedBy: string = "All";
  public get addedBy(): string {
    return this._addedBy;
  }
  public set addedBy(value: string) {
    this._addedBy = value;
  }

  ngOnInit() {
    // this.getDataInquiryList();
    if (this.userInRoleService.userInRole !== undefined) {
      this.diRequest = new DataInquiryRequest();
      this.diRequest.endUserID = this.userInRoleService.userInRole.httpUsername;
    }

    this.exportOptions = "EXCEL";
  }
  _requestedFromDate: string = "";
  // requestedFromDate: any = "";
  public get requestedFromDate(): string {
    // return this._requestedFromDate;
    return "";
  }
  public set requestedFromDate(value: string) {
    this._requestedFromDate = value;
    // this.getfilteredPredefInfoListRecords();
  }


  _requestedToDate: string = "";
  public get requestedToDate(): string {
    return "";
  }
  public set requestedToDate(value: string) {
    this._requestedToDate = value;
  }





  _submittedFromDate: string = "";
  // rsubmittedFromDate: any = "";
  public get submittedFromDate(): string {
    // return this._rsubmittedFromDate;
    return "";
  }
  public set submittedFromDate(value: string) {
    this._submittedFromDate = value;
    // this.getfilteredPredefInfoListRecords();
  }


  _submittedToDate: string = "";
  public get submittedToDate(): string {
    return "";
  }
  public set submittedToDate(value: string) {
    this._submittedToDate = value;
  }






  _completedFromDate: string = "";
  // rcompletedFromDate: any = "";
  public get completedFromDate(): string {
    // return this._rcompletedFromDate;
    return "";
  }
  public set completedFromDate(value: string) {
    this._completedFromDate = value;
    // this.getfilteredPredefInfoListRecords();
  }


  _completedToDate: string = "";
  public get completedToDate(): string {
    return "";
  }
  public set completedToDate(value: string) {
    this._completedToDate = value;
  }

  checkValidDate(dateString) {

    switch (dateString) {
      case "requestedFromDate":      
      case "requestedToDate":
        this.showRequestedDateAlert = !this.validateRequestedDate();
        this.filloutBothRequestedDatesFlag = this.filloutBothDatesFlag;
        break;
      case "submittedFromDate":      
      case "submittedToDate":
        this.showSubmittedDateAlert = !this.validateSubmittedDate();
        this.filloutBothSubmittedDatesFlag = this.filloutBothDatesFlag;
        break;
      case "completedFromDate":
      case "completedToDate":
        this.showCompletedDateAlert = !this.validateCompletedDate();
        this.filloutBothCompletedDatesFlag = this.filloutBothDatesFlag;
        break;
      default:
        break;
    }
    // console.log(" this.showRequestedDateAlert: " + this.showRequestedDateAlert);
    // console.log(" this.showSubmittedDateAlert: " + this.showSubmittedDateAlert);
    // console.log(" this.showCompletedDateAlert: " + this.showCompletedDateAlert);
    // console.log(" this.filloutBothDatesFlag: " + this.filloutBothDatesFlag);
  }

  private validateRequestedDate(): boolean {

    this.showRequestedDateAlert = false;
    let isDateValid: boolean = false;
    this.requestedateAlertMessage = "";
    isDateValid = this.validateDateRange(this._requestedFromDate, this._requestedToDate);
    this.requestedateAlertMessage = this.dateRangeAlertMessage;
    console.log("this.requestedateAlertMessage = " + this.requestedateAlertMessage);
    return isDateValid;
  }


  private validateSubmittedDate(): boolean {

    this.showSubmittedDateAlert = false;
    let isDateValid: boolean = false;
    this.submittedateAlertMessage = "";
    isDateValid = this.validateDateRange(this._submittedFromDate, this._submittedToDate);
    this.submittedateAlertMessage = this.dateRangeAlertMessage;
    console.log("this.SubmittedateAlertMessage = " + this.submittedateAlertMessage);
    return isDateValid;
  }



  private validateCompletedDate(): boolean {

    this.showCompletedDateAlert = false;
    let isDateValid: boolean = false;
    this.CompletedateAlertMessage = "";
    isDateValid = this.validateDateRange(this._completedFromDate, this._completedToDate);
    this.CompletedateAlertMessage = this.dateRangeAlertMessage;
    console.log("this.CompletedateAlertMessage = " + this.CompletedateAlertMessage);
    return isDateValid;
  }

  validateDateRange(fromDate: string, toDate: string): boolean {
    this.dateRangeAlertMessage = "";
    this.filloutBothDatesFlag = false;
    let retVal: boolean = true;
    console.log("from date, and todates are: " + fromDate + ", " + toDate);
    if (toDate !== null && toDate !== undefined && toDate !== "") {
      console.log("toDate is not empty or not null");
      if (fromDate !== null && fromDate !== undefined && fromDate !== "") {
        console.log("fromDate is not empty or not null");
        let validEndDate = new Date(formatDate(toDate, 'MM/dd/yyyy', 'en-US'));
        if (fromDate !== "" && fromDate !== null) {
          let end = formatDate(toDate, 'MM/dd/yyyy', 'en-US');
          let start = formatDate(fromDate, 'MM/dd/yyyy', 'en-US');

          if (end.length >= 8 && start.length >= 8) {
            let validBeginDate = new Date(formatDate(fromDate, 'MM/dd/yyyy', 'en-US'));
            if (validEndDate.getTime() < validBeginDate.getTime()) {

              this.dateRangeAlertMessage = "Invalid Date Range.  End Date cannot be before Start Date";
              return false;
            }
            else {
              return true;
            }
          }
        }
      }
      else {
        // this.dateRangeAlertMessage = "Please fill out both dates.";
        this.filloutBothDatesFlag = true;
        console.log(" this.filloutBothDatesFlag =  " +  this.filloutBothDatesFlag );
      }

    }
    else {
      if (
        (((toDate == null || toDate == undefined || toDate == "")  && fromDate !== undefined && fromDate !== null && fromDate !== "")
          || (toDate !== undefined && toDate !== null && toDate !== "" && (fromDate == undefined || fromDate == null || fromDate == ""))
        )
      ) {
        this.filloutBothDatesFlag = true;
        console.log(" this.filloutBothDatesFlag =  " +  this.filloutBothDatesFlag );
        
      }


    }
    return retVal;
  }


  validateReceiptNumber (receipt):boolean{
    let receiptPattern = /^[A-Z]{3}\d{10}$/;
    // console.log("the RN is: " + receipt);
    if(receipt !== undefined && receipt !==null && receipt !== ""){
     this.validReceiptNumber = receiptPattern.test(receipt.toUpperCase()) ;
    //  console.log("validating RN, " + receipt + ", " + this.validReceiptNumber);
    } else{
     this.validReceiptNumber = true ;
 }
     return this.validReceiptNumber;
 }
 

  endDateBeforeStartDate(fromDate: string, toDate: string): boolean {
    let retVal: boolean = false;
    if (fromDate !== null && fromDate !== undefined && fromDate !== "") {
      var selectedDate = new Date(fromDate);
      var now = new Date();
      // selectedDate.setDate(selectedDate.getDate());
      now.setDate(now.getDate() - 1);

      // console.log("the selected date is in the past..." + selectedDate);
      // console.log("the selected date is in the past..." + selectedDate.getDate());
      if (selectedDate < now) {
        retVal = true;
      }
    }
    return retVal;
  }



  private bothDatesNotEmpty(fromDate: string, toDate: string) {
    let bothEmptyOrBothNotEmpty: boolean = false;
    if ((toDate !== null && toDate !== undefined && toDate !== "")
      && (fromDate !== null && fromDate !== undefined && fromDate !== "")) {
      bothEmptyOrBothNotEmpty = true;
      console.log("both valid until dates are not empty");
    }
    console.log("fromDate, todate: " + fromDate + ", " + toDate);
    return bothEmptyOrBothNotEmpty;
  }

  private bothDatesEmpty(fromDate: string, toDate: string) {
    let bothEmpty: boolean = false;
    if ((fromDate == null || fromDate == undefined || fromDate == "")
      && (toDate == null || toDate == undefined || toDate == "")) {
      bothEmpty = true;
      console.log("both valid until dates are empty");
    }
    return bothEmpty;
  }

  onPageChange(e) {
    if (e)
      this.p = e;
  }


  onKey(event) {
    if(event.target.value !== ""){
    let dunsPattern = /^\d{9}$/;
    if (event !== undefined && event !== null && (dunsPattern.test(event.target.value)==true)){
        this.isDunsValid = true;
    }
    else {
        this.isDunsValid = false;
    }
    
    console.log(dunsPattern.test(event.target.value));
  }
  else 
  this.isDunsValid = true;
    console.log("the event is: " + event.target.value);
}

onPaste(event: ClipboardEvent) {
    let dunsPattern = /^\d{9}$/;
    let clipboardData = event.clipboardData ;
    let pastedText = clipboardData.getData('text');
    if (pastedText !== undefined && pastedText !== null &&  (dunsPattern.test(pastedText)==true)) {
        this.isDunsValid = true;
    }
    else {
        this.isDunsValid = false;
    }
    console.log("clipboardData " + (dunsPattern.test(pastedText)==true));
  }

  searchDI() {
    if(this.filloutBothRequestedDatesFlag == true ||
      this.filloutBothCompletedDatesFlag  == true||
      this.filloutBothSubmittedDatesFlag == true)
      this.displayFilloutBothDatesAlert();
      else if(this.showRequestedDateAlert !== true && this.showCompletedDateAlert !== true 
        && this.showSubmittedDateAlert !== true && this.validReceiptNumber == true && this.isDunsValid == true)
     
    this.getDataInquiryList();
  }
  
  displayFilloutBothDatesAlert(){
    if(this.filloutBothRequestedDatesFlag == true ){
      this.showRequestedDateAlert = true;
      this.requestedateAlertMessage = this.fillOutBothDatesMessage;
    }
      if(this.filloutBothCompletedDatesFlag  == true){
        this.showCompletedDateAlert = true;
        this.CompletedateAlertMessage = this.fillOutBothDatesMessage;
      }
      if(this.filloutBothSubmittedDatesFlag == true){
        this.showSubmittedDateAlert = true;
        this.submittedateAlertMessage = this.fillOutBothDatesMessage;
      }
  }
  resetDI() {
    this.dataInquiryListRecord = [];
    this.requestedFromDateInput.value = "";
    this.requestedToDateInput.value = "";
    this.submittedFromDateInput.value = "";
    this.submittedToDateInput.value = "";
    this.completedFromDateInput.value = "";
    this.completedToDateInput.value = "";
    this._completedFromDate = "";
    this._completedToDate = "";
    this._requestedFromDate = "";
    this._requestedToDate = "";
    this._submittedFromDate = "";
    this._submittedToDate = "";
    this.filloutBothDatesFlag = false;
    this.filloutBothRequestedDatesFlag = false;
    this.filloutBothSubmittedDatesFlag = false;
    this.filloutBothCompletedDatesFlag = false;

    
  this.showRequestedDateAlert = false;
  this.requestedateAlertMessage = "";
  this.showSubmittedDateAlert = false;
  this.submittedateAlertMessage = "";
  this.showCompletedDateAlert = false;
  this.CompletedateAlertMessage = "";
  this.appsAlert = "";  
  this.validReceiptNumber = true;
  this.isDunsValid = true;

  this.diRequest = new DataInquiryRequest();
  this.diRequest.requestedDateRange = new DateRange();
  this.diRequest.completedDateRange = new DateRange();
  this.diRequest.submittedDateRange = new DateRange();
  }

  onEditDataInquiryList(diRecord: DataInquiryListRecord) {

  }

  refresh(): void {
    this.loading = true;
    this.cisUserSearchService.getDataInquiryUser().subscribe(
      data => {
        this.loading = false;
        if (data && !JSON.stringify(data).includes("Error") && !JSON.stringify(data).includes("ESB2Exception")) {
          // console.log("The di user list is: " + JSON.stringify(data));
          this.frequentUser = data;
          this.frequentUserRecord = this.frequentUser.FrequentUpdaterListGetResponse.FrequentUserResultSet.FrequentUserRecord;
          this.filteredFrequentUsers = this.frequentUserRecord;
          this.addedBy = "";
          if (this.userInRoleService.userInRole && (this.userInRoleService.userInRole.vibeTeam || this.userInRoleService.userInRole.cfdoOrRiskAnalyst))
            this.addedBy = this.userInRoleService.userInRole.username;
        }
        else {

          if (JSON.stringify(data).includes(AppSettings.VSR_EXCEPTION_CODE_0107))
            this.appsAlert = AppSettings.VSR_EXCEPTION_CODE_0107_DESC;
          else if (JSON.stringify(data).includes(AppSettings.VSR_EXCEPTION_CODE_0108))
            this.appsAlert = AppSettings.VSR_EXCEPTION_CODE_0108_DESC;
          else if (JSON.stringify(data).includes(AppSettings.VSR_EXCEPTION_CODE_0500))
            this.appsAlert = AppSettings.VSR_EXCEPTION_CODE_0500_DESC;
          else
            this.appsAlert = AppSettings.SYSTEM_EXCEPTION;

          this.loading = false;
        }
      }, error => {
        (async () => {
          // await this.delay(1000);  //when simulating a long delay or timeout from a service.

          this.loading = false;


        })();
      }
    );
  }

  pageClick(event: number) {
    // console.log("the this.pagination.currentPage is: " + JSON.stringify(this.pagination.currentPage));
    if (this.dataInquiryListRecord !== undefined && this.dataInquiryListRecord !== null) {
      if (this.dataInquiryListRecord.length > 0 && (this.dataInquiryListRecord.length - event < this.recordsPerPage)) {

        console.log("the current record is at the last page: " + event);
        this.getAdditionalDataInquiryList();
      }
    }
    console.log("the event is: " + event);
  }


  exportReport() {

    `
    Inquiry ID
Added By
Receipt Number
Company Name
USCIS Office
G-28 Address Match
Form Type
Classification
FEIN
IIP Comment
Inquiry Status
Resolution Status
Resolution Comment
Date Requested
Date Completed
VIBE Team Review
AGN ID#


Inquiry ID	Receipt Number	Company Name	G-28 Address Match	Form Type	Classification	FEIN	Inquiry DUNS	Resolution DUNS
  Reason for Inquiry	IIP Comment	Resolution Status	Resolution Comment	Petitioner Street	Petitioner City	Petitioner State	
  Region	Petitioner ZIP	Phone Number	Additional Street	Additional City	Additional State	
  Additional ZIP	Adjudicative Status	Score	2-YR Previous Filings	Date Requested	Date Completed
`

    let dir: DataInquiryExcelReport;
    let diReports: DataInquiryExcelReport[] = [];
    if (this.dataInquiryListRecord && this.dataInquiryListRecord !== undefined && this.dataInquiryListRecord !== null) {
     

      if (this.exportOptions == "CSV") {
        diReports = this.prepareExcelReport();
        this.excelService.exportAsCSVFile(diReports, "VibeDIReport")
      }
      else if (this.exportOptions == "EXCEL") {
        diReports = this.prepareExcelReport();
        this.excelService.exportAsExcelFile(diReports, 'VibeDIReport');
      }
      else if (this.exportOptions == "SIEVE") {
        let disr: DataInquirySIEVEReport;
        let DISReports: DataInquirySIEVEReport[] = [];
        DISReports = this.prepareSIEVEReport( );
        this.excelService.exportAsExcelFile(DISReports, 'VibeDI_SIEVEReport');
      }

    }

  }


  private prepareExcelReport() {
    let dir: DataInquiryExcelReport;
    let diReports: DataInquiryExcelReport[] = [];
    for (let di of this.dataInquiryListRecord) {
      dir = new DataInquiryExcelReport();
      dir.DataInquiryID = di.DataInquiryID;
      dir.ReceiptNumber = di.ReceiptNumber;
      dir.OrganizationName = di.OrganizationName;
      dir.G28Match = di.G28Match;
      dir.FormType = di.FormType;
      dir.VisaType = di.VisaType;
      dir.Fein = di.Fein;
      dir.IipComment = di.IipComment;
      dir.ProcessStatus = this.getStatus(di.ProcessStatus);
      dir.ResolutionStatus = this.getResolutionStatus(di.ResolutionStatus);
      dir.DateRequested = di.DateRequested;
      dir.CompletedDate = di.CompletedDate;
      dir.VibeTeamReview = di.VibeTeamReview;
      dir.AgnID = di.AgnID;
      dir.RequestedBy = di.RequestedBy;
      dir.Office = di.Office;
      diReports.push(dir);
    }
    return diReports;
  }


  private prepareSIEVEReport(): DataInquirySIEVEReport[] {
   let disr: DataInquirySIEVEReport;
   let DISReports: DataInquirySIEVEReport[] = [];
    for (let di of this.dataInquiryListRecord) {
      disr = new DataInquirySIEVEReport();
      disr.InquiryID = di.DataInquiryID;
      disr.ReceiptNumber = di.ReceiptNumber;
      disr.CompanyName = di.OrganizationName;
      disr.G28AddressMatch = di.G28Match;
      disr.FormType = di.FormType;
      disr.Classification = di.VisaType;
      disr.Fein = di.Fein;
      disr.InquiryDUNS = di.DunsNumber
      disr.ResolutionDuns = di.ResolutionDuns;
      disr.ReasonForInquiry = di.ReasonForInquiry;
      disr.IipComment = di.IipComment;
      disr.ResolutionStatus = di.ResolutionStatus;
      disr.ResolutionComment = di.ResolutionComment;
      disr.PetitionerStreet = di.PetitionerAddress.StreetFullText;
      disr.PetitionerCity = di.PetitionerAddress.LocationCityName;
      disr.PetitionerState = di.PetitionerAddress.LocationStateName;
      disr.Region = di.PetitionerAddress.LocationCountryName ;
      disr.PetitionerZIP = di.PetitionerAddress.LocationPostalCode;
      disr.PhoneNumber = di.OrganizationPhone.TelephoneNumberFullID ;
      disr.AdditionalStreet = di.AdditionalAddress.StreetFullText;
      disr.AdditionalCity = di.AdditionalAddress.LocationCityName;
      disr.AdditionalState = di.AdditionalAddress.LocationStateName;
      disr.AdditionalZIP = di.AdditionalAddress.LocationPostalCode;
      disr.AdjudicativeStatus = di.AdjudicativeStatus;
      disr.Score = di.Score;
      disr.TwoYRPreviousFilings = di.PfCount;
      disr.DateRequested = di.DateRequested;
      disr.DateCompleted = di.CompletedDate;
      DISReports.push(disr);
    }
    return DISReports;
  }

  getStatus(value: string): string {
    `
    <option value="" selected="selected" id="statusOfInquirySelected"></option>
                                    <option value="U">Unprocessed</option>
                                    <option value="P">Pending</option>
                                    <option value="A">Accepted</option>
                                    <option value="C">Closed by SCOPS</option>
                                    <option value="S">Submitted</option>
                                    <option value="I">In Progress</option>
                                    <option value="D">Completed by IIP</option>`
    let status: string = "";
    switch (value) {
      case "U":
        status = "Unprocessed";
        break;

      case "A":
        status = "Accepted";
        break;

      case "C":
        status = "Closed";;
        break;
      case "P":
        status = "Pending";
        break;
      case "S":
        status = "Submitted";
        break;
      case "I":
        status = "In Progress";
        break;
      case "D":
        status = "Completed by IIP";
        break;
      case "R":
        status = "Rejected";
        break;
      default:
        status = value;
        break;
    }
    return status;
  }



  getResolutionStatus(value: string): string {
    `
    <option value="" selected="selected" id="resolutionStatusSelected"></option>
    <option value="P">Pending SCOPS Review</option>
    <option value="RIIP">Resolved with IIP Results</option>
    <option value="RS">Resolved by SCOPS</option>
    <option value="ISR">SCOPS Inconclusive Review</option>
    <option value="PF">Pending IIP Follow-up</option>
    <option value="RIIPF">Resolved with IIP Follow-up</option>
    <option value="CS">Admin Closed by SCOPS</option>
    <option value="SS">Site Visit - SIEVE</option>
    <option value="SDO">Site Visit - DOS</option>
    <option value="ST">Site Visit - TSVVP</option>
    <option value="RSS">Resolved with SIEVE</option>
    <option value="RST">Resolved with TSVVP</option>
    <option value="O">Other</option>
    `
    let status: string = "";
    switch (value) {
      case "P":
        status = "Pending SCOPS Review";
        break;

      case "RIIP":
        status = "Resolved with IIP Results";
        break;

      case "RS":
        status = "Resolved by SCOPS";;
        break;
      case "ISR":
        status = "SCOPS Inconclusive Review";
        break;
      case "PF":
        status = "Pending IIP Follow-up";
        break;
      case "RIIPF":
        status = "Resolved with IIP Follow-up";
        break;
      case "CS":
        status = "Admin Closed by SCOPS";;
        break;
      case "SS":
        status = "Site Visit - SIEVE";;
        break;
      case "SDO":
        status = "Site Visit - DOS";;
        break;
      case "ST":
        status = "Site Visit - TSVVP";;
        break;
      case "RSS":
        status = "Resolved with SIEVE";;
        break;
      case "RST":
        status = "Resolved with TSVVP";;
        break;
      case "O":
        status = "Other";;
        break;
      default:
        status = value;
        break;
    }
    return status;
  }

  private getAdditionalDataInquiryList(): void {
    this.loading = true;
    this.diRequest.endUserID = this.userInRoleService.userInRole.httpUsername;
    this.diRequest.startRecordNumber = (this.diLastRecordNumber + 1).toString();
    this.diRequest.endRecordNumber = (this.diLastRecordNumber + this.diMaxRowsReturned).toString();
    this.diRequest.sourceSystemID = "vibe-plus";
    this.diRequest.sourceTransactionID = "23423432432432";
    this.appsAlert = "";
    this.diRequestService.getDataInquiryListInJson<DataInquiryList>(this.diRequest).subscribe(
      diResponse => {
        this.loading = false;
        if (diResponse && !JSON.stringify(diResponse).includes("Error") && !JSON.stringify(diResponse).includes("ESB2Exception")) {

          if (diResponse.DataInquiryGetListResponse.DataInquiryListResultSet !== undefined
            && diResponse.DataInquiryGetListResponse.DataInquiryListResultSet !== null &&
            diResponse.DataInquiryGetListResponse.DataInquiryListResultSet.DataInquiryListRecord !== undefined &&
            diResponse.DataInquiryGetListResponse.DataInquiryListResultSet.DataInquiryListRecord !== null
          ) {
            this.totalNumberOfRecords = diResponse.DataInquiryGetListResponse.DataInquiryListResultSet.totalRecordCount;
            let diRecord = diResponse.DataInquiryGetListResponse.DataInquiryListResultSet.DataInquiryListRecord;
            for (let i = 0; i < diRecord.length; i++) {
              this.dataInquiryListRecord.push(diRecord[i]);
            }
            console.log("Now there are " + this.dataInquiryListRecord.length + " records.");
            this.diLastRecordNumber = this.dataInquiryListRecord.length;
          }



          if (diResponse.DataInquiryGetListResponse.ResponseStatusMessage !== undefined
            && diResponse.DataInquiryGetListResponse.ResponseStatusMessage !== null) {
            if (diResponse.DataInquiryGetListResponse.ResponseStatusMessage.StatusCode == "ESB-VIBE.STATUS.001") {
              this.appsAlert = AppSettings.VSR_STATUS_CODE_001_DESC
              console.log("the alert message is ${this.appsAlert}.")

            }
          }

        }
        else {

          if (JSON.stringify(diResponse).includes(AppSettings.VSR_EXCEPTION_CODE_0107))
            this.appsAlert = AppSettings.VSR_EXCEPTION_CODE_0107_DESC;
          else if (JSON.stringify(diResponse).includes(AppSettings.VSR_EXCEPTION_CODE_0108))
            this.appsAlert = AppSettings.VSR_EXCEPTION_CODE_0108_DESC;
          else if (JSON.stringify(diResponse).includes(AppSettings.VSR_EXCEPTION_CODE_0500))
            this.appsAlert = AppSettings.VSR_EXCEPTION_CODE_0500_DESC;
          else
            this.appsAlert = AppSettings.SYSTEM_EXCEPTION;

          this.loading = false;
        }
      }, error => {
        (async () => {
          // await this.delay(1000);  //when simulating a long delay or timeout from a service.

          this.loading = false;


        })();
      }
    );
  }

  private getDataInquiryList(): void {
    this.loading = true;


    this.diRequest.endUserID = this.userInRoleService.userInRole.httpUsername;
    this.diRequest.startRecordNumber = "1";
    this.diRequest.endRecordNumber = this.diMaxRowsReturned.toString();
    this.diRequest.sourceSystemID = "vibe-plus";
    this.diRequest.sourceTransactionID = "23423432432432";
    
  this.diRequest.requestedDateRange = new DateRange();
  this.diRequest.completedDateRange = new DateRange();
  this.diRequest.submittedDateRange = new DateRange();
    this.diRequest.completedDateRange.startDate =  this.datepipe.transformWorkflowDates(this._completedFromDate, 'yyyy-MM-dd');
    this.diRequest.completedDateRange.endDate =  this.datepipe.transformWorkflowDates(this._completedToDate , 'yyyy-MM-dd');
    this.diRequest.submittedDateRange.startDate =  this.datepipe.transformWorkflowDates(this._submittedFromDate , 'yyyy-MM-dd');
    this.diRequest.submittedDateRange.endDate =   this.datepipe.transformWorkflowDates(this._submittedToDate, 'yyyy-MM-dd');
    this.diRequest.requestedDateRange.startDate =   this.datepipe.transformWorkflowDates(this._requestedFromDate, 'yyyy-MM-dd');
    this.diRequest.requestedDateRange.endDate =   this.datepipe.transformWorkflowDates(this._requestedToDate, 'yyyy-MM-dd');

    // console.log(" this.diRequest.addedBy is: " + this.diRequest.addedBy);

    console.log("the request is: " + JSON.stringify(this.diRequest));
    this.appsAlert = "";
    this.diRequestService.getDataInquiryListInJson<DataInquiryList>(this.diRequest).subscribe(
      diResponse => {
        this.loading = false;
        if (diResponse && !JSON.stringify(diResponse).includes("Error") && !JSON.stringify(diResponse).includes("ESB2Exception")) {
          this.dataInquiryList = diResponse;
          if (this.dataInquiryList.DataInquiryGetListResponse.DataInquiryListResultSet !== undefined
            && this.dataInquiryList.DataInquiryGetListResponse.DataInquiryListResultSet !== null &&
            this.dataInquiryList.DataInquiryGetListResponse.DataInquiryListResultSet.DataInquiryListRecord !== undefined &&
            this.dataInquiryList.DataInquiryGetListResponse.DataInquiryListResultSet.DataInquiryListRecord !== null
          ) {
            this.dataInquiryListRecord = this.dataInquiryList.DataInquiryGetListResponse.DataInquiryListResultSet.DataInquiryListRecord;
            this.diLastRecordNumber = this.dataInquiryListRecord.length;
            this.totalNumberOfRecords = diResponse.DataInquiryGetListResponse.DataInquiryListResultSet.totalRecordCount;
          }



          if (this.dataInquiryList.DataInquiryGetListResponse.ResponseStatusMessage !== undefined
            && this.dataInquiryList.DataInquiryGetListResponse.ResponseStatusMessage !== null) {
            if (this.dataInquiryList.DataInquiryGetListResponse.ResponseStatusMessage.StatusCode == "ESB-VIBE.STATUS.001") {
              
              this.dataInquiryListRecord = [];
              this.appsAlert = AppSettings.VSR_STATUS_CODE_001_DESC;
              console.log("the alert message is ${this.appsAlert}." + this.dataInquiryListRecord.length);

            }
          }

        }
        else {

          if (JSON.stringify(diResponse).includes(AppSettings.VSR_EXCEPTION_CODE_0107))
            this.appsAlert = AppSettings.VSR_EXCEPTION_CODE_0107_DESC;
          else if (JSON.stringify(diResponse).includes(AppSettings.VSR_EXCEPTION_CODE_0108))
            this.appsAlert = AppSettings.VSR_EXCEPTION_CODE_0108_DESC;
          else if (JSON.stringify(diResponse).includes(AppSettings.VSR_EXCEPTION_CODE_0500))
            this.appsAlert = AppSettings.VSR_EXCEPTION_CODE_0500_DESC;
          else
            this.appsAlert = AppSettings.SYSTEM_EXCEPTION;

          this.loading = false;
        }
      }, error => {
        (async () => {
          // await this.delay(1000);  //when simulating a long delay or timeout from a service.

          this.loading = false;


        })();
      }
    );
  }
}

export class DataInquiryExcelReport {
  DataInquiryID: string;
  RequestedBy: string;
  ReceiptNumber: string;
  OrganizationName: string;
  Office: string;
  G28Match: string;
  VisaType: string;
  ResolutionDuns: string;
  ReasonForInquiry: string;
  IipComment: string;
  ProcessStatus: string;
  ResolutionStatus: string;
  AdjudicativeStatus: string;
  Score: string;
  DateRequested: string;
  CompletedDate: string;
  VibeTeamReview: boolean;
  AgnID: string;
  FormType: string;
  Fein: string;
  DunsNumber: string;
  PfCount: string;
}


export class DataInquirySIEVEReport {
  InquiryID: string;
  ReceiptNumber: string;
  CompanyName: string;
  G28AddressMatch: string;
  FormType: string;
  Classification: string;
  Fein: string;
  InquiryDUNS: string;
  ResolutionDuns: string;
  ReasonForInquiry: string;
  IipComment: string;
  ResolutionStatus: string;
  ResolutionComment: string;
  PetitionerStreet: string;
  PetitionerCity: string;
  PetitionerState: string;
  Region: string;
  PetitionerZIP: string;
  PhoneNumber: string;
  AdditionalStreet: string;
  AdditionalCity: string;
  AdditionalState: string;
  AdditionalZIP: string;
  AdjudicativeStatus: string;
  Score: string;
  TwoYRPreviousFilings: string;
  DateRequested: string;
  DateCompleted: string;
 
}

`Inquiry ID	Receipt Number	Company Name	G-28 Address Match	Form Type	Classification	FEIN	Inquiry DUNS	Resolution DUNS
Reason for Inquiry	IIP Comment	Resolution Status	Resolution Comment	Petitioner Street	Petitioner City	Petitioner State	
Region	Petitioner ZIP	Phone Number	Additional Street	Additional City	Additional State	
Additional ZIP	Adjudicative Status	Score	2-YR Previous Filings	Date Requested	Date Completed
`