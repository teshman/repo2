

    export class DateRange {
        startDate: string;
        endDate: string;
    }


    export class DataInquiryRequest {
        endUserID: string;
        startRecordNumber: string;
        endRecordNumber: string;
        sourceSystemID: string;
        sourceTransactionID: string;
        receiptNumber: string;
        duns: string;
        organizationName: string;
        office: string;
        requestedDateRange: DateRange;
        addedBy: string;
        inquiryId: string;
        visaType: string;
        g28Match: string;
        reasonForInquiry: string;
        inquiryStatus: string;
        submittedDateRange: DateRange;
        completedDateRange: DateRange;
        resolutionStatus: string;
        resolutionCode: string;
        iipCaseId: string;
        vibeTeamReview: string;
        internationalIndicator: string;
    }
