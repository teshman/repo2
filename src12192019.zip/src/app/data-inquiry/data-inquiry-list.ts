

    export interface PetitionerAddress {
        StreetFullText: string;
        LocationCityName: string;
        LocationPostalCode: string;
        LocationStateName: string;
        LocationCountryName: string;
    }

    export interface OrganizationPhone {
        TelephoneNumberFullID?: any;
    }

    export interface AdditionalAddress {
        StreetFullText?: any;
        LocationCityName?: any;
        LocationPostalCode?: any;
        LocationStateName?: any;
    }

    export interface DataInquiryListRecord {
        DataInquiryID: string;
        RequestedBy: string;
        ReceiptNumber: string;
        OrganizationName: string;
        Office: string;
        G28Match: string;
        VisaType: string;
        ResolutionDuns: string;
        ReasonForInquiry: string;
        IipComment: string;
        ProcessStatus: string;
        ResolutionStatus: string;
        ResolutionComment: string;
        PetitionerAddress: PetitionerAddress;
        OrganizationPhone: OrganizationPhone;
        AdditionalAddress: AdditionalAddress;
        AdjudicativeStatus: string;
        Score: string;
        DateRequested: string;
        CompletedDate: string;
        DateSubmitted: string;
        VibeTeamReview: boolean;
        AgnID: string;
        FormType: string;
        Fein: string;
        DunsNumber: string;
        PfCount: string;
    }

    export interface DataInquiryListResultSet {
        lastRecordIndex: number;
        recordCountInThisResultSet: number;
        totalRecordCount: number;
        DataInquiryListRecord: DataInquiryListRecord[];
    }

    export interface DataInquiryGetListResponse {
        SourceSystemID: string;
        SourceTransactionID: string;
        ServiceRequestTimestamp: Date;
        ServiceResponseTimestamp: Date;
        AuditCorrelationID: string; 
        ResponseStatusMessage: ResponseStatusMessage;
        DataInquiryListResultSet: DataInquiryListResultSet;
    }

    export interface DataInquiryList {
        DataInquiryGetListResponse: DataInquiryGetListResponse;
    }


    export interface ResponseStatusMessage {
        StatusCode: string;
        Status: string;
    }


    

   
