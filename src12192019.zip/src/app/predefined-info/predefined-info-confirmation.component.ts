import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { PredefWorkflowService } from './predef-workflow.service';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';

@Component({
  selector: 'predefined-info-confirmation',
  templateUrl: './predefined-info-confirmation.component.html',
  styleUrls: ['./predefined-info-confirmation.component.css']
})
export class PredefinedInfoConfirmationComponent implements OnInit {
  
  confirmationForm: FormGroup;  
  addCommentFullForm: FormGroup;

  @Input() showSubmitResponse: boolean = false;
  @Input() approvalResponseMessage:string = "";
  
  @Output() confirmationComplete: EventEmitter<string> = new EventEmitter<string>();
  predefWFS:PredefWorkflowService
  constructor( private predefWorkflowService:PredefWorkflowService , private fb: FormBuilder) {    
    
    this.predefWFS = this.predefWorkflowService;
  }

  ngOnInit() {
    
    this.setupInputForms();
    this.
      addCommentFullForm.
      valueChanges.
      subscribe(form => {
        // this.setFormType();
      });
      this.
      confirmationForm.
      valueChanges.
      subscribe(form => {
        // this.hideDisplayFieldsPerScore();
      });
  }

  
   setupInputForms() {
    this.addCommentFullForm = this.fb.group({
      textAreaJustification: new FormControl(''),
      textAreaVibeComment: new FormControl('')
    });

    this.confirmationForm = this.fb.group({
      frmTypeI129: new FormControl(''),
      frmTypeI140: new FormControl(''),
      frmTypeI360: new FormControl(''),
      frmTypeI485J: new FormControl(''),
      fdnsFormattedText: new FormControl(''),
      siteVisitProgram: new FormControl('')
      
    });
  }
 
   setFormType() {
    let formType = this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.preDefFormCommentType;
    // console.log("manualEdit & forceEdit : " + this.predefWorkflowService.predefCompleteList.formTypeManualEdit + ", " + 
    // this.predefWorkflowService.predefCompleteList.forceEdit);
    if (this.predefWorkflowService.predefCompleteList.formTypeManualEdit !== true && this.predefWorkflowService.predefCompleteList.forceEdit == true) {
      console.log("Not in Edit Mode or forceEdit not true...formtype is: " + formType);
      for (let ft of this.predefWorkflowService.predefCompleteList.formTypes) {
        if (formType && formType.includes(ft))
        this.predefWorkflowService.predefCompleteList.selectedFormType[ft] = true;
        else 
        this.predefWorkflowService.predefCompleteList.selectedFormType[ft] = false;
      }
      this.predefWorkflowService.predefCompleteList.forceEdit = false;

    }
    
  }

   updateFormTypeInputValues(ctrl) {
    let formTypeStr = "";
    let ctrlState:boolean = false;
    let ctrlState1:boolean = true;
    this.predefWorkflowService.predefCompleteList.formTypeManualEdit = true;
    ctrlState1 =  this.predefWorkflowService.predefCompleteList.selectedFormType[ctrl];
   
    for (let ft of this.predefWorkflowService.predefCompleteList.formTypes) {
      if (ft !== ctrl) {        
      ctrlState = this.predefWorkflowService.predefCompleteList.selectedFormType[ft];
        if (ctrlState) formTypeStr = formTypeStr + ft;      
      }
      else if (!ctrlState1){
        formTypeStr = formTypeStr + ft;
      }
    }    
    this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.preDefFormCommentType = 
    formTypeStr;   
  }

  hideDisplayFieldsPerScore() {
    let score = this.predefWFS.predefCompleteList.predefinedInformationRequest.overrideScore;
    if (score !== undefined && score !== null && score.trim().toUpperCase() === 'RED') {
      this.predefWFS.predefCompleteList.predefinedInformationRequest.preDefFormCommentType = "I129I140I360I485J";
      this.predefWFS.predefCompleteList.setFormType();
      
      console.log("inside hideDisplayFieldsPerScore")
    } 
    else if (score !== undefined && score !== null && score.trim().toUpperCase() === "N/A") {      
      this.predefWFS.predefCompleteList.predefinedInformationRequest.preDefFormCommentType = "";
    }
  }

}
