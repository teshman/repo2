import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PredefinedInfoApprovalComponent } from './predefined-info-approval.component';

describe('PredefinedInfoApprovalComponent', () => {
  let component: PredefinedInfoApprovalComponent;
  let fixture: ComponentFixture<PredefinedInfoApprovalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PredefinedInfoApprovalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PredefinedInfoApprovalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
