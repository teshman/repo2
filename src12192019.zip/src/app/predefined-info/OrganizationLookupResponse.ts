﻿// Stores the currently-being-typechecked object for error messages.
let obj: any = null;
export class OrganizationLookupResponseProxy {
  public readonly SourceSystemID: string;
  public readonly SourceTransactionID: string;
  public readonly ServiceRequestTimestamp: string;
  public readonly ServiceResponseTimestamp: string;
  public readonly AuditCorrelationID: string;
  public readonly DunsNumber: string;
  public readonly AgnID: string;
  public readonly OrganizationName: string;
  public readonly ConfidenceFactor: string;
  public readonly Address: PhysicalAddressOrAddressProxy;
  public readonly PredefinedInformationRecord: PredefinedInformationRecordProxy;
  public readonly OrganizationInformation: OrganizationInformationProxy;
  public static Parse(d: string): OrganizationLookupResponseProxy {
    return OrganizationLookupResponseProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): OrganizationLookupResponseProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    checkString(d.SourceSystemID, false, field + ".SourceSystemID");
    checkString(d.SourceTransactionID, false, field + ".SourceTransactionID");
    checkString(d.ServiceRequestTimestamp, false, field + ".ServiceRequestTimestamp");
    checkString(d.ServiceResponseTimestamp, false, field + ".ServiceResponseTimestamp");
    checkString(d.AuditCorrelationID, false, field + ".AuditCorrelationID");
    checkString(d.DunsNumber, false, field + ".DunsNumber");
    checkString(d.AgnID, false, field + ".AgnID");

    checkString(d.OrganizationName, false, field + ".OrganizationName");
    checkString(d.ConfidenceFactor, false, field + ".ConfidenceFactor");
    d.Address = PhysicalAddressOrAddressProxy.Create(d.Address, field + ".Address");
    d.PredefinedInformationRecord = PredefinedInformationRecordProxy.Create(d.PredefinedInformationRecord, field + ".PredefinedInformationRecord");
    d.OrganizationInformation = OrganizationInformationProxy.Create(d.OrganizationInformation, field + ".OrganizationInformation");
    return new OrganizationLookupResponseProxy(d);
  }
  private constructor(d: any) {
    this.SourceSystemID = d.SourceSystemID;
    this.SourceTransactionID = d.SourceTransactionID;
    this.ServiceRequestTimestamp = d.ServiceRequestTimestamp;
    this.ServiceResponseTimestamp = d.ServiceResponseTimestamp;
    this.AuditCorrelationID = d.AuditCorrelationID;
    this.AgnID = d.AgnID;
    this.DunsNumber = d.DunsNumber;
    this.OrganizationName = d.OrganizationName;
    this.ConfidenceFactor = d.ConfidenceFactor;
    this.Address = d.Address;
    this.PredefinedInformationRecord = d.PredefinedInformationRecord;
    this.OrganizationInformation = d.OrganizationInformation;
  }
}

export class PhysicalAddressOrAddressProxy {
  public readonly StreetFullText: string;
  public readonly LocationCityName: string;
  public readonly LocationPostalCode: string;
  public readonly LocationStateName: string;
  public readonly LocationCountryName: string;
  public static Parse(d: string): PhysicalAddressOrAddressProxy {
    return PhysicalAddressOrAddressProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): PhysicalAddressOrAddressProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    checkString(d.StreetFullText, false, field + ".StreetFullText");
    checkString(d.LocationCityName, false, field + ".LocationCityName");
    checkString(d.LocationPostalCode, false, field + ".LocationPostalCode");
    checkString(d.LocationStateName, false, field + ".LocationStateName");
    checkString(d.LocationCountryName, false, field + ".LocationCountryName");
    return new PhysicalAddressOrAddressProxy(d);
  }
  private constructor(d: any) {
    this.StreetFullText = d.StreetFullText;
    this.LocationCityName = d.LocationCityName;
    this.LocationPostalCode = d.LocationPostalCode;
    this.LocationStateName = d.LocationStateName;
    this.LocationCountryName = d.LocationCountryName;
  }
}

export class PredefinedInformationRecordProxy {
  public readonly ExceptionID: string;
  public readonly DunsNumber: string;
  public readonly AgnID?: any;
  public readonly OrganizationName: string;
  public readonly Comment: string;
  public readonly Justification: string;
  public readonly ProcessStatus: string;
  public readonly OverrideScore: string;
  public readonly ValidStartDate: string;
  public readonly ValidEndDate: string;
  public readonly DateAdded: string;
  public readonly ApprovedBy: string;
  public readonly ApprovalDate: Date;
  public readonly AddedBy: string;
  public readonly preDefCommentT?: any;
  public readonly preDefFormCommentT: string;
  public readonly FDNSDSNumber: string;
  public readonly ReceiptNumber: string;
  public readonly LockedBy: string;
  public readonly LockedTime: string;
  public readonly Fein: string;
  public readonly Address: orgLookUpAddress;
  public readonly Office: string;
  public readonly SiteVisitProgram: string;
  public readonly NominationSource: string;
  public static Parse(d: string): PredefinedInformationRecordProxy {
    return PredefinedInformationRecordProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): PredefinedInformationRecordProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    checkString(d.ExceptionID, false, field + ".ExceptionID");
    checkString(d.DunsNumber, false, field + ".DunsNumber");
    checkString(d.OrganizationName, false, field + ".OrganizationName");
    checkString(d.Comment, false, field + ".Comment");
    checkString(d.ProcessStatus, false, field + ".ProcessStatus");
    checkString(d.Justification, false, field + ".Justification");
    checkString(d.OverrideScore, false, field + ".OverrideScore");
    checkString(d.ValidStartDate, false, field + ".ValidStartDate");
    checkString(d.ValidEndDate, false, field + ".ValidEndDate");
    checkString(d.DateAdded, false, field + ".DateAdded");
    checkString(d.ApprovedBy, false, field + ".ApprovedBy");
    checkString(d.ApprovalDate, false, field + ".ApprovalDate");
    checkString(d.LockedBy, false, field + ".LockedBy");
    checkString(d.LockedTime, false, field + ".LockedTime");
    checkString(d.AddedBy, false, field + ".AddedBy");
    checkString(d.ReceiptNumber, false, field + ".ReceiptNumber");
    checkString(d.Fein, false, field + ".Fein");
    checkString(d.Office, false, field + ".Office");
    checkString(d.NominationSource, false, field + ".Office");
    return new PredefinedInformationRecordProxy(d);
  }
  private constructor(d: any) {
    this.ExceptionID = d.ExceptionID;
    this.DunsNumber = d.DunsNumber;
    this.OrganizationName = d.OrganizationName;
    this.Comment = d.Comment;
    this.Justification = d.Justification;
    this.ProcessStatus = d.ProcessStatus;
    this.OverrideScore = d.OverrideScore;
    this.ValidStartDate = d.ValidStartDate;
    this.ValidEndDate = d.ValidEndDate;
    this.DateAdded = d.DateAdded;
    this.ApprovedBy = d.ApprovedBy;
    this.ApprovalDate = d.ApprovalDate;
    this.LockedBy = d.LockedBy;
    this.LockedTime = d.LockedTime;
    this.AddedBy = d.AddedBy;
    this.ReceiptNumber = d.ReceiptNumber;
    this.Fein = d.Fein;
    this.Office = d.Office;
  }
}



  export interface orgLookUpAddress {
      AddressID: string;
      OrganizationName: string;
      TelephoneNumberFullID: string;
      StreetFullText: string;
      StreetExtensionText?: any;
      LocationCityName: string;
      LocationPostalCode: string;
      LocationStateName: string;
      LocationCountryName: string;
  }

  // export interface PredefinedInformationRecordProxy {
  //     ExceptionID: string;
  //     DunsNumber: string;
  //     AgnID?: any;
  //     OrganizationName: string;
  //     Comment: string;
  //     ProcessStatus: string;
  //     OverrideScore: string;
  //     ValidStartDate: string;
  //     ValidEndDate: string;
  //     DateAdded: string;
  //     ApprovedBy: string;
  //     ApprovalDate: Date;
  //     AddedBy: string;
  //     preDefCommentT?: any;
  //     preDefFormCommentT: string;
  //     FDNSDSNumber: string;
  //     ReceiptNumber: string;
  //     Fein: string;
  //     Address: orgLookUpAddress;
  //     Office: string;
  //     SiteVisitProgram: string;
  // }




export class OrganizationInformationProxy {
  public readonly OrganizationDetail: OrganizationDetailProxy;
  public readonly PhysicalAddress: PhysicalAddressOrAddressProxy;
  public static Parse(d: string): OrganizationInformationProxy {
    return OrganizationInformationProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): OrganizationInformationProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    d.OrganizationDetail = OrganizationDetailProxy.Create(d.OrganizationDetail, field + ".OrganizationDetail");
    d.PhysicalAddress = PhysicalAddressOrAddressProxy.Create(d.PhysicalAddress, field + ".PhysicalAddress");
    return new OrganizationInformationProxy(d);
  }
  private constructor(d: any) {
    this.OrganizationDetail = d.OrganizationDetail;
    this.PhysicalAddress = d.PhysicalAddress;
  }
}

export class OrganizationDetailProxy {
  public readonly AGN_ID: string;
  public readonly DUNSNumber: string;
  public readonly MatchConfidenseCode: string;
  public readonly OutOfBusinessIndicator: string;
  public readonly OrganizationName: string;
  public readonly OrganizationPhone: OrganizationPhoneProxy;
  public readonly TradeStyleNames: TradeStyleNamesProxy;
  public readonly OrganizationEstablishedDate: string;
  public readonly SubsidiaryIndicator: string;
  public readonly LocalBusinessID: string;
  public readonly LocalBusinessID_EIN_TIN: string;
  public readonly SmallBusinessIndicator: string;
  public readonly GlobalUltimateDUNSNumber: string;
  public readonly GlobalUltimateName: GlobalUltimateNameProxy;
  public readonly GlobalUltimateCountryCode: string;
  public readonly DomesticUltimateDUNSNumber: string;
  public readonly DomesticUltimateName: string;
  public readonly EmployeeGrowthRate3Year: string;
  public readonly EmployeeCountUSA: number;
  public readonly EmployeeCountUSACode: number;
  public readonly EmployeeCountWorldWide: number;
  public readonly EmployeeCountWorldWideCode: number;
  public readonly NorthAmericanIndustryClassificationSystems: NorthAmericanIndustryClassificationSystemsProxy;
  public readonly GovernmentContractor: string;
  public readonly LocationCountryDescription: string;
  public readonly LegalStatusCode: string;
  public readonly SiteStatusIndicator: string;
  public readonly LocationType: string;
  public readonly ImportExportIndicator: string;
  public readonly NumberFamilyMembers: string;
  public readonly ProofOfRightCount: string;
  public readonly TotalTradePayments: string;
  public readonly CEOFullName: string;
  public readonly ControlYear: string;
  public readonly OwnsRentsIndicator: string;
  public readonly FinancialStressClass: string;
  public readonly HistoryIndicator: string;
  public readonly Executives: ExecutivesProxy;
  public readonly SalesVolumeUSA: string;
  public readonly SalesVolumeUSACode: string;
  public readonly ForeignAffliateIndicator: string;
  public readonly NixieCode: string;
  public readonly Latitude: string;
  public readonly Longitude: string;
  public readonly TixieFlag: string;
  public readonly PopulationCode: string;
  public readonly PrimarySicCode: string;
  public readonly HighCredit: string;
  public readonly AvgCredit: string;
  public readonly SecuredFilingsIndc: string;
  public readonly SuitsJudgmentsIndc: string;
  public readonly ClaimsIndc: string;
  public readonly PaydexScore: string;
  public readonly FinancialEmbarrasIndc: string;
  public readonly EaiCode: string;
  public static Parse(d: string): OrganizationDetailProxy {
    return OrganizationDetailProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): OrganizationDetailProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    checkString(d.AGN_ID, false, field + ".AGN_ID");
    checkString(d.DUNSNumber, false, field + ".DUNSNumber");
    checkString(d.MatchConfidenseCode, false, field + ".MatchConfidenseCode");
    checkString(d.OutOfBusinessIndicator, false, field + ".OutOfBusinessIndicator");
    checkString(d.OrganizationName, false, field + ".OrganizationName");
    d.OrganizationPhone = OrganizationPhoneProxy.Create(d.OrganizationPhone, field + ".OrganizationPhone");
    d.TradeStyleNames = TradeStyleNamesProxy.Create(d.TradeStyleNames, field + ".TradeStyleNames");
    checkString(d.OrganizationEstablishedDate, false, field + ".OrganizationEstablishedDate");
    checkString(d.SubsidiaryIndicator, false, field + ".SubsidiaryIndicator");
    checkString(d.LocalBusinessID, false, field + ".LocalBusinessID");
    checkString(d.LocalBusinessID_EIN_TIN, false, field + ".LocalBusinessID_EIN_TIN");
    checkString(d.SmallBusinessIndicator, false, field + ".SmallBusinessIndicator");
    checkString(d.GlobalUltimateDUNSNumber, false, field + ".GlobalUltimateDUNSNumber");
    d.GlobalUltimateName = GlobalUltimateNameProxy.Create(d.GlobalUltimateName, field + ".GlobalUltimateName");
    checkString(d.GlobalUltimateCountryCode, false, field + ".GlobalUltimateCountryCode");
    checkString(d.DomesticUltimateDUNSNumber, false, field + ".DomesticUltimateDUNSNumber");
    checkString(d.DomesticUltimateName, false, field + ".DomesticUltimateName");
    checkString(d.EmployeeGrowthRate3Year, false, field + ".EmployeeGrowthRate3Year");
    checkNumber(d.EmployeeCountUSA, false, field + ".EmployeeCountUSA");
    checkNumber(d.EmployeeCountUSACode, false, field + ".EmployeeCountUSACode");
    checkNumber(d.EmployeeCountWorldWide, false, field + ".EmployeeCountWorldWide");
    checkNumber(d.EmployeeCountWorldWideCode, false, field + ".EmployeeCountWorldWideCode");
    d.NorthAmericanIndustryClassificationSystems = NorthAmericanIndustryClassificationSystemsProxy.Create(d.NorthAmericanIndustryClassificationSystems, field + ".NorthAmericanIndustryClassificationSystems");
    checkString(d.GovernmentContractor, false, field + ".GovernmentContractor");
    checkString(d.LocationCountryDescription, false, field + ".LocationCountryDescription");
    checkString(d.LegalStatusCode, false, field + ".LegalStatusCode");
    checkString(d.SiteStatusIndicator, false, field + ".SiteStatusIndicator");
    checkString(d.LocationType, false, field + ".LocationType");
    checkString(d.ImportExportIndicator, false, field + ".ImportExportIndicator");
    checkString(d.NumberFamilyMembers, false, field + ".NumberFamilyMembers");
    checkString(d.ProofOfRightCount, false, field + ".ProofOfRightCount");
    checkString(d.TotalTradePayments, false, field + ".TotalTradePayments");
    checkString(d.CEOFullName, false, field + ".CEOFullName");
    checkString(d.ControlYear, false, field + ".ControlYear");
    checkString(d.OwnsRentsIndicator, false, field + ".OwnsRentsIndicator");
    checkString(d.FinancialStressClass, false, field + ".FinancialStressClass");
    checkString(d.HistoryIndicator, false, field + ".HistoryIndicator");
    d.Executives = ExecutivesProxy.Create(d.Executives, field + ".Executives");
    checkString(d.SalesVolumeUSA, false, field + ".SalesVolumeUSA");
    checkString(d.SalesVolumeUSACode, false, field + ".SalesVolumeUSACode");
    checkString(d.ForeignAffliateIndicator, false, field + ".ForeignAffliateIndicator");
    checkString(d.NixieCode, false, field + ".NixieCode");
    checkString(d.Latitude, false, field + ".Latitude");
    checkString(d.Longitude, false, field + ".Longitude");
    checkString(d.TixieFlag, false, field + ".TixieFlag");
    checkString(d.PopulationCode, false, field + ".PopulationCode");
    checkString(d.PrimarySicCode, false, field + ".PrimarySicCode");
    checkString(d.HighCredit, false, field + ".HighCredit");
    checkString(d.AvgCredit, false, field + ".AvgCredit");
    checkString(d.SecuredFilingsIndc, false, field + ".SecuredFilingsIndc");
    checkString(d.SuitsJudgmentsIndc, false, field + ".SuitsJudgmentsIndc");
    checkString(d.ClaimsIndc, false, field + ".ClaimsIndc");
    checkString(d.PaydexScore, false, field + ".PaydexScore");
    checkString(d.FinancialEmbarrasIndc, false, field + ".FinancialEmbarrasIndc");
    checkString(d.EaiCode, false, field + ".EaiCode");
    return new OrganizationDetailProxy(d);
  }
  private constructor(d: any) {
    this.AGN_ID = d.AGN_ID;
    this.DUNSNumber = d.DUNSNumber;
    this.MatchConfidenseCode = d.MatchConfidenseCode;
    this.OutOfBusinessIndicator = d.OutOfBusinessIndicator;
    this.OrganizationName = d.OrganizationName;
    this.OrganizationPhone = d.OrganizationPhone;
    this.TradeStyleNames = d.TradeStyleNames;
    this.OrganizationEstablishedDate = d.OrganizationEstablishedDate;
    this.SubsidiaryIndicator = d.SubsidiaryIndicator;
    this.LocalBusinessID = d.LocalBusinessID;
    this.LocalBusinessID_EIN_TIN = d.LocalBusinessID_EIN_TIN;
    this.SmallBusinessIndicator = d.SmallBusinessIndicator;
    this.GlobalUltimateDUNSNumber = d.GlobalUltimateDUNSNumber;
    this.GlobalUltimateName = d.GlobalUltimateName;
    this.GlobalUltimateCountryCode = d.GlobalUltimateCountryCode;
    this.DomesticUltimateDUNSNumber = d.DomesticUltimateDUNSNumber;
    this.DomesticUltimateName = d.DomesticUltimateName;
    this.EmployeeGrowthRate3Year = d.EmployeeGrowthRate3Year;
    this.EmployeeCountUSA = d.EmployeeCountUSA;
    this.EmployeeCountUSACode = d.EmployeeCountUSACode;
    this.EmployeeCountWorldWide = d.EmployeeCountWorldWide;
    this.EmployeeCountWorldWideCode = d.EmployeeCountWorldWideCode;
    this.NorthAmericanIndustryClassificationSystems = d.NorthAmericanIndustryClassificationSystems;
    this.GovernmentContractor = d.GovernmentContractor;
    this.LocationCountryDescription = d.LocationCountryDescription;
    this.LegalStatusCode = d.LegalStatusCode;
    this.SiteStatusIndicator = d.SiteStatusIndicator;
    this.LocationType = d.LocationType;
    this.ImportExportIndicator = d.ImportExportIndicator;
    this.NumberFamilyMembers = d.NumberFamilyMembers;
    this.ProofOfRightCount = d.ProofOfRightCount;
    this.TotalTradePayments = d.TotalTradePayments;
    this.CEOFullName = d.CEOFullName;
    this.ControlYear = d.ControlYear;
    this.OwnsRentsIndicator = d.OwnsRentsIndicator;
    this.FinancialStressClass = d.FinancialStressClass;
    this.HistoryIndicator = d.HistoryIndicator;
    this.Executives = d.Executives;
    this.SalesVolumeUSA = d.SalesVolumeUSA;
    this.SalesVolumeUSACode = d.SalesVolumeUSACode;
    this.ForeignAffliateIndicator = d.ForeignAffliateIndicator;
    this.NixieCode = d.NixieCode;
    this.Latitude = d.Latitude;
    this.Longitude = d.Longitude;
    this.TixieFlag = d.TixieFlag;
    this.PopulationCode = d.PopulationCode;
    this.PrimarySicCode = d.PrimarySicCode;
    this.HighCredit = d.HighCredit;
    this.AvgCredit = d.AvgCredit;
    this.SecuredFilingsIndc = d.SecuredFilingsIndc;
    this.SuitsJudgmentsIndc = d.SuitsJudgmentsIndc;
    this.ClaimsIndc = d.ClaimsIndc;
    this.PaydexScore = d.PaydexScore;
    this.FinancialEmbarrasIndc = d.FinancialEmbarrasIndc;
    this.EaiCode = d.EaiCode;
  }
}

export class OrganizationPhoneProxy {
  public readonly TelephoneCountryCodeID: string[] | null;
  public readonly TelephoneNumberID: string[] | null;
  public static Parse(d: string): OrganizationPhoneProxy {
    return OrganizationPhoneProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): OrganizationPhoneProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    checkArray(d.TelephoneCountryCodeID, field + ".TelephoneCountryCodeID");
    if (d.TelephoneCountryCodeID) {
      for (let i = 0; i < d.TelephoneCountryCodeID.length; i++) {
        checkString(d.TelephoneCountryCodeID[i], false, field + ".TelephoneCountryCodeID" + "[" + i + "]");
      }
    }
    if (d.TelephoneCountryCodeID === undefined) {
      d.TelephoneCountryCodeID = null;
    }
    checkArray(d.TelephoneNumberID, field + ".TelephoneNumberID");
    if (d.TelephoneNumberID) {
      for (let i = 0; i < d.TelephoneNumberID.length; i++) {
        checkString(d.TelephoneNumberID[i], false, field + ".TelephoneNumberID" + "[" + i + "]");
      }
    }
    if (d.TelephoneNumberID === undefined) {
      d.TelephoneNumberID = null;
    }
    return new OrganizationPhoneProxy(d);
  }
  private constructor(d: any) {
    this.TelephoneCountryCodeID = d.TelephoneCountryCodeID;
    this.TelephoneNumberID = d.TelephoneNumberID;
  }
}

export class TradeStyleNamesProxy {
  public readonly OrganizationDoingBusinessAsName: OrganizationDoingBusinessAsNameEntityOrExecutiveEntityProxy[] | null;
  public static Parse(d: string): TradeStyleNamesProxy {
    return TradeStyleNamesProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): TradeStyleNamesProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    checkArray(d.OrganizationDoingBusinessAsName, field + ".OrganizationDoingBusinessAsName");
    if (d.OrganizationDoingBusinessAsName) {
      for (let i = 0; i < d.OrganizationDoingBusinessAsName.length; i++) {
        d.OrganizationDoingBusinessAsName[i] = OrganizationDoingBusinessAsNameEntityOrExecutiveEntityProxy.Create(d.OrganizationDoingBusinessAsName[i], field + ".OrganizationDoingBusinessAsName" + "[" + i + "]");
      }
    }
    if (d.OrganizationDoingBusinessAsName === undefined) {
      d.OrganizationDoingBusinessAsName = null;
    }
    return new TradeStyleNamesProxy(d);
  }
  private constructor(d: any) {
    this.OrganizationDoingBusinessAsName = d.OrganizationDoingBusinessAsName;
  }
}

export class OrganizationDoingBusinessAsNameEntityOrExecutiveEntityProxy {
  public readonly id: string;
  public readonly _content_: string;
  public static Parse(d: string): OrganizationDoingBusinessAsNameEntityOrExecutiveEntityProxy {
    return OrganizationDoingBusinessAsNameEntityOrExecutiveEntityProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): OrganizationDoingBusinessAsNameEntityOrExecutiveEntityProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    checkString(d.id, false, field + ".id");
    checkString(d._content_, false, field + "._content_");
    return new OrganizationDoingBusinessAsNameEntityOrExecutiveEntityProxy(d);
  }
  private constructor(d: any) {
    this.id = d.id;
    this._content_ = d._content_;
  }
}

export class GlobalUltimateNameProxy {
  public readonly OrganizationName: string[] | null;
  public static Parse(d: string): GlobalUltimateNameProxy {
    return GlobalUltimateNameProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): GlobalUltimateNameProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    checkArray(d.OrganizationName, field + ".OrganizationName");
    if (d.OrganizationName) {
      for (let i = 0; i < d.OrganizationName.length; i++) {
        checkString(d.OrganizationName[i], false, field + ".OrganizationName" + "[" + i + "]");
      }
    }
    if (d.OrganizationName === undefined) {
      d.OrganizationName = null;
    }
    return new GlobalUltimateNameProxy(d);
  }
  private constructor(d: any) {
    this.OrganizationName = d.OrganizationName;
  }
}

export class NorthAmericanIndustryClassificationSystemsProxy {
  public readonly NAICS: NAICSEntityProxy[] | null;
  public static Parse(d: string): NorthAmericanIndustryClassificationSystemsProxy {
    return NorthAmericanIndustryClassificationSystemsProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): NorthAmericanIndustryClassificationSystemsProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    checkArray(d.NAICS, field + ".NAICS");
    if (d.NAICS) {
      for (let i = 0; i < d.NAICS.length; i++) {
        d.NAICS[i] = NAICSEntityProxy.Create(d.NAICS[i], field + ".NAICS" + "[" + i + "]");
      }
    }
    if (d.NAICS === undefined) {
      d.NAICS = null;
    }
    return new NorthAmericanIndustryClassificationSystemsProxy(d);
  }
  private constructor(d: any) {
    this.NAICS = d.NAICS;
  }
}

export class NAICSEntityProxy {
  public readonly NAICSCode: string;
  public readonly NAICSDescription: string;
  public static Parse(d: string): NAICSEntityProxy {
    return NAICSEntityProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): NAICSEntityProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    checkString(d.NAICSCode, false, field + ".NAICSCode");
    checkString(d.NAICSDescription, false, field + ".NAICSDescription");
    return new NAICSEntityProxy(d);
  }
  private constructor(d: any) {
    this.NAICSCode = d.NAICSCode;
    this.NAICSDescription = d.NAICSDescription;
  }
}

export class ExecutivesProxy {
  public readonly Executive: OrganizationDoingBusinessAsNameEntityOrExecutiveEntityProxy[] | null;
  public static Parse(d: string): ExecutivesProxy {
    return ExecutivesProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): ExecutivesProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    checkArray(d.Executive, field + ".Executive");
    if (d.Executive) {
      for (let i = 0; i < d.Executive.length; i++) {
        d.Executive[i] = OrganizationDoingBusinessAsNameEntityOrExecutiveEntityProxy.Create(d.Executive[i], field + ".Executive" + "[" + i + "]");
      }
    }
    if (d.Executive === undefined) {
      d.Executive = null;
    }
    return new ExecutivesProxy(d);
  }
  private constructor(d: any) {
    this.Executive = d.Executive;
  }
}

export interface OcrGetStatusResponse {
  isActive: boolean;
}

export interface OcrResponse {
  OcrGetStatusResponse: OcrGetStatusResponse;
}

function throwNull2NonNull(field: string, d: any): never {
  return errorHelper(field, d, "non-nullable object", false);
}
function throwNotObject(field: string, d: any, nullable: boolean): never {
  return errorHelper(field, d, "object", nullable);
}
function throwIsArray(field: string, d: any, nullable: boolean): never {
  return errorHelper(field, d, "object", nullable);
}
function checkArray(d: any, field: string): void {
  if (!Array.isArray(d) && d !== null && d !== undefined) {
    errorHelper(field, d, "array", true);
  }
}
function checkNumber(d: any, nullable: boolean, field: string): void {
  if (typeof(d) !== 'number' && (!nullable || (nullable && d !== null && d !== undefined))) {
    errorHelper(field, d, "number", nullable);
  }
}
function checkString(d: any, nullable: boolean, field: string): void {
  if (typeof(d) !== 'string' && (!nullable || (nullable && d !== null && d !== undefined))) {
    errorHelper(field, d, "string", nullable);
  }
}
function errorHelper(field: string, d: any, type: string, nullable: boolean): never {
  if (nullable) {
    type += ", null, or undefined";
  }
  throw new TypeError('Expected ' + type + " at " + field + " but found:\n" + JSON.stringify(d) + "\n\nFull object:\n" + JSON.stringify(obj));
}
