import { Injectable } from '@angular/core';
import { PredefinedInfoWorkflowFacade } from '../shared/predefined-info-workflow-facade';

@Injectable()
export class PredefWorkflowService {
    predefCompleteList:PredefinedInfoWorkflowFacade;
}
