import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { of, interval } from 'rxjs';
import { catchError, map, tap, flatMap, retryWhen, mergeMap, retry, delay } from 'rxjs/operators';
import { PredefinedInformationProxy } from '../shared/predefined-Information-Proxy';
import { AppSettings } from '../shared/app-settings';
import { throwError } from 'rxjs';
import 'rxjs/add/operator/catch';
import 'rxjs/add/Observable/throw';
import { PredefinedInformationGetDetailResponse } from '../shared/predefined-info-response';

@Injectable({
  providedIn: 'root'
})

export class PredefinedInfoService {

  private predefUrl = AppSettings.PREDEF_URL;
  private predefDetailUrl = AppSettings.PREDEF_DETAIL_URL;
  constructor(private http: HttpClient) { }

  getPredefInfo(): Observable<PredefinedInformationProxy> {
    const url = this.predefUrl;
    return this.http.get<PredefinedInformationProxy>(url).pipe(
      tap(_ => 
        this.log(`get predefined info list`)
      )
      // ,     catchError(this.handleError<CisUserProxy>(`error get VSR receipt # ${receiptNumber}`))     
      , catchError(this.handleErrorObservable)
      // ,     catchError(this.handleErrorObservable))
    );
  }

  private handleErrorObservable(error: Response | any) {
    console.error("the error thrown is: " + (error.message));
    let statusMessage: string = "";
    // return Observable.throw(error.message || error);
    //return Observable.throw(new Error(error.status));
    let status: string = JSON.stringify(error.status);
    switch (status) {
      case '400':
        statusMessage = AppSettings.HTTP_STATUS_400;
        break;
        case '401':
          statusMessage = AppSettings.HTTP_STATUS_401;
          break;
      case '404':
        statusMessage = AppSettings.HTTP_STATUS_404;
        break;
      case '500':
        statusMessage = AppSettings.HTTP_STATUS_500;
        break;
      case '503':
        statusMessage = AppSettings.HTTP_STATUS_503;
        break;
      case '502':
        statusMessage = AppSettings.HTTP_STATUS_502;
        break;
      case '599':
        statusMessage = AppSettings.HTTP_STATUS_599;
        break;
      case '408':
        statusMessage = AppSettings.HTTP_STATUS_408;
        break;
      default:
        statusMessage = AppSettings.HTTP_STATUS_UNKNOWN;
  }
    return throwError(statusMessage);
  }


  getPredefInfoFromFile(): Observable<PredefinedInformationProxy> {

    const url = AppSettings.PREDEF_INFO_LIST_JSON;
    console.log("retrying from vsrhist")
    let i:number = 0;
    return this.http.get<PredefinedInformationProxy>(url).pipe(
      
      retryWhen(_ => {
        return interval(10000).pipe(
          flatMap(count => count == 5 ? throwError("Giving up") : of(count))
        )
      }
      )

)}


getPredefInfoDetailFromFile(exceptionId:string): Observable<PredefinedInformationGetDetailResponse> {

  const url = AppSettings.PREDEF_INFO_DETAIL_BY_EXCEPTION_ID_JSON;
  let i:number = 0;
  return this.http.get<PredefinedInformationGetDetailResponse>(url).pipe(
    
    retryWhen(_ => {
      return interval(1000).pipe(
        flatMap(count => count == 3 ? throwError("Giving up") : of(count))
      )
    }
    )

)}


getPredefInfoDetailByExceptionId(exceptionId:string): Observable<PredefinedInformationGetDetailResponse> {
  console.log("the exception id is: " + exceptionId);
  const url = this.predefDetailUrl + exceptionId ;
  return this.http.get<PredefinedInformationGetDetailResponse>(url).pipe(
    tap(_ => 
      this.log(`get predefined info detail by exception id`)
    )       
    , catchError(this.handleErrorObservable)
  );
}


 /**
   * Handle Http operation that failed.
   * Let the app continue.
   * @param operation - name of the operation that failed
   * @param result - optional value to return as the observable result
   */
  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // TODO: better job of transforming error for user consumption
      this.log(`${operation} failed: ${error.message}`);

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }

  private log(message: string) {
   // console.log(`VSR: ${message}`);

  }

  
}