import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PredefinedInfoAddCommentComponent } from './predefined-info-add-comment.component';

describe('PredefinedInfoAddCommentComponent', () => {
  let component: PredefinedInfoAddCommentComponent;
  let fixture: ComponentFixture<PredefinedInfoAddCommentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PredefinedInfoAddCommentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PredefinedInfoAddCommentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
