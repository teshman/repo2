import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PredefinedInfoComponent } from './predefined-info.component';

describe('PredefinedInfoComponent', () => {
  let component: PredefinedInfoComponent;
  let fixture: ComponentFixture<PredefinedInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PredefinedInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PredefinedInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
