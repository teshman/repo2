import { Component, OnInit, Input } from '@angular/core';
import { PredefWorkflowService } from './predef-workflow.service';
import { FormControl, FormGroup, Validators, FormBuilder } from '@angular/forms';

import { TooltipPosition } from '@angular/material/tooltip';
@Component({
  selector: 'predefined-info-add-comment',
  templateUrl: './predefined-info-add-comment.component.html',
  styleUrls: ['./predefined-info-add-comment.component.css']
})
export class PredefinedInfoAddCommentComponent implements OnInit {
  
  addCommentCompactForm: FormGroup;
  addCommentFullForm: FormGroup;
  isFormValid:boolean = false;
  validReceiptNumber:boolean = true;
  validFEIN:boolean = true;

  // selectedCommentType: { [commentType: string]: boolean } = {};
  predefWFS: PredefWorkflowService;

  constructor(private predefWorkflowService: PredefWorkflowService, private fb: FormBuilder) { 
    
    this.predefWFS = this.predefWorkflowService;
  }

  ngOnInit() {
    this.setupInputForms();
    this.
      addCommentCompactForm.
      valueChanges.
      subscribe(form => {     
        if(this.predefWFS.predefCompleteList.formTypeManualEdit !== true && this.predefWFS.predefCompleteList.forceEdit !== true) { 
        this.predefWFS.predefCompleteList.setFormType();     
        
        // console.log("inside ngOnInit")   
      }
      //  this.predefWFS.predefCompleteList.addCommentFormValid = true;     
        this.validateFormFields();
      });
      
    this.addCommentFullForm.
    valueChanges.
    subscribe(form => {       
      if(this.predefWFS.predefCompleteList.formTypeManualEdit !== true && this.predefWFS.predefCompleteList.forceEdit !== true)
      // this.predefWFS.predefCompleteList.setFormType();
        this.validateFormFields();
      });

  }

  overrideScoreChanged(){
    let score = this.predefWFS.predefCompleteList.predefinedInformationRequest.overrideScore;
    if (score.trim().toUpperCase() === 'RED') {
      this.predefWFS.predefCompleteList.predefinedInformationRequest.preDefFormCommentType = "I129I140I360I485J";
      // console.log("form modified...");
      this.predefWFS.predefCompleteList.setFormType();
    } 
    else if (score.trim().toUpperCase() === "N/A") {      
      this.predefWFS.predefCompleteList.predefinedInformationRequest.preDefFormCommentType = "";
    }
    this.validateFormFields();
    
  }

   validateFormFields() {
    let office = this.predefWFS.predefCompleteList.predefinedInformationRequest.office;
    let score = this.predefWFS.predefCompleteList.predefinedInformationRequest.overrideScore;
    let fdnsdsNumber = this.predefWFS.predefCompleteList.predefinedInformationRequest.fdnsdsNumber;
    let preDefFormCommentType = this.predefWFS.predefCompleteList.predefinedInformationRequest.preDefFormCommentType;
    let predefinedInformationComment = this.predefWFS.predefCompleteList.predefinedInformationRequest.predefinedInformationComment;
      // console.log("we are at the top, the score is: " +
      //   this.predefWFS.predefCompleteList.predefinedInformationRequest.overrideScore);


    if (office !== undefined &&
      score !== undefined &&
      office !== null &&
      score !== null &&
      office !== "" &&
      score !== "") {

      if (score.trim().toUpperCase() === 'RED') {
        this.handleRed(fdnsdsNumber, preDefFormCommentType,predefinedInformationComment);
      } 
      else if (score.trim().toUpperCase() === "N/A") {
        this.handleNA(predefinedInformationComment);

      }
    }
    else
      this.predefWFS.predefCompleteList.addCommentFormValid = false;
  }




   handleNA(predefinedInformationComment: string) {
    if (predefinedInformationComment !== null &&
      predefinedInformationComment !== undefined &&
      predefinedInformationComment !== "") {
      this.predefWFS.predefCompleteList.addCommentFormValid = true;
    }
    else {
      this.predefWFS.predefCompleteList.addCommentFormValid = false;
    }
  }

   handleRed(fdnsdsNumber: string, preDefFormCommentType: string, predefinedInformationComment: string) {
    if (fdnsdsNumber !== null &&
      fdnsdsNumber !== undefined &&
      fdnsdsNumber !== "" && predefinedInformationComment !== null &&
      predefinedInformationComment !== undefined &&
      predefinedInformationComment !== "") {
      if (preDefFormCommentType !== null &&
        preDefFormCommentType !== undefined &&
        preDefFormCommentType.trim() !== "") {
        this.predefWFS.predefCompleteList.addCommentFormValid = true;
        // console.log("addCommentFormValid is set to true, predefformtype is: " + preDefFormCommentType);
        // console.log("addCommentFormValid is set to true, the fdnsdsNumber is: " + fdnsdsNumber);
      }
      else {
        // console.log("addCommentFormValid is set to false, predefformtype is: " + preDefFormCommentType);
        this.predefWFS.predefCompleteList.addCommentFormValid = false;
      }
    }else {
      // console.log("addCommentFormValid is set to false, fdnsdsNumber is: " + fdnsdsNumber);
      this.predefWFS.predefCompleteList.addCommentFormValid = false;
    }
  }

   setupInputForms() {
    this.addCommentFullForm = this.fb.group({
      textAreaJustification: new FormControl('', Validators.required),
      textAreaVibeComment: new FormControl('', Validators.required)
    });

    this.addCommentCompactForm = this.fb.group({
      
      office: new FormControl('', Validators.required),
      overrideScore: new FormControl('', Validators.required),
      formTypeI129: new FormControl('', Validators.required),
      formTypeI140: new FormControl('', Validators.required),
      formTypeI360: new FormControl('', Validators.required),
      formTypeI485J: new FormControl('', Validators.required),
      fdnsFormattedText: new FormControl('', Validators.required),
      siteVisitProgram: new FormControl('', Validators.required),
      FDNS_DS_NUMBER: new FormControl('', Validators.required),
      receipt_Number: new FormControl(''),
      FEIN: new FormControl(''),
      FDNS_DS_CME_Type: new FormControl('', Validators.required)
    });
  } 

  updateFormTypeInputValues(ctrl) {
    this.predefWFS.predefCompleteList.updateFormTypeInputValues(ctrl);
  }

  setFDNS() {
    this.predefWFS.predefCompleteList.setFDNS();
    this.validateFormFields();
  }

  validateForm():boolean{
   
   return this.isFormValid;
  }


  
  validateReceiptNumber (receipt):boolean{
    let receiptPattern = /^[A-Z]{3}\d{10}$/;
    // console.log("the RN is: " + receipt);
    if(receipt !== undefined && receipt !==null && receipt !== ""){
     this.validReceiptNumber = receiptPattern.test(receipt.toUpperCase()) ;
    //  console.log("validating RN, " + receipt + ", " + this.validReceiptNumber);
    } else{
     this.validReceiptNumber = true ;
 }
     return this.validReceiptNumber;
 }
 
 
 validateFEIN (FEIN:string):boolean{
   if(!FEIN || FEIN.length == 0){
     this.validFEIN = true;
     return this.validFEIN;
   }
   let feinPattern = /^\d{9}$/;
  //  console.log("the FEIN is: " + FEIN);
   if(FEIN !== undefined && FEIN !==null  && FEIN.toUpperCase() !=="N/A" && FEIN !== ""){
    this.validFEIN = feinPattern.test(FEIN.toUpperCase()) ;
    // console.log("validating FEIN, " + FEIN + ", " + this.validFEIN);
   } else if(FEIN !== undefined && FEIN !==null  && FEIN.toUpperCase() =="N/A")
    this.validFEIN = true ; 
    
 
    return this.validFEIN;
 }
 

}
