import { Component, EventEmitter, Output, OnInit, Input, OnDestroy, } from '@angular/core';
import { FormControl, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AppSettings } from '../shared/app-settings';
import { HttpClient } from '@angular/common/http';
import { VSRResubmitAddress } from '../shared/vsr-resubmit';
import { SmartSearchModel } from '../shared/smart-search-model';
import { SmartSearchService } from '../smart-search.service';
import { ComponentStatusService } from '../shared/service/component-status.service';
import { ComponentStatus } from '../shared/service/component-status';
import { Subject } from 'rxjs/Subject';
import { Subscription } from 'rxjs';
import { PredfinedInfoRequestAddress } from '../shared/predefined-Info-request';
import { PredefWorkflowService } from './predef-workflow.service';
import { PredefinedInfoProvider } from '../predefined-info-provider';


@Component({
  selector: 'predefined-info-business-search-form',
  templateUrl: './predefined-info-business-search-form.component.html',
  styleUrls: ['./predefined-info-business-search-form.component.css']
})
export class PredefinedInfoBusinessSearchFormComponent implements OnInit, OnDestroy {

  @Output() address: EventEmitter<VSRResubmitAddress> = new EventEmitter<VSRResubmitAddress>();
  defaultSearchAddress: PredfinedInfoRequestAddress;
  addressInputForm: FormGroup;
  model: SmartSearchModel = new SmartSearchModel;
  opened = false;
  isFormValid: boolean = false;
  formFilledExternally: boolean = true;
  statusMessage: string = "";
  disableState = false;
  countries: CountryStatesProvinces[];
  defaultCountry: string = "United States"
  selectedCountry: CountryStatesProvinces;
  selectedProvince: CountryStatesProvinces;
  statesOrProvinces: CountryStatesProvinces[];
  selectedCurrentAddress: PredfinedInfoRequestAddress;

  cssSubscription: Subscription;
  cssStatusService: ComponentStatusService;
  predefWFS: PredefWorkflowService;
  states: CountryStatesProvinces[];
  provinces: CountryStatesProvinces[];

  constructor(private httpService: HttpClient, private fb: FormBuilder, private predefInfoProvider: PredefinedInfoProvider,
    private predefWorkflowService: PredefWorkflowService) {
    this.predefWFS = this.predefWorkflowService;
    this.countries = predefInfoProvider.getCountries();
    this.states = predefInfoProvider.getStates();
    this.provinces = predefInfoProvider.getProvinces();
    this.statesOrProvinces = this.states;
    console.log(this.countries)
  }
  ngOnInit() {

    this.populateCountries();
    this.populateStates();
    this.initAddressInputForm();


    this.
      addressInputForm.
      valueChanges.
      subscribe(form => {
        sessionStorage.setItem('form', JSON.stringify(form));
        if (this.formFilledExternally !== true && this.predefWorkflowService.predefCompleteList.workFlowStatus !== 'INIT_STARTED') {
          this.predefWorkflowService.predefCompleteList.businessSearchAddress.organizationName = form.org;
          this.predefWorkflowService.predefCompleteList.businessSearchAddress.streetFull = form.street;
          this.predefWorkflowService.predefCompleteList.businessSearchAddress.city = form.city;
          this.predefWorkflowService.predefCompleteList.businessSearchAddress.country = form.country;
          this.predefWorkflowService.predefCompleteList.businessSearchAddress.state = form.state;
          this.predefWorkflowService.predefCompleteList.businessSearchAddress.postalCode = form.zip;

          this.address.emit(this.predefWorkflowService.predefCompleteList.businessSearchAddress);
        }

        if (this.predefWorkflowService.predefCompleteList.workFlowStatus == 'INIT_STARTED') {
          console.log("inside ngOninit calling fillBusinessSearchForm when workFlowStatus == 'INIT_STARTED'")
          this.fillBusinessSearchForm(this.predefWorkflowService.predefCompleteList.businessSearchAddress);
          this.predefWorkflowService.predefCompleteList.workFlowStatus = 'INIT_COMPLETED'
        }

        console.log("this.formFilledExternally", JSON.stringify(this.formFilledExternally));
        if (this.addressInputForm.status == "VALID") {
          this.isFormValid = true;
          this.address.emit(this.predefWorkflowService.predefCompleteList.businessSearchAddress);
          console.log("emmitted from ngOnInit after the form is valid...");
        }
        else {
          // console.log("form may not be valid. " + JSON.stringify(form));
        }

      });
    this.initForm();

  }
  ngOnDestroy() { this.addressInputForm.reset(); }
  initAddressInputFormWithoutDefault() {
    console.log("inside initAddressInputFormWithoutDefault");
    this.addressInputForm = this.fb.group({
      org: ["", Validators.required],
      street: ["", Validators.required],
      city: [""],
      state: new FormControl({ value: '', disabled: false }, Validators.required),
      zip: [""],
      country: ["", Validators.required]
    });
    this.countries = null;
  }
  initAddressInputForm() {
    this.addressInputForm = this.fb.group({
      org: ["", Validators.required],
      street: ["", Validators.required],
      city: [""],
      state: new FormControl({ value: '', disabled: false }, Validators.required),
      zip: [""],
      country: ["UNITED STATES", Validators.required]
    });
    this.addressInputForm.controls["country"].setValue("US")
  }

  public start(selectedAddress: PredfinedInfoRequestAddress) {

    console.log("inside selectedAddress");
    this.selectedCurrentAddress = selectedAddress;
    this.formFilledExternally = true;


    (async () => {

      console.log("inside start async method before calling this.fillBusinessSearchForm");
      this.fillBusinessSearchForm(selectedAddress);
      await this.delay(100);

      this.updateStatesByAddressInput(selectedAddress);
      this.address.emit(this.predefWorkflowService.predefCompleteList.businessSearchAddress);

      this.formFilledExternally = false;

    })();



  }



  async  delay(ms: number) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  fillBusinessSearchForm(address: PredfinedInfoRequestAddress) {

    console.log("inside fillBusinessSearchForm, the address is: " + JSON.stringify(address));
    this.formFilledExternally = true;
    if (address !== undefined && address !== null &&
      address.organizationName !== undefined && address.organizationName !== null && address.organizationName !== "") {
      console.log("address is not null or empty. " + JSON.stringify(address));
      this.predefWorkflowService.predefCompleteList.businessSearchAddress = new PredfinedInfoRequestAddress();
      if (address.organizationName !== undefined && address.organizationName !== null && address.organizationName !== "")
        this.predefWFS.predefCompleteList.businessSearchAddress.organizationName = address.organizationName.replace(',', '');

      this.predefWFS.predefCompleteList.businessSearchAddress.streetFull = address.streetFull.replace(',', '');
      this.predefWFS.predefCompleteList.businessSearchAddress.city = address.city.replace(',', '');
      this.predefWFS.predefCompleteList.businessSearchAddress.postalCode = address.postalCode.replace(',', '');
      let cntry = address.country.replace(',', '');
      this.predefWFS.predefCompleteList.businessSearchAddress.country = cntry == undefined ? "" : cntry;
      if (this.disableState == true && cntry !== undefined && cntry !== "") {
        this.populateStates();
        this.addressInputForm.controls["state"].enable();
        this.disableState = false;
      }

      if (cntry !== undefined && cntry !== null && cntry !== "") {

        console.log("the country is: " + cntry);
        if (cntry.trim().toUpperCase() == "CA" || cntry.trim().toUpperCase() == "CANADA") {

          console.log("populating the provinces: " + cntry);
          this.populateProvinces();
        }

        this.updateSelectedCountry(cntry);


        this.updateStatesByAddressInput(address);
      } else {

        this.updateSelectedCountry("");
        this.updateSelectedState("");
      }

      this.predefWFS.predefCompleteList.businessSearchAddress.postalCode = address.postalCode.replace(',', '');
      this.predefWorkflowService.predefCompleteList.workFlowStatus = "INIT_COMPLETED";

    }
    else {
      this.resetForm();
    }

  }

  private updateStatesByAddressInput(address: PredfinedInfoRequestAddress) {
    let cntry: string = "";
    let states: string = "";
    if (address !== undefined && address.country !== undefined)
      cntry = address.country.replace(',', '');

    if (address !== undefined && address.state !== undefined)
      states = address.state.replace(',', '');

    this.predefWFS.predefCompleteList.businessSearchAddress.state = states == undefined ? "" : states;
    if (cntry.trim().toUpperCase() == "CA" || cntry.trim().toUpperCase() == "CANADA") {
      if (states !== undefined && states !== null && states !== "") {
        if (states.trim().length === 2)
          states = "CA-" + states.trim();
        console.log("canadian province is: " + states + " and the length is: " + states.length);
      }
    }
    this.updateSelectedState(states);
  }

  resetForm() {
    console.log("inside resetForm");
    this.predefWorkflowService.predefCompleteList.businessSearchAddress = new PredfinedInfoRequestAddress();
  }
  updateSelectedState(states: string) {

    console.log("inside updateSelectedState, the state is: " + states);
    let stateIndex: number = 0;

    this.statesOrProvinces.forEach(element => {
      let statematch = element.name.split("-")[0].trim().toUpperCase()
      console.log(element.abbreviation)
      //if (element.name.includes(states.trim()) || element.abbreviation === states.trim()) {
      if (statematch === states.toUpperCase().trim() || element.abbreviation.trim() === states.trim()) {
        console.log("Matched " + JSON.stringify(element) )
        stateIndex = this.statesOrProvinces.indexOf(element);
        stateIndex += 1;
        this.setSelectedStateIndex(document.getElementById("state"), (stateIndex));
        this.addressInputForm.controls["state"].setValue(element.abbreviation);

      }
    });
    if (stateIndex < 1) {
      this.setSelectedStateIndex(document.getElementById("state"), 0);
    }
  }

  updateSelectedCountry(cntry: string) {
    let countryIndex: number = 0;
    if (cntry.toUpperCase() === 'USA' || cntry.toUpperCase() === 'US' || cntry.toUpperCase() === 'U.S.A.'){
      this.addressInputForm.controls["country"].setValue('US');
      return;
    }
    if (cntry.toUpperCase() === "CANADA" || cntry.toUpperCase() === "CA"){
      this.addressInputForm.controls["country"].setValue("CA");
      return;
    }
    this.countries.forEach(element => {
      if (element.name === cntry.trim() || element.abbreviation === cntry.trim()) {
        countryIndex = this.countries.indexOf(element);
        countryIndex++ ;
        this.setSelectedCountryIndex(document.getElementById("country"), (countryIndex));
        this.addressInputForm.controls["country"].setValue(element.abbreviation);

      }
    });

    if (countryIndex < 1) {
      if (cntry.toUpperCase() === 'USA' || cntry.toUpperCase() === 'US' || cntry.toUpperCase() === 'U.S.A.'){
        this.setSelectedCountryIndex(document.getElementById("country"), 0);
        this.addressInputForm.controls["country"].setValue(this.countries[0].abbreviation);
      }
      else {
        console.log("country index is: " + countryIndex);
        this.setSelectedCountryIndex(document.getElementById("country"), countryIndex);
        this.addressInputForm.controls["country"].setValue(this.countries[0].abbreviation);
      }
    }
  }

  setSelectedStateIndex(s, i) {
    try {
      s.options[i].selected = true;
    } catch (error) {
      this.predefWFS.predefCompleteList.businessSearchAddress.streetFull
      return;
    }

    return;

  }



  setSelectedCountryIndex(s, i) {
    try {
      s.options[i].selected = true;
    } catch (error) {
      return;
    }

    return;

  }

  onStateSelect(state: string) {

    console.log("inside onStateSelect the state is: " + state);
    this.predefWorkflowService.predefCompleteList.businessSearchAddress.state = state;
    this.address.emit(this.predefWorkflowService.predefCompleteList.businessSearchAddress);
  }



  populateStates() {
    // const url = AppSettings.US_STATES_JSON;
    // this.httpService.get(url).subscribe(
    //   data => {
        this.statesOrProvinces = this.states as CountryStatesProvinces[];

    //   }
    // );
  }
  validateFormFields() {
    console.log("inside validateFormFields, the address is: " + JSON.stringify(this.predefWorkflowService.predefCompleteList.businessSearchAddress));
    if (this.predefWorkflowService.predefCompleteList.businessSearchAddress !== undefined &&
      this.predefWorkflowService.predefCompleteList.businessSearchAddress !== null) {
      if (this.predefWorkflowService.predefCompleteList.businessSearchAddress.country == undefined ||
        this.predefWorkflowService.predefCompleteList.businessSearchAddress.country == "")
        this.predefWorkflowService.predefCompleteList.businessSearchAddress.country = "UNITED STATES";
    }
    this.address.emit(this.predefWorkflowService.predefCompleteList.businessSearchAddress);
  }
  populateCountries() {
    const url = AppSettings.COUNTRIES_JSON;
    // this.httpService.get(url).subscribe(
    //   data => {
        this.countries = this.countries as CountryStatesProvinces[];

    //   }
    // );
  }


  


  onCountrySelect(countryId: string) {
    console.log(countryId)
    if (countryId.trim().toUpperCase() == "CANADA" || countryId.trim().toUpperCase() == "CA") {
      this.populateProvinces();

      this.predefWorkflowService.predefCompleteList.businessSearchAddress.state = "";
      this.addressInputForm.controls["state"].enable()

    } else if (countryId.trim().toUpperCase() == "UNITED STATES" || countryId.trim().toUpperCase() == "US") {

      this.populateStates();

      this.predefWorkflowService.predefCompleteList.businessSearchAddress.state = "";
      this.addressInputForm.controls["state"].enable()
      if (this.addressInputForm.controls["state"].value !== null && this.addressInputForm.controls["state"].value !== "") {
        this.updateSelectedState(this.addressInputForm.controls["state"].value.trim());
      }
    } else {
      this.statesOrProvinces = [];
      this.addressInputForm.controls["state"].disable();
      this.disableState = true;
    }
    this.predefWorkflowService.predefCompleteList.businessSearchAddress.country = countryId;

    this.predefWorkflowService.predefCompleteList.businessSearchAddress.state = "";
    this.address.emit(this.predefWorkflowService.predefCompleteList.businessSearchAddress);
  }

  initForm() {
    console.log("init form was called.");

    this.addressInputForm = this.fb.group({
      org: ["", Validators.required],
      street: ["", Validators.required],
      city: [""],
      state: new FormControl({ value: '', disabled: false }, Validators.required),
      zip: [""],
      country: ["", Validators.required]
    });
    this.addressInputForm.controls["country"].setValue("US");
  }

  populateProvinces() {
    // const url = AppSettings.PROVINCES_JSON;
    // this.httpService.get(url).subscribe(
    //   data => {
        // if (data) {
          this.statesOrProvinces = this.provinces;
    //     }
    //     else
    //       this.statesOrProvinces = [];
    //   }
    // );
  }

}

export class CountryStatesProvinces {
  name: string;
  abbreviation: string;
}

