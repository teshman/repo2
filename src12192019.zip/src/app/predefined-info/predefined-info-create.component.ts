
import { OnInit, Component, Input, Output, EventEmitter, AfterViewInit, ViewChild, ElementRef, SimpleChanges } from "@angular/core";
import { ClrWizard, ClrWizardPage } from "@clr/angular";
import { PredefinedInformationWorkflowRequest, PredfinedInfoRequestAddress, WorkflowResponse, ValidUntilDateRange } from "../shared/predefined-Info-request";
import { PredefOrgLookupRequest, VsrRecordEntity, VSRResubmitAddress } from "../shared/vsr-resubmit";

import { AppSettings } from "../shared/app-settings";
import { PredefinedInfoBusinessSearchFormComponent } from "./predefined-info-business-search-form.component";
import { VsrManualSearchService } from '../vsr-manual-search.service';
import { PredefWorkflowService } from "./predef-workflow.service";
import { PredefinedInfoWorkflowFacade } from "../shared/predefined-info-workflow-facade";
import { UserInRoleService } from "../user-profile/user-in-role.service";
import { DolManualSearchService } from "../shared/service/dol-manual-search.service";
import { OrganizationLookupResponseProxy, OcrResponse } from "./OrganizationLookupResponse";
import { FormControl, FormBuilder } from "@angular/forms";
import { PredefinedInfoService } from "./predefined-info.service";
import { PredefinedInformationGetDetailResponse } from "../shared/predefined-info-response";
import { DatePipe } from '@angular/common'
import { DateFormatPipe } from "../shared/dateFormat-pipe";
import { ClickThis} from "../shared/directives/click.directive"
import { isUndefined } from "util";
import { throwError } from "rxjs";

@Component({
    selector: 'predefined-info-create',
    templateUrl: './predefined-info-create.component.html',
    styleUrls: ['./predefined-info-create.component.css']
})
export class PredefinedInfoCreateComponent implements OnInit{


    @Input() showFormModal: boolean = false;
    // @Input() predefInfoRequest: PredefinedInformationWorkflowRequest;
    @Output() hideFormModal: EventEmitter<boolean> = new EventEmitter<boolean>();
    @Output() addToPredefinedInfo: EventEmitter<PredefinedInformationWorkflowRequest> = new EventEmitter<PredefinedInformationWorkflowRequest>();



    @ViewChild("wizard", {
        static: true
    }) wizard: ClrWizard;

    @ViewChild(PredefinedInfoBusinessSearchFormComponent, {
        static: true
    }) businessSearch: PredefinedInfoBusinessSearchFormComponent;

    @ViewChild("compSearch", {static: true}) compSearch: ClrWizardPage;
    @ViewChild("iipInformation", {static: true}) iipInformation: ClrWizardPage;
    @ViewChild("addComments", {static: true}) addComments: ClrWizardPage;
    @ViewChild("confirmations", {static: true}) confirmations: ClrWizardPage;
    @ViewChild(ClickThis , {static: false}) clickThis: ClickThis;

    clickAddress() {
        if(this.clickThis){
        this.clickThis.clickThisNow();
        }
    }
    @Input() categoryId: string;

    ngOnChanges(changes: SimpleChanges) {

       if(changes.showFormModal.currentValue == true){
           
      if(this.predefWorkflowService.predefCompleteList.PredefinedInformationGetDetailResponse !== undefined &&
        this.predefWorkflowService.predefCompleteList.PredefinedInformationGetDetailResponse !== undefined && 
        this.predefWorkflowService.predefCompleteList.PredefinedInformationGetDetailResponse.processStatus.toUpperCase() == "P")
      this.setPage();
      console.log("page is set to advance...")
       }

    }

    currentPageId: string = "";
    vsrAddressOption: any;
    predefListDunsAddressSelection: any;
    isFormValid: boolean = false;
    showDunsInput: boolean = false;
    manualSaveClicked: boolean = false;
    searchStringEmpty = false;
    predefOrgLookupRequest: PredefOrgLookupRequest;
    iipAlertMessage: string = "";
    systemAlertMessage: string = "";
    systemAlertInfoMessage: string = "";
    iipFooterMessage: string = "";
    loading: boolean = false;
    OCRStatus: OcrResponse;
    untouched: boolean = true;
    readyToIIPNext: boolean = false;
    readyToIIPCreate: boolean = false;
    createIfLowConfidence: boolean = false;
    rejectDisabled: boolean = false;
    selectedVsrRecord: VsrRecordEntity;
    source: string = "";
    searchBy: string = "";
    addressSearchInprogress: boolean = false;
    IIPAddress: VSRResubmitAddress;
    displayApprovalNA: boolean = false;
    displayApproval: boolean = false;
    isAddCommentFormValid: boolean = false;
    userInRoeleBA: boolean = false;
    canRequestPredefinedInfo:boolean = false;
    searchByAddress: boolean = false;
    disableAllButtons: boolean = false;
    showConfirmationResponse: boolean = false;
    predefWFS: PredefWorkflowService;
    @Output() refreshInfoList = new EventEmitter<boolean>();
    constructor(private vsrManualSearchService: VsrManualSearchService, public datepipe: DateFormatPipe,
        private predefWorkflowService: PredefWorkflowService, private fb: FormBuilder,
        private userInRoleService: UserInRoleService,
        private predefInfoListService: PredefinedInfoService, private dmss: DolManualSearchService) {
        this.predefWFS = this.predefWorkflowService;
    }




    
 setPage(){
    this.wizard.navService.setCurrentPage(this.compSearch);
    if (this.predefWorkflowService.predefCompleteList.PredefinedInformationGetDetailResponse !== undefined &&
        this.predefWorkflowService.predefCompleteList.PredefinedInformationGetDetailResponse !== null) {
        this.IIPAddress = this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.address;
        this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.exceptionID = 
        this.predefWorkflowService.predefCompleteList.PredefinedInformationGetDetailResponse.exceptionId;
        this.readyToIIPNext = true;
    }
    
    this.wizard.forceNext();
    this.processAddCommentStep();
    this.wizard.forceNext();
    this.wizard.forceNext();
     this.wizard.open();
     console.log("Inside setPage, the current page id is: " +  this.wizard.currentPage.id);
   
    }

 


    pageCreate(event: string): void {
        this.clearAlertMesssages;
        this.createIIPinfo();

    }

    pageSaveReject(event: string): void {
        let predefInfo = this.predefWorkflowService.predefCompleteList.predefinedInformationRequest;
        predefInfo.operationCode = event.toLocaleUpperCase();
        let fileName = predefInfo.receiptNumber + ".json";
        try {
            switch (event) {
                case 'save':
                    this.manualSaveClicked = true;
                    this.saveWorkflowRequestOperation();
                    break;
                case 'create':
                    this.createIIPinfo();
                    break;
                case 'reject':
                    this.savePredefinedInfoWorkflowRequest(predefInfo);
                    break;
                case 'request':
                    if (this.userInRoeleBA == true) {
                        this.advanceToApprovalProcess();
                    } else {
                        // this.approvalAcknowledgementMessage = "Predefined Information for " + predefInfo.address.organizationName + " was submitted for approval."
                        // this.showConfirmationResponse = true;

                    }
                    break;
                default:
                    break;
            }
        } catch (error) {
            this.clearAlertMesssages();
            this.systemAlertMessage = AppSettings.PREDEF_REQUEST_SAVE_FAILURE_MESSAGE
            this.manualSaveClicked = false;
            this.predefWorkflowService.predefCompleteList.addCommentFormSaved = false;
        }
    }

    advanceToApprovalProcess() {
        if (this.currentPageId == "confirmation" &&
            this.displayApprovalNA == false && this.displayApproval == false) {
            if (this.predefWorkflowService.predefCompleteList.PredefinedInformationGetDetailResponse ) {
                this.displayApprovalNA = true;
                this.displayApproval = false;
                console.log("Predef info detail response is not null...");
            }
            else {
                this.displayApproval = true;
                this.displayApprovalNA = false;
                console.log("Predef info detail response is null...");
            }
        }
        // console.log("the detail response is: " + JSON.stringify(this.predefWorkflowService.predefCompleteList.PredefinedInformationGetDetailResponse));
        this.wizard.forceNext();
    }

    searchByDunsOrAddress(searchBy: string) {

        if (this.predefOrgLookupRequest !== undefined && this.predefOrgLookupRequest !== null &&
            this.predefOrgLookupRequest.duns !== undefined && this.predefOrgLookupRequest.duns !== null) {

            this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.duns = "";
            console.log("this.predefOrgLookupRequest.duns is: " + this.predefOrgLookupRequest.duns)
            this.predefOrgLookupRequest.duns = "";
        }
        this.predefWorkflowService.predefCompleteList.businessSearchAddress = new PredfinedInfoRequestAddress();
        // this.predefWorkflowService.predefCompleteList.businessSearchAddress.country = "USA" ;
        this.searchStringEmpty = true;
        if (searchBy.toUpperCase() == "DUNS") {
            this.predefWorkflowService.predefCompleteList.searchByAddress = false;
            this.isFormValid = false;
            this.predefWFS.predefCompleteList.predefinedInformationRequest.duns = "";
            this.showDunsInput = true;
        }
        else {
            this.predefWorkflowService.predefCompleteList.searchByAddress = true;
            this.isFormValid = false;
            this.showDunsInput = false;
        }
    }

    savePredefinedInfoToFile(text, filename) {
        var a = document.createElement('a');
        a.setAttribute('href', 'data:text/plain;charset=utf-u,' + encodeURIComponent(text));
        a.setAttribute('download', filename);
        a.click()
    }

    confirmationCompleted($event) {
        this.onCancelFinishClicked($event);
    }

    ngOnInit() {
        this.getOCRStatus();
        this.initSearchParams();
        console.log("this userInRoleBA is: " + this.userInRoeleBA);
        if (this.userInRoleService.userInRole.businessAdministrator ||
            this.userInRoleService.userInRole.vibeTeam ||
            this.userInRoleService.userInRole.cfdoOrRiskAnalyst ) {
            this.canRequestPredefinedInfo = true;
          }


    }

    initSearchParams() {
        if (this.userInRoleService.userInRole && this.userInRoleService.userInRole.businessAdministrator)
            this.userInRoeleBA = true;
        this.searchByAddress = this.predefWorkflowService.predefCompleteList.searchByAddress;
        if (this.searchByAddress !== true &&
            this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.duns !== undefined &&
            this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.duns !== null) {
            this.isFormValid = true;
            this.searchStringEmpty = false;
        }
        console.log("the user role is: " + this.userInRoeleBA);
    }


    getAddress(): VSRResubmitAddress {
        let addr: VSRResubmitAddress = new VSRResubmitAddress();

        let organizationName = this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.address.organizationName;
        let streetFull = this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.address.streetFull;
        let city = this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.address.city;
        let state = this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.address.state;
        let postalCode = this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.address.postalCode;
        let country = this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.address.country;
        let DNBMatchedCompanyAddress = streetFull + city + state + postalCode + country;
        DNBMatchedCompanyAddress = this.removelastCommaCharacter(DNBMatchedCompanyAddress.trim());
        this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.address.singleLineFullAddress = DNBMatchedCompanyAddress;
        // let country = this.predefWorkflowService.predefCompleteList.businessSearchAddress;

        if (organizationName !== undefined && organizationName !== null) addr.organizationName = organizationName.trim();
        if (streetFull !== undefined && streetFull !== null) addr.streetFull = streetFull.trim();
        if (city !== undefined && city !== null) addr.city = city.trim();
        if (state !== undefined && state !== null) addr.state = state.trim();
        if (postalCode !== undefined && postalCode !== null) addr.postalCode = postalCode;
        if (country !== undefined && country !== null) addr.country = country.trim();
        return addr;
    }

    onNextBackClicked(event: string) {
        if (event == "back") this.clearAlertMesssages();
        this.currentPageId = this.wizard.currentPage.id.substring(16);
        console.log("the current page id is: " + this.currentPageId);
        let emptyAddress: VSRResubmitAddress = new VSRResubmitAddress();
        if (this.currentPageId == "iipInfo" && event == "next") {
            try {

                if (this.predefWorkflowService.predefCompleteList.PredefinedInformationGetDetailResponse !== undefined &&
                    this.predefWorkflowService.predefCompleteList.PredefinedInformationGetDetailResponse !== null) {
                    this.IIPAddress = this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.address;
                    this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.exceptionID = 
                    this.predefWorkflowService.predefCompleteList.PredefinedInformationGetDetailResponse.exceptionId;
                    this.readyToIIPNext = true;
                }
                else

                    this.processIIPInfoStep(emptyAddress);
            } catch (error) {
                console.log("error happens while executing processIIPInfoStep" + JSON.stringify(error));
            }
        }
        else if (this.currentPageId == "approval" && event == "next") {
            this.processApprovalStep();
        }
        else if (this.currentPageId == "confirmation" && event == "next") {
            this.clearAlertMesssages();
        }
        else if (this.currentPageId == "addComment" && event == "next") {
            // if(this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.iipConfidenceCode < 7)
            this.processAddCommentStep();
        }

        else if (this.currentPageId == "companySearch" && event == "back") {
            this.readyToIIPCreate = false;
        }

    }

    disableButtons() {
        this.disableAllButtons = true;
        this.predefWorkflowService.predefCompleteList.approvalFormAccepted = true;
    }
    createIIPinfo() {
        this.createIfLowConfidence = true;
        this.getOrgLookupInfo("");
        this.readyToIIPCreate = false;
    }

    processAddCommentStep() {
        this.predefWorkflowService.predefCompleteList.forceEdit = true;
        this.predefWorkflowService.predefCompleteList.setFormType();
        if (this.userInRoleService.userInRole && this.userInRoleService.userInRole.businessAdministrator)
        this.userInRoeleBA = true;

        
          if( this.predefWorkflowService.predefCompleteList.PredefinedInformationGetDetailResponse !== undefined &&
            this.predefWorkflowService.predefCompleteList.PredefinedInformationGetDetailResponse.addressId !== null &&
            this.predefWorkflowService.predefCompleteList.PredefinedInformationGetDetailResponse.addressId !==undefined &&
            this.predefWorkflowService.predefCompleteList.PredefinedInformationGetDetailResponse.addressId !== ""
            ){
               
                this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.addressId = 
                this.predefWorkflowService.predefCompleteList.PredefinedInformationGetDetailResponse.addressId;
            }
       
        if (this.predefWorkflowService.predefCompleteList.PredefinedInformationGetDetailResponse !== undefined &&
            this.predefWorkflowService.predefCompleteList.PredefinedInformationGetDetailResponse !== null) {

            let predef = JSON.parse(JSON.stringify(this.predefWorkflowService.predefCompleteList.PredefinedInformationGetDetailResponse));
            console.log("inside processAddCommentStep");            
                
                // console.log("this.predefWorkflowService.predefCompleteList.PredefinedInformationGetDetailResponse.processStatus " +
                //     JSON.stringify(predef));

                if (predef.processStatus !== undefined &&
                    predef.processStatus !== null &&
                    predef.processStatus.toUpperCase() == "A"){
                    this.rejectDisabled = true;     
                    this.displayApprovalNA = true;
                    this.displayApproval = false;     
                    console.log("inside processAddCommentStep, this.displayApprovalNA: " + this.displayApprovalNA);  
                } else {
                    this.displayApproval = true;
                    this.displayApprovalNA = false; 
                
                    console.log("inside processAddCommentStep, this.displayApprovalNA: " + this.displayApprovalNA);  
                }
       
        } else {
            this.displayApproval = true;
            this.displayApprovalNA = false;
        }

    }

    processApprovalStep() {

        this.clearAlertMesssages();
        this.savePredefinedInfoRequestBeforeApproval();
        let ns:string =  this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.nominationSource;
        if(ns !== undefined && ns !== null)
        ns = ns.toUpperCase();
        console.log("the nomination source is: " + ns);
        this.predefWorkflowService.predefCompleteList.setNominationSource(ns);      
    }


    savePredefinedInfoRequestBeforeApproval(): void {
        let predefRequest = this.predefWorkflowService.predefCompleteList.predefinedInformationRequest;
        if( this.predefWorkflowService.predefCompleteList.PredefinedInformationGetDetailResponse !== undefined &&
            this.predefWorkflowService.predefCompleteList.PredefinedInformationGetDetailResponse.exceptionId !== null &&
            this.predefWorkflowService.predefCompleteList.PredefinedInformationGetDetailResponse.exceptionId !==undefined &&
            this.predefWorkflowService.predefCompleteList.PredefinedInformationGetDetailResponse.exceptionId !== ""
            ){
               
                this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.exceptionID = 
                this.predefWorkflowService.predefCompleteList.PredefinedInformationGetDetailResponse.exceptionId;
            }

            if( this.predefWorkflowService.predefCompleteList.PredefinedInformationGetDetailResponse !== undefined &&
                this.predefWorkflowService.predefCompleteList.PredefinedInformationGetDetailResponse.addressId !== null &&
                this.predefWorkflowService.predefCompleteList.PredefinedInformationGetDetailResponse.addressId !==undefined &&
                this.predefWorkflowService.predefCompleteList.PredefinedInformationGetDetailResponse.addressId !== ""
                ){
                   
                    this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.addressId = 
                    this.predefWorkflowService.predefCompleteList.PredefinedInformationGetDetailResponse.addressId;
                }

        (async () => {
            try {
                this.loading = true;

                predefRequest.operationCode = "REQUEST";
                this.formatValidDates();               

                this.predefWorkflowService.predefCompleteList.exceptionID = "";

                console.log("before savePredefinedInfoWorkflowRequest...")
                this.savePredefinedInfoWorkflowRequest(predefRequest);

                console.log("after savePredefinedInfoWorkflowRequest...")
                await this.delay(1000);
                while (this.predefWorkflowService.predefCompleteList.exceptionID == "") {
                    // this.loading = true;
                    await this.delay(1000);
                    console.log("in a while loop...this.predefWorkflowService.predefCompleteList.exceptionID is: " +
                        this.predefWorkflowService.predefCompleteList.exceptionID);
                    if (this.predefWorkflowService.predefCompleteList.exceptionID !== "") break;
                }

                let exceptionID = this.predefWorkflowService.predefCompleteList.exceptionID
                if (exceptionID !== undefined && exceptionID.toUpperCase() !== "ERROR" && exceptionID !== "") {
                    // this.loading = true;
                    console.log("IMMEDIATELY before updatePredefineReqeestFromDetailAndSaveWorkflow..");
                    predefRequest.exceptionID = exceptionID;
                    this.lookupPredefinedInfoDetailAndUpdateAgnId(exceptionID);

                }



            } catch (error) {
                console.log("error happens inside savePredefInfoAndGetAgnId ");
                this.predefWorkflowService.predefCompleteList.exceptionID = "ERROR" ;
                this.clearAlertMesssages();
                let predefRequest = this.predefWorkflowService.predefCompleteList.predefinedInformationRequest;
                if (this.currentPageId == "confirmation" || this.currentPageId == "approval") {
                    if (predefRequest.operationCode.toUpperCase() == "REQUEST") {
                        this.systemAlertMessage = AppSettings.PREDEF_REQUEST_SUBMIT_FAILURE_MESSAGE;
                    }
                }
                this.loading = false;
            }

        })();


    }


    private formatValidDates() {
        if (this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.validUntilDateRange !== undefined &&
            this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.validUntilDateRange.startDate !== undefined &&
            this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.validUntilDateRange.startDate !== null &&
            this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.validUntilDateRange.endDate !== undefined &&
            this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.validUntilDateRange.endDate !== null) {
            if (this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.validUntilDateRange.endDate.length !== 10 &&
                this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.validUntilDateRange.endDate.length !== 16) {
                this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.validUntilDateRange.startDate =
                    this.datepipe.transformWorkflowDates(this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.validUntilDateRange.startDate, 'yyyy-MM-dd-05:00');
                this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.validUntilDateRange.endDate =
                    this.datepipe.transformWorkflowDates(this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.validUntilDateRange.endDate, 'yyyy-MM-dd-05:00');
            }
        }
    }

    saveWorkflowRequestOperation() {
        let predefInfo = this.predefWorkflowService.predefCompleteList.predefinedInformationRequest;
        predefInfo.operationCode = "SAVE";
        console.log("here is the exceptionID: " + this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.exceptionID);
        if( this.predefWorkflowService.predefCompleteList.PredefinedInformationGetDetailResponse !== undefined &&
            this.predefWorkflowService.predefCompleteList.PredefinedInformationGetDetailResponse.exceptionId !== null &&
            this.predefWorkflowService.predefCompleteList.PredefinedInformationGetDetailResponse.exceptionId !==undefined &&
            this.predefWorkflowService.predefCompleteList.PredefinedInformationGetDetailResponse.exceptionId !== ""
            ){
               
                this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.exceptionID = 
                this.predefWorkflowService.predefCompleteList.PredefinedInformationGetDetailResponse.exceptionId;
            }
            if( this.predefWorkflowService.predefCompleteList.PredefinedInformationGetDetailResponse !== undefined &&
                this.predefWorkflowService.predefCompleteList.PredefinedInformationGetDetailResponse.addressId !== null &&
                this.predefWorkflowService.predefCompleteList.PredefinedInformationGetDetailResponse.addressId !==undefined &&
                this.predefWorkflowService.predefCompleteList.PredefinedInformationGetDetailResponse.addressId !== ""
                ){
                   
                    this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.addressId = 
                    this.predefWorkflowService.predefCompleteList.PredefinedInformationGetDetailResponse.addressId;
                }

        if (this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.validUntilDateRange !== undefined &&
            this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.validUntilDateRange.startDate !== undefined &&
            this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.validUntilDateRange.startDate !== null &&
            this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.validUntilDateRange.endDate !== undefined &&
            this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.validUntilDateRange.endDate !== null) {
            let currentDateValue: string = this.predefWorkflowService.predefCompleteList.
                predefinedInformationRequest.validUntilDateRange.startDate;
            console.log("the current date value is: " + currentDateValue);
            if (currentDateValue.length !== 10 && currentDateValue.length !== 16) {
                this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.validUntilDateRange.startDate =
                    this.datepipe.transformWorkflowDates(this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.validUntilDateRange.startDate, 'yyyy-MM-dd-05:00');
                this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.validUntilDateRange.endDate =
                    this.datepipe.transformWorkflowDates(this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.validUntilDateRange.endDate, 'yyyy-MM-dd-05:00');
                this.savePredefinedInfoWorkflowRequest(predefInfo);
            }
            if (currentDateValue.length == 16) {
                this.savePredefinedInfoWorkflowRequest(predefInfo);
            }
            if (currentDateValue.length == 10) {
                this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.validUntilDateRange.startDate =
                    this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.validUntilDateRange.startDate + "-05:00";

                this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.validUntilDateRange.endDate =
                    this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.validUntilDateRange.endDate + "-05:00";

                this.savePredefinedInfoWorkflowRequest(predefInfo);
            }
        }
        else {
            this.savePredefinedInfoWorkflowRequest(predefInfo);
        }
    }

    processIIPInfoStep(emptyAddress: VSRResubmitAddress) {
        console.log("inside processIIPInfoStep the exception ID is: " + this.predefWorkflowService.predefCompleteList.exceptionID);
        this.IIPAddress = this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.address;
        this.predefOrgLookupRequest = new PredefOrgLookupRequest();
        this.predefOrgLookupRequest.sourceSystemID = "vsr";
        this.predefOrgLookupRequest.sourceTransactionID = AppSettings.SOURCE_TRANSACTION_ID;
        this.predefOrgLookupRequest.duns = "";
        this.predefOrgLookupRequest.endUserID = this.userInRoleService.userInRole.username;
        this.predefOrgLookupRequest.organizationName = this.IIPAddress.organizationName;
        this.addressSearchInprogress = true;
        this.predefOrgLookupRequest.address = new VSRResubmitAddress();
        if (this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.duns !== null &&
            this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.duns !== undefined &&
            this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.duns !== "") {
            this.predefOrgLookupRequest.duns = this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.duns;
            this.predefOrgLookupRequest.organizationName = this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.organizationName;
            this.predefOrgLookupRequest.insertIfLowConfidence = false;
            this.createIfLowConfidence = false;
            this.predefOrgLookupRequest.address = emptyAddress;

            // console.log("the this.predefOrgLookupRequest processing by duns: " + JSON.stringify(this.predefOrgLookupRequest));
            let searchBy: string = "dunsNumber";
            this.getOrgLookupInfo(searchBy);
        }
        else {
            // console.log("this.predefWorkflowService.predefCompleteList.predefinedInformationRequest processing by address: " + JSON.stringify(this.predefWorkflowService.predefCompleteList.predefinedInformationRequest));
            let searchBy: string = "address";
            this.predefOrgLookupRequest.duns = "";
            this.predefOrgLookupRequest.insertIfLowConfidence = false;
            this.createIfLowConfidence = false;
            this.predefOrgLookupRequest.organizationName = this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.address.organizationName.trim();
            this.predefOrgLookupRequest.address = this.getAddress();
            this.predefOrgLookupRequest.organizationName = this.predefOrgLookupRequest.address.organizationName;
            console.log(" this.predefOrgLookupRequest.organizationName: " + this.predefOrgLookupRequest.organizationName);
            // console.log("the  this.predefOrgLookupRequest.address is: " + JSON.stringify(this.predefOrgLookupRequest.address));
            this.getOrgLookupInfo(searchBy);
        }
    }


    getOrgLookupInfoFromFile(searchBy: string) {
        this.clearAlertMesssages();
        this.loading = true;
        this.vsrManualSearchService.getOrganizationInfoFromFile()
            .subscribe(resubmitResponse => {
                this.loading = false;
                this.handleOrganizationLookupInfo(resubmitResponse, searchBy);

            }, error => {
                this.loading = false;
                (async () => {
                    this.clearAlertMesssages();
                    this.iipAlertMessage = "The service for requesting predefined information is not available at this time. Please try again later.";
                })();
            });
    }

    onCancelFinishClicked(event: string) {
        this.predefWorkflowService.predefCompleteList.source = ''
        this.vsrAddressOption = null;
        this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.fdnsdsNumber = "";
        this.predefListDunsAddressSelection = null;
        this.predefWorkflowService.predefCompleteList.addCommentFormValid = false;
        this.readyToIIPCreate = false;
        this.disableAllButtons = false;

        this.predefWorkflowService.predefCompleteList.approvalFormAccepted = false;
        this.clearAlertMesssages();
        this.resetPredefInfoRequest();
        this.resetWizard();
        this.refreshInfoList.emit(true)
    }

    onAcceptSubmitClicked(event: string) {
        let predefRequest = this.predefWorkflowService.predefCompleteList.predefinedInformationRequest;
        this.clearAlertMesssages();
        if (this.predefWorkflowService.predefCompleteList.approvalFormInputValid == false && event.toUpperCase() == "ACCEPT") {
            this.clearAlertMesssages();
            this.systemAlertMessage = "Please check if all required fields are filled, and try again."
        }
        else {

            predefRequest.operationCode = "REQUEST";
            (async () => {
                try {
                    this.loading = true;
                    if (this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.validUntilDateRange !== undefined &&
                        this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.validUntilDateRange.startDate !== undefined &&
                        this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.validUntilDateRange.startDate !== null &&
                        this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.validUntilDateRange.endDate !== undefined &&
                        this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.validUntilDateRange.endDate !== null) {
                        if (this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.validUntilDateRange.endDate.length !== 10 &&
                            this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.validUntilDateRange.endDate.length !== 16) {

                            this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.validUntilDateRange.startDate =
                                this.datepipe.transformWorkflowDates(this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.validUntilDateRange.startDate,
                                    'yyyy-MM-dd-05:00');
                            this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.validUntilDateRange.endDate =
                                this.datepipe.transformWorkflowDates(this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.validUntilDateRange.endDate,
                                    'yyyy-MM-dd-05:00');
                        }
                        console.log("date is validated...");
                    }


                    this.predefWorkflowService.predefCompleteList.exceptionID = "";

                    console.log("before savePredefinedInfoWorkflowRequest...")
                    this.savePredefinedInfoWorkflowRequest(predefRequest);

                    console.log("after savePredefinedInfoWorkflowRequest...")
                    await this.delay(1000);
                    let waitTimeInsec:number = 0;
                    while (this.predefWorkflowService.predefCompleteList.exceptionID == "" && waitTimeInsec < 15) {
                        this.loading = true;
                        await this.delay(1000);
                        console.log("in a while loop...this.predefWorkflowService.predefCompleteList.exceptionID is: " +
                            this.predefWorkflowService.predefCompleteList.exceptionID);
                            this.loading = false;
                        if (this.predefWorkflowService.predefCompleteList.exceptionID !== "" ) break;

                        if(waitTimeInsec > 13){
                            this.loading = false;
                            console.log("breaking...Save Operation Took Long");
                            throw new Error("Save Operation Took Long");
                            break;
                        }
                        waitTimeInsec += 1;

                    }

                    let exceptionID = this.predefWorkflowService.predefCompleteList.exceptionID


                    if (event.toUpperCase() == "ACCEPT" && exceptionID !== undefined && exceptionID.toUpperCase() !== "ERROR" && exceptionID !== "") {
                        this.loading = true;
                        // await this.delay(1000);
                        console.log("IMMEDIATELY before updatePredefineReqeestFromDetailAndSaveWorkflow..");
                        predefRequest.operationCode = event.toUpperCase();
                        predefRequest.exceptionID = exceptionID;
                        this.updatePredefinedReqestFromDetailAndSaveWorkflow(exceptionID);

                    }

                } catch (error) {
                    console.log("error happens inside onAcceptSubmitClicked ");                    
                this.predefWorkflowService.predefCompleteList.exceptionID = "ERROR" ;
                    this.clearAlertMesssages();
                    let predefRequest = this.predefWorkflowService.predefCompleteList.predefinedInformationRequest;
                    if (this.currentPageId == "confirmation" || this.currentPageId == "approval") {                       
                            this.systemAlertMessage = AppSettings.PREDEF_REQUEST_REJECT_FAILURE_MESSAGE;
                    }
                    // this.disableButtons();
                    this.showConfirmationResponse = true;
                    this.loading = false;
                }

            })();
        }




    }



    
    onSubmitClicked(event: string) {
        let predefRequest = this.predefWorkflowService.predefCompleteList.predefinedInformationRequest;
        this.clearAlertMesssages();       

            predefRequest.operationCode = "REQUEST";
            (async () => {
                try {
                    this.loading = true;
                    if (this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.validUntilDateRange !== undefined &&
                        this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.validUntilDateRange.startDate !== undefined &&
                        this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.validUntilDateRange.startDate !== null &&
                        this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.validUntilDateRange.endDate !== undefined &&
                        this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.validUntilDateRange.endDate !== null) {
                        if (this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.validUntilDateRange.endDate.length !== 10 &&
                            this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.validUntilDateRange.endDate.length !== 16) {

                            this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.validUntilDateRange.startDate =
                                this.datepipe.transformWorkflowDates(this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.validUntilDateRange.startDate,
                                    'yyyy-MM-dd-05:00');
                            this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.validUntilDateRange.endDate =
                                this.datepipe.transformWorkflowDates(this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.validUntilDateRange.endDate,
                                    'yyyy-MM-dd-05:00');
                        }
                        console.log("date is validated...");
                    }

                    this.predefWorkflowService.predefCompleteList.exceptionID = "";

                    console.log("before savePredefinedInfoWorkflowRequest...")
                    this.savePredefinedInfoWorkflowRequest(predefRequest);  

                } catch (error) {
                    console.log("error happens inside onSubmitClicked ");                    
                this.predefWorkflowService.predefCompleteList.exceptionID = "ERROR" ;
                    this.clearAlertMesssages();
                    let predefRequest = this.predefWorkflowService.predefCompleteList.predefinedInformationRequest;
                    if (this.currentPageId == "confirmation" || this.currentPageId == "approval") {                       
                            this.systemAlertMessage = AppSettings.PREDEF_REQUEST_REJECT_FAILURE_MESSAGE;
                    }
                    this.showConfirmationResponse = true;
                    this.loading = false;
                }

            })();




    }



    clearAlertMesssages() {
        this.iipAlertMessage = "";
        this.systemAlertMessage = "";
        this.systemAlertInfoMessage = "";
        this.iipFooterMessage = "";
    }
    resetWizard(): void {


        this.currentPageId = "";
        this.isFormValid = false;
        this.iipAlertMessage = "";
        this.loading = false;
        this.readyToIIPNext = false;
        this.source = "";
        this.searchBy = "";
        this.addressSearchInprogress = false;
        this.isAddCommentFormValid = false;
        // this.userInRoeleBA= false;
        this.showConfirmationResponse = false;
        this.wizard.reset();

        this.showFormModal = false;
        this.hideFormModal.emit(true);
    }

    savePredefinedInfoWorkflowRequest(predefRequest: PredefinedInformationWorkflowRequest) {
        this.clearAlertMesssages();
        this.loading = true;
        if (predefRequest.address !== undefined && predefRequest.address !== null && predefRequest.address.organizationName !== "") {
            predefRequest.organizationName = predefRequest.address.organizationName;
        }
        // console.log("the PredefinedInformationRequest before saving: " + JSON.stringify(predefRequest));
        this.vsrManualSearchService.saveWorkFlowRequestInJson(predefRequest)
            .subscribe(savePredefInfoResponse => {
                this.loading = false;
                this.handleSavePredefinedInfoWorkflowResponse(savePredefInfoResponse);


            }, error => {
                if (this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.operationCode == "REQUEST")
                    this.predefWorkflowService.predefCompleteList.exceptionID = "ERROR";
                this.loading = false;
                (async () => {
                    this.clearAlertMesssages();
                    this.systemAlertMessage = "The service for requesting predefined information is not available at this time. Please try again later.";
                })();
            });
    }

    handleSavePredefinedInfoWorkflowResponse(savePredefInfoResponse: WorkflowResponse) {
        let statusMessage: string = savePredefInfoResponse.PredefinedInformationResponse.responseStatusMessage.statusCode;
        if (JSON.stringify(savePredefInfoResponse).includes("ESB2Exception")) {
            this.clearAlertMesssages();
            this.systemAlertMessage = "Error happens..." + JSON.stringify(savePredefInfoResponse);
            this.loading = false;
            this.readyToIIPNext = false;
            this.addressSearchInprogress = false;
            this.iipFooterMessage = "";

            this.handleErrorUnsccessfullOperation(statusMessage);

        }
        else if (savePredefInfoResponse !== undefined) {
            // console.log("the savePredefInfoResponse object contains this: " + JSON.stringify(resubmitResponse));

            this.clearAlertMesssages();
            if (statusMessage == "ESB-VIBE.STATUS.002") {

                let predef = JSON.parse(JSON.stringify(savePredefInfoResponse));
                let predefRequest = this.predefWorkflowService.predefCompleteList.predefinedInformationRequest;


                // console.log("Mission accomplished: " + statusMessage + " the whole response is: " + JSON.stringify(savePredefInfoResponse));

                this.predefWorkflowService.predefCompleteList.exceptionID = predef.PredefinedInformationResponse.exceptionID;
                this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.exceptionID = predef.PredefinedInformationResponse.exceptionID;
                console.log("the exception id inside the handle response method is: " + this.predefWorkflowService.predefCompleteList.exceptionID);
                if ((predefRequest.operationCode.toUpperCase() == "SAVE")) {
                    if (this.manualSaveClicked == true)
                        this.systemAlertInfoMessage = AppSettings.PREDEF_REQUEST_SAVE_MESSAGE.replace("<Company Name >",
                            predefRequest.address.organizationName);
                    this.predefWorkflowService.predefCompleteList.addCommentFormSaved = true;
                }
                if ((predefRequest.operationCode.toUpperCase() == "REJECT"))
                    this.systemAlertInfoMessage = AppSettings.PREDEF_REQUEST_REJECT_MESSAGE.replace("<Company Name >",
                        predefRequest.address.organizationName);
                if (this.currentPageId == "confirmation" || this.currentPageId == "approval") {
                    if ( predefRequest.operationCode.toUpperCase() == "REQUEST" && this.currentPageId == "confirmation") {
                        if(predefRequest.validUntilDateRange !== undefined && predefRequest.validUntilDateRange !== null)
                        predefRequest.validUntilDateRange.endDate = "";
                        this.systemAlertInfoMessage = AppSettings.PREDEF_REQUEST_SUBMIT_MESSAGE.replace("<Company Name >",
                            predefRequest.address.organizationName);
                    }
                    else if (predefRequest.operationCode.toUpperCase() == "ACCEPT" && this.currentPageId == "approval") {
                        this.systemAlertInfoMessage = AppSettings.PREDEF_REQUEST_ACCEPT_MESSAGE.replace("<Company Name >",
                            predefRequest.address.organizationName).replace("<end date>", predefRequest.validUntilDateRange.endDate.substring(0, 10)).
                            replace("<start date>", predefRequest.validUntilDateRange.startDate.substring(0, 10))
                        this.systemAlertInfoMessage = this.systemAlertInfoMessage.replace("-05:00", "");
                        console.log("the acceptance message is: " + this.systemAlertInfoMessage);
                    }
                    if ((predefRequest.operationCode.toUpperCase() == "ACCEPT" ||
                        (predefRequest.operationCode.toUpperCase() == "REJECT")))
                        this.disableButtons();

                    if ((predefRequest.operationCode.toUpperCase() == "REQUEST") && !this.userInRoeleBA)
                        this.disableButtons();
                }
                if (predefRequest)
                    this.addToPredefinedInfo.emit(predefRequest);
            }
            else {
                // this.loading = false;
                this.handleErrorUnsccessfullOperation(statusMessage);

            }
        }
        this.manualSaveClicked = false;
    }

    acceptFormValid: boolean = false;

    private handleErrorUnsccessfullOperation(statusMessage: string) {
        if (this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.operationCode == "REQUEST")
            this.predefWorkflowService.predefCompleteList.exceptionID = "ERROR";
        let predefRequest = this.predefWorkflowService.predefCompleteList.predefinedInformationRequest;
        if ((predefRequest.operationCode.toUpperCase() == "SAVE")) {
            this.clearAlertMesssages();
            this.systemAlertMessage = AppSettings.PREDEF_REQUEST_SAVE_FAILURE_MESSAGE.replace("<Company Name >", predefRequest.address.organizationName);
            this.predefWorkflowService.predefCompleteList.addCommentFormSaved = false;
        }
        console.log("Mission UNSUCCESSFULL: " + statusMessage);
        if (this.currentPageId == "confirmation" || this.currentPageId == "approval") {
            if (this.userInRoeleBA !== true && predefRequest.operationCode.toUpperCase() == "REQUEST" && this.currentPageId == "confirmation") {
                this.clearAlertMesssages();
                this.systemAlertMessage = AppSettings.PREDEF_REQUEST_SUBMIT_FAILURE_MESSAGE;
                this.disableButtons();
            }
            else if (this.userInRoeleBA == true && predefRequest.operationCode.toUpperCase() == "REQUEST" && this.currentPageId == "approval") {
                this.clearAlertMesssages();
                this.systemAlertMessage = AppSettings.PREDEF_REQUEST_ACCEPT_FAILURE_MESSAGE;
                this.disableButtons();
            }
            else if (predefRequest.operationCode.toUpperCase() == "ACCEPT") {
                this.clearAlertMesssages();
                this.systemAlertMessage = AppSettings.PREDEF_REQUEST_ACCEPT_FAILURE_MESSAGE;
                this.disableButtons();
            }
        }
    }

    getOrgLookupInfo(searchBy: string) {
        this.iipAlertMessage = "";
        this.loading = true;
        try {
            this.vsrManualSearchService.getOrganizationInfo(this.predefOrgLookupRequest)
                .subscribe(orgLookupResponse => {
                    this.loading = false;
                    this.handleOrganizationLookupInfo(orgLookupResponse, searchBy);

                }, error => {
                    this.loading = false;
                    (async () => {
                        this.clearAlertMesssages();
                        this.iipAlertMessage = "The service for requesting predefined information is not available at this time. Please try again later.";
                    })();
                });
        } catch (error) {
            this.clearAlertMesssages();
            this.iipAlertMessage = "The service for requesting predefined information is not available at this time. Please try again later.";
        }

    }




    handleOrganizationLookupInfo(orgLookupResponse: OrganizationLookupResponseProxy, searchBy: string) {

        if (JSON.stringify(orgLookupResponse).includes("ESB2Exception")) {
            this.clearAlertMesssages();
            this.systemAlertMessage = AppSettings.SYSTEM_EXCEPTION;
            this.loading = false;
            this.readyToIIPNext = false;
            this.addressSearchInprogress = false;
            this.iipFooterMessage = "";
        }
        else if (orgLookupResponse !== undefined) {
            if (JSON.stringify(orgLookupResponse).includes("ESB-VIBE.STATUS.001")) {
                this.clearAlertMesssages();

                this.iipAlertMessage = AppSettings.VSR_STATUS_CODE_001_DESC;
            } else {

                if (this.createIfLowConfidence == true) {

                    console.log("this.predefOrgLookupRequest.insertIfLowConfidence is: " + this.predefOrgLookupRequest.insertIfLowConfidence);
                    this.updateIIPInfo(orgLookupResponse);
                    this.clearAlertMesssages();
                    this.readyToIIPNext = true;
                    this.readyToIIPCreate = false;
                    this.iipFooterMessage = "";
                }
                else if (
                    orgLookupResponse.ConfidenceFactor !== undefined &&
                    orgLookupResponse.ConfidenceFactor !== null &&
                    parseInt(orgLookupResponse.ConfidenceFactor) > 6) {
                    this.updateIIPInfo(orgLookupResponse);
                    this.addressSearchInprogress = false;
                    this.clearAlertMesssages();
                    this.loading = false;
                    this.readyToIIPNext = true;
                }
                else {
                    this.getOCRStatus();
                    if (this.OCRStatus.OcrGetStatusResponse.isActive) {
                        this.clearAlertMesssages();
                        this.clearAlertMesssages();
                        this.iipAlertMessage = "The service for requesting predefined information is not available at this time.Please try again later.";
                        this.readyToIIPNext = false;
                    }
                    else {
                        this.clearAlertMesssages();
                        this.iipAlertMessage = "IIP could not identify the company searched.";
                        this.readyToIIPNext = false;
                        if (searchBy == 'address') {
                            this.iipFooterMessage = "Click 'CREATE' to create predefined information for this company.";
                            this.readyToIIPCreate = true;
                        }
                    }
                    this.loading = false;
                    this.addressSearchInprogress = false;
                }

            }
        }
    }

    getOCRStatus() {
        this.clearAlertMesssages();
        this.iipAlertMessage = "";
        this.loading = true;
        this.vsrManualSearchService.getOCRStatus()
            .subscribe(status => {
                this.loading = false;
                this.OCRStatus = status;

            }, error => {
                this.loading = false;
                (async () => {
                    this.clearAlertMesssages();
                    this.iipAlertMessage = "The service for requesting ocr information is not available at this time. Please try again later.";
                })();
            });
    }

    lookupPredefinedInfoDetailAndUpdateAgnId(exceptionID: string): void {

        this.predefInfoListService.getPredefInfoDetailByExceptionId(exceptionID).subscribe(

            data => {
                if (data && !JSON.stringify(data).includes("ESB2Exception")) {
                    try {
                        let predefResponse = new PredefinedInformationGetDetailResponse();
                        predefResponse.address = new PredfinedInfoRequestAddress();
                        if (!this.displayApprovalNA == true) {
                            this.predefWorkflowService.predefCompleteList.PredefinedInformationGetDetailResponse = new PredefinedInformationGetDetailResponse();
                            this.predefWorkflowService.predefCompleteList.PredefinedInformationGetDetailResponse = data as PredefinedInformationGetDetailResponse;
                        }
                        predefResponse = data as PredefinedInformationGetDetailResponse;
                        let predef = JSON.parse(JSON.stringify(data));
                        this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.agn = predef.PredefinedInformationGetDetailResponse.agn;

                        console.log("exception id is here.." + exceptionID);
                        // console.log("the predef response is: " + JSON.stringify(predefResponse));
                        if (predef.PredefinedInformationGetDetailResponse.address !== undefined && predef.PredefinedInformationGetDetailResponse.address !== null)
                            this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.addressId = predef.PredefinedInformationGetDetailResponse.address.addressId;
                        console.log("the addressid is not null.");
                        console.log("the addressid is: " + predef.PredefinedInformationGetDetailResponse.address.addressId);
                        console.log("this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.agn is: " +
                            this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.agn);
                        this.loading = false;
                    } catch (error) {
                        this.loading = false;
                        this.clearAlertMesssages();

                        this.systemAlertMessage = AppSettings.SYSTEM_EXCEPTION;
                        console.log("Error inside updatePredefineReqeestFromDetailAndSaveWorkflow..." + JSON.stringify(error));
                    }

                }
                else {
                    this.loading = false;

                    this.clearAlertMesssages();
                    this.systemAlertMessage = AppSettings.SYSTEM_EXCEPTION;
                    // console.log("no good response retieved..." + JSON.stringify(data));
                }
            }, error => {
                this.clearAlertMesssages();
                (async () => {
                    // await this.delay(1000);  //when simulating a long delay or timeout from a service.

                    this.clearAlertMesssages();
                    // console.log("data not retieved. error happens..." + JSON.stringify(error));
                    if (JSON.stringify(error).includes(AppSettings.VSR_EXCEPTION_CODE_0107))
                        this.systemAlertMessage = AppSettings.VSR_EXCEPTION_CODE_0107_DESC;
                    else if (JSON.stringify(error).includes(AppSettings.VSR_EXCEPTION_CODE_0108))
                        this.systemAlertMessage = AppSettings.VSR_EXCEPTION_CODE_0108_DESC;
                    else if (JSON.stringify(error).includes(AppSettings.VSR_EXCEPTION_CODE_0500))
                        this.systemAlertMessage = AppSettings.VSR_EXCEPTION_CODE_0500_DESC;
                    else
                        this.systemAlertMessage = AppSettings.SYSTEM_EXCEPTION;
                    this.loading = false;
                })();
                this.systemAlertMessage = AppSettings.SYSTEM_EXCEPTION;
            }


        );

    }
    updatePredefinedReqestFromDetailAndSaveWorkflow(exceptionID: string): void {

        this.predefInfoListService.getPredefInfoDetailByExceptionId(exceptionID).subscribe(

            data => {
                if (data && !JSON.stringify(data).includes("ESB2Exception")) {
                    try {
                        let predefResponse = new PredefinedInformationGetDetailResponse();
                        predefResponse.address = new PredfinedInfoRequestAddress();
                        if (!this.displayApprovalNA == true) {
                            this.predefWorkflowService.predefCompleteList.PredefinedInformationGetDetailResponse = new PredefinedInformationGetDetailResponse();
                            this.predefWorkflowService.predefCompleteList.PredefinedInformationGetDetailResponse = data as PredefinedInformationGetDetailResponse;
                        }
                        predefResponse = data as PredefinedInformationGetDetailResponse;
                        let predef = JSON.parse(JSON.stringify(data));
                        this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.agn = predef.PredefinedInformationGetDetailResponse.agn;

                        console.log("exception id is here.." + exceptionID);
                        // console.log("the predef response is: " + JSON.stringify(predefResponse));
                        if (predef.PredefinedInformationGetDetailResponse.address !== undefined && predef.PredefinedInformationGetDetailResponse.address !== null)
                            console.log("the addressid is not null.");
                        console.log("the addressid is: " + predef.PredefinedInformationGetDetailResponse.address.addressId);
                        this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.addressId = predef.PredefinedInformationGetDetailResponse.address.addressId;
                        //  predefResponse.address.addressId; 
                        // predef.address.addressId;  
                        console.log("this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.agn is: " +
                            this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.agn);
                        this.savePredefinedInfoWorkflowRequest(this.predefWorkflowService.predefCompleteList.predefinedInformationRequest);
                        // this.loading = false;
                    } catch (error) {
                        this.loading = false;
                        this.clearAlertMesssages();

                        this.systemAlertMessage = AppSettings.SYSTEM_EXCEPTION;
                        console.log("Error inside updatePredefineReqeestFromDetailAndSaveWorkflow..." + JSON.stringify(error));
                    }

                }
                else {
                    this.loading = false;

                    this.clearAlertMesssages();
                    this.systemAlertMessage = AppSettings.SYSTEM_EXCEPTION;
                    // console.log("no good response retieved..." + JSON.stringify(data));
                }
            }, error => {
                this.clearAlertMesssages();
                (async () => {
                    // await this.delay(1000);  //when simulating a long delay or timeout from a service.

                    this.clearAlertMesssages();
                    // console.log("data not retieved. error happens..." + JSON.stringify(error));
                    if (JSON.stringify(error).includes(AppSettings.VSR_EXCEPTION_CODE_0107))
                        this.systemAlertMessage = AppSettings.VSR_EXCEPTION_CODE_0107_DESC;
                    else if (JSON.stringify(error).includes(AppSettings.VSR_EXCEPTION_CODE_0108))
                        this.systemAlertMessage = AppSettings.VSR_EXCEPTION_CODE_0108_DESC;
                    else if (JSON.stringify(error).includes(AppSettings.VSR_EXCEPTION_CODE_0500))
                        this.systemAlertMessage = AppSettings.VSR_EXCEPTION_CODE_0500_DESC;
                    else
                        this.systemAlertMessage = AppSettings.SYSTEM_EXCEPTION;
                    this.loading = false;
                })();
                this.systemAlertMessage = AppSettings.SYSTEM_EXCEPTION;
            }


        );

    }

    validateAddCommentForm() {
        if (this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.office !== undefined &&
            this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.overrideScore !== undefined &&
            this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.preDefFormCommentType !== undefined &&
            this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.fdnsdsNumber !== undefined &&
            this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.siteVisitProgram !== undefined &&
            this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.justificationComment !== undefined &&
            this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.predefinedInformationComment !== undefined &&
            this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.office !== "" &&
            this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.overrideScore !== "" &&
            this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.preDefFormCommentType !== "" &&
            this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.fdnsdsNumber !== "" &&
            this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.siteVisitProgram !== "" &&
            this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.justificationComment !== "" &&
            this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.predefinedInformationComment !== "") {
            this.isAddCommentFormValid = true;
        }
    }

    onKey(event) {
        let dunsPattern = /^\d{9}$/;
        if (event !== undefined && event !== null && (dunsPattern.test(event.target.value)==true)){
            this.searchStringEmpty = false;
            this.isFormValid = true;
        }
        else {
            this.isFormValid = false;
            this.searchStringEmpty = true;
        }
        console.log("the event is: " + event.target.value);
        console.log(dunsPattern.test(event.target.value));
    }

    onPaste(event: ClipboardEvent) {
        let dunsPattern = /^\d{9}$/;
        let clipboardData = event.clipboardData ;
        let pastedText = clipboardData.getData('text');
        if (pastedText !== undefined && pastedText !== null &&  (dunsPattern.test(pastedText)==true)) {
            this.searchStringEmpty = false;
            this.isFormValid = true;
        }
        else {
            this.isFormValid = false;
            this.searchStringEmpty = true;
        }
        console.log("clipboardData " + (dunsPattern.test(pastedText)==true));
      }




    populateMockData() {
        this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.fdnsdsNumber = "Case 1-470140435";
        this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.office = "VSC ADJ";
        this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.preDefFormCommentType = "I129I140I360I485J";
        this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.siteVisitProgram = "ASVVP";
        this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.justificationComment = "Because I want to score the company RED";
        this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.overrideScore = "RED";
        this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.predefinedInformationComment = "This is a predefined comment that needs to be saved.";

    }
    resetPredefInfoRequest() {
        
        let resetPredef: PredefinedInfoWorkflowFacade = new PredefinedInfoWorkflowFacade({ source: "vsr" });
        resetPredef.businessSearchAddress = new PredfinedInfoRequestAddress();
        console.log("the business search address is reset");
        resetPredef.PetitionAddress = new PredfinedInfoRequestAddress();
        resetPredef.ManualSearchAddress = new PredfinedInfoRequestAddress();
        resetPredef.IIPMatchedAddress = new PredfinedInfoRequestAddress();
        resetPredef.predefinedInformationRequest = new PredefinedInformationWorkflowRequest();
        resetPredef.predefinedInformationRequest.address = new PredfinedInfoRequestAddress();
        this.predefWorkflowService.predefCompleteList = resetPredef;
    }
    updateSearchAddressInfo(address: VSRResubmitAddress) {
        // console.log("alert message emmitted...");
        this.validateBusinessSearchForm(address);
        if (this.isFormValid == true && address.organizationName !== undefined && address.organizationName !== null &&
            address.organizationName !== "") {
            this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.address = new PredfinedInfoRequestAddress();
            this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.address.singleLineFullAddress = "";
            this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.address.city = address.city;
            this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.address.country = address.country;
            this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.address.organizationName = address.organizationName;
            this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.address.postalCode = address.postalCode;
            this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.address.state = address.state;
            this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.address.streetFull = address.streetFull;
            let DNBMatchedCompanyAddress = address.streetFull + ", " + address.city + ", " + address.state  + ", " + address.postalCode  + ", " +  address.country;

            this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.address.singleLineFullAddress = DNBMatchedCompanyAddress;
            this.searchStringEmpty = false;
        }
    }

    validateBusinessSearchForm(address: VSRResubmitAddress) {
        let formValid: boolean = false;
        if (address !== undefined && address !== null &&
            address.organizationName !== undefined
            && address.organizationName !== null && address.organizationName.length > 0 &&
            address.streetFull !== undefined && address.streetFull !== null && address.streetFull.length > 0 &&
            address.country !== undefined && address.country !== null && address.country.length > 0) {
            formValid = true;
            // this.searchStringEmpty = false;
            if (address.country.trim().toUpperCase() == "CANADA" ||
                address.country.trim().toUpperCase() == "USA" ||
                address.country.trim().toUpperCase() == "UNITED STATES") {
                if ((address.state == undefined || address.state == null) ||
                    (address.state !== undefined && address.state !== null && address.state.length < 1))
                    formValid = false;
                console.log("formValid is set to be false, the address is: " + (address.country.trim().toUpperCase()));
            }



            console.log("formValid is set to be true, the address is: " + (address.country.trim().toUpperCase()));
        }
        else {
            if (this.predefOrgLookupRequest && this.predefOrgLookupRequest.duns !== undefined && this.predefOrgLookupRequest.duns !== null && this.predefOrgLookupRequest.duns !== "") {
                formValid = true;
                console.log("formValid is set to true, because duns number is not null. " + this.predefOrgLookupRequest.duns);
            }
            else formValid = false;
        }
        this.isFormValid = formValid;
        // console.log("form is valid? " + this.isFormValid + " the form is: " + JSON.stringify(address));
    }
    isOCRRunning(): boolean {
        this.getOCRStatus();
        // console.log("the OCR Status is: " + JSON.stringify(this.OCRStatus));
        return this.OCRStatus.OcrGetStatusResponse.isActive;
    }


 updateIIPInfo(selectedVsrRecord: OrganizationLookupResponseProxy) {
        // console.log("inside updateIIPInfo, selectedVsrRecord is: " + JSON.stringify(selectedVsrRecord));
        this.predefWorkflowService.predefCompleteList.confidenceCode = "";
        let StreetFullText: string = "";
        let LocationCityName: string = "";
        let LocationStateName: string = "";
        let LocationPostalCode: string = "";
        let LocationCountryName: string = "";
        if (this.createIfLowConfidence !== true) {
            StreetFullText = (selectedVsrRecord.Address.StreetFullText == null) ? "" : selectedVsrRecord.Address.StreetFullText + ", ";
            LocationCityName = (selectedVsrRecord.Address.LocationCityName == null) ? "" : selectedVsrRecord.Address.LocationCityName + ", ";
            LocationStateName = (selectedVsrRecord.Address.LocationStateName == null) ? "" : selectedVsrRecord.Address.LocationStateName + ", ";
            LocationPostalCode = (selectedVsrRecord.Address.LocationPostalCode == null) ? "" : selectedVsrRecord.Address.LocationPostalCode + ", ";
            LocationCountryName = (selectedVsrRecord.Address.LocationCountryName == null) ? "" : selectedVsrRecord.Address.LocationCountryName;
            this.processHighConfidenceScoreInfo(selectedVsrRecord);
            let DNBMatchedCompanyAddress = StreetFullText + LocationCityName + LocationStateName + LocationPostalCode + LocationCountryName;
            DNBMatchedCompanyAddress = this.removelastCommaCharacter(DNBMatchedCompanyAddress.trim());
            this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.address.singleLineFullAddress = DNBMatchedCompanyAddress;
        }
        else {
            
            this.processLowConfidenceFactorInfo();
        }

this.mapPredefinedInfoDetailResponse(selectedVsrRecord);
        let score = this.predefWFS.predefCompleteList.predefinedInformationRequest.overrideScore == undefined ? "" :
            this.predefWFS.predefCompleteList.predefinedInformationRequest.overrideScore;
        if (score.trim().toUpperCase() === 'RED') {
            this.predefWFS.predefCompleteList.predefinedInformationRequest.preDefFormCommentType = "I129I140I360I485J";
        }
        else if (score.trim().toUpperCase() === "N/A") {
            this.predefWFS.predefCompleteList.predefinedInformationRequest.preDefFormCommentType = "";
        }

    }


    private mapPredefinedInfoDetailResponse(selectedVsrRecord: OrganizationLookupResponseProxy) {
        if (selectedVsrRecord.PredefinedInformationRecord !== undefined &&
            selectedVsrRecord.PredefinedInformationRecord !== null){
                let predefList: PredefinedInfoWorkflowFacade = this.predefWFS.predefCompleteList;
    
      
                console.log("THE RESPONSE IS: " + JSON.stringify(selectedVsrRecord.PredefinedInformationRecord));
                predefList.PredefinedInformationGetDetailResponse = new PredefinedInformationGetDetailResponse();
               
                predefList.PredefinedInformationGetDetailResponse.fein = selectedVsrRecord.PredefinedInformationRecord.Fein;
                predefList.PredefinedInformationGetDetailResponse.exceptionId = selectedVsrRecord.PredefinedInformationRecord.ExceptionID;
                predefList.PredefinedInformationGetDetailResponse.duns = selectedVsrRecord.PredefinedInformationRecord.DunsNumber;
                predefList.PredefinedInformationGetDetailResponse.addressId = selectedVsrRecord.PredefinedInformationRecord.Address.AddressID;
                predefList.PredefinedInformationGetDetailResponse.receiptNumber = selectedVsrRecord.PredefinedInformationRecord.ReceiptNumber;
                predefList.PredefinedInformationGetDetailResponse.processStatus = selectedVsrRecord.PredefinedInformationRecord.ProcessStatus;
                predefList.PredefinedInformationGetDetailResponse.agn = selectedVsrRecord.PredefinedInformationRecord.AgnID;
                predefList.PredefinedInformationGetDetailResponse.validUntilDateRange = new ValidUntilDateRange();
            
                  if (selectedVsrRecord.PredefinedInformationRecord.ValidStartDate !== undefined &&
                    selectedVsrRecord.PredefinedInformationRecord.ValidStartDate !== null &&
                    selectedVsrRecord.PredefinedInformationRecord.ValidStartDate !== "null") {
                    predefList.PredefinedInformationGetDetailResponse.validUntilDateRange.startDate = selectedVsrRecord.PredefinedInformationRecord.ValidStartDate;
                  }
                  if (selectedVsrRecord.PredefinedInformationRecord.ValidEndDate !== undefined &&
                    selectedVsrRecord.PredefinedInformationRecord.ValidEndDate !== null &&
                    selectedVsrRecord.PredefinedInformationRecord.ValidEndDate !== "null") {
                    predefList.PredefinedInformationGetDetailResponse.validUntilDateRange.endDate = selectedVsrRecord.PredefinedInformationRecord.ValidEndDate;
                  }
               
            
                predefList.PredefinedInformationGetDetailResponse.office = selectedVsrRecord.PredefinedInformationRecord.Office;
                predefList.PredefinedInformationGetDetailResponse.fdnsdsNumber = selectedVsrRecord.PredefinedInformationRecord.FDNSDSNumber;
                predefList.PredefinedInformationGetDetailResponse.predefinedInformationComment = selectedVsrRecord.PredefinedInformationRecord.Comment;
                predefList.PredefinedInformationGetDetailResponse.justificationComment = selectedVsrRecord.PredefinedInformationRecord.Justification;
                predefList.PredefinedInformationGetDetailResponse.siteVisitProgram = selectedVsrRecord.PredefinedInformationRecord.SiteVisitProgram;
                predefList.PredefinedInformationGetDetailResponse.nominationSource = selectedVsrRecord.PredefinedInformationRecord.NominationSource;
                this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.nominationSource = selectedVsrRecord.PredefinedInformationRecord.NominationSource;
                predefList.PredefinedInformationGetDetailResponse.organizationName = selectedVsrRecord.PredefinedInformationRecord.OrganizationName;
                predefList.PredefinedInformationGetDetailResponse.address = new PredfinedInfoRequestAddress();
                predefList.PredefinedInformationGetDetailResponse.address.city = selectedVsrRecord.PredefinedInformationRecord.Address.LocationCityName;
                predefList.PredefinedInformationGetDetailResponse.address.country = selectedVsrRecord.PredefinedInformationRecord.Address.LocationCountryName;
                predefList.PredefinedInformationGetDetailResponse.address.organizationName = selectedVsrRecord.PredefinedInformationRecord.Address.OrganizationName;
                predefList.PredefinedInformationGetDetailResponse.address.postalCode = selectedVsrRecord.PredefinedInformationRecord.Address.LocationPostalCode;
                predefList.PredefinedInformationGetDetailResponse.address.state = selectedVsrRecord.PredefinedInformationRecord.Address.LocationStateName;
                predefList.PredefinedInformationGetDetailResponse.address.streetExtension = selectedVsrRecord.PredefinedInformationRecord.Address.StreetExtensionText;
                predefList.PredefinedInformationGetDetailResponse.address.streetFull = selectedVsrRecord.PredefinedInformationRecord.Address.StreetFullText;
                predefList.PredefinedInformationGetDetailResponse.address.telephoneNumber = selectedVsrRecord.PredefinedInformationRecord.Address.TelephoneNumberFullID;
                predefList.PredefinedInformationGetDetailResponse.preDefCommentType = this.getPredefCommentType(selectedVsrRecord.PredefinedInformationRecord.preDefCommentT);
                predefList.PredefinedInformationGetDetailResponse.preDefFormCommentType = selectedVsrRecord.PredefinedInformationRecord.preDefFormCommentT;
                predefList.PredefinedInformationGetDetailResponse.overrideScore = selectedVsrRecord.PredefinedInformationRecord.OverrideScore;
                this.predefWFS.predefCompleteList.PredefinedInformationGetDetailResponse.address.singleLineFullAddress = this.predefWFS.predefCompleteList.predefinedInformationRequest.address.singleLineFullAddress;
                
                console.log("predefList.PredefinedInformationGetDetailResponse.address.streetFull" + predefList.PredefinedInformationGetDetailResponse.address.streetFull);
            // console.log("what is the exception Id? " + predefList.PredefinedInformationGetDetailResponse.exceptionId);

            }


       
      }

      
  getPredefCommentType(commentType:string):string{
    let commentTypeStr:string = "";
    if(commentType !== undefined && commentType !== null){
    for (let i = 0; i < commentType.length; i++) {
      let ct = commentType.charAt(i);
      switch (ct.toUpperCase()) {
        case "L":
          commentTypeStr = commentTypeStr + " " + "LE13";
          break;
  
        case "H":
          commentTypeStr  = commentTypeStr + " " +  "H2A";
          break;
  
        case "Q":
          commentTypeStr  = commentTypeStr + " " +  "Q";;
          break;
        case "S":
          commentTypeStr  = commentTypeStr + " " +  "SIEVE";
          break;
        case "V":
          commentTypeStr  = commentTypeStr + " " +  "Viability";
          break;
        case "P":
          commentTypeStr  = commentTypeStr + " " +  "Public Law";
          break;
        default:
          commentTypeStr  = commentTypeStr + " " +  "";
          break;
      }
  
    }
  }
  return commentTypeStr;
  }

    private processLowConfidenceFactorInfo() {
        console.log("processing low confidence factor")
        let StreetFullText: string = "";
        let LocationCityName: string = "";
        let LocationStateName: string = "";
        let LocationPostalCode: string = "";
        let LocationCountryName: string = "";

        let busRequestAddress: VSRResubmitAddress = this.predefWorkflowService.predefCompleteList.businessSearchAddress;
        StreetFullText = (busRequestAddress.streetFull == null) ? "" : busRequestAddress.streetFull + ", ";
        LocationCityName = (busRequestAddress.city == null) ? "" : busRequestAddress.city + ", ";
        LocationStateName = (busRequestAddress.state == null) ? "" : busRequestAddress.state + ", ";
        LocationPostalCode = (busRequestAddress.postalCode == null) ? "" : busRequestAddress.postalCode + ", ";
        LocationCountryName = (busRequestAddress.country == null) ? "" : busRequestAddress.country;


        let DNBMatchedCompanyAddress = StreetFullText + LocationCityName + LocationStateName + LocationPostalCode + LocationCountryName;
        DNBMatchedCompanyAddress = this.removelastCommaCharacter(DNBMatchedCompanyAddress.trim());

        this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.address.singleLineFullAddress = DNBMatchedCompanyAddress;
        this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.address.city =
            busRequestAddress.city;
        this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.address.country =
            busRequestAddress.country;
        this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.address.postalCode =
            busRequestAddress.postalCode;
        this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.address.state =
            busRequestAddress.state;
        this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.address.streetFull =
            busRequestAddress.streetFull;
        this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.address.singleLineFullAddress = DNBMatchedCompanyAddress;
        this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.organizationName = busRequestAddress.organizationName;
        this.IIPAddress.organizationName = busRequestAddress.organizationName;

    }

    private processHighConfidenceScoreInfo(selectedVsrRecord: OrganizationLookupResponseProxy) {
        this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.address.city =
            selectedVsrRecord.Address.LocationCityName;
        this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.address.country =
            selectedVsrRecord.Address.LocationCountryName;
        this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.address.postalCode =
            selectedVsrRecord.Address.LocationPostalCode;
        this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.address.state =
            selectedVsrRecord.Address.LocationStateName;
        this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.address.streetFull =
            selectedVsrRecord.Address.StreetFullText;
        this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.duns = selectedVsrRecord.DunsNumber;
        this.predefWorkflowService.predefCompleteList.confidenceCode = selectedVsrRecord.OrganizationInformation.OrganizationDetail.MatchConfidenseCode;
        if (selectedVsrRecord !== undefined && selectedVsrRecord.OrganizationInformation !== undefined &&
            selectedVsrRecord.OrganizationInformation.OrganizationDetail !== undefined &&
            selectedVsrRecord.OrganizationInformation.OrganizationDetail.AGN_ID !== undefined) {
            this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.agn = selectedVsrRecord.OrganizationInformation.OrganizationDetail.AGN_ID;
            this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.organizationName = selectedVsrRecord.OrganizationInformation.OrganizationDetail.OrganizationName;
            this.IIPAddress.organizationName = selectedVsrRecord.OrganizationInformation.OrganizationDetail.OrganizationName;
            if (selectedVsrRecord.PredefinedInformationRecord !== undefined && selectedVsrRecord.PredefinedInformationRecord !== null) {
                this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.exceptionID = selectedVsrRecord.PredefinedInformationRecord.ExceptionID;
                this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.duns = selectedVsrRecord.PredefinedInformationRecord.DunsNumber;
                this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.predefinedInformationComment = selectedVsrRecord.PredefinedInformationRecord.Comment;
                this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.justificationComment = selectedVsrRecord.PredefinedInformationRecord.Justification;
                this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.overrideScore = selectedVsrRecord.PredefinedInformationRecord.OverrideScore;
                this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.validUntilDateRange = new ValidUntilDateRange();
                this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.validUntilDateRange.endDate = selectedVsrRecord.PredefinedInformationRecord.ValidEndDate;
                this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.validUntilDateRange.startDate = selectedVsrRecord.PredefinedInformationRecord.ValidStartDate;
                this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.fdnsdsNumber = selectedVsrRecord.PredefinedInformationRecord.FDNSDSNumber;
                this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.receiptNumber = selectedVsrRecord.PredefinedInformationRecord.ReceiptNumber;
                this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.fein = selectedVsrRecord.PredefinedInformationRecord.Fein;
                this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.office = selectedVsrRecord.PredefinedInformationRecord.Office;
                this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.addressId = selectedVsrRecord.PredefinedInformationRecord.Address.AddressID;
            }

        }
         if (selectedVsrRecord !== undefined && selectedVsrRecord.AgnID !== undefined &&
            selectedVsrRecord.AgnID !== null &&
            selectedVsrRecord.OrganizationName !== undefined &&
            selectedVsrRecord.OrganizationName !== null) {
            this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.agn = selectedVsrRecord.AgnID;
            this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.organizationName = selectedVsrRecord.OrganizationName;
            this.IIPAddress.organizationName = selectedVsrRecord.OrganizationName;
            console.log("selectedVsrRecord.AgnID is : " + selectedVsrRecord.AgnID);
        }
    }

    removelastCommaCharacter(str: string): string {
        if (str !== null && str.length > 0 && str.charAt(str.length - 1) == ',') {
            str = str.substring(0, str.length - 1);
        }
        return str;
    }

    async  delay(ms: number) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    get readyToFinish(): boolean {
        return !this.untouched && !this.loading;
    }

    get readyToIIPnext(): boolean {
        return this.readyToIIPNext;
    }

}
