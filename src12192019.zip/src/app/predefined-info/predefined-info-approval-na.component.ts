import { Component, OnInit, Input } from '@angular/core';
import { PredefWorkflowService } from './predef-workflow.service';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { formatDate } from '@angular/common';
@Component({
  selector: 'predefined-info-approval-na',
  templateUrl: './predefined-info-approval-na.component.html',
  styleUrls: ['./predefined-info-approval-na.component.css']
})
export class PredefinedInfoApprovalNAComponent implements OnInit {
  approvalForm: FormGroup;  
  addCommentFullForm: FormGroup;
  predefWFS:PredefWorkflowService ;
  showValiddReceiptAlert:boolean;


  constructor( private predefWorkflowService:PredefWorkflowService ,  private fb: FormBuilder) {
    this._validStartDate = new Date();
    this.predefWFS = this.predefWorkflowService;
   }

  ngOnInit() {
    this.setupInputForms();
    this.
      approvalForm.
      valueChanges.
      subscribe(form => {          
        if(this.predefWorkflowService.predefCompleteList.formTypeManualEdit !== true)  
       {
          this.predefWorkflowService.predefCompleteList.setFormType();
        // console.log("inside ngOnInit")
        // this.predefWorkflowService.predefCompleteList.setNominationSource();
      }

      });
  }


   setupInputForms() {
    
    this.addCommentFullForm = this.fb.group({
      textAreaJustification: new FormControl(''),
      textAreaVibeComment: new FormControl('')
    });

    this.approvalForm = this.fb.group({
      commentTypeLE13: new FormControl(''),
      commentTypeH2A: new FormControl(''),
      commentTypeQ: new FormControl(''),
      commentTypeSIEVE: new FormControl(''),
      commentTypeVIABILITY: new FormControl(''),
      commentTypePublicLaw: new FormControl(''),
      validStartDate: new FormControl(''),
      validEndDate: new FormControl(''),
      ftI129: new FormControl(''),
      ftI140: new FormControl(''),
      ftI360: new FormControl(''),
      ftI485J: new FormControl(''),
      nsCSC: new FormControl(''),
      nsVSC: new FormControl(''),
      nsTSC: new FormControl(''),
      nsNSC: new FormControl(''),
      nsPSC: new FormControl(''),
      nsAAO: new FormControl(''),
      nsCBP: new FormControl(''),
      nsICE: new FormControl(''),
      nsDOL: new FormControl(''),
      nsDSS: new FormControl(''),
      nsKCC: new FormControl(''),
      nsNBC: new FormControl(''),
      nsSIEVE: new FormControl(''),
      nsFieldFDNS: new FormControl(''),
      nsSCOPSHQ: new FormControl(''),
      receipt_Number: new FormControl(''),
      office: new FormControl('', Validators.required),
      overrideScore: new FormControl('', Validators.required),
      FEIN: new FormControl(''),
      fdnsFormattedText: new FormControl(''),
      siteVisitProgram: new FormControl('', Validators.required),
      FDNS_DS_Number: new FormControl('', Validators.required),
      FDNS_DS_CME_Type: new FormControl('', Validators.required) ,  
      textAreaJustification: new FormControl(''),
      textAreaVibeComment: new FormControl('')
      
    });
  }
  validReceiptNumber:boolean = true;
  validFEIN:boolean = true;
  
   showValiddDateAlert: boolean = false;   
   untilDateAlertMessage =  "Invalid Date Range.  End Date cannot be before Start Date";  
   
  _validStartDate: any;
  public get validStartDate(): string {
    return this._validStartDate;
  }
  public set validStartDate(value: string) {
    this._validStartDate = value;
  }

  _validEndDate: string = "";
  public get validEndDate(): string {
    return "";
  }
  public set validEndDate(value: string) {
    this._validEndDate = value;
  }

  
    startDateInThePast():boolean {    
    let retVal:boolean = false;   
    if(this._validStartDate !== null && this._validStartDate !== undefined && this._validStartDate !== "") {
    var selectedDate = new Date(this._validStartDate);
    var now = new Date();
    now.setDate(now.getDate() - 1);
    
      if (selectedDate < now) {
        retVal = true;
       }
    }
    return retVal;    
  }


   checkValidUntilDates() {
    if(this.startDateInThePast() == true){
      this.untilDateAlertMessage = "Valid Start Date cannot be in the past.";
      this.showValiddDateAlert = true;
    } else{
      this.untilDateAlertMessage = "";
      this.showValiddDateAlert = false;
      if (
        (this._validEndDate == null || this._validEndDate == undefined || this._validEndDate == "")
        && (this._validStartDate == null || this._validStartDate == undefined || this._validStartDate == "")) {
        this.showValiddDateAlert = false;
        this.validateDates();
      }
      else if (
        (this._validEndDate !== null && this._validEndDate !== undefined && this._validEndDate !== "")
        && (this._validStartDate !== null && this._validStartDate !== undefined && this._validStartDate !== "")) {
        this.showValiddDateAlert = false;
        this.validateDates();
      }
    }
    this.validateApprovalFormInput();

  }

   validateDates() {
    try {
      if (this.datesValidated()) {
        this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.setValidUntilDateRange(this._validStartDate, this._validEndDate);
      }
    } catch (error) {
      console.log("error in validDates method " + JSON.stringify(error));
    }

  }
   datesValidated(): boolean {
    let validUntlDates: boolean = false;
    let untilDatesEmpty: boolean = false;
    try {

      if (
        (this._validEndDate == null || this._validEndDate == undefined || this._validEndDate == "")
        && (this._validStartDate == null || this._validStartDate == undefined || this._validStartDate == "")) {
        this.showValiddDateAlert = false;
        untilDatesEmpty = true;
        validUntlDates = true;
      }


      if (untilDatesEmpty == true) {
        // console.log("all dates are empty");
        return true;
      }


      if (!untilDatesEmpty) {
        // console.log("atleast one until dates is not empty.");
        if (this.validateUntilDates()) {
          this.showValiddDateAlert = false;
          validUntlDates = true;
        } else {
          this.showValiddDateAlert = true;
          validUntlDates = false;
          
        }
      }


      if (validUntlDates == true) {
        // console.log("all dates are validated.");
        
        // console.log(" this.showValiddDateAlert = true;." + this.untilDateAlertMessage);
       return true;
      }
      else
       { 
        // console.log("atleast one date is not validated.");;
        return false;
      }

       
    }
    catch (error) {
      // console.log("error happens..." + error);
      return false;
    }
  }
   validateUntilDates() {
    let retVal:boolean = false;
     if (this._validEndDate !== null && this._validEndDate !== undefined && this._validEndDate !== "") {
      //  console.log("this._validEndDate is not empty or not null");
       if (this._validStartDate !== null && this._validStartDate !== undefined && this._validStartDate !== "") {
        //  console.log("this._validStartDate is not empty or not null");
         let validEndDate = new Date(formatDate(this._validEndDate, 'MM/dd/yyyy', 'en-US'));
         if (this._validStartDate !== "" && this._validStartDate !== null) {
           let end = formatDate(this._validEndDate, 'MM/dd/yyyy', 'en-US');
           let start = formatDate(this._validStartDate, 'MM/dd/yyyy', 'en-US');
 
           if (end.length >= 8 && start.length >= 8) {
             let validBeginDate = new Date(formatDate(this._validStartDate, 'MM/dd/yyyy', 'en-US'));
             if (validEndDate.getTime() < validBeginDate.getTime()) {
               this.untilDateAlertMessage = "Invalid Date Range.  End Date cannot be before Start Date";
               this.showValiddDateAlert = true;
               return false;
             }
             else {
               this.showValiddDateAlert = false;
               return true;
             }
           }
         }
       }
       else{
         this.untilDateAlertMessage = "Please fill out both dates.";
         this.showValiddDateAlert = true;
         return false;
       }
 
     } 
     else 
     {
       if (
         (((this._validEndDate == null || this._validEndDate == undefined || this._validEndDate == "") && this._validStartDate !== null && this._validStartDate !== "")
           || (this._validEndDate !== null && this._validEndDate !== "" && (this._validStartDate == null || this._validStartDate == ""))
         )
       ) { 
           this.untilDateAlertMessage = "Please fill out both dates.";
           this.showValiddDateAlert = true;                
          return false;
         
       }
     }
     return retVal;
   } 

    


   overrideScoreChanged(){
    let score = this.predefWFS.predefCompleteList.predefinedInformationRequest.overrideScore;
    if (score !== undefined && score!== null && score.trim().toUpperCase() === 'RED') {
      
      console.log("inside overrideScoreChanged")
      this.predefWFS.predefCompleteList.predefinedInformationRequest.preDefFormCommentType = "I129I140I360I485J";
      this.predefWFS.predefCompleteList.setFormType();
    } 
    else if (score !== undefined && score!== null && score.trim().toUpperCase() === "N/A") {      
      this.predefWFS.predefCompleteList.predefinedInformationRequest.preDefFormCommentType = "";
    }
    this.validateApprovalFormInput();
  }

  validateReceiptNumber (receipt):boolean{
   let receiptPattern = /^[A-Z]{3}\d{10}$/;
   console.log("the RN is: " + receipt);
   if(receipt !== undefined && receipt !==null && receipt !== ""){
    this.validReceiptNumber = receiptPattern.test(receipt.toUpperCase()) ;
    console.log("validating RN, " + receipt + ", " + this.validReceiptNumber);
   } else{
    this.validReceiptNumber = true ;
}
    return this.validReceiptNumber;
}


validateFEIN (FEIN:string):boolean{
  if(!FEIN || FEIN.length == 0){
    this.validFEIN = true;
    return this.validFEIN;
  }
  let feinPattern = /^\d{9}$/;
                // = /^\d{9}$/;
  console.log("the FEIN is: " + FEIN);
  if(FEIN !== undefined && FEIN !==null  && FEIN.toUpperCase() !=="N/A" && FEIN !== ""){
   this.validFEIN = feinPattern.test(FEIN.toUpperCase()) ;
   console.log("validating FEIN, " + FEIN + ", " + this.validFEIN);
  } else if(FEIN !== undefined && FEIN !==null  && FEIN.toUpperCase() =="N/A")
   this.validFEIN = true ; 

   return this.validFEIN;
}

  validateApprovalFormInput() {
    try {
      console.log(" inside validateApprovalFormInput top ");
      let predefRequest = this.predefWorkflowService.predefCompleteList.predefinedInformationRequest;
      let score = this.predefWFS.predefCompleteList.predefinedInformationRequest.overrideScore;
      let fdnsdsNumber = this.predefWFS.predefCompleteList.predefinedInformationRequest.fdnsdsNumber;
      let ns = this.predefWFS.predefCompleteList.predefinedInformationRequest.nominationSource;
      if (
        predefRequest.organizationName !== undefined && predefRequest.organizationName !== null && predefRequest.organizationName !== "" &&
       (( predefRequest.agn !== undefined && predefRequest.agn !== null && predefRequest.agn !== "") ||
       ( predefRequest.duns !== undefined && predefRequest.duns !== null && predefRequest.duns !== "")) &&
        (this._validEndDate !== null && this._validEndDate !== undefined && this._validEndDate !== "")
        && (this._validStartDate !== null && this._validStartDate !== undefined && this._validStartDate !== "") &&
        predefRequest.overrideScore !== undefined && predefRequest.overrideScore !== null && predefRequest.overrideScore !== "" &&
        predefRequest.predefinedInformationComment !== undefined && predefRequest.predefinedInformationComment !== null && predefRequest.predefinedInformationComment !== "" &&
        predefRequest.office !== undefined && predefRequest.office !== null && predefRequest.office !== "" )  {
          if (predefRequest.overrideScore !== undefined && predefRequest.overrideScore !== null && predefRequest.overrideScore.toUpperCase() === "RED") {
  
            if (ns == undefined || ns == null || ns == "")
              this.predefWorkflowService.predefCompleteList.approvalFormInputValid = false;
            else
              this.validateFormFields();
          }
          else
            this.validateFormFields();
        }
      else {
        this.predefWorkflowService.predefCompleteList.approvalFormInputValid = false;
      }
    } catch (error) {
      console.log("error happens ...");
    }

  }


  validateFormFields() {
    console.log("inside validateFormFields: ");
    let office = this.predefWFS.predefCompleteList.predefinedInformationRequest.office;
    let score = this.predefWFS.predefCompleteList.predefinedInformationRequest.overrideScore;
    let receiptNumber = this.predefWFS.predefCompleteList.predefinedInformationRequest.receiptNumber;
    let FEIN = this.predefWFS.predefCompleteList.predefinedInformationRequest.fein;
    let fdnsdsNumber = this.predefWFS.predefCompleteList.predefinedInformationRequest.fdnsdsNumber;
    let preDefFormCommentType = this.predefWFS.predefCompleteList.predefinedInformationRequest.preDefFormCommentType;
    let predefinedInformationComment = this.predefWFS.predefCompleteList.predefinedInformationRequest.predefinedInformationComment;


    if (office !== undefined &&
      score !== undefined &&
      office !== null &&
      score !== null &&
      office !== "" &&
      score !== "") {

      if (score.trim().toUpperCase() === 'RED') {
        this.handleRed(fdnsdsNumber, preDefFormCommentType);
      }
      else if (score.trim().toUpperCase() === "N/A") {
        this.handleNA(predefinedInformationComment);

      }
      if (this.validateReceiptNumber(receiptNumber) !== true ||
      this.validateFEIN(FEIN) !== true) {
        this.predefWorkflowService.predefCompleteList.approvalFormInputValid = false;
      }
    }
    else
      this.predefWorkflowService.predefCompleteList.approvalFormInputValid = false;
  }

  handleNA(predefinedInformationComment: string) {
    if (predefinedInformationComment !== null &&
      predefinedInformationComment !== undefined &&
      predefinedInformationComment !== "" &&
      this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.preDefCommentType !== null &&
      this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.preDefCommentType !== undefined &&
      this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.preDefCommentType !== "") {
      this.predefWorkflowService.predefCompleteList.approvalFormInputValid = true;
    }
    else {
      this.predefWorkflowService.predefCompleteList.approvalFormInputValid = false;
    }
  }

   handleRed(fdnsdsNumber: string, preDefFormCommentType: string) {
    if (fdnsdsNumber !== null &&
      fdnsdsNumber !== undefined &&
      fdnsdsNumber !== "") {
      if (preDefFormCommentType !== null &&
        preDefFormCommentType !== undefined &&
        preDefFormCommentType.trim() !== "") {
          this.predefWorkflowService.predefCompleteList.approvalFormInputValid = true;
        console.log("approvalFormInputValid is set to true, predefformtype is: " + preDefFormCommentType);
        console.log("approvalFormInputValid is set to true, the fdnsdsNumber is: " + fdnsdsNumber);
      }
      else {
        console.log("approvalFormInputValid is set to false, predefformtype is: " + preDefFormCommentType);
        this.predefWorkflowService.predefCompleteList.approvalFormInputValid = false;
      }
    }else {
      console.log("approvalFormInputValid is set to false, fdnsdsNumber is: " + fdnsdsNumber);
      this.predefWorkflowService.predefCompleteList.approvalFormInputValid = false;
    }
  }

  
  updateFormTypeInputValues(ctrl) {
    this.predefWorkflowService.predefCompleteList.updateFormTypeInputValues(ctrl);
    this.validateApprovalFormInput();
  }
   updateCommentTypeInputValues(ctrl){
     this.predefWorkflowService.predefCompleteList.updateCommentTypeInputValues(ctrl); 
     this.validateApprovalFormInput();  
  }  
   setNominationSourceInputValues(ctrl) {
    this.predefWorkflowService.predefCompleteList.setNominationSourceInputValues(ctrl);
    this.validateApprovalFormInput();
  }
  
  setFDNS() {
    this.predefWorkflowService.predefCompleteList.setFDNS();
  }
}
