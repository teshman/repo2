import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PredefinedInfoConfirmationComponent } from './predefined-info-confirmation.component';

describe('PredefinedInfoConfirmationComponent', () => {
  let component: PredefinedInfoConfirmationComponent;
  let fixture: ComponentFixture<PredefinedInfoConfirmationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PredefinedInfoConfirmationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PredefinedInfoConfirmationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
