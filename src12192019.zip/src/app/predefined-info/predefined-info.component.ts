import { Component, OnInit, ViewChild, NgModule, OnDestroy } from "@angular/core";
import {
  FormGroup, FormControl
} from "@angular/forms";
import { CISUserService } from "./cis-user.service";
import { FrequentUserEntityProxy } from "../shared/frequent-user-proxy";
import { FrequentUser, FrequentUserRecordEntity } from "../shared/frequent-user";
import { PredefinedInfoService } from "./predefined-info.service";
import { PredefinedInformation, PredefinedInformationRecordEntity } from "../shared/predefined-Information";
import { dateFilter } from "../previous-filings-imq/date-filter/date-filter.component";
import { formatDate } from "@angular/common";
import { AppSettings } from "../shared/app-settings";
import { UserInRoleService } from "../user-profile/user-in-role.service";
import { ExcelService } from "../excel.service";
import { MatInput } from "@angular/material";
import { PredefWorkflowService } from "./predef-workflow.service";
import { PredefinedInfoWorkflowFacade } from "../shared/predefined-info-workflow-facade";
import { PredefinedInformationWorkflowRequest, PredfinedInfoRequestAddress, ValidUntilDateRange } from "../shared/predefined-Info-request";
import { PredefinedInformationGetDetailResponse } from "../shared/predefined-info-response";
import { PredefinedInfoCreateComponent } from "./predefined-info-create.component";
import { PredefinedInfoProvider } from "../predefined-info-provider";
import { CountryStatesProvinces } from "../manual-resubmit/manual-search-modal.component";
import { Subscription } from "rxjs";
import { ComponentStatusService } from "../shared/service/component-status.service";
import { ClrDatagridPagination } from "@clr/angular";

@Component({
  selector: 'app-predefined-information-list',
  templateUrl: './predefined-info.component.html',
  styleUrls: ['./predefined-info.component.css']
})


export class PredefinedInfoComponent implements OnInit {

  @ViewChild(PredefinedInfoCreateComponent, {
    static: true
  }) predefCreate: PredefinedInfoCreateComponent;



  preDefinedForm: FormGroup;

  p: number = 1;
  recordsPerPage: number = 20;
  PAGINATION_COUNT: number = 20;
  showListView: boolean = false;
  loading: boolean = true;
  appsAlert: string = "";
  predefLoading: boolean = false;
  predefResponse: PredefinedInformationGetDetailResponse;
  showPredefExpireForm: boolean = false;
  onPageChange(e) {
    if (e)
      this.p = e;
  }
  showValiddDateAlert: boolean = false;
  showAddedDateAlert: boolean = false;
  predefAlertMessage: string = "";
  showPredefAlertMessage: boolean = false;
  canRequestPredefinedInfo: boolean = false;
  canEditPredefinedInfo: boolean = false;
  canExpirePredefinedInfo: boolean = false;

  showPredefRequestWizard: boolean = false;
  showPredefViewDetailForm: boolean = false;
  predefinedInfoRecord: PredefinedInformationRecordEntity;

  _addedBy: string = "All";
  public get addedBy(): string {
    return this._addedBy;
  }
  public set addedBy(value: string) {
    this._addedBy = value;
    this.getfilteredPredefInfoListRecords();
  }
  _agnID: string = "";
  public get agnID(): string {
    return this._agnID;
  }
  public set agnID(value: string) {
    this._agnID = value;
    this.getfilteredPredefInfoListRecords();
  }

  _validStartDate: string = "";
  // validStartDate: any = "";
  public get validStartDate(): string {
    // return this._validStartDate;
    return "";
  }
  public set validStartDate(value: string) {
    this._validStartDate = value;
    // this.getfilteredPredefInfoListRecords();
  }

  onHidePredefFormModal($event) {
    this.showPredefRequestWizard = false;
  }




  _validEndDate: string = "";
  // validEndDate: string = "";
  public get validEndDate(): string {
    // return this._validEndDate;
    return "";
  }
  public set validEndDate(value: string) {
    this._validEndDate = value;
    // this.getfilteredPredefInfoListRecords();
  }


  _dateAddedStart: string = "";
  public get dateAddedStart(): string {
    return "";
  }
  public set dateAddedStart(value: string) {
    this._dateAddedStart = value;
    // this.getfilteredPredefInfoListRecords();
  }
  _dateAddedEnd: string = "";
  public get dateAddedEnd(): string {
    return "";
  }
  public set dateAddedEnd(value: string) {
    this._dateAddedEnd = value;
    // this.getfilteredPredefInfoListRecords();
  }
  _dunsNumber: string = "";
  get dunsNumber(): string {
    return this._dunsNumber;
  }
  set dunsNumber(value: string) {
    this._dunsNumber = value;
    this.getfilteredPredefInfoListRecords();
  }
  _overrideScore: string = "All";
  public get overrideScore(): string {
    return this._overrideScore;
  }
  public set overrideScore(value: string) {
    this._overrideScore = value;
    this.getfilteredPredefInfoListRecords();
  }

  private _office: string = "All";
  public get office(): string {
    return this._office;
  }
  public set office(value: string) {
    this._office = value;
    this.getfilteredPredefInfoListRecords();
  }

  _organizationName: string = "";
  public get organizationName(): string {
    return this._organizationName;
  }
  public set organizationName(value: string) {
    this._organizationName = value;
    this.getfilteredPredefInfoListRecords();
  }
  _preDefCommentT: string = "All";
  public get preDefCommentT(): string {
    return this._preDefCommentT;
  }
  public set preDefCommentT(value: string) {
    this._preDefCommentT = value;
    this.getfilteredPredefInfoListRecords();
  }
  _preDefFormCommentT: string = "All";
  public get preDefFormCommentT(): string {
    return this._preDefFormCommentT;
  }
  public set preDefFormCommentT(value: string) {
    this._preDefFormCommentT = value;
    this.getfilteredPredefInfoListRecords();
  }
  _processStatus: string = "All";
  public get processStatus(): string {
    return this._processStatus;
  }
  public set processStatus(value: string) {
    this._processStatus = value;
    this.getfilteredPredefInfoListRecords();
  }
  _idType: string = "All";
  public get idType(): string {
    return this._idType;
  }
  public set idType(value: string) {
    this._idType = value;
    this.getfilteredPredefInfoListRecords();
  }

  frequentUser: FrequentUser;
  frequentUserRecord: FrequentUserRecordEntity[] = [];
  filteredFrequentUsers: FrequentUserRecordEntity[] = [];


  predefInfoList: PredefinedInformation;
  predefInfoListRecord: PredefinedInformationRecordEntity[] = [];
  filteredPredefInfoListRecords: PredefinedInformationRecordEntity[] = [];
  displayCommentType:boolean = true;
  untilDateAlertMessage = "Invalid Date Range.  End Date cannot be before Start Date";
  addDateAlertMessage = "Invalid Date Range.  End Date cannot be before Start Date";
  exportOptions: string = "";
  countries: CountryStatesProvinces[];

  predefWFS: PredefWorkflowService
  cssSubscription: Subscription;
  cssStatusService: ComponentStatusService;
  showpage: boolean = false;
  constructor(
    private excelService: ExcelService,
    private predefWorkflowService: PredefWorkflowService,
    private cisUserSearchService: CISUserService,
    private predefInfoListService: PredefinedInfoService,
    private userInRoleService: UserInRoleService, private predefInfoProvider: PredefinedInfoProvider, private css: ComponentStatusService) {
    this.predefWFS = this.predefWorkflowService;
    this.cssStatusService = this.css
    this.countries = this.predefInfoProvider.getCountries()
    this.predefInfoProvider.refreshPredefInfo();
    this.predefInfoList = this.predefInfoProvider.getPredefInfo();

    console.log(this.predefInfoList)

  }

  @ViewChild('validStartDateInput', {
    read: MatInput,
    static: false
  }) validStartDateInput: MatInput;


  @ViewChild('validEndDateInput', {
    read: MatInput,
    static: false
  }) validEndDateInput: MatInput;


  @ViewChild('.OrganizationNameInput', {
    read: MatInput,
    static: false
  }) OrganizationNameInput: MatInput;

  @ViewChild('addStartDateInput', {
    read: MatInput,
    static: false
  }) addStartDateInput: MatInput;
  @ViewChild('addEndDateInput', {
    read: MatInput,
    static: false
  }) addEndDateInput: MatInput;


  clearAll() {
    this.validStartDateInput.value = "";
    if (this.validEndDateInput !== undefined)
      this.validEndDateInput.value = "";
    this.addStartDateInput.value = "";
    this.addEndDateInput.value = "";
    this._validEndDate = "";
    this._validStartDate = "";
    this.dateAddedEnd = "";
    this.dateAddedStart = "";
    this._agnID = "";
    this._addedBy = "All";
    this._dunsNumber = "";
    this._idType = "All";
    this._organizationName = "";
    this._overrideScore = "All";
    this._preDefCommentT = "All";
    this._preDefFormCommentT = "All";
    this.processStatus = "All";
    this.showAddedDateAlert = false;
    this.showValiddDateAlert = false;

  }
  getStatus(value: string): string {
    let status: string = "";
    switch (value) {
      case "U":
        status = "Unsubmitted";
        break;

      case "A":
        status = "Accepted";
        break;

      case "R":
        status = "Rejected";;
        break;
      case "P":
        status = "Pending";
        break;
      case "E":
        status = "Expired";
        break;
      case "F":
        status = "Future";
        break;
      default:
        status = value;
        break;
    }
    return status;
  }

  overrideScoreChanged() {
    let score = this.overrideScore;
    if (score !== undefined && score !== null && score.trim().toUpperCase() === 'RED'){
      this.preDefCommentT = 'All';
      this.displayCommentType = false;
    }
    else this.displayCommentType = true;

  }

  getfilteredPredefInfoListRecords() {
    try {
      if (this.datesValidated()) {
        this.filteredPredefInfoListRecords = this.predefInfoListRecord;
        this.filterInfoList('AddedBy', this.addedBy);
        this.filterInfoList('AgnID', this.agnID);
        this.filterInfoList('DateAdded', this._dateAddedStart);
        this.filterInfoList('DateAdded', this._dateAddedEnd);
        this.filterInfoList('ValidStartDate', this._validStartDate);
        this.filterInfoList('ValidEndDate', this._validEndDate);
        this.filterInfoList('DunsNumber', this.dunsNumber);
        this.filterInfoList('OverrideScore', this.overrideScore);
        this.filterInfoList('preDefCommentT', this.preDefCommentT);
        this.filterInfoList('preDefFormCommentT', this.preDefFormCommentT);
        this.filterInfoList('idType', this.idType);
        this.filterInfoList('ProcessStatus', this.processStatus);
        this.filterInfoList('OrganizationName', this.organizationName);
        this.filterInfoList('Office', this.office);
      }
    } catch (error) {

    }

  }

  onAddToPredefinedInfo(predef) {
    // let pr:PredefinedInformationRecordEntity[] = [];
    // pr[0].AddedBy = predef.endUserID;
    //  pr[0].DunsNumber = predef.duns;
    //  pr[0].OrganizationName = predef.organizationName;
    //  pr[0].ProcessStatus = predef.operationCode;
    //  pr[0].OverrideScore = predef.overrideScore;
    //  pr[0].ValidStartDate = predef.validUntilDateRange.startDate;
    //  pr[0].ValidEndDate = predef.validUntilDateRange.endDate;
    //  pr[0].ExceptionID = predef.exceptionID;
    //  pr[0].AgnID = predef.agn;
    //  pr[0].Comment = predef.predefinedInformationComment;
    //  pr[0].preDefFormCommentT = predef.preDefFormCommentType;
    // let matchFound: boolean = false;
    // if (this.predefInfoListRecord && this.predefInfoListRecord !== undefined && this.predefInfoListRecord !== null) {
    //   for (let item of this.predefInfoListRecord) {
    //     if(item.ExceptionID == predef.exceptionID) matchFound = true;
    //   }
    // }
    // if(!matchFound) 
    // this.predefInfoListRecord.push(pr[0]);

  }


  exportReport() {
    let pr: PredefinedInfoReport;
    let predefinedInfoReports: PredefinedInfoReport[] = [];
    if (this.filteredPredefInfoListRecords && this.filteredPredefInfoListRecords !== undefined && this.filteredPredefInfoListRecords !== null) {
      for (let predef of this.filteredPredefInfoListRecords) {
        pr = new PredefinedInfoReport();
        pr.DunsNumber = predef.DunsNumber;
        pr.OrganizationName = predef.OrganizationName;
        pr.ProcessStatus = predef.ProcessStatus;
        pr.OverrideScore = predef.OverrideScore;
        pr.ValidStartDate = predef.ValidStartDate;
        pr.ValidEndDate = predef.ValidEndDate;
        pr.AddedBy = predef.AddedBy;
        pr.AgnID = predef.AgnID;
        predefinedInfoReports.push(pr);
      }

      if (this.exportOptions == "CSV") {
        this.excelService.exportAsCSVFile(predefinedInfoReports, "preDefineReports")
      }
      else this.excelService.exportAsExcelFile(predefinedInfoReports, 'preDefineReports');

    }

  }
  checkValidUntilDatesAndGetfilteredPredefInfoListRecords() {
    if (
      (this._validEndDate == null || this._validEndDate == undefined || this._validEndDate == "")
      && (this._validStartDate == null || this._validStartDate == undefined || this._validStartDate == "")) {
      this.showValiddDateAlert = false;
      this.getfilteredPredefInfoListRecords();
      console.log("both valid until dates are empty");
    }
    else if (
      (this._validEndDate !== null && this._validEndDate !== undefined && this._validEndDate !== "")
      && (this._validStartDate !== null && this._validStartDate !== undefined && this._validStartDate !== "")) {
      this.showValiddDateAlert = false;
      console.log("both valid until dates are not empty");
      this.getfilteredPredefInfoListRecords();
    }

  }


  checkAddDatesAndGetfilteredPredefInfoListRecords() {
    if ((this._dateAddedEnd == null || this._dateAddedEnd == undefined || this._dateAddedEnd == "")
      && (this._dateAddedStart == null || this._dateAddedStart == undefined || this._dateAddedStart == "")) {
      this.showAddedDateAlert = false;
      console.log("both added dates are empty");
      this.getfilteredPredefInfoListRecords();
    }
    else if ((this._dateAddedEnd !== null && this._dateAddedEnd !== undefined && this._dateAddedEnd !== "")
      && (this._dateAddedStart !== null && this._dateAddedStart !== undefined && this._dateAddedStart !== "")) {
      this.showAddedDateAlert = false;
      console.log("both added dates are not empty");
      this.getfilteredPredefInfoListRecords();
    }

  }

  datesValidated(): boolean {
    let validUntlDates: boolean = false;
    let validAddedDates: boolean = false;
    let untilDatesEmpty: boolean = false;
    let addedDatesEmpty: boolean = false;
    try {
      // console.log("starts validating dates.");



      if (
        (this._validEndDate == null || this._validEndDate == undefined || this._validEndDate == "")
        && (this._validStartDate == null || this._validStartDate == undefined || this._validStartDate == "")) {
        this.showValiddDateAlert = false;
        untilDatesEmpty = true;
        validUntlDates = true;
        // console.log("both valid until dates are empty");
      }

      if ((this._dateAddedEnd == null || this._dateAddedEnd == undefined || this._dateAddedEnd == "")
        && (this._dateAddedStart == null || this._dateAddedStart == undefined || this._dateAddedStart == "")) {
        this.showAddedDateAlert = false;
        addedDatesEmpty = true;
        validAddedDates = true;

        // console.log("both added dates are empty");

      }

      if (untilDatesEmpty == true && addedDatesEmpty == true) {
        // console.log("all dates are empty");
        return true;
      }


      if (untilDatesEmpty !== true) {
        // console.log("atleast one until dates is not empty.");
        if (this.validateUntilDates()) {
          this.showValiddDateAlert = false;
          validUntlDates = true;
        } else {
          this.showValiddDateAlert = true;
          validUntlDates = false;

        }
      }

      if (addedDatesEmpty !== true) {

        // console.log("atleast one added dates is not empty.");
        if (this.validateDateAdded()) {
          this.showAddedDateAlert = false;
          validAddedDates = true;
        } else {
          this.showAddedDateAlert = true;
          validAddedDates = false;
        }
      }


      if (validAddedDates == true && validUntlDates == true) {
        // console.log("all dates are validated.");

        // console.log(" this.showValiddDateAlert = true;." + this.untilDateAlertMessage);
        return true;
      }
      else {
        // console.log("atleast one date is not validated.");
        return false;
      }


    }
    catch (error) {
      console.log("error happens..." + error);
      return false;
    }
  }

  validateUntilDates() {
    let retVal: boolean = false;

    if (this._validEndDate !== null && this._validEndDate !== undefined && this._validEndDate !== "") {
      console.log("this._validEndDate is not empty or not null");
      if (this._validStartDate !== null && this._validStartDate !== undefined && this._validStartDate !== "") {
        console.log("this._validStartDate is not empty or not null");
        let validEndDate = new Date(formatDate(this._validEndDate, 'MM/dd/yyyy', 'en-US'));
        if (this._validStartDate !== "" && this._validStartDate !== null) {
          let end = formatDate(this._validEndDate, 'MM/dd/yyyy', 'en-US');
          let start = formatDate(this._validStartDate, 'MM/dd/yyyy', 'en-US');

          if (end.length >= 8 && start.length >= 8) {
            let validBeginDate = new Date(formatDate(this._validStartDate, 'MM/dd/yyyy', 'en-US'));
            if (validEndDate.getTime() < validBeginDate.getTime()) {
              this.untilDateAlertMessage = "Invalid Date Range.  End Date cannot be before Start Date";
              this.showValiddDateAlert = true;
              return false;
            }
            else {
              this.showValiddDateAlert = false;
              return true;
            }
          }
        }
      }
      else {
        this.untilDateAlertMessage = "Please fill out both dates.";
        this.showValiddDateAlert = true;
        return false;
      }

    }
    else {
      if (
        (((this._validEndDate == null || this._validEndDate == undefined || this._validEndDate == "") && this._validStartDate !== null && this._validStartDate !== "")
          || (this._validEndDate !== null && this._validEndDate !== "" && (this._validStartDate == null || this._validStartDate == ""))
        )
      ) {
        if (this.filteredPredefInfoListRecords && this.filteredPredefInfoListRecords !== undefined && this.filteredPredefInfoListRecords !== null) {
          this.untilDateAlertMessage = "Please fill out both dates.";
          this.showValiddDateAlert = true;

          // console.log("this._validStartDate is not empty " + JSON.stringify(this._validStartDate));

          return false;
        }
      }
    }
    return retVal;
  }



  validateDateAdded() {
    let retVal: boolean = false;
    if (this._dateAddedEnd !== null && this._dateAddedEnd !== undefined && this._dateAddedEnd !== "") {
      console.log("this._dateAddedEnd is not empty or not null");
      if (this._dateAddedStart !== null && this._dateAddedStart !== undefined && this._dateAddedStart !== "") {
        console.log("this._dateAddedStart is not empty or not null");
        let addedEndDate = new Date(formatDate(this._dateAddedEnd, 'MM/dd/yyyy', 'en-US'));
        if (this._dateAddedStart !== "" && this._dateAddedStart !== null) {
          let end = formatDate(this._dateAddedEnd, 'MM/dd/yyyy', 'en-US');
          let start = formatDate(this._dateAddedStart, 'MM/dd/yyyy', 'en-US');

          if (end.length >= 8 && start.length >= 8) {
            let addedStartDate = new Date(formatDate(this._dateAddedStart, 'MM/dd/yyyy', 'en-US'));
            if (addedEndDate.getTime() < addedStartDate.getTime()) {
              this.addDateAlertMessage = "Invalid Date Range.  End Date cannot be before Start Date";
              this.showAddedDateAlert = true;
              return false;
            }
            else {
              this.showAddedDateAlert = false;
              return true;
            }
          }
        }
      }
      else {
        this.addDateAlertMessage = "Please fill out both dates.";
        this.showAddedDateAlert = true;
        return false;
      }

    }
    else {
      if (
        (((this._dateAddedEnd == null || this._dateAddedEnd == "") && this._dateAddedStart !== null && this._dateAddedStart !== "")
          || (this._dateAddedEnd !== null && this._dateAddedEnd !== "" && (this._dateAddedStart == null || this._dateAddedStart == ""))
        )
      ) {
        if (this.filteredPredefInfoListRecords && this.filteredPredefInfoListRecords !== undefined && this.filteredPredefInfoListRecords !== null) {
          this.addDateAlertMessage = "Please fill out both dates.";
          this.showAddedDateAlert = true;
          return false;
        }
      }
    }
    return retVal;
  }


@ViewChild('pagination', {static: false}) pager: ClrDatagridPagination;
  filterInfoList(filteredBy: string, filteredValue: string) {

    if (filteredValue !== undefined && filteredValue !== null && filteredValue !== "" && filteredValue !== "All" && this.predefInfoListRecord.length > 1) {

      if ((filteredBy == "ValidEndDate" && this._validStartDate !== null && this._validEndDate !== null && this._validStartDate !== "") ||
        (filteredBy == "ValidStartDate" && this._validStartDate !== null && this._validEndDate !== null && this._validEndDate !== "")) {
        let end = formatDate(this._validEndDate, 'MM/dd/yyyy', 'en-US');
        let start = formatDate(this._validStartDate, 'MM/dd/yyyy', 'en-US');
        if (end.length >= 8 && start.length >= 8) {
          let dt = new Date(this._validStartDate);
          dt.setDate(dt.getDate() - 1);
          this.filteredPredefInfoListRecords = this.filteredPredefInfoListRecords.filter(preDefRecord =>
            preDefRecord[filteredBy] !== undefined && preDefRecord[filteredBy] !== null &&
            (new Date(preDefRecord.ValidEndDate).getTime() >= (new Date(dt)).getTime())
            &&
            (new Date(preDefRecord.ValidEndDate).getTime() <= (new Date(this._validEndDate)).getTime())
          );
        }

      }

      else if ((filteredBy == "DateAdded" && this._dateAddedStart !== undefined && this._dateAddedStart !== null && this._dateAddedStart !== "")
        || (filteredBy == "DateAdded" && this._dateAddedEnd !== undefined && this._dateAddedEnd !== null && this._dateAddedEnd !== "")) {

        let end = formatDate(this._dateAddedEnd, 'MM/dd/yyyy', 'en-US');
        let start = formatDate(this._dateAddedEnd, 'MM/dd/yyyy', 'en-US');

        if (end.length >= 8 && start.length >= 8) {
          let dtAdd = new Date(this._dateAddedStart);


          dtAdd.setDate(dtAdd.getDate() - 1);
          this.filteredPredefInfoListRecords = this.filteredPredefInfoListRecords.filter(preDefRecord =>
            preDefRecord.DateAdded !== undefined && preDefRecord.DateAdded !== null &&
            new Date(preDefRecord.DateAdded).getTime() >= (new Date(dtAdd)).getTime() &&
            new Date(preDefRecord.DateAdded).getTime() <= (new Date(this._dateAddedEnd)).getTime()
          );
        }
      }
      else if (filteredBy == "idType") {
        if (filteredValue == "DUNS")
          this.filteredPredefInfoListRecords = this.filteredPredefInfoListRecords.filter(preDefRecord =>
            preDefRecord.DunsNumber !== undefined && preDefRecord.DunsNumber !== null &&
            preDefRecord.DunsNumber.length > 0 &&
            (preDefRecord.AgnID == undefined || preDefRecord.AgnID == null ||
            preDefRecord.AgnID.trim().length < 1));
        else if (filteredValue == "AGN"){
          console.log("filter by AgnID...");
          this.filteredPredefInfoListRecords = this.filteredPredefInfoListRecords.filter(preDefRecord =>
            preDefRecord.AgnID !== undefined && preDefRecord.AgnID !== null &&
            (preDefRecord.DunsNumber == undefined || preDefRecord.DunsNumber == null ||
            preDefRecord.DunsNumber.trim().length < 1));
      }
}
      else if (filteredValue === "DunsNumber" || filteredValue === "AgnID") this.filteredPredefInfoListRecords = this.filteredPredefInfoListRecords.filter(preDefRecord =>
        preDefRecord[filteredBy] !== undefined && preDefRecord[filteredBy] !== null &&
        preDefRecord[filteredBy].includes(filteredValue) !== -1
      );

      else {

        if (filteredBy !== "DateAdded" && filteredBy !== "ValidStartDate" && filteredBy !== "ValidEndDate")
          this.filteredPredefInfoListRecords = this.filteredPredefInfoListRecords.filter(preDefRecord =>
            preDefRecord[filteredBy] !== undefined && preDefRecord[filteredBy] !== null &&
            preDefRecord[filteredBy].toLowerCase().search(filteredValue.trim().toLowerCase()) !== -1
          );
      }
    }
    if(this.pager){
    this.pager.currentPage = 1
    }
  }

  ngOnDestroy() {
    console.log("On Destroy")
    this.showpage = false;
  }

  ngOnInit() {
    this.showpage = false;
    this.cssSubscription = this.cssStatusService.currentMessage.subscribe(message => {

      if (message.destComponentName == AppSettings.CS_PREDEF_INFO) {

        console.log("iN Predefined Info Subscriber")
        console.log(message);
        this.predefInfoList = JSON.parse(message.data)
        console.log(this.predefInfoList)
        this.getPredefinedInfoList();
        this.initPredefList();
        this.showpage = true;
        if ((this.userInRoleService && this.userInRoleService.userInRole !== undefined && this.userInRoleService.userInRole !== null)
          && (this.userInRoleService.userInRole.businessAdministrator ||
            this.userInRoleService.userInRole.vibeTeam ||
            this.userInRoleService.userInRole.cfdoOrRiskAnalyst)) {
          this.canRequestPredefinedInfo = true;
         }


      }
    })


    this.exportOptions = "EXCEL";
    if ((this.userInRoleService && this.userInRoleService.userInRole !== undefined && this.userInRoleService.userInRole !== null)
      && (this.userInRoleService.userInRole.businessAdministrator ||
        this.userInRoleService.userInRole.vibeTeam ||
        this.userInRoleService.userInRole.cfdoOrRiskAnalyst)) {
      this.canRequestPredefinedInfo = true;
    }
    if (!this.predefInfoList) {
      this.showpage = false;
      return;
    } else this.showpage = true;
    this.getPredefinedInfoList();


    this.initPredefList();
  }


  private sortByOrganizationName(recordToSort) {
    try {
      this.predefInfoListRecord.sort(function (a, b) {

        if (a.OrganizationName !== undefined)
          return b ? a.OrganizationName.localeCompare(b.OrganizationName) : -1;
        else if (b.OrganizationName !== undefined)
          return a ? b.OrganizationName.localeCompare(a.OrganizationName) : 1;
      });


    } catch (error) {
      console.log("error happens while sorting..");
    }
  }


  refresh(): void {

    this.loading = true;
    this.cisUserSearchService.getCisUser().subscribe(
      data => {
        this.loading = false;
        if (data && !JSON.stringify(data).includes("Error") && !JSON.stringify(data).includes("ESB2Exception")) {
          this.frequentUser = data;
          this.frequentUserRecord = this.frequentUser.FrequentUpdaterListGetResponse.FrequentUserResultSet.FrequentUserRecord;
          this.filteredFrequentUsers = this.frequentUserRecord;
          this.addedBy = "All";
          this.idType = "All";
          if (this.userInRoleService.userInRole && (this.userInRoleService.userInRole.vibeTeam || this.userInRoleService.userInRole.cfdoOrRiskAnalyst))
            this.addedBy = this.userInRoleService.userInRole.username;
          this.showListView = true;
        }
        else {

          if (JSON.stringify(data).includes(AppSettings.VSR_EXCEPTION_CODE_0107))
            this.appsAlert = AppSettings.VSR_EXCEPTION_CODE_0107_DESC;
          else if (JSON.stringify(data).includes(AppSettings.VSR_EXCEPTION_CODE_0108))
            this.appsAlert = AppSettings.VSR_EXCEPTION_CODE_0108_DESC;
          else if (JSON.stringify(data).includes(AppSettings.VSR_EXCEPTION_CODE_0500))
            this.appsAlert = AppSettings.VSR_EXCEPTION_CODE_0500_DESC;
          else
            this.appsAlert = AppSettings.SYSTEM_EXCEPTION;

          this.loading = false;
        }
      }, error => {
        (async () => {
          // await this.delay(1000);  //when simulating a long delay or timeout from a service.

          this.loading = false;


        })();
      }
    );
  }

  getPredefinedInfoList(): void {
    this.loading = true;

    let data: PredefinedInformation = this.predefInfoList;
    console.log(data)
    // this.predefInfoListService.getPredefInfo().subscribe(

    //   data => {

    if (data && !JSON.stringify(data).includes("ESB2Exception")) {
      this.predefInfoList = data;
      this.predefInfoListRecord = this.predefInfoList.PredefinedInformationGetListResponse.PredefinedInformationResultSet.PredefinedInformationRecord;
      this.sortByOrganizationName(this.predefInfoListRecord);
      this.filteredPredefInfoListRecords = this.predefInfoListRecord;
      // console.log("here is the predefInfoListRecorddata...: " + JSON.stringify(this.filteredPredefInfoListRecords));
      this.refresh();

    }
    else {

      if (JSON.stringify(data).includes(AppSettings.VSR_EXCEPTION_CODE_0107))
        this.appsAlert = AppSettings.VSR_EXCEPTION_CODE_0107_DESC;
      else if (JSON.stringify(data).includes(AppSettings.VSR_EXCEPTION_CODE_0108))
        this.appsAlert = AppSettings.VSR_EXCEPTION_CODE_0108_DESC;
      else if (JSON.stringify(data).includes(AppSettings.VSR_EXCEPTION_CODE_0500))
        this.appsAlert = AppSettings.VSR_EXCEPTION_CODE_0500_DESC;
      else if (JSON.stringify(data).includes(AppSettings.HTTP_STATUS_401))
        this.appsAlert = AppSettings.VSR_EXCEPTION_CODE_0500_DESC;
      else
        this.appsAlert = AppSettings.SYSTEM_EXCEPTION;

      this.loading = false;

    }
    //   }, error => {
    //     (async () => {
    //       if (JSON.stringify(error).includes(AppSettings.VSR_EXCEPTION_CODE_0107))
    //         this.appsAlert = AppSettings.VSR_EXCEPTION_CODE_0107_DESC;
    //       else if (JSON.stringify(error).includes(AppSettings.VSR_EXCEPTION_CODE_0108))
    //         this.appsAlert = AppSettings.VSR_EXCEPTION_CODE_0108_DESC;
    //       else if (JSON.stringify(error).includes(AppSettings.VSR_EXCEPTION_CODE_0500))
    //         this.appsAlert = AppSettings.VSR_EXCEPTION_CODE_0500_DESC;
    //       else
    //         this.appsAlert = AppSettings.SYSTEM_EXCEPTION;

    //       this.loading = false;


    //     })();
    //   }
    // );

  }

  refreshPredefinedInfo(evt) {
    this.loading = true;
    this.predefInfoProvider.refreshPredefInfo();
    this.predefInfoList = this.predefInfoProvider.getPredefInfo();
    this.predefInfoListRecord = this.predefInfoList.PredefinedInformationGetListResponse.PredefinedInformationResultSet.PredefinedInformationRecord
    this.loading = false;
  }
  showWizard() {
    this.initPredefList();
    this.predefWorkflowService.predefCompleteList.formTypeManualEdit = true;
    this.predefAlertMessage = "";
    this.predefWorkflowService.predefCompleteList.searchByAddress = false;
    this.showPredefRequestWizard = true;
  }
  initPredefList() {

    let predefList: PredefinedInfoWorkflowFacade = new PredefinedInfoWorkflowFacade({ source: "menu" });
    predefList.businessSearchAddress = new PredfinedInfoRequestAddress();
    predefList.predefinedInformationRequest = new PredefinedInformationWorkflowRequest();
    predefList.predefinedInformationRequest.address = new PredfinedInfoRequestAddress();
    predefList.formTypeManualEdit = true;
    predefList.forceEdit = true;
    console.log("the predeflist is: " + JSON.stringify(predefList));
    this.predefWorkflowService.predefCompleteList = predefList;

  }




  // the following code is implementation of the predefined info when a click happens 
  // inside the detail grid.

  setAlertMessage(data: PredefinedInformationGetDetailResponse) {
    if (JSON.stringify(data).includes(AppSettings.VSR_EXCEPTION_CODE_0107))
      this.predefAlertMessage = AppSettings.VSR_EXCEPTION_CODE_0107_DESC;
    else if (JSON.stringify(data).includes(AppSettings.VSR_EXCEPTION_CODE_0108))
      this.predefAlertMessage = AppSettings.VSR_EXCEPTION_CODE_0108_DESC;
    else if (JSON.stringify(data).includes(AppSettings.VSR_EXCEPTION_CODE_0500))
      this.predefAlertMessage = AppSettings.VSR_EXCEPTION_CODE_0500_DESC;
    else if (JSON.stringify(data).includes(AppSettings.HTTP_STATUS_401))
      this.predefAlertMessage = AppSettings.VSR_EXCEPTION_CODE_0500_DESC;
    else if (JSON.stringify(data).includes("exception"))
      this.predefAlertMessage = AppSettings.SYSTEM_EXCEPTION;
    else {
      // console.log("none system exception... processig new predefined Info creation.");
      this.predefAlertMessage = "UNKOWN ERROR..."
    }
    if (this.predefAlertMessage !== "")
      this.showPredefAlertMessage = true;
    // console.log("the predefAlertMessage is: " + this.predefAlertMessage);
  }

  removelastCommaCharacter(str: string): string {
    if (str !== null && str.length > 0 && str.charAt(str.length - 1) == ',') {
      str = str.substring(0, str.length - 1);
    }
    return str;
  }
  processExistingPredefinedInfo(exceptionId: string) {

    let predefList: PredefinedInfoWorkflowFacade = new PredefinedInfoWorkflowFacade({ source: "vsr" });
    if (this.predefWorkflowService.predefCompleteList) {

      try {
        this.getExistingPredefinedInfoByExceptionID(exceptionId);


      } catch (error) {
        console.log("error happens inside processExistingPredefinedInfo " + JSON.stringify(error));

      }


    }
    else {
      this.initPredefList();
    }
  }

  getExistingPredefinedInfoByExceptionID(exceptionID: string): void {
    this.predefLoading = true;
    this.showPredefAlertMessage = false;
    this.predefAlertMessage = "";
    this.predefInfoListService.getPredefInfoDetailByExceptionId(exceptionID).subscribe(

      data => {
        if (data && !JSON.stringify(data).includes("ESB2Exception")) {
          try {
            this.predefResponse = new PredefinedInformationGetDetailResponse();
            this.predefWorkflowService.predefCompleteList.PredefinedInformationGetDetailResponse = new PredefinedInformationGetDetailResponse();
            this.predefResponse = data as PredefinedInformationGetDetailResponse;
            if (this.predefResponse) {
              let predef = JSON.parse(JSON.stringify(this.predefResponse));
              console.log("capturing predefResponse" + JSON.stringify(this.predefResponse));
              this.mapWorkFlowRecords(exceptionID);
              this.predefWorkflowService.predefCompleteList.forceEdit = true;
              this.predefWorkflowService.predefCompleteList.setFormType();
              this.predefWorkflowService.predefCompleteList.businessSearchEditDetailAddress.organizationName = predef.PredefinedInformationGetDetailResponse.organizationName;
              this.showPredefViewDetailForm = true;
              this.showPredefRequestWizard = false;
            }
            else {
              this.appsAlert = "unable to process Predefined Information Request at this time."
            }
            this.predefLoading = false;
          } catch (error) {
            this.predefLoading = false;
            console.log("no good response retieved..." + JSON.stringify(error));
            this.setAlertMessage(data);
          }

        }
        else {
          this.predefLoading = false;
          console.log("no good response retieved..." + JSON.stringify(data));
          this.setAlertMessage(data);
        }
      }, error => {
        (async () => {
          // await this.delay(1000);  //when simulating a long delay or timeout from a service.

          console.log("data not retieved. error happens..." + JSON.stringify(error));
          if (JSON.stringify(error).includes(AppSettings.VSR_EXCEPTION_CODE_0107))
            this.appsAlert = AppSettings.VSR_EXCEPTION_CODE_0107_DESC;
          else if (JSON.stringify(error).includes(AppSettings.VSR_EXCEPTION_CODE_0108))
            this.appsAlert = AppSettings.VSR_EXCEPTION_CODE_0108_DESC;
          else if (JSON.stringify(error).includes(AppSettings.VSR_EXCEPTION_CODE_0500))
            this.appsAlert = AppSettings.VSR_EXCEPTION_CODE_0500_DESC;
          else
            this.appsAlert = AppSettings.SYSTEM_EXCEPTION;
          this.predefLoading = false;
        })();
        this.predefAlertMessage = "Error while retrieving predefined info.";
        if (this.predefAlertMessage !== "")
          this.showPredefAlertMessage = true;
        // console.log("the predefAlertMessage is: " + this.predefAlertMessage) ;
      }


    );

  }

  mapWorkFlowRecords(exceptionID: string) {
    try {
      let predefList: PredefinedInfoWorkflowFacade = new PredefinedInfoWorkflowFacade({ source: "vsr" });
      let predef = this.mapPredefinedInfoRequestData(predefList);
      this.mapPredefinedInfoDetailResponse(predefList, predef, exceptionID);
      let StreetFullText = (predef.PredefinedInformationGetDetailResponse.address.streetFull == null) ? "" : predef.PredefinedInformationGetDetailResponse.address.streetFull + ", ";
      let LocationCityName = (predef.PredefinedInformationGetDetailResponse.address.city == null) ? "" : predef.PredefinedInformationGetDetailResponse.address.city + ", ";
      let LocationStateName = (predef.PredefinedInformationGetDetailResponse.address.state == null) ? "" : predef.PredefinedInformationGetDetailResponse.address.state + ", ";
      let LocationPostalCode = (predef.PredefinedInformationGetDetailResponse.address.postalCode == null) ? "" : predef.PredefinedInformationGetDetailResponse.address.postalCode + ", ";
      let LocationCountryName = (predef.PredefinedInformationGetDetailResponse.address.country == null) ? "" : predef.PredefinedInformationGetDetailResponse.address.country;

      let DNBMatchedCompanyAddress = StreetFullText + LocationCityName + LocationStateName + LocationPostalCode + LocationCountryName;
      DNBMatchedCompanyAddress = this.removelastCommaCharacter(DNBMatchedCompanyAddress.trim());
      predefList.PredefinedInformationGetDetailResponse.address.singleLineFullAddress = DNBMatchedCompanyAddress;
      predefList.predefinedInformationRequest.address.singleLineFullAddress = DNBMatchedCompanyAddress;
      this.predefWorkflowService.predefCompleteList = predefList;

      // console.log("inside mapWorkFlowRecords this.predefWorkflowService.predefCompleteList: " + JSON.stringify(this.predefWorkflowService.predefCompleteList));
    } catch (error) {
      console.log("error is happening inside mapWorkFlowRecords: " + JSON.stringify(error));
    }



  }


  mapPredefinedInfoRequestData(predefList: PredefinedInfoWorkflowFacade) {
    let predef = JSON.parse(JSON.stringify(this.predefResponse));
    try {
      predefList.predefinedInformationRequest = new PredefinedInformationWorkflowRequest();
      if (predef.PredefinedInformationGetDetailResponse !== undefined) {
        if (predef.PredefinedInformationGetDetailResponse.fein !== undefined) predefList.predefinedInformationRequest.fein = predef.PredefinedInformationGetDetailResponse.fein;
        if (predef.PredefinedInformationGetDetailResponse !== undefined) predefList.predefinedInformationRequest.duns = predef.PredefinedInformationGetDetailResponse.duns;
        if (predef.PredefinedInformationGetDetailResponse !== undefined) predefList.predefinedInformationRequest.exceptionID = predef.PredefinedInformationGetDetailResponse.exceptionID;
        if (predef.PredefinedInformationGetDetailResponse !== undefined) predefList.predefinedInformationRequest.agn = predef.PredefinedInformationGetDetailResponse.agn;
        if (predef.PredefinedInformationGetDetailResponse !== undefined) predefList.predefinedInformationRequest.receiptNumber = predef.PredefinedInformationGetDetailResponse.receiptNumber;
        if (predef.PredefinedInformationGetDetailResponse !== undefined) predefList.predefinedInformationRequest.organizationName = predef.PredefinedInformationGetDetailResponse.organizationName;
        if (predef.PredefinedInformationGetDetailResponse !== undefined) predefList.predefinedInformationRequest.address = new PredfinedInfoRequestAddress();

        if (predef.PredefinedInformationGetDetailResponse !== undefined) predefList.businessSearchAddress = new PredfinedInfoRequestAddress();
        if (predef.PredefinedInformationGetDetailResponse !== undefined) predefList.predefinedInformationRequest.address.city = predef.PredefinedInformationGetDetailResponse.address.city;
        if (predef.PredefinedInformationGetDetailResponse !== undefined) predefList.predefinedInformationRequest.address.country = predef.PredefinedInformationGetDetailResponse.address.country;
        if (predef.PredefinedInformationGetDetailResponse !== undefined) predefList.predefinedInformationRequest.address.organizationName = predef.PredefinedInformationGetDetailResponse.address.organizationName;
        if (predef.PredefinedInformationGetDetailResponse !== undefined) predefList.predefinedInformationRequest.address.postalCode = predef.PredefinedInformationGetDetailResponse.address.postalCode;
        if (predef.PredefinedInformationGetDetailResponse !== undefined) predefList.predefinedInformationRequest.address.state = predef.PredefinedInformationGetDetailResponse.address.state;
        if (predef.PredefinedInformationGetDetailResponse !== undefined) predefList.predefinedInformationRequest.address.streetExtension = predef.PredefinedInformationGetDetailResponse.address.streetExtension;
        if (predef.PredefinedInformationGetDetailResponse !== undefined) predefList.predefinedInformationRequest.address.streetFull = predef.PredefinedInformationGetDetailResponse.address.streetFull;
        if (predef.PredefinedInformationGetDetailResponse !== undefined) predefList.predefinedInformationRequest.address.telephoneNumber = predef.PredefinedInformationGetDetailResponse.address.telephoneNumber;
        // predefList.businessSearchAddress = predefList.predefinedInformationRequest.address;
        predefList.businessSearchEditDetailAddress = new PredfinedInfoRequestAddress();
        predefList.businessSearchEditDetailAddress = predefList.predefinedInformationRequest.address;
        predefList.businessSearchAddress.organizationName = predef.PredefinedInformationGetDetailResponse.organizationName;
        if (predef.PredefinedInformationGetDetailResponse !== undefined) predefList.predefinedInformationRequest.operationCode = predef.PredefinedInformationGetDetailResponse.operationCode;

        if (predef.PredefinedInformationGetDetailResponse !== undefined) predefList.predefinedInformationRequest.overrideScore = predef.PredefinedInformationGetDetailResponse.overrideScore;
        if (predef.PredefinedInformationGetDetailResponse !== undefined) predefList.predefinedInformationRequest.preDefFormCommentType = predef.PredefinedInformationGetDetailResponse.preDefFormCommentType;
        if (predef.PredefinedInformationGetDetailResponse !== undefined) predefList.predefinedInformationRequest.office = predef.PredefinedInformationGetDetailResponse.office;



        if (predef.PredefinedInformationGetDetailResponse !== undefined) predefList.predefinedInformationRequest.fdnsdsNumber = predef.PredefinedInformationGetDetailResponse.fdnsdsNumber;
        if (predef.PredefinedInformationGetDetailResponse !== undefined) predefList.predefinedInformationRequest.predefinedInformationComment = predef.PredefinedInformationGetDetailResponse.predefinedInformationComment;
        if (predef.PredefinedInformationGetDetailResponse !== undefined) predefList.predefinedInformationRequest.justificationComment = predef.PredefinedInformationGetDetailResponse.justificationComment;
        if (predef.PredefinedInformationGetDetailResponse !== undefined) predefList.predefinedInformationRequest.siteVisitProgram = predef.PredefinedInformationGetDetailResponse.siteVisitProgram;
        if (predef.PredefinedInformationGetDetailResponse !== undefined) predefList.predefinedInformationRequest.nominationSource = predef.PredefinedInformationGetDetailResponse.nominationSource;
        if (predef.PredefinedInformationGetDetailResponse !== undefined) predefList.predefinedInformationRequest.addressId = predef.PredefinedInformationGetDetailResponse.address.addressId;
        if (predef.PredefinedInformationGetDetailResponse !== undefined) predefList.predefinedInformationRequest.addressId = predef.PredefinedInformationGetDetailResponse.addressId;

      }
    } catch (error) {
      console.log("error happens while fetching detail InfoWindowManager. " + error);
    }
    return predef;
  }


  mapPredefinedInfoDetailResponse(predefList: PredefinedInfoWorkflowFacade, predef: any, exceptionID: string) {
    console.log("the process status is: " + predef.PredefinedInformationGetDetailResponse.processStatus)
    predefList.PredefinedInformationGetDetailResponse = new PredefinedInformationGetDetailResponse();
    if (predef.PredefinedInformationGetDetailResponse.processStatus == "E" || predef.PredefinedInformationGetDetailResponse.processStatus == "R") {
      this.canEditPredefinedInfo = false;
    }
    else {
      this.canEditPredefinedInfo = true;
    }

    if (predef.PredefinedInformationGetDetailResponse.processStatus == "A" && this.userInRoleService.userInRole.businessAdministrator == true)
      this.canExpirePredefinedInfo = true;
    else
      this.canExpirePredefinedInfo = false;


    predefList.PredefinedInformationGetDetailResponse.fein = predef.PredefinedInformationGetDetailResponse.fein;
    predefList.PredefinedInformationGetDetailResponse.exceptionId = exceptionID;
    predefList.PredefinedInformationGetDetailResponse.duns = predef.PredefinedInformationGetDetailResponse.duns;
    predefList.PredefinedInformationGetDetailResponse.addressId = predef.PredefinedInformationGetDetailResponse.address.addressId;
    predefList.PredefinedInformationGetDetailResponse.receiptNumber = predef.PredefinedInformationGetDetailResponse.receiptNumber;
    predefList.PredefinedInformationGetDetailResponse.processStatus = predef.PredefinedInformationGetDetailResponse.processStatus;
    predefList.PredefinedInformationGetDetailResponse.agn = predef.PredefinedInformationGetDetailResponse.agn;
    predefList.PredefinedInformationGetDetailResponse.iipConfidenceCode = predef.PredefinedInformationGetDetailResponse.iipConfidenceCode;
    predefList.PredefinedInformationGetDetailResponse.validUntilDateRange = new ValidUntilDateRange();
    if (predef.PredefinedInformationGetDetailResponse.validUntilDateRange !== undefined && predef.PredefinedInformationGetDetailResponse.validUntilDateRange !== null) {

      if (predef.PredefinedInformationGetDetailResponse.validUntilDateRange.startDate !== undefined &&
        predef.PredefinedInformationGetDetailResponse.validUntilDateRange.startDate !== null &&
        predef.PredefinedInformationGetDetailResponse.validUntilDateRange.startDate !== "null") {
        predefList.PredefinedInformationGetDetailResponse.validUntilDateRange.startDate = predef.PredefinedInformationGetDetailResponse.validUntilDateRange.startDate;
      }
      if (predef.PredefinedInformationGetDetailResponse.validUntilDateRange.endDate !== undefined &&
        predef.PredefinedInformationGetDetailResponse.validUntilDateRange.endDate !== null &&
        predef.PredefinedInformationGetDetailResponse.validUntilDateRange.endDate !== "null") {
        predefList.PredefinedInformationGetDetailResponse.validUntilDateRange.endDate = predef.PredefinedInformationGetDetailResponse.validUntilDateRange.endDate;
      }
    }


    predefList.PredefinedInformationGetDetailResponse.office = predef.PredefinedInformationGetDetailResponse.office;
    predefList.PredefinedInformationGetDetailResponse.fdnsdsNumber = predef.PredefinedInformationGetDetailResponse.fdnsdsNumber;
    predefList.PredefinedInformationGetDetailResponse.predefinedInformationComment = predef.PredefinedInformationGetDetailResponse.predefinedInformationComment;
    predefList.PredefinedInformationGetDetailResponse.justificationComment = predef.PredefinedInformationGetDetailResponse.justificationComment;
    predefList.PredefinedInformationGetDetailResponse.siteVisitProgram = predef.PredefinedInformationGetDetailResponse.siteVisitProgram;
    predefList.PredefinedInformationGetDetailResponse.nominationSource = predef.PredefinedInformationGetDetailResponse.nominationSource;
    predefList.PredefinedInformationGetDetailResponse.addressId = predef.PredefinedInformationGetDetailResponse.address.addressId;
    predefList.PredefinedInformationGetDetailResponse.organizationName = predef.PredefinedInformationGetDetailResponse.organizationName;
    predefList.PredefinedInformationGetDetailResponse.address = new PredfinedInfoRequestAddress();
    // console.log("predefList.PredefinedInformationGetDetailResponse.receiptNumber" + predefList.PredefinedInformationGetDetailResponse.receiptNumber);
    predefList.PredefinedInformationGetDetailResponse.address.city = predef.PredefinedInformationGetDetailResponse.address.city;
    predefList.PredefinedInformationGetDetailResponse.address.country = predef.PredefinedInformationGetDetailResponse.address.country;
    predefList.PredefinedInformationGetDetailResponse.address.organizationName = predef.PredefinedInformationGetDetailResponse.address.organizationName;
    predefList.PredefinedInformationGetDetailResponse.address.postalCode = predef.PredefinedInformationGetDetailResponse.address.postalCode;
    predefList.PredefinedInformationGetDetailResponse.address.state = predef.PredefinedInformationGetDetailResponse.address.state;
    predefList.PredefinedInformationGetDetailResponse.address.streetExtension = predef.PredefinedInformationGetDetailResponse.address.streetExtension;
    predefList.PredefinedInformationGetDetailResponse.address.streetFull = predef.PredefinedInformationGetDetailResponse.address.streetFull;
    predefList.PredefinedInformationGetDetailResponse.address.telephoneNumber = predef.PredefinedInformationGetDetailResponse.address.telephoneNumber;
    predefList.PredefinedInformationGetDetailResponse.preDefCommentType = this.getPredefCommentType(predef.PredefinedInformationGetDetailResponse.preDefCommentType);
    predefList.PredefinedInformationGetDetailResponse.preDefFormCommentType = predef.PredefinedInformationGetDetailResponse.preDefFormCommentType;
    predefList.PredefinedInformationGetDetailResponse.lastWizardStep = predef.PredefinedInformationGetDetailResponse.lastWizardStep;
    predefList.PredefinedInformationGetDetailResponse.operationCode = predef.PredefinedInformationGetDetailResponse.operationCode;
    predefList.PredefinedInformationGetDetailResponse.overrideScore = predef.PredefinedInformationGetDetailResponse.overrideScore;
  }


  getPredefCommentType(commentType: string): string {
    let commentTypeStr: string = "";
    if (commentType !== undefined && commentType !== null) {
      for (let i = 0; i < commentType.length; i++) {
        let ct = commentType.charAt(i);
        switch (ct.toUpperCase()) {
          case "L":
            commentTypeStr = commentTypeStr + " " + "LE13";
            break;

          case "H":
            commentTypeStr = commentTypeStr + " " + "H2A";
            break;

          case "Q":
            commentTypeStr = commentTypeStr + " " + "Q";;
            break;
          case "S":
            commentTypeStr = commentTypeStr + " " + "SIEVE";
            break;
          case "V":
            commentTypeStr = commentTypeStr + " " + "Viability";
            break;
          case "P":
            commentTypeStr = commentTypeStr + " " + "Public Law";
            break;
          default:
            commentTypeStr = commentTypeStr + " " + "";
            break;
        }

      }
    }
    return commentTypeStr;
  }

  closePredefEditForm() {
    let predefList: PredefinedInfoWorkflowFacade = new PredefinedInfoWorkflowFacade({ source: "vsr" });
    predefList.predefinedInformationRequest = new PredefinedInformationWorkflowRequest();
    this.predefWorkflowService.predefCompleteList.predefinedInformationRequest = predefList.predefinedInformationRequest;
    this.predefWorkflowService.predefCompleteList.searchByAddress = false;
    this.showPredefViewDetailForm = false;
  }

  closePredefExpireForm() {
    let predefList: PredefinedInfoWorkflowFacade = new PredefinedInfoWorkflowFacade({ source: "vsr" });
    predefList.predefinedInformationRequest = new PredefinedInformationWorkflowRequest();
    this.predefWorkflowService.predefCompleteList.predefinedInformationRequest = predefList.predefinedInformationRequest;
    this.predefWorkflowService.predefCompleteList.searchByAddress = false;
    this.showPredefExpireForm = false;
  }

  predefInfoDetailEdit(action: string) {
    this.showPredefViewDetailForm = false;    
    this.showPredefExpireForm = false;
    if (this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.duns !== undefined &&
      this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.duns !== null &&
      this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.duns !== "") {
      this.predefWorkflowService.predefCompleteList.searchByAddress = false;
      this.predefWorkflowService.predefCompleteList.iipNextDisabled = false;
    }
    else {
      this.predefWorkflowService.predefCompleteList.searchByAddress = true;
      this.predefWorkflowService.predefCompleteList.iipNextDisabled = true;
    }
    if (action == "EXPIRE") {
      this.predefWorkflowService.predefCompleteList.expirePredefinedInfo = true;
      this.showPredefExpireForm = true;
      console.log("expire is set to launch.");
    }
    else {
      this.predefWorkflowService.predefCompleteList.forceEdit = true;
      this.showPredefRequestWizard = true;
    }
  }

  onEditPredefList(predefRecord: PredefinedInformationRecordEntity) {
    this.predefAlertMessage = "";
    let exceptionId: string = "";
    this.showPredefAlertMessage = false;

    if (this.userInRoleService.userInRole.businessAdministrator ||
      this.userInRoleService.userInRole.vibeTeam ||
      this.userInRoleService.userInRole.cfdoOrRiskAnalyst) {
      this.canRequestPredefinedInfo = true;
    }


    if (predefRecord.ExceptionID !== undefined && predefRecord.ExceptionID !== null)
      exceptionId = predefRecord.ExceptionID;
    // console.log("the selected predef record is: " + JSON.stringify(predefRecord));
    this.initPredefList();
    this.processExistingPredefinedInfo(exceptionId);

    console.log("the selected predef record is: " + JSON.stringify(this.predefWorkflowService.predefCompleteList.predefinedInformationRequest));


    `
    1. init PredefList -> this.initPredefList();
    2. process ExistingPredefined Info -> processExistingPredefinedInfo();
        a) try and fetch if there is existing record matching the exceptionID -> getExistingPredefinedInfoByExceptionID();
        b) if a record exists, map workflow and predefined information records
            -> this.mapPredefinedInfoRequestData(predefList);
            ->  this.mapPredefinedInfoDetailResponse(predefList, predef);

    `
  }


}
// 


export class PredefinedInfoReport {
  DunsNumber: string;
  OrganizationName: string;
  ProcessStatus: string;
  OverrideScore: string;
  ValidStartDate: string;
  ValidEndDate: string;
  AddedBy: string;
  AgnID: string;
  public constructor(
    fields?: {

      DunsNumber?: string,
      OrganizationName?: string,
      ProcessStatus?: string,
      OverrideScore?: string,
      ValidStartDate?: string,
      ValidEndDate?: string,
      AddedBy?: string,
      AgnID?: string
    }) {
    if (fields) Object.assign(this, fields);
  }
}
