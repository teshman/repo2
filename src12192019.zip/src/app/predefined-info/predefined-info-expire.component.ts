import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { PredefWorkflowService } from './predef-workflow.service';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { formatDate } from '@angular/common';
import { PredefinedInformationWorkflowRequest, WorkflowResponse } from '../shared/predefined-Info-request';
import { VsrManualSearchService } from '../vsr-manual-search.service';
import { PredefinedInfoWorkflowFacade } from '../shared/predefined-info-workflow-facade';
import { AppSettings } from '../shared/app-settings';

@Component({
  selector: 'predefined-info-expire',
  templateUrl: './predefined-info-expire.component.html',
  styleUrls: ['./predefined-info-create.component.css']
})
export class PredefinedInfoExpireComponent implements OnInit {
  @Input() showPredefExpireForm: boolean = false;
  expireForm: FormGroup;  
  expireCommentFullForm: FormGroup;
  predefWFS:PredefWorkflowService
  loading: boolean = false;
  expiredSuccessful:boolean = false;
  expiredStatus:string = '';
  systemAlertMessage: string = "";
  @Output() refreshInfoList = new EventEmitter<boolean>();
  addCommentFullForm: FormGroup;
  constructor(private vsrManualSearchService: VsrManualSearchService, private predefWorkflowService:PredefWorkflowService ,  private fb: FormBuilder) {
    
    
    this.predefWFS = this.predefWorkflowService;
    this._validEndDate = new Date();
   }

  ngOnInit() {
    this.addCommentFullForm = this.fb.group({
        textAreaJustification: new FormControl('', Validators.required),
        textAreaVibeComment: new FormControl('', Validators.required)
      });
  }

  
 closePredefExpireForm() {
    let predefList: PredefinedInfoWorkflowFacade = new PredefinedInfoWorkflowFacade({ source: "vsr" });
    predefList.predefinedInformationRequest = new PredefinedInformationWorkflowRequest();
    this.predefWorkflowService.predefCompleteList.predefinedInformationRequest = predefList.predefinedInformationRequest;
    this.predefWorkflowService.predefCompleteList.searchByAddress = false;
    this.showPredefExpireForm = !this.showPredefExpireForm;
    this.refreshInfoList.emit(true)

  }

  predefInfoExpire()
{
    this.expiredStatus = "";   
    let predefRequest = this.predefWorkflowService.predefCompleteList.predefinedInformationRequest;
    let predefDetailResponse = this.predefWFS.predefCompleteList.PredefinedInformationGetDetailResponse;
    predefRequest.operationCode = "EXPIRE";
    predefRequest.setValidUntilDateRange(predefDetailResponse.validUntilDateRange.startDate, this.validEndDate) ;
    predefRequest.exceptionID = predefDetailResponse.exceptionId;
    if(predefRequest.justificationComment !== undefined && 
        predefRequest.justificationComment !== null && 
        predefRequest.justificationComment !== "")
    this.savePredefinedInfoWorkflowRequest(predefRequest);
    else 
    this.expiredStatus = "The Justification comment is required. Please update the comment and try again.";
}

  _validEndDate: any;
  public get validEndDate(): string {
    return this._validEndDate ;
  }
  public set validEndDate(value: string) {
    this._validEndDate = value;
  }

  
  savePredefinedInfoWorkflowRequest(predefRequest: PredefinedInformationWorkflowRequest) {
    this.loading = true;
    this.expiredStatus = '';

    if (predefRequest.address !== undefined && predefRequest.address !== null && predefRequest.address.organizationName !== "") {
        predefRequest.organizationName = predefRequest.address.organizationName;
    }
    console.log("the PredefinedInformationRequest before saving: " + JSON.stringify(predefRequest));
    this.vsrManualSearchService.saveWorkFlowRequestInJson(predefRequest)
        .subscribe(savePredefInfoResponse => {
            this.loading = false;
            this.handleSavePredefinedInfoWorkflowResponse(savePredefInfoResponse);


        }, error => {
            if (this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.operationCode == "REQUEST")
                this.predefWorkflowService.predefCompleteList.exceptionID = "ERROR";
            this.loading = false;
            (async () => {
                this.expiredStatus = "The service for requesting predefined information is not available at this time. Please try again later.";
            })();
        });
}

handleSavePredefinedInfoWorkflowResponse(savePredefInfoResponse: WorkflowResponse) {
    this.expiredStatus = '';

    let statusMessage: string = savePredefInfoResponse.PredefinedInformationResponse.responseStatusMessage.statusCode;
    if (JSON.stringify(savePredefInfoResponse).includes("ESB2Exception")) {
        this.systemAlertMessage = "Error happens..." + JSON.stringify(savePredefInfoResponse);
        this.loading = false;

        this.handleErrorUnsccessfullOperation(statusMessage);

    }
    else if (savePredefInfoResponse !== undefined) {
        if (statusMessage == "ESB-VIBE.STATUS.002") {
           
            let predef = JSON.parse(JSON.stringify(savePredefInfoResponse));
            let predefRequest = this.predefWorkflowService.predefCompleteList.predefinedInformationRequest;


            // console.log("Mission accomplished: " + statusMessage + " the whole response is: " + JSON.stringify(savePredefInfoResponse));

            this.predefWorkflowService.predefCompleteList.exceptionID = predef.PredefinedInformationResponse.exceptionID;
            this.predefWorkflowService.predefCompleteList.predefinedInformationRequest.exceptionID = predef.PredefinedInformationResponse.exceptionID;
            console.log("the exception id inside the handle response method is: " + this.predefWorkflowService.predefCompleteList.exceptionID);
            this.expiredSuccessful = true;
            this.expiredStatus = AppSettings.PREDEF_REQUEST_EXPIRE_MESSAGE.replace("<Company Name >",
            predefRequest.address.organizationName);;
            }
        }
        else {
            // this.loading = false;
            this.handleErrorUnsccessfullOperation(statusMessage);

        }
    }



private handleErrorUnsccessfullOperation(statusMessage: string) {    
    this.expiredStatus = AppSettings.PREDEF_REQUEST_EXPIRE_MESSAGE;    
    this.expiredSuccessful = true;
}

}
