import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { DolEtaSearchComponent } from './dol-eta-search.component';
import {ClarityModule} from '@clr/angular';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TopMenuComponent } from '../top-menu/top-menu.component';
import { TopAlertsComponent } from '../top-alerts/top-alerts.component';
import { AppRoutingModule } from '../app-routing.module';
import { VsrComponent } from '../vsr/vsr.component';
import { VsrHistoryComponent } from '../vsr/vsr-history/vsr-history.component';
import { RedReportsComponent } from '../red-reports/red-reports.component';
import { AdminComponent } from '../admin/admin.component';
import { ManualSearchModalComponent } from '../manual-resubmit/manual-search-modal.component';
import { GoogleMapsComponent } from '../google-maps/google-maps.component';
import { ScoreCardComponent } from '../score-card/score-card.component';
import { vsrCompareFormComponent } from '../vsr/vsr-compare-form/vsr-compare-form.component';
import { AgmCoreModule } from '@agm/core';
import {APP_BASE_HREF} from '@angular/common'
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { DolEtaSearchService } from '../dol-eta-search.service';
import { UserProfilesComponent } from '../user-profile/user-profile.component';
import { HelpfulLinksComponent } from '../helpful-links/helpful-links.component';
import {imports } from '../app.imports'
import {declarations} from '../app.declarations'
import { providers } from '../app.providers';
import { AppSettings } from '../shared/app-settings';

describe('DolEtaSearchComponent', () => {
  let component: DolEtaSearchComponent;
  let fixture: ComponentFixture<DolEtaSearchComponent>;
  let dolsvc: DolEtaSearchService;
  let data: any
  beforeEach(() => {

    TestBed.configureTestingModule({
      imports: imports,
      declarations: declarations,
      providers: providers,//{provide: APP_BASE_HREF, useValue: '/dol-eta-search'}
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DolEtaSearchComponent);
    component = fixture.componentInstance;
    
    fixture.detectChanges();
  });

  it('should create dol eta page', () => {
    expect(component).toBeTruthy();
  });

  it('should parse dol data', () => {
   data = require('src/assets/H30014321198839.json')
    component.parseDolData(data)
    expect(component.dolEta.DOL_ETA_CLOB);
    expect(component.dolEta.DOL_ETA_WORKSITES)
  })
});
