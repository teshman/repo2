import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { SmartSearchModel } from './shared/smart-search-model';

@Injectable({
  providedIn: 'root'
})
export class SmartSearchService {

  private messageSource = new BehaviorSubject<SmartSearchModel>(new SmartSearchModel());
  public currentMessage = this.messageSource.asObservable(); 

  constructor() { }

  changeMessage(message: SmartSearchModel){
    console.log(" changeMessage >>" + JSON.stringify(message));
    this.messageSource.next(message);
  }
}
