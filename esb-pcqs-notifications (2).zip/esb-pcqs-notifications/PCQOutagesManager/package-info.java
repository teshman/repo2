@XmlSchema(
    namespace="www.google.com",
    elementFormDefault = XmlNsForm.QUALIFIED,
    xmlns={
        @XmlNs(namespaceURI = "http://uscis.gov/uscis/xsd/services/pcq/outages", prefix = "ns0"),
        @XmlNs(namespaceURI = "http://uscis.gov/uscis/xsd/services/pcq/outages", prefix = "ns0"),
    })
package pcq.outages.manager;
import javax.xml.bind.annotation.*;