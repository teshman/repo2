package pcq.outages.manager;

import java.io.IOException;
import java.util.ArrayList;
import java.util.UUID;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/UpdateOutage")
public class UpdateOutage extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public UpdateOutage() {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(true);
		String statusMode = request.getParameter("statusMode");
		if(session.getAttribute("username") != null){
		String userName = session.getAttribute("username").toString();
		String lockedBy = AppConfig.getInstance().getPropertyByKey("FileLockedBy");		
			session.setAttribute("statusMessage", "");	
			Outage outage = new Outage();
			String outageID = request.getParameter("OutageID");
			RepeatingDuration rd = new RepeatingDuration();
			FixedDuration fd = new FixedDuration();	
			if(statusMode.equals("EDIT")){
				AppConfig.getInstance().setPropertyKeyValue("FileLockedBy", userName);
				AppConfig.getInstance().setPropertyKeyValue("FileLockedForEdit", "true");
				outage = DataHandler.getOutageById(outageID);
				}	
			else if(statusMode.equals("UPDATE")){
				saveUpdatesToFile(request, outage, outageID, rd, fd);
			}
			rd = outage.getRepeatingDuration();
			fd = outage.getFixedDuration();		

			setupSessionAttributes(outage, rd, fd, session);
			redirectPageToTarget(request, response, statusMode);
			}
		else  {
		    	session.removeAttribute("username");
				session.invalidate();
				response.sendRedirect("login.jsp");
		    }			
		}
	private void redirectPageToTarget(HttpServletRequest request, HttpServletResponse response, String statusMode)
			throws IOException, ServletException {
		if(statusMode.equals("EDIT")){	
			saveLstOutagesSession(request);
			response.sendRedirect("updateOutage.jsp");}
		if(statusMode.equals("UPDATE")){
			saveLstOutagesSession(request);
			RequestDispatcher rd1= request.getRequestDispatcher("viewOutages.jsp");
			rd1.forward(request, response);
			}
	}
	private void saveLstOutagesSession(HttpServletRequest request) {
		ArrayList<Outage> lstOutages = DataHandler.getOutagesListFromWS();
		for(Outage outage : lstOutages){
			switch(outage.getNotificationType()) {
	        case "0" :
	        	outage.setNotificationType("outage"); 
	           break;	         
	        case "1" :
	        	outage.setNotificationType("outage and notifications");
	           break;
	        case "2" :
	        	outage.setNotificationType("notifications only");	
	        	}
			}
		HttpSession updSession = request.getSession();
		updSession.removeAttribute("lstOutage");
		updSession.setAttribute("lstOutage", lstOutages);
	}
	private void setupSessionAttributes(Outage outage, RepeatingDuration rd, FixedDuration fd, HttpSession session) {
		session.setAttribute("getEnabled", outage.getEnabled());
		session.setAttribute("getIsFixedDuration", outage.getIsFixedDuration());
		session.setAttribute("FixedDuration", outage.getFixedDuration());	
		session.setAttribute("getIcon", outage.getIcon());
		session.setAttribute("getNotificationType", outage.getNotificationType());
		session.setAttribute("getOutageID", outage.getOutageID());
		session.setAttribute("getMessage", outage.getMessage());
		setupDurationSession(outage, rd, fd, session);
		session.setAttribute("getSystem", outage.getSystem());		
		session.setAttribute("getType", outage.getType());
	}
	private void setupDurationSession(Outage outage, RepeatingDuration rd, FixedDuration fd, HttpSession session) {
		if(rd!=null){
			session.setAttribute("getDays", rd.getDays());
			session.setAttribute("getEndTime", rd.getEndTime());
			session.setAttribute("getStartTime",rd.getStartTime());	
			}
		if(fd!=null){
			session.setAttribute("getEndDateTime", fd.getEndDateTime());
			session.setAttribute("getStartDateTime", fd.getStartDateTime());
			session.setAttribute("getDays", "Mon");			
		    }
	}
	private void saveUpdatesToFile(HttpServletRequest request, Outage outage, String outageID,
		RepeatingDuration rd, FixedDuration fd) {
		outage.setSystem(request.getParameter("system"));
		outage.setType(request.getParameter("typeOfOutage"));
		String message = request.getParameter("notificationMessage").replace(">", "-");
		message = message.replaceAll("&", "and ");
		outage.setMessage(message);
		outage.setNotificationType(request.getParameter("notificationType"));
		outage.setIcon(request.getParameter("icon"));
		if(request.getParameter("enabled")==null) outage.setEnabled("false");
		else outage.setEnabled("true");		
		setupOutageDuration(request, outage, rd, fd);
		outage.setAction("Updated");
		outage.setOutageID(outageID);		
		Boolean success = DataHandler.saveUpdateToFile(outage, outageID);
	}
	private void setupOutageDuration(HttpServletRequest request, Outage outage, RepeatingDuration rd,
			FixedDuration fd) {
		if(request.getParameter("durationRadio").equals("fixedDuration")){ 
			outage.setIsFixedDuration("true");
			fd.setStartDateTime(request.getParameter("startDateTime"));
			fd.setEndDateTime(request.getParameter("endDateTime"));
			outage.setFixedDuration(fd);
			outage.setRepeatingDuration(null);
			}
		else{
			rd.setStartTime(request.getParameter("startTime"));
			rd.setEndTime(request.getParameter("endTime"));
			rd.setDays(request.getParameter("days"));			
			fd.setStartDateTime(null);
			fd.setEndDateTime(null);
			outage.setFixedDuration(fd);
			outage.setRepeatingDuration(rd);
			outage.setIsFixedDuration("false");
		}
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
