package pcq.outages.manager;

import java.io.IOException;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class AddOutage
 */
@WebServlet("/AddOutage")
public class AddOutage extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddOutage() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		if (request.getParameter("Logout") != null) {
	    	session.removeAttribute("uname");
			session.invalidate();
			response.sendRedirect("login.jsp");
	    }
		else{
		Outage outage = new Outage();
		RepeatingDuration rd = new RepeatingDuration();
		FixedDuration fd = new FixedDuration();
		
		String outageID = (UUID.randomUUID().toString()).substring(0,8);
		outage.setSystem(request.getParameter("system"));
		outage.setType(request.getParameter("typeOfOutage"));
		outage.setMessage(request.getParameter("notificationMessage"));
		outage.setNotificationType(request.getParameter("notificationType"));
		outage.setIcon(request.getParameter("icon"));
		if(request.getParameter("enabled")=="on")
			outage.setEnabled("true");
		else
			outage.setEnabled("false");
		if(request.getParameter("durationRadio").equals("fixedDuration")){ 
			outage.setIsFixedDuration("true");
			fd.setStartDateTime(request.getParameter("startDateTime") +":00");
			fd.setEndDateTime(request.getParameter("endDateTime")+":00");
			System.out.println("request.getParameter(endDateTime)+:00 is: " + fd.getEndDateTime());
			outage.setFixedDuration(fd);}
		else
		{
			rd.setStartTime(request.getParameter("startTime"));
			rd.setEndTime(request.getParameter("endTime"));
			rd.setDays(request.getParameter("days"));
			outage.setRepeatingDuration(rd);
			outage.setIsFixedDuration("false");
		}
		outage.setAction("New");
		outage.setOutageID(outageID);
		Boolean success = DataHandler.addOutageToFile(outage);
		request.getSession().invalidate();
		response.sendRedirect("addOutage.jsp");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
