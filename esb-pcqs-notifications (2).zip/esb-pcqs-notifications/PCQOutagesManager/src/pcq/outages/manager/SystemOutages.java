package pcq.outages.manager;

import javax.xml.bind.*;
import java.util.List;
import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement
public class SystemOutages implements java.io.Serializable {
	private static final long serialVersionUID = 1L;
private List<Outage> listOutage;
public SystemOutages(){}
public List<Outage> getOutage(){
	return listOutage;
}
 public void setOutage(List<Outage> outage) {
	 listOutage = outage;
 }
}

