package pcq.outages.manager;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/ViewOutages")
public class ViewOutages extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public ViewOutages() {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		if (session.getAttribute("username") == null) {
			session.invalidate();
			response.sendRedirect("login.jsp");
			} 
		else {
			String filterBy = "";
			ArrayList<Outage> lstOutages = DataHandler.getOutagesListFromWS();
			for(Outage outage : lstOutages){
				switch(outage.getNotificationType()) {
		        case "0" :
		        	outage.setNotificationType("outage"); 
		           break;	         
		        case "1" :
		        	outage.setNotificationType("outage and notifications");
		           break;
		        case "2" :
		        	outage.setNotificationType("notifications only");
		        	}
				}
			if(request.getParameter("viewType") != null) filterBy = (String) request.getParameter("viewType");
			final String filterBy2 = filterBy;
			ArrayList<Outage> newOutages = filterByViewType(lstOutages, filterBy2);			
			session.removeAttribute("lstOutage");
			if(filterBy!="")
				session.setAttribute("lstOutage", newOutages);
			else
				session.setAttribute("lstOutage", lstOutages);
			RequestDispatcher rd= request.getRequestDispatcher("viewOutages.jsp");
			rd.forward(request, response);
			}
		}
	private ArrayList<Outage> filterByViewType(ArrayList<Outage> lstOutages, final String filterBy2) {
		ArrayList<Outage> newOutages  = new ArrayList<Outage>();
		switch(filterBy2) {
        case "Active" :
        	newOutages = (ArrayList<Outage>) lstOutages.stream()        	
		    .filter(p -> p.getEnabled().equals("true")).collect(Collectors.toList());
           break;	         
        case "Expired" :
        	for(Outage outage : lstOutages){                             
                    try {
						if(outage.getIsFixedDuration().equals("true")){
							String endDateTime = outage.getFixedDuration().getEndDateTime();
							Date EndDateTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(endDateTime.replace("T", " "));
							if(EndDateTime.before(new Date())) newOutages.add(outage);
						}
					} catch (ParseException e) {
						e.printStackTrace();
					} 
                }           
           break;
        default:
        	newOutages = (ArrayList<Outage>) lstOutages.stream()
		    .filter(p -> p.getAction().equals(filterBy2)).collect(Collectors.toList());
        	}	
		
		return newOutages;
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {		
		doGet(request, response);
	}

}
