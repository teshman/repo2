package pcq.outages.manager;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Properties;
import java.util.Set;
 
public class AppConfig
{	
   private final Properties configProp = new Properties();
   private static AppConfig instance = null;   
   protected AppConfig()
   {
      try {
    	  
    	  InputStream input = new FileInputStream("src/App.Config");                      
          configProp.load(input);
      } catch (IOException e) {
          e.printStackTrace();
      }
   }  
   public static AppConfig getInstance()
   {
	   if(instance == null) {
	         instance = new AppConfig();
	      }
	      return instance;
   }
   public void setPropertyKeyValue(String key, String value){
	   configProp.setProperty(key, value);
	 }
   public String getPropertyByKey(String key){
      return configProp.getProperty(key);
   }    
   public Set<String> getAllPropertyNames(){
      return configProp.stringPropertyNames();
   }
   public void StoreToFile(){
	   OutputStream output = null;
	   try {
		   output = new FileOutputStream("App.Config");
		   } catch (FileNotFoundException e) {
			   e.printStackTrace();
			   }
	   try {
		   configProp.store(output, null);
		   } catch (IOException e) {
			   e.printStackTrace();
			   }
	   } 
   public boolean containsKey(String key){
      return configProp.containsKey(key);
   }
}