package pcq.outages.manager;
import javax.xml.bind.*;
import javax.xml.bind.annotation.XmlType;

@XmlType(propOrder = {"startTime","endTime", "days"})
public class RepeatingDuration {
	public RepeatingDuration (){}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	public String getDays() {
		return days;
	}
	public void setDays(String days) {
		this.days = days;
	}
	private String startTime;
	private String endTime;
	private String days;
}
