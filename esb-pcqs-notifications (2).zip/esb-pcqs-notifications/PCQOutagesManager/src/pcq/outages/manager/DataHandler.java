package pcq.outages.manager;

import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.*;
import org.xml.sax.InputSource;

public class DataHandler {
	public DataHandler(){}
	public static String nameSpace = "<ns0:systemOutages xmlns:ns0=\"http://uscis.gov/uscis/xsd/services/pcq/outages\">";
	
	public static  ArrayList<Outage> getOutagesListFromWS() {
		ArrayList<Outage> outageList = new ArrayList<Outage>();
		StringBuilder sb = new StringBuilder();
		 String inputLine = "";
		 try {
				String urlString = AppConfig.getInstance().getPropertyByKey("NotificationServiceInputURL") ;
				try {
					AppConfig cache = AppConfig.getInstance();	
					URL url = new URL(urlString);
					System.out.println("input urlString: " + urlString);
					BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));
					while ((inputLine = in.readLine()) != null)
					{ 
						sb.append(inputLine);
					}
					in.close();
				} catch (MalformedURLException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}
				String theXML = sb.toString().replace(
						"xmlversion", "xml version").replace(
								"encoding=", " encoding=").replace("standalone=", " standalone=").replace("ns0:", "").replaceAll("&(?!amp;)", "&amp;").replaceAll("\t", "");
				Document doc = loadXMLFromString(theXML);
				doc.getDocumentElement().normalize();
				NodeList nList = doc.getElementsByTagName("outage");
				convertNodeListToOutages(outageList, nList);
				}
			     catch (Exception e) {
				e.printStackTrace();
			    }
		 if (outageList.size() > 0) {
			  Collections.sort(outageList, new Comparator<Outage>() {
				  @Override
				  public int compare(final Outage object1, final Outage object2) {
			          return object1.getSystem().compareTo(object2.getSystem());
			          }
			      }
			  );
			  }
		 return outageList;
		 }
	private static void convertNodeListToOutages(ArrayList<Outage> outageList, NodeList nList){
		for (int temp = 0; temp < nList.getLength(); temp++){
		 	Outage outage = new Outage();
			Node nNode = nList.item(temp);
			if (nNode.getNodeType() == Node.ELEMENT_NODE){	
				Element eElement = (Element) nNode;
				outage.setSystem(eElement.getElementsByTagName("system").item(0).getTextContent());
				outage.setType(eElement.getElementsByTagName("type").item(0).getTextContent());
				outage.setMessage(eElement.getElementsByTagName("message").item(0).getTextContent().trim());
				outage.setEnabled(eElement.getElementsByTagName("enabled").item(0).getTextContent());
				outage.setAction(eElement.getElementsByTagName("action").item(0).getTextContent());
				outage.setOutageID(eElement.getElementsByTagName("outageID").item(0).getTextContent());
				outage.setNotificationType(eElement.getElementsByTagName("notificationType").item(0).getTextContent());							
				outage.setIcon(eElement.getElementsByTagName("icon").item(0).getTextContent());	
				parseDurationInfo(eElement,outage );
				}
			outageList.add(outage);				
			}
		}
	public static Document loadXMLFromString(String xml) throws Exception
	{
		xml = xml.replace(
				"xmlversion", "xml version").replace(
						"encoding=", " encoding=").replace("standalone=", " standalone=");
	    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
	    DocumentBuilder builder = factory.newDocumentBuilder();
	    InputSource is = new InputSource(new StringReader(xml));
	    return builder.parse(is);
	}	
	public static  ArrayList<Outage> getOutagesListFromXMLFile() {
		ArrayList<Outage> outageList = new ArrayList<Outage>();		
		 try {
			 File fXmlFile = new File(AppConfig.getInstance().getPropertyByKey("UnavailableSystemsFile")) ;
			 DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			 DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			 Document doc = dBuilder.parse(fXmlFile);
			 doc.getDocumentElement().normalize();
			 NodeList nList = doc.getElementsByTagName("outage");
			 convertNodeListToOutages(outageList, nList);
			 }
		 catch (Exception e) {
			 e.printStackTrace();
			 }
		 return outageList;
		 }	
	private static void parseDurationInfo(Element eElement, Outage duration){
		if (eElement.hasChildNodes()){
			NodeList outageChildNodes = eElement.getChildNodes();
			// Loop through all the nodes and find the duration node only
			for (int i = 0; i < outageChildNodes.getLength(); i++){
				Node child = outageChildNodes.item(i);
				if(child.getNodeName().equals("repeatingDuration")){
				parseRepeatingDurationInfo(eElement, duration);
				}
				else if(child.getNodeName().equals("fixedDuration")){
					parseFixedDurationInfo(eElement, duration);
					}
				}
			}
		}
	private static void parseFixedDurationInfo(Element eElement, Outage outage) {
		String fixedDuration = (eElement.getElementsByTagName("fixedDuration").item(0).getTextContent().trim());
		FixedDuration fd = new FixedDuration();
		if (fixedDuration.length()>0){
			fd.setStartDateTime((fixedDuration.substring(0,(fixedDuration.length()/2)).trim()));
			fd.setEndDateTime((fixedDuration.substring((fixedDuration.length()/2))).trim());
		}		
		outage.setFixedDuration(fd);
		outage.setNotificationType(eElement.getElementsByTagName("notificationType").item(0).getTextContent().trim());
		outage.setIcon(eElement.getElementsByTagName("icon").item(0).getTextContent().trim());
		outage.setIsFixedDuration("true");
		outage.setOutageID(eElement.getElementsByTagName("outageID").item(0).getTextContent().trim());
	}
	private static void parseRepeatingDurationInfo(Element eElement,Outage outage ) {
		String repeatingInfo[] = (eElement.getElementsByTagName("repeatingDuration").item(0).getTextContent().trim()).split("\\s+");;
		RepeatingDuration rd = new RepeatingDuration();
		rd.setStartTime(repeatingInfo[0].trim());
		rd.setEndTime(repeatingInfo[1].trim());
		rd.setDays(repeatingInfo[2].trim());	
		outage.setRepeatingDuration(rd);
		outage.setIsFixedDuration("false");
		outage.setNotificationType(eElement.getElementsByTagName("notificationType").item(0).getTextContent().trim());
		outage.setIcon(eElement.getElementsByTagName("icon").item(0).getTextContent().trim());
		}
	public static String getXMLstring(Outage outage) {
	    String xmlString = "";
	    try {
	        JAXBContext context = JAXBContext.newInstance(Outage.class);
	        Marshaller m = context.createMarshaller();
	        m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE); 
	        StringWriter sw = new StringWriter();
	        m.marshal(outage, sw);
	        xmlString = sw.toString().replaceAll("&(?!amp;)", "&amp;");
	        } 
	    catch (JAXBException e) {
	    	e.printStackTrace();
	    	}
	    return xmlString;
	}
	public static String getXMLstring(SystemOutages systemOutages) {
	    String xmlString = "";
	    try {
	        JAXBContext context = JAXBContext.newInstance(SystemOutages.class);
	        Marshaller m = context.createMarshaller();
	        m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
	        StringWriter sw = new StringWriter();
	        m.marshal(systemOutages, sw);
	        xmlString = sw.toString().replaceAll("&(?!amp;)", "&amp;");
	    } catch (JAXBException e) {
	        e.printStackTrace();
	    }
	    return xmlString;
	}
	public static Boolean saveOutagesToDisk(ArrayList<Outage> outageList){
		SystemOutages systemOutages = new SystemOutages();
		systemOutages.setOutage(outageList);
		String xmlString = getFormattedString(systemOutages);
		try {
			File file = new File(AppConfig.getInstance().getPropertyByKey("UnavailableSystemsFile"));
			FileWriter fileWriter = new FileWriter(file);
			fileWriter.write(xmlString);
			fileWriter.flush();
			fileWriter.close();
			} 
		catch (IOException e){
			e.printStackTrace();
			}
		return true;
		}
	public static Boolean saveOutagesViaWS(ArrayList<Outage> outageList){
		SystemOutages systemOutages = new SystemOutages();
		systemOutages.setOutage(outageList);
		String xmlString = getFormattedString(systemOutages);			
		System.out.println("xmlString is: " + xmlString);
		String inputLine = "";
		String urlString = AppConfig.getInstance().getPropertyByKey("NotificationServiceOutputURL")+xmlString;
		try {
			URL url = new URL(urlString);
			System.out.println("urlString is: " + urlString);
			BufferedReader in = new BufferedReader(
			            new InputStreamReader(
			            url.openStream()));
			while ((inputLine = in.readLine()) != null)
			in.close();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return true;
		}
	private static String getFormattedString(SystemOutages systemOutages) {
		String xmlString = getXMLstring(systemOutages).replaceAll(
				"<", "<ns0:").replaceAll(
						"<ns0:systemOutages>", nameSpace).replaceAll(
						"<ns0:/", "</ns0:").replaceAll(
								"ns0:\\?xml", "?xml").replaceAll(
										">", "%3E").replaceAll(
												"<", "%3C").replace(
														"\n", "").replace(
																"\r", "").replaceAll(" ", "%20").replaceAll("&(?!amp;)", "&amp;");
		return xmlString;
	}	
	public static Boolean saveUpdateToFile(Outage updatedOutage, String outageID){
		ArrayList<Outage> systemOutages = getOutagesListFromWS();
		List<Outage> found = new ArrayList<Outage>();
		for(Outage outage : systemOutages){
		    if(outage.getOutageID().equals(outageID) ){
		        systemOutages.remove(outage);
		        systemOutages.add(updatedOutage);
		        break;
		    }
		}		
		return saveOutagesViaWS(systemOutages);		
	}
	public static Boolean addOutageToFile(Outage outage){
		ArrayList<Outage> outageList = new ArrayList<Outage>();
		outageList = getOutagesListFromWS();
		outageList.add(outage);		
		return saveOutagesViaWS(outageList);		
	}
	public static Boolean deleteOutageById(String outageID){
		ArrayList<Outage> systemOutages = getOutagesListFromWS();
		for(Outage outage : systemOutages){
		    if(outage.getOutageID().equals(outageID) ){
		    	systemOutages.remove(outage);
		    	break;
		    }
		}		
		return saveOutagesViaWS(systemOutages);		
	}
	private static void cloneOutage(Outage outage, Outage foundOutage){		
		foundOutage.setSystem(outage.getSystem());
		foundOutage.setType(outage.getType());
		foundOutage.setMessage(outage.getMessage());
		foundOutage.setOutageID(outage.getOutageID());
		foundOutage.setEnabled(outage.getEnabled());
		foundOutage.setRepeatingDuration(outage.getRepeatingDuration());
		foundOutage.setFixedDuration(outage.getFixedDuration());		
		foundOutage.setIsFixedDuration(outage.getIsFixedDuration());
		foundOutage.setIcon(outage.getIcon());
		foundOutage.setNotificationType(outage.getNotificationType());
		foundOutage.setMessage(outage.getMessage());
	}
	public static Outage getOutageById(String outageID){		   
		ArrayList<Outage> systemOutages = getOutagesListFromWS();
		Outage foundOutage = new Outage();
		for(Outage outage : systemOutages){			 
		    if(outage.getOutageID().equals(outageID) ){
		    	cloneOutage(outage, foundOutage);	
		    	  break;
		    	  }
		}
		return foundOutage;
	}	
	private File[]  SortFiles(File dir){
		File[] files = dir.listFiles();

		Arrays.sort(files, new Comparator<File>(){
		    public int compare(File f1, File f2)
		    {
		        return Long.valueOf(f1.lastModified()).compareTo(f2.lastModified());
		    } });
		return files;
	}
}
