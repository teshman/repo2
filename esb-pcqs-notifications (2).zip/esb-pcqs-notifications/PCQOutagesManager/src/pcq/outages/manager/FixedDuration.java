package pcq.outages.manager;
import javax.xml.bind.*;
import javax.xml.bind.annotation.XmlType;

@XmlType(propOrder = {"startDateTime","endDateTime"})
public class FixedDuration {
	private String startDateTime;
	private String endDateTime;

	public FixedDuration() {
	}

	public String getEndDateTime() {
		return endDateTime;
	}

	public void setEndDateTime(String endDateTime) {
		this.endDateTime = endDateTime;
	}

	public String getStartDateTime() {
		return startDateTime;
	}

	public void setStartDateTime(String startDateTime) {
		this.startDateTime = startDateTime;
	}

}
