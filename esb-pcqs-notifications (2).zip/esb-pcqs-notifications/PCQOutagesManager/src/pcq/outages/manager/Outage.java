  

package pcq.outages.manager;

import javax.xml.bind.*;
import javax.xml.bind.annotation.XmlType;

@XmlType(propOrder = {"system","type","message","isFixedDuration","fixedDuration","repeatingDuration",
		"notificationType","icon","enabled","action","outageID"})
public class Outage {
	private static final long serialVersionUID = -6809299553130452029L;
	private String system;
	private String type;
	private String message;
	private String isFixedDuration;
	private FixedDuration fixedDuration;
	private RepeatingDuration repeatingDuration;	
	private String notificationType;
	private String icon;
	private String enabled;
	private String action;
	private String outageID;	
	public String getSystem() {
		return system;
	}
	public void setSystem(String system) {
		this.system = system;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getIsFixedDuration() {
		return isFixedDuration;
	}
	public void setIsFixedDuration(String isFixedDuration) {
		this.isFixedDuration = isFixedDuration;
	}	
	public String getNotificationType() {
		return notificationType;
	}
	public void setNotificationType(String notificationType) {
		this.notificationType = notificationType;
	}
	public String getIcon() {
		return icon;
	}
	public void setIcon(String icon) {
		this.icon = icon;
	}
	public String getEnabled() {
		return enabled;
	}
	public void setEnabled(String enabled) {
		this.enabled = enabled;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getOutageID() {
		return outageID;
	}
	public void setOutageID(String outageID) {
		this.outageID = outageID;
	}	
	public RepeatingDuration getRepeatingDuration() {
		return repeatingDuration;
	}
	public void setRepeatingDuration(RepeatingDuration repeatingDuration) {
		this.repeatingDuration = repeatingDuration;
	}
	public FixedDuration getFixedDuration() {
		return fixedDuration;
	}
	public void setFixedDuration(FixedDuration fixedDuration) {
		this.fixedDuration = fixedDuration;
	}
}
